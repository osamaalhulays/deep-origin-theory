# نظرية الأصل العميق / الحزم النهائية العربية

هذا الجناح يحتوي الحزم العربية النهائية المعتمدة المواجهة للعرض الخارجي داخل **نظرية الأصل العميق**.

إذا كنت جديدًا على المشروع، فابدأ أولًا من:

- `START_HERE_FIRST.md`

الحزم المدرجة:

- `Keystone_I_The_First_Bearing_20260429`
- `Keystone_II_Source_Governed_Framework_20260520`
- `DEEP_ORIGIN_PUBLIC_CORE_20260528`
- `FIRSTLIGHT_PUBLIC_FACE_20260528`
- `AUTHOR_AND_THEORY_FRONTMATTER_20260527`

فهرس ظهور المصادر وطبقة الحوكمة:

- `SOURCE_LAYER_INDEX.md`

ترتيب القراءة المقترح:

1. `START_HERE_FIRST.md`
2. `Keystone_I_The_First_Bearing_20260429`
3. `Keystone_II_Source_Governed_Framework_20260520`
4. `DEEP_ORIGIN_PUBLIC_CORE_20260528`
5. `FIRSTLIGHT_PUBLIC_FACE_20260528`
6. `AUTHOR_AND_THEORY_FRONTMATTER_20260527`
7. `SOURCE_LAYER_INDEX.md`
