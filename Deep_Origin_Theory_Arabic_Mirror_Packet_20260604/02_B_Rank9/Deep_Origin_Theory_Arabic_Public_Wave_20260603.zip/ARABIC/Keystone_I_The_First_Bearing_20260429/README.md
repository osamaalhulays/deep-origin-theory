# نظرية الأصل العميق / حزمة المرتكز الأول العربية

هذه الحزمة هي المدخل التقني العربي العام لورقة **المرتكز الأول: الحمل الأول**
داخل **نظرية الأصل العميق**.

إذا كنت جديدًا على هذه الحزمة، فابدأ من:

- `START_HERE_FIRST.md`

## ما هذه الحزمة؟

**المرتكز الأول** يقدّم نتيجة منضبطة:

- طبقة **توحيد استجابي** قابلة للمراجعة،
- مع إبقاء الكونيات مغلقة صراحة،
- ومع إظهار الشروط القاتلة بدل إخفائها.

ينبغي أن تُقرأ هذه الحزمة على أنها **ورقة تقنية ما قبل-كونية**، لا على أنها نتيجة كونيات مكتملة.

وما أُغلق قبل رتبة 10 مُلخَّص هنا:

- `WHAT_HAS_ALREADY_BEEN_ACHIEVED_THROUGH_RANK9.md`
- `RANK9_CLOSURE_AND_RANK10_BOUNDARY_NOTE.md`

## ما الذي لا تدّعيه؟

هذه الحزمة لا تدّعي:

- نموذجًا كونيًا مكتملًا،
- تحققًا رصديًا،
- توافق Pantheon+,
- إغلاق BAO/CMB,
- حكمًا رصديًا نهائيًا،
- أو نتيجة نهائية للتوحيد.

## لماذا قد تكون مهمة؟

قيمتها المقصودة أضيق من ذلك لكنها جادة:

- تحاول إظهار معمار استجابي مشترك منضبط،
- وتقوم على مسار مشترك الأصل ومواءمة صريحة للأساس الاختباري وغرسٍ تام
  وتكاملٍ خلوي موقّع، لا على تشابه وصفي فضفاض،
- تعلن دعواها ضمن حد ادعاء مضبوط،
- وتصرّح بما يقتلها.

## تنبيه للقارئ الجديد

بعض السجلات تحتفظ بصياغات داخلية مؤرشفة.
أما القراءة العلنية المفضلة لهذه الحزمة فتستخدم:

- `القطاع محدود الحجم`
- `القطاع المحلي داخل العنقود`
- `النتيجة الجسرية المنضبطة`
- `إطار مشترك الأصل`
- `حد الادعاء`

وهذه هي الصياغات التي ينبغي أن تقود القراءة العامة.
أما الاختزالات الأقدم فتعامل على أنها بقايا تسمية داخلية فقط.

الموقف العام:

- `نظرية الأصل العميق / المرتكز الأول: توحيد استجابي ذو صلاحية جسرية مع إبقاء الكونيات مغلقة.`

ترتيب القراءة داخل الحزمة:

1. `START_HERE_FIRST.md`
2. `WHAT_HAS_ALREADY_BEEN_ACHIEVED_THROUGH_RANK9.md`
3. `CURRENT_STAGE_AND_PREDICTION_STATUS.md`
4. `RANK9_CLOSURE_AND_RANK10_BOUNDARY_NOTE.md`
5. `PHYSICAL_INTERPRETATION_NOTE.md`
6. `RESPONSE_OBJECT_PROVENANCE_NOTE.md`
7. `COMMON_BASIS_VECTOR_DERIVATION_NOTE.md`
8. `NUMERIC_REPRODUCTION_ROUTE_NOTE.md`
9. `PARENT_OPERATOR_MEANING_NOTE.md`
10. `CLUSTER_LOCAL_OBJECT_STATUS_NOTE.md`
11. `XI_DIAGNOSTIC_INTERPRETATION_NOTE.md`
12. `XI_SUCCESS_CRITERION_NOTE.md`
13. `PARENT_LAW_STATUS_NOTE.md`
14. `LITERATURE_POSITIONING_NOTE.md`
15. `LITERATURE_COMPARISON_NOTE.md`
16. `ABSTRACT.md`
17. `MANUSCRIPT.md`
18. `PUBLIC_WITNESS_CARD.md`
19. `PUBLIC_EVIDENCE_APPENDIX.md`
20. `CLAIM_BOUNDARY_CARD.md`
21. `SOURCE_LAYER.md`

ظهور المصادر:

- `SOURCE_LAYER.md`
