# Author Brand Positioning

## 1. Positioning Sentence

**A theoretical physicist developing disciplined routes from deep physical structure to cosmological law.**

## 2. Who The Author Is

المؤلف ليس:

- مروّجًا لنظرية كبرى غير منضبطة
- ولا iconoclast يهاجم السائد لمجرد الهجوم
- ولا بائع إجابات نهائية

المؤلف هو:

- باحث نظري
- يبني برامج غير اعتيادية
- لكن تحت سقوف قاسية
- ويعامل الحدود واللاادعاءات كجزء من النتيجة نفسها

## 3. What The Author Offers

الخدمة الأساسية ليست "قصة عميقة" فقط.

الخدمة هي:

**محاولة اشتقاق قوانين أو جسور كونية من بنية أعمق، من دون إنقاذ الادعاءات بترقيع ملائمات لاحقة.**

## 4. What Makes The Author Distinct

### المنهج

- derived before fitted
- source-governed before consumer-shaped
- explicit ceilings before rhetorical inflation

### السلوك العلمي

- لا يبيع أكثر مما لديه
- لا يخلط ما ثبت بما لم يثبت
- يبني audit trail بدل ترك claims معلقة
- يحافظ على kill logic واضحة

### الأثر الظاهر

النتيجة التي يجب أن يخرج بها القارئ ليست:

"هذا شخص يدّعي أشياء ضخمة"

بل:

"هذا شخص يعمل على أسئلة كبيرة، لكنه منضبط على نحو غير مألوف."

## 5. Target Audiences

### الدائرة الأولى

- theoretical physicists
- cosmologists
- mathematically severe readers

### الدائرة الثانية

- interdisciplinary researchers in foundations
- scientifically literate outsiders who value rigor over hype

## 6. Audience Impression Goal

نريد 4 انطباعات فقط:

1. unusual
2. serious
3. bounded
4. worth tracking

## 7. What The Brand Must Never Sound Like

- prophet
- guru
- anti-establishment performance
- final-answer salesman
- mystical origin storyteller

## 8. Author Archetype

أفضل archetype هنا:

**The disciplined frontier theorist**

لا:

- rebel-genius
- lone visionary
- system-breaker

## 9. Core Promise

> I work on large physical questions under hard ceilings: derive before fitting, and claim less publicly than ambition would tempt me to claim.

## 10. Public English Positioning Block

> The author is a theoretical physicist working on disciplined programs that connect deep physical structure to cosmological law. The distinctive feature of this work is not scale alone, but discipline: explicit ceilings, clear non-claims, reproducible artifacts, and a preference for laws that are derived before they are fitted.

## 11. Public Arabic Positioning Block

> المؤلف باحث في الفيزياء النظرية يعمل على برامج منضبطة تربط البنية الفيزيائية العميقة بالقانون الكوني. ما يميز هذا المسار ليس حجم الأسئلة فقط، بل الانضباط: سقوف صريحة، ولاادعاءات واضحة، ومخرجات قابلة للتدقيق، وتفضيل للقوانين التي تُشتق قبل أن تُلائم.
