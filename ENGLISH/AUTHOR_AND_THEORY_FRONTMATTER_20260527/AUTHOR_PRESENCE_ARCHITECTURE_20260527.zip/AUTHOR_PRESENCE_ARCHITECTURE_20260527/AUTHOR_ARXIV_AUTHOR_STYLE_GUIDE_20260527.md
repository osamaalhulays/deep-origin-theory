# arXiv Author Style Guide

## Role of arXiv

arXiv لا تبني البراند عبر profile narrative.
هي تبنيها عبر:

- title discipline
- abstract discipline
- author-line consistency

## Title Rules

- problem-first
- result-first
- no inflated grand nouns
- no “Theory of Everything” language
- no internal rank language

## Abstract Rules

كل abstract يجب أن تحتوي:

1. ما الشيء الذي تم بناؤه أو إثباته؟
2. تحت أي سقف؟
3. ما الذي لا تدعيه الورقة؟
4. لماذا النتيجة غير تافهة؟

## Author Voice

Use:

- precise
- bounded
- reviewable
- non-defensive

Avoid:

- “finally”
- “ultimate”
- “complete”
- “revolutionary”
- “solves all”

## Non-Claim Discipline

For this program, arXiv abstracts should often state explicitly when absent:

- no cosmology completion
- no final TOE claim
- no predictive H(z) law if not present
- no Pantheon+/BAO/CMB closure if not present

## Reusable arXiv Signature Sentence

> We present a bounded, source-governed result with explicit non-claims, rather than a totalizing completion claim.

## Practical Rule

If a sentence sounds larger than the evidence, cut it.
