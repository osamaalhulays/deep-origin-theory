# Author Master Source Text

هذا هو **النص الأم** لحضور المؤلف.

وظيفته:

- تثبيت الجملة الحاكمة
- تثبيت الوعد العام
- تثبيت الحدود
- وتوفير مادة خام تشتق منها bios والملفات والمنصات

## 1. Core English Signature

> A theoretical physicist developing disciplined routes from deep physical structure to cosmological law.

## 2. Core Arabic Signature

> باحث في الفيزياء النظرية يطوّر مسارات منضبطة من البنية الفيزيائية العميقة إلى القانون الكوني.

## 3. Core Promise

### English

> The aim is not to enlarge claims quickly, but to derive lawful physical structure before data fitting, and to state openly what has and has not been achieved.

### Arabic

> الغاية ليست تكبير الادعاءات بسرعة، بل اشتقاق بنى وقوانين فيزيائية قبل ملاءمتها بالبيانات، مع التصريح الواضح بما أُنجز وما لم يُنجز بعد.

## 4. Method Fingerprint

- source-first
- derived before fitted
- explicit ceilings
- explicit non-claims
- reproducible artifacts
- kill logic preserved
- no rescue by post-hoc patching

## 5. Public Research Territory

- response unification
- deep-origin theoretical programs
- source-to-cosmology pathways
- controlled observable interfaces
- pre-fit cosmological law construction

## 6. Strongest Currently Defensible Public Result

> A bridge-admitted response-unification result under an explicit no-cosmology-completion ceiling.

## 7. Public Non-Claims

Do not claim:

- final cosmology
- solved quantum gravity
- complete deep-origin closure
- observational closure already achieved
- theory of everything
- predictive H(z) completion if not explicitly materialized

## 8. Reusable Public Lines

- `Derived before fitted.`
- `Hard ceilings, not soft promises.`
- `Deep structure, disciplined claims.`
- `From deep structure to cosmological law, under explicit limits.`
- `Large questions, bounded claims.`

## 9. Word Preference

Prefer:

- disciplined
- bounded
- source-governed
- derived
- auditable
- controlled
- explicit limits

Avoid:

- ultimate
- final
- revolutionary
- complete
- solves everything
- paradigm-ending

## 10. Master English Paragraph

> The author works on theoretical physics programs that connect deep physical structure to cosmological law under unusually strict claim discipline. The distinctive feature of this work is methodological rather than rhetorical: explicit ceilings, clear non-claims, reproducible artifacts, and a preference for laws that are derived before they are fitted. Current work spans response unification, deep-origin programs, and disciplined pathways from formal structure to observable cosmology.

## 11. Master Arabic Paragraph

> يعمل المؤلف على برامج في الفيزياء النظرية تربط البنية الفيزيائية العميقة بالقانون الكوني تحت انضباط ادعائي غير مألوف في شدته. ما يميز هذا المسار ليس البلاغة، بل المنهج: سقوف صريحة، ولاادعاءات واضحة، ومخرجات قابلة للتدقيق، وتفضيل للقوانين التي تُشتق قبل أن تُلائم. يشمل العمل الحالي التوحيد الاستجابي، وبرامج الأصل العميق، ومسارات منضبطة من البنية الصورية إلى الكونيات القابلة للرصد.
