# Personal Site Copy

## Role of the Site

الموقع الشخصي هو المركز السردي الأول.

هو ليس CV جامدة.
هو المكان الذي يشرح:

- من هو المؤلف
- ما منهجه
- ما البرنامج الكبير
- ما هي القطع الحالية

## Homepage Hero

### Headline

> Theoretical physics under hard ceilings

### Subheadline

> Disciplined programs from deep structure to cosmological law, built with explicit limits, reproducible artifacts, and laws that are derived before they are fitted.

## About Section

> I work on theoretical physics programs that begin from deep structural questions but are judged by strict outward discipline. My interest is not in producing large claims quickly, but in building disciplined constructions that remain auditable, bounded, and physically meaningful. Current lines of work include response unification, deep-origin theoretical programs, and controlled pathways from formal structure to observable cosmology.

## Method Section

Title:

`Method before mythology`

Copy:

> The method is simple to state and difficult to sustain: define the object, state the ceiling, specify what is not claimed, preserve a kill logic, and avoid rescuing the result through post-hoc fit machinery. If a law is worth keeping, it should survive under explicit limits.

## Research Program Section

Suggested buckets:

- Response Unification
- White-Law / Source-Governed Structure
- Deep-Origin Programs
- Cosmology Interfaces

## Selected Work Framing

For each featured paper/project, show:

- one-line claim
- one-line limit
- link to paper
- link to artifacts if public

## Homepage Rules

- no giant promise
- no TOE banner
- no “revolutionary breakthrough” voice
- no overload of internal terms

## Site Footer Signature

> Derived before fitted. Bounded before amplified.
