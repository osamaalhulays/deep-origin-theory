# GitHub Profile Copy

## Role of GitHub

GitHub هنا ليست مجرد code host.
هي واجهة:

- discipline
- reproducibility
- visible structure
- open artifacts

## Profile Bio

Use a short public bio such as:

> Theoretical physics | hard ceilings | response unification | derived-before-fitted cosmology

## Profile README Structure

### Opening

> I work on theoretical physics programs with explicit claim ceilings, reproducible artifacts, and controlled pathways from formal structure to observable cosmology.

### What this profile emphasizes

- bounded claims
- auditable artifacts
- paper-linked outputs
- public bundles where lawful

### Current public fronts

- response-unification publication line
- white-law publication line
- publication strategy / public bundles

### What this profile does not do

- sell a final TOE claim
- treat internal stage labels as peer review
- inflate cosmology completion before it exists

## Pinned Repository Logic

Pin only:

1. public publication bundle
2. reproducibility-friendly repo or repo mirror
3. profile or site repo
4. one clean strategy/publication repo if useful

Do not pin:

- noisy internal development trunks
- unfinished trench repos
- confusing experimental leftovers

## GitHub Tone

- clean
- minimal
- high-signal
- no badge clutter
- no vanity stats
