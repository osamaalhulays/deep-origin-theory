# ORCID Profile Copy

## Goal

ORCID هي الهوية الرسمية المحمولة.

يجب أن تكون:

- قصيرة
- نظيفة
- discoverable
- غير متضخمة

## Suggested Biography

> The author works on theoretical physics focused on response unification, deep physical structure, and controlled cosmological law construction. The work emphasizes explicit claim ceilings, reproducible artifacts, and laws that are derived before they are fitted.

## Suggested Keywords

- theoretical physics
- cosmology
- deep physical structure
- response unification
- source-governed theory
- spacetime foundations
- pre-fit cosmological law

## Suggested Researcher URLs

Add, in this order:

1. personal site
2. GitHub profile
3. INSPIRE author profile
4. arXiv author/search page if useful

## Visibility Policy

- biography: public
- keywords: public
- websites: public
- works: public whenever lawful

## What Not To Put In ORCID

- manifesto language
- TOE claims
- internal ladder language
- speculative future claims

## ORCID One-Line Version

> Theoretical physics across response unification, deep structure, and cosmological law.
