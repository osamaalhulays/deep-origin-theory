# Platform Map

## الحكم

براند المؤلف لا تُبنى في كل منصة بالطريقة نفسها.

هناك ثلاث طبقات:

1. هوية
2. إخراج أعمال
3. اكتشاف وفهرسة

## A. Identity Platforms

### 1. Personal Site

هذا هو **المركز الحقيقي للبراند**.

وظيفته:

- السرد الرئيسي
- تعريف المنهج
- تعريف البرنامج
- عرض الأوراق/القطع
- بيان ما الذي يقال وما الذي لا يقال

### 2. ORCID

هذه هي **الهوية الرسمية المحمولة**.

وظيفتها:

- اسم الباحث الرسمي
- biography مختصرة
- كلمات مفتاحية
- روابط إلى الموقع وGitHub وINSPIRE
- ربط الأعمال والهوية

### 3. GitHub

هذه هي **هوية العمل المنضبط القابل للتدقيق**.

وظيفتها:

- profile bio
- profile README
- pinned repositories
- تحويل discipline إلى شيء مرئي

## B. Community Legitimacy Platforms

### 4. arXiv

ليست منصة profile كاملة.
لكنها أهم واجهة paper-facing.

وظيفتها:

- title discipline
- abstract discipline
- author note consistency

### 5. INSPIRE

مهمة جدًا للفيزياء النظرية.

وظيفتها:

- author authority inside the field
- clean profile linkage
- authorship claiming
- discoverability in the physics corpus

## C. Output Platforms

### 6. Zenodo

وظيفتها:

- releases
- software
- datasets
- archival records

ليست مكان CV أو براند شخصية.

### 7. Google Scholar

وظيفتها:

- discoverability
- citation visibility
- basic public academic presence

ليست مكان السرد المركزي.

## D. Derived Presence Logic

### المركز

- Personal Site
- ORCID

### الجسر بين الهوية والأعمال

- GitHub
- arXiv
- INSPIRE

### الأرشفة والاكتشاف

- Zenodo
- Google Scholar

## E. Implementation Rule

الاشتقاق يكون هكذا:

- `AUTHOR_BRAND_POSITIONING`
- `AUTHOR_MESSAGE_HOUSE`
- `AUTHOR_MASTER_SOURCE_TEXT`
- `AUTHOR_MASTER_CV`
- platform-specific copy

ثم:

- لا نكتب من الصفر لكل منصة
- لا نترك كل منصة تتحدث بصوت مختلف
- لا نحمّل كل المنصات نفس الوزن السردي
- ولا نسمح بأن تضيف منصة صغيرة ادعاءً لا يحمله النص الأم

كل منصة تأخذ نسخة مشتقة من نفس master CV:

- الموقع الشخصي يأخذ السرد الكامل
- ORCID تأخذ الهوية المختصرة الرسمية
- GitHub تأخذ وجه الانضباط والـartifacts
- arXiv تأخذ صوت النتائج المنضبطة
- INSPIRE تأخذ الربط الحقلّي النظيف
- Zenodo تأخذ outputs فقط
