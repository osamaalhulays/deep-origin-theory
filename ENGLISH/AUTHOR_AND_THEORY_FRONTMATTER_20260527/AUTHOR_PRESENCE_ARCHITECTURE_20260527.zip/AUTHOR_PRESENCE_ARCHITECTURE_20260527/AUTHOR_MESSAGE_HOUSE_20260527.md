# Author Message House

## Core Message

**This author works on ambitious theoretical physics under hard ceilings, aiming to derive cosmological law from deeper physical layers rather than manufacturing it through post-hoc fitting.**

## Supporting Message 1

### Discipline

The work is defined as much by what it refuses to claim as by what it claims.

Proof points:

- explicit non-claims
- bounded scopes
- kill logic
- no-patch methodology

## Supporting Message 2

### Scientific Service

The author is not selling depth for its own sake.
The aim is to produce lawful bridges or laws that matter for observable cosmology.

Proof points:

- response-unification line
- white-law line
- controlled cosmology-facing interfaces

## Supporting Message 3

### Auditability

The work is built to be checked, not merely admired.

Proof points:

- reproducibility bundles
- canonical diagnostics
- explicit ceilings and exclusion rules

## Supporting Message 4

### Tempered Ambition

The questions are large, but the public claims are deliberately narrower than the ambitions.

Proof points:

- no final TOE language
- no premature cosmology completion claim
- staged publication logic

## Short Reusable Lines

Use as needed:

- `Derived before fitted.`
- `Hard ceilings, not soft promises.`
- `Deep structure, disciplined claims.`
- `From deep structure to cosmological law, under explicit limits.`
- `Large questions, bounded claims.`

## Lines To Avoid

- `solving everything`
- `redefining all of physics`
- `revolutionary final framework`
- `the answer to the universe`

## One-Sentence Elevator Version

> He works on ambitious theoretical physics questions, but under unusual claim discipline: laws should be derived before they are fitted, and public conclusions should stay below what the evidence can really carry.
