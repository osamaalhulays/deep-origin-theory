# Zenodo Policy

## Role of Zenodo

Zenodo هي منصة **outputs** لا منصة **CV شخصية**.

نستخدمها من أجل:

- software releases
- data packages
- supplementary artifacts
- reproducibility bundles
- archival publication companions

## What Goes To Zenodo

- clean public bundles
- datasets with clear scope
- software snapshots
- supplementary notes that are lawful research outputs

## What Does Not Go To Zenodo

- CV
- personal manifesto
- author branding prose
- internal governance ladders
- unfinished trench material

## Metadata Rules

Each deposit should include:

- clean title
- short bounded description
- author identity linked to ORCID
- keywords
- related identifier links when appropriate

## Branding Rule

Zenodo should reinforce the message:

**this author produces citable, archivable, auditable outputs**

It should not attempt to tell the whole story of the author.
