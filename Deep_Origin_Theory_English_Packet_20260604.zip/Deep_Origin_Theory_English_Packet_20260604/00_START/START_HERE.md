# Deep Origin Theory English Packet

Date: `2026-06-04`

This is the current English packet for Deep Origin Theory.

It brings together three visible shelves:

- `A` = pre-Rank 9 foundation
- `B` = current Rank 9 public wave
- `C` = current bounded cluster dossier

The packet is meant to be read as one outward-facing bundle while keeping the
three shelves visibly separate.

## Independent paper

The bounded paper remains independently citable here:

- `Keystone I: The First Bearing`
- DOI: `10.5281/zenodo.20465860`

## Reading order

1. `PACKET_SCOPE.md`
2. `01_A_PreRank9`
3. `02_B_Rank9`
4. `03_C_Cluster`
