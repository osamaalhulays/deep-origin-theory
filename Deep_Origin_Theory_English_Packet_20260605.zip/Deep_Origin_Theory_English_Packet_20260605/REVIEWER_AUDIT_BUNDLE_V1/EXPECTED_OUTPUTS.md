# Reviewer Audit Bundle Expected Outputs

Date: `2026-06-06`

This mini-bundle is meant for one cold reviewer pass through the current
English packet without requiring a long narrative read first.

## Run order

Run:

- `REVIEWER_AUDIT_BUNDLE_V1/RUN_AUDIT_ALL.sh`

## Expected success shape

The run is healthy if all of the following happen:

1. `packet_root_sha_check.txt` is produced and contains only `OK` lines.
2. `shelf_A_sha_check.txt` is produced and contains only `OK` lines.
3. `shelf_B_sha_check.txt` is produced and contains only `OK` lines.
4. `shelf_C_sha_check.txt` is produced and contains only `OK` lines.
5. `ngc0247_current_stack.json` is produced and is valid JSON.
6. `ngc0247_current_row_comparator.json` is produced and is valid JSON.
7. `ngc6946_fixed_qumond_summary.json` is produced and is valid JSON.
8. `macs1206_public_source_profile.json` is produced.
9. the run prints one unique temporary audit-directory path at the end.

For the `NGC6946` bounded audit surface, also expect:

- `all_QUMOND_residuals_negative = true`
- `delta_true_sign_split_label = 29 negative / 29 positive`
- one small nonzero recompute error budget caused by row-table rounding rather
  than by comparator drift

## Acceptable `MACS1206` outcomes

Two `MACS1206` audit outcomes are acceptable:

- full local replay available:
  - JSON shows `row_count = 4`
  - and includes the emitted CSV path
- optional external FITS not bundled:
  - JSON shows
    `status = skipped_external_fits_dependency_not_bundled`
  - and lists the missing FITS paths

The second outcome is intentionally accepted. It means the dossier preserves
the derived public-source table, while the optional external replay footing is
not bundled with the cold review copy.

## What counts as a real failure

Treat these as real regressions:

- any root or inner-shelf SHA check failure
- any raw traceback from the two `NGC0247` reproduction scripts
- any raw traceback from the `NGC6946` bounded audit script
- any hard crash from the `MACS1206` script
- any `MACS1206` output state other than:
  - the four-row summary
  - or the explicit skip-safe external-dependency state
