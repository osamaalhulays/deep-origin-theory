# Reviewer Audit Bundle Known External Dependencies

Date: `2026-06-06`

This bundle is designed to stay mostly self-contained.

## No network dependency

The audit route does not require network access.

It does assume ordinary local tooling already present:

- `bash`
- `shasum`
- `unzip`
- `python3`
- `node`

## One optional companion dependency class

The only optional dependency class in the current cold audit route is the
public-source `MACS1206` CLASH FITS footing used by:

- `03_C_Cluster/Deep_Origin_Theory_C_Cluster_Dossier_20260605.zip`
- `REPRODUCE_MACS1206_PUBLIC_SOURCE_PROFILE_V1.cjs`

Those companion FITS files may exist in the broader local research tree, but
they are not required for the packet to pass a bounded cold audit.

## Why this is still acceptable

The packet already carries:

- the emitted public-source-derived weak-lensing table,
- the explanation note,
- and the replay script.

So the scientific surface remains inspectable even when the optional companion
FITS files are absent from the packet copy itself.

## Packet-contained bounded audit surfaces

The current cold audit bundle includes packet-contained bounded audit routes
for:

- `NGC0247` current stack
- `NGC0247` current row comparator
- `NGC6946` fixed-`QUMOND` second witness summary

Only the optional `MACS1206` public-source replay has an accepted external
dependency class.

## Accepted behavior when companion FITS are absent

If the companion FITS files are absent, the script must exit cleanly with:

- `status = skipped_external_fits_dependency_not_bundled`

That is an allowed audit result, not a failure.
