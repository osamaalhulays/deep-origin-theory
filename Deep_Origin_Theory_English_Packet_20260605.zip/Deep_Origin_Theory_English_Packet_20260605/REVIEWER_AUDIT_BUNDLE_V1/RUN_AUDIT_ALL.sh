#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PACKET_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
AUDIT_DIR="$(mktemp -d "${TMPDIR:-/tmp}/deep_origin_reviewer_audit_XXXXXX")"

print_audit_dir() {
  local exit_code=$?
  echo
  if [[ $exit_code -eq 0 ]]; then
    echo "Outputs saved under:"
  else
    echo "Audit stopped early. Partial outputs saved under:"
  fi
  echo "$AUDIT_DIR"
}

trap print_audit_dir EXIT

verify_inner_zip() {
  local zip_path="$1"
  local label="$2"
  local extract_dir="$AUDIT_DIR/$label"
  local ledger_path
  local ledger_dir

  mkdir -p "$extract_dir"
  unzip -q "$zip_path" -d "$extract_dir"

  ledger_path="$(find_first_file "$extract_dir" "SHA256SUMS.txt")"
  if [[ -z "$ledger_path" ]]; then
    echo "Could not find SHA256SUMS.txt inside $label." >&2
    exit 1
  fi

  ledger_dir="$(cd "$(dirname "$ledger_path")" && pwd)"

  (
    cd "$ledger_dir"
    shasum -a 256 -c SHA256SUMS.txt
  ) > "$AUDIT_DIR/${label}_sha_check.txt"
}

find_first_file() {
  local root_dir="$1"
  local target_name="$2"

  find "$root_dir" -type f -name "$target_name" -print -quit
}

echo "[1/6] Verifying packet-root SHA256 ledger"
(
  cd "$PACKET_DIR"
  shasum -a 256 -c SHA256SUMS.txt
) > "$AUDIT_DIR/packet_root_sha_check.txt"

echo "[2/6] Verifying inner shelf ledgers for A, B, and C"
verify_inner_zip \
  "$PACKET_DIR/01_A_PreRank9/Deep_Origin_Theory_English_Package_A_PreRank9_20260603.zip" \
  "shelf_A"
verify_inner_zip \
  "$PACKET_DIR/02_B_Rank9/Deep_Origin_Theory_English_Public_Wave_20260603.zip" \
  "shelf_B"
verify_inner_zip \
  "$PACKET_DIR/03_C_Cluster/Deep_Origin_Theory_C_Cluster_Dossier_20260605.zip" \
  "shelf_C"

echo "[3/6] Rebuilding the current NGC0247 stack"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC0247_CURRENT_STACK_V1.py" \
  > "$AUDIT_DIR/ngc0247_current_stack.json"

echo "[4/6] Rebuilding the current NGC0247 row comparator"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC0247_PHASE2_CURRENT_QCT_ROW_COMPARATOR_V1.py" \
  > "$AUDIT_DIR/ngc0247_current_row_comparator.json"

echo "[5/6] Auditing the second named fixed-QUMOND witness"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC6946_FIXED_QUMOND_SUMMARY_V1.py" \
  > "$AUDIT_DIR/ngc6946_fixed_qumond_summary.json"

echo "[6/6] Probing the MACS1206 public-source replay contract"

C_SCRIPT_PATH="$(find_first_file "$AUDIT_DIR/shelf_C" "REPRODUCE_MACS1206_PUBLIC_SOURCE_PROFILE_V1.cjs")"

if [[ -z "$C_SCRIPT_PATH" ]]; then
  echo "Could not find REPRODUCE_MACS1206_PUBLIC_SOURCE_PROFILE_V1.cjs inside extracted shelf C." >&2
  exit 1
fi

node \
  "$C_SCRIPT_PATH" \
  > "$AUDIT_DIR/macs1206_public_source_profile.json"

echo
echo "Audit complete."
