# Citation And Attribution Note

Date: `2026-06-05`

This note exists to make later citation safer and colder.

## If you cite this packet

Please cite:

- the packet for packet-level scope, claim boundaries, and current shelf
  assembly,
- and the specific shelf or appendix you actually relied on for the scientific
  point you are citing.

## Examples

### If your point is about the bounded `Rank 9` bridge

Cite:

- the packet,
- plus `Keystone I` material inside shelf `B`.

### If your point is about the named `NGC0247` witness

Cite:

- the packet,
- plus:
  - `DIFFERENTIAL_WITNESS_CAPSULE__NGC0247__V1.md`
  - `DIFFERENTIAL_WITNESS_APPENDIX__NGC0247__ROW_TABLE__V1.md`
  - `FIXED_QUMOND_COMPARATOR_APPENDIX__NGC0247__SOURCE_LOCKED_V1.md`
  - and, if relevant,
    `NGC0247_CURRENT_REPLICATION_CAPSULE_V1.md`

### If your point is about what is still deferred

Cite:

- `DEFERRED_SCOPE_AND_ACTIVE_DEBTS.md`
- and `KEY_QUESTIONS_AND_SCOPE.md`

## What should not be cited as if already closed

Do **not** cite this packet as if it already proved:

- full cosmology,
- whole-family `MOND/QUMOND` non-reducibility,
- final `MACS1206` ascent,
- true `L0` observational crossing,
- or complete community consensus.

## Why this matters

The packet is trying to make outside engagement easier without laundering one
bounded success into a total finished story.

Good citation should preserve that discipline.
