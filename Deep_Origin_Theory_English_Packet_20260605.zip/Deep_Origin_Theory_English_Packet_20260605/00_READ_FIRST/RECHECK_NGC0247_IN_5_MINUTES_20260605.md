# Re-check `NGC0247` In 5 Minutes

Date: `2026-06-05`

This route is for a reader who wants one bounded external check immediately.

## Read these files only

1. `DIFFERENTIAL_WITNESS_CAPSULE__NGC0247__V1.md`
2. `DIFFERENTIAL_WITNESS_APPENDIX__NGC0247__ROW_TABLE__V1.md`
3. `FIXED_QUMOND_COMPARATOR_APPENDIX__NGC0247__SOURCE_LOCKED_V1.md`
4. `NGC0247_CURRENT_REPLICATION_CAPSULE_V1.md`
5. `NGC0247_CURRENT_REPLICATION_ROWS_V1.csv`
6. `REPRODUCE_NGC0247_CURRENT_STACK_V1.py`

## What to check

You do not need to judge the whole theory.
Check only these points:

1. can `v_QUMOND` be recomputed from the published table inputs?
2. are the fixed-`QUMOND` residuals one-sided across the visible rows?
3. is `delta_true` sign-changing across radius rather than a flat offset?
4. does the small script reproduce the visible bounded claims?

## What this would and would not show

If these checks pass, that supports one narrow conclusion:

- the packet contains one real bounded reviewer-readable witness against fixed
  simple-`QUMOND`.

It would **not** by itself prove:

- full `MOND/QUMOND` family defeat,
- final public `v_QCT_current` closure,
- or finished cosmology.

## Why this route exists

Many readers are willing to test one object before reading one whole program.

This route is built for that exact reader.
