# Deferred Scope And Active Debts

This note exists so the reader can distinguish between:

- what is already being claimed,
- what is deliberately deferred,
- and what remains tracked as a live debt.

## Deliberately not claimed here

This packet does **not** claim:

- finished cosmology,
- completed observational closure,
- completed `MOND/QUMOND` non-reducibility proof,
- final `MACS1206` ascent,
- true `L0` observational crossing,
- cross-shelf `Xi` identity closure,
- or completed external scientific acceptance.

## Highest live debts

1. external peer review
2. a public `MOND/QUMOND` differential witness stronger than the current
   bounded named spear
3. `MACS1206` independent replication or stronger trace authority
4. true `Rank10` data-opening crossing if such a lawful crossing exists
5. cleaner cross-shelf `A -> B` `Xi` continuity
