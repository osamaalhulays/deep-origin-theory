# Prediction And Testability Closure Ledger

Date: `2026-06-05`

This ledger records the strongest already-materialized surfaces behind the
packet's prediction / testability / falsifiability axis.

Its purpose is not to inflate the packet.
Its purpose is to distinguish:

- real already-testable prediction surfaces,
- real later-stage observational openings,
- and under-advertised bounded predictive strength that was being scored as if
  it were still only preparatory.

## Short verdict

The repo sweep supports a stronger reading than the packet had been making
obvious:

- one named differential witness is already row-auditable,
- one second named differential witness is now row-readable against the same
  fixed comparator,
- one fixed-`QUMOND` comparator is already openly recomputable,
- one bounded current replication stack is already runnable,
- one formal falsification front already existed before Rank 9,
- one reproducible pre-observational normalized prediction bundle already
  existed before `L0` opening,
- and the later `C` shelf already carries bounded benchmark-row material plus
  exact next blockers.

What remains open is narrower than "predictions still mostly missing."

## A. Already testable now

### 1. `NGC0247` is no longer only a named case; it is a row-auditable witness

The packet already exposes for one named galaxy:

- a bounded witness capsule,
- a `26`-row radial appendix,
- a fixed simple-`QUMOND` row comparator,
- a bounded historical case-level benchmark bridge,
- a current row-visible replication stack,
- and a runnable reproduction script.

That is already a real test surface, not merely a verbal promise of later
testability.

### 2. `NGC6946` now gives a second named row-readable differential witness

The packet now also exposes for `NGC6946`:

- one bounded second-witness capsule,
- one source-locked fixed-`QUMOND` row comparator across `58` rows,
- one one-sided residual pattern against that fixed comparator,
- and one sign-changing oracle profile split `29` negative / `29` positive.

This is narrower than the `NGC0247` spear because it still lacks:

- the current bounded replication stack,
- and the bounded case-level benchmark bridge.

But it still materially upgrades the predictive axis because the packet is no
longer asking to be judged on one galaxy alone.

### 3. The fixed-`QUMOND` comparator is openly recomputable

The current packet already makes the bounded check public:

- `a0` is frozen,
- the `simple nu(y)` rule is frozen,
- `g_bar = v_bar^2 / R` is frozen,
- and `v_QUMOND = v_bar * sqrt(nu(y))` is frozen.

So the reviewer does not have to trust a hidden pipeline to test the witness.
The row comparator can already be recomputed from the visible table.

### 4. The witness is differential, not merely aggregate

The packet now preserves at least one real differential prediction surface:

- the same named case `NGC0247`,
- with one-sided fixed-`QUMOND` residual pressure,
- paired with a sign-changing radial `delta_true` structure.

That matters because the packet is no longer asking to be judged only on broad
aggregate pressure against `MOND/QUMOND`.

It already exposes one bounded reviewer-readable differential spear.
It now also exposes one second narrower named holdout witness at row-readable
fixed-comparator level.

### 5. A runnable current replication stack already exists

The packet now preserves:

- one current row file,
- one explicit model-lock card,
- one metric-bridge note,
- and one small reproduction script for the visible `NGC0247` stack.

That is a real testability gain.

It means the packet is not saying only:

- "trust our interpretation of the witness,"

but also:

- "here is one bounded stack you can rerun directly."

### 6. A formal falsification front existed before Rank 9

The earlier lineage layer already preserved:

- a no-photon-tailoring rule,
- a branch-disciplined lensing structure,
- and a formal falsification runbook for later external execution.

So falsifiability is not a new late add-on.
It was already built into the older public scientific grammar.

## B. Already predictive, even where full observational opening is still closed

### 7. `B` already carries stage-local public numerical outputs

`Keystone I` already publishes:

- `Xi_raw`
- `Xi_hat`
- `Xi_hat_min`

These are not final cosmological observables.
But they are still real public stage-local outputs, not empty framework
language.

### 8. A reproducible `301`-row normalized background prediction bundle already existed

Before observational opening, the packet already preserves a:

- reproducible `301`-row predata model-prediction bundle
- in the normalized `H(z) / E(z)` background family

with:

- no observed data,
- no likelihood,
- no fit,
- and no hidden repair.

So it is inaccurate to read the current shelf as:

- "no cosmological predictive object at all."

The fairer reading is:

- one normalized pre-observational predictive object already existed,
- while later observed-data confrontation remained lawfully deferred.

### 9. `C` already carries bounded benchmark-row material

The later `C` shelf now preserves a bounded observed benchmark-row pack for
the normalized `H(z) / E(z)` family with:

- `active_benchmark_row_count = 5`
- downstream use limited to background comparison and rowwise residual
  preparation only

That still stops before:

- QCT-side prediction rows,
- likelihood,
- fit,
- or claim.

But it means the packet has moved beyond:

- "future cosmology only,"

into:

- "bounded benchmark-row readiness already visible, with exact remaining
  blocker."

## C. Already falsifiable and already disciplined

### 10. The packet already exposes kill-front logic, not only support surfaces

The visible predictive culture is not:

- "many friendly diagnostics and no sharp failure mode."

It already includes:

- a fixed comparator that can miss row by row,
- a sign-structure witness that can fail morphologically,
- a lensing front framed as a later kill-switch,
- and explicit non-claim boundaries when the lawful opening has not occurred.

That is stronger falsifiability discipline than the score suggests.

### 11. Sentinel and holdout discipline already exist

The packet now also makes visible one historical blind same-source holdout
pass on bounded branch-level terms, in addition to the later `C`-shelf
independent holdout grammar.

The packet already preserves:

- one fixed six-case sentinel core,
- explicit holdout language,
- and no-promotion-by-inference discipline from partial-stage success.

So the program is not wandering opportunistically from one favorable case to
another.

Its out-of-sample grammar is already more serious than a casual reader may
infer.

## D. What remains genuinely open

### 12. Final public fitted-`Y` closure for the `NGC0247` case is still absent

The packet still does not publish:

- the final current public `v_QCT_current` row comparator,
- or the exact fitted-`Y` production closure object for the same named case.

This is real.
But it is now a narrow remaining gap above an already testable witness stack.

### 13. Whole-family `MOND/QUMOND` non-reducibility is still not closed publicly

The current packet still does not lawfully claim:

- full defeat of the wider `MOND/QUMOND` family,
- or final aggregate closure from one bounded named spear.

That is a fair remaining deduction.
It is not evidence that there is no differential prediction.

### 14. Rank-10 observational opening is still bounded below full fit

`C` still keeps exact blockers visible:

- missing QCT-side normalized `H100` prediction rows at `L0`,
- missing source-side baryonic components for the non-`SPARC` independent
  `L2` holdout route.

These are real later openings.
But they are narrower than saying the packet has not yet become properly
testable.

## E. Fair scoring consequence

After this sweep, the prediction / testability axis should no longer be read
as:

- "a mostly preparatory packet waiting for Rank 10 before real testing
  begins."

The fairer reading is:

- one named differential witness is already public and row-auditable,
- one second named holdout witness is now public at row-readable
  fixed-comparator level,
- one fixed comparator is already recomputable,
- one bounded replication stack is already runnable,
- one formal falsification front already exists,
- one normalized pre-observational prediction lane already existed before data
  opening,
- and one bounded benchmark-row readiness layer is already visible in `C`.

The remaining gaps are real, but narrower:

- final current-production comparator closure,
- broader family-wide non-reducibility closure,
- and later lawful observational openings.

## Best short route

If prediction / testability is the main concern, read:

1. `PREDICTION_AND_FALSIFIABILITY_NOTE_20260605.md`
2. `DIFFERENTIAL_WITNESS_CAPSULE__NGC0247__V1.md`
3. `FIXED_QUMOND_COMPARATOR_APPENDIX__NGC0247__SOURCE_LOCKED_V1.md`
4. `NGC0247_CURRENT_REPLICATION_CAPSULE_V1.md`
5. `REPRODUCE_NGC0247_CURRENT_STACK_V1.py`
6. `01_A_PreRank9/.../WHAT_HAS_ALREADY_BEEN_ACHIEVED_BEFORE_RANK9.md`
7. `01_A_PreRank9/.../QCT_LINEAGE_AND_APEX_20260218_20260228/LENSING_DISCIPLINATOR_AND_BRANCH_DISCIPLINE_NOTE.md`
8. `02_B_Rank9/.../CURRENT_STAGE_AND_PREDICTION_STATUS.md`
9. `02_B_Rank9/.../Keystone_I_The_First_Bearing_20260429/CURRENT_STAGE_AND_PREDICTION_STATUS.md`
10. `03_C_Cluster/.../C_HARVEST_NOTE.md`
11. `03_C_Cluster/.../C_LIVE_PHASE_KEYS_20260605.md`

## Bottom line

The packet's predictive axis is stronger than the current score suggests.

Not because every later observational frontier is already open,
but because multiple bounded predictive and falsifiable surfaces are already
materialized and reviewable now, including one primary spear, one second
row-readable holdout witness, one runnable replication stack, and one bounded
late-stage readiness layer.
