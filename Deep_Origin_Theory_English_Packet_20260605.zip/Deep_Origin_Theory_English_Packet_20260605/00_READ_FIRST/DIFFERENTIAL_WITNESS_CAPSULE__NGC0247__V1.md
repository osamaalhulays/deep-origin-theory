# Differential Witness Capsule — NGC0247 vs Fixed QUMOND

Date: `2026-06-04`

Status: `bounded outward-facing capsule`

Purpose:

This capsule answers one narrow reviewer question directly:

Do we now have one named, reviewer-readable differential witness against the
fixed `QUMOND` benchmark, rather than only an aggregate harshness surface?

Short answer:

- `yes, in bounded form`

## Case

- named case = `NGC0247`
- comparator = fixed `QUMOND` benchmark

## What is frozen here

The bounded witness claim frozen here is:

- `NGC0247` is the cleanest current named differential stress witness against
  the fixed `QUMOND` benchmark at the sentinel front.

This is **not** yet a whole-program victory claim and **not** a full public
proof of `MOND/QUMOND` non-reducibility.

## Witness type

Witness type:

- `radius-resolved sign-changing correction-profile requirement under fixed benchmark pressure`

The preserved local row-wise oracle surface for `NGC0247` already shows:

- `26` rows
- `13` negative rows
- `13` positive rows
- `delta_true_min = -0.147828327514717`
- `delta_true_max = 0.25`

The exact preserved row list is now published in:

- `DIFFERENTIAL_WITNESS_APPENDIX__NGC0247__ROW_TABLE__V1.md`

So the case is no longer only:

- anonymous aggregate harshness,
- or a loose offender shortlist,
- or generic “QCT pressure” language.

It now has:

- one named galaxy,
- one fixed comparator,
- one radius-resolved observable class,
- and one bounded outward-safe claim.

## Why this case matters

`NGC0247` is not selected arbitrarily.

The preserved later state already makes it the cleanest spear:

- persistent sentinel top case
- recurrence = `5/5`
- weighted class = `clear_signature`

The harsher `QUMOND` surface is therefore no longer a faceless wall.

It already contains a named recurring offender core, and `NGC0247` leads that
core at the sentinel front.

## Reviewer-readable benchmark localization

The broader aggregate benchmark remains harsh, but it is already structured
enough for one bounded reviewer reading:

- unique valid-case layer = `175`
- multiseed report layer = `875 = 175 x 5`
- named offender core includes:
  - `NGC0247`
  - `NGC5055`
  - `NGC6946`
  - secondarily `UGC11914`

At the deeper sentinel archive level, `NGC0247` also appears inside the
repeated early-exit triplet, with preserved `delta_aic_free` maxima around
`157.86` under the sentinel tightening surfaces.

That does **not** yet give a full public case-by-case benchmark decomposition,
but it does localize the pressure to a specific recurring object rather than
to anonymous bulk alone.

## Why this does not collapse into radius-only or anonymous benchmark bulk

This capsule does not claim that one galaxy alone defeats the entire
`MOND/QUMOND` family.

It claims something narrower and reviewer-useful:

1. the benchmark harshness is localized to a named recurring object,
2. the preserved local target for that object is non-flat and sign-changing
   across radius,
3. and the later pre-`Rank 9` line had already identified the stronger
   anti-`MOND/QUMOND` threshold as:
   - differential signature,
   - plus morphology necessity,
   - not fit vanity alone.

So the witness is meaningful because it combines:

- named recurrence,
- radius-resolved structured correction demand,
- and a benchmark surface no longer readable as pure anonymous aggregate fog.

## What this capsule does not claim

This capsule does **not** claim:

- full public `MOND/QUMOND` non-reducibility closure,
- whole-program superiority,
- final reviewer-grade causal decomposition of every harsh aggregate row,
- or final cosmology / lensing / cross-domain closure.

## Current state table

| Field | Current state |
| --- | --- |
| Named case | `closed` |
| Comparator name | `closed` |
| Observable class | `closed` |
| Radius-resolved sign-changing support | `closed` |
| Reviewer-safe outward wording | `closed` |
| Aggregate benchmark localization to named offender core | `closed` |
| Public row-by-row witness appendix | `closed` |
| Public source-locked fixed-`QUMOND` row comparator | `closed` |
| Exact public fixed-`QUMOND` benchmark comparator table | `pending` |
| Full public `MOND/QUMOND` non-reducibility claim | `pending` |

## Short outward-safe wording

One outward-safe summary sentence is:

> `NGC0247` is the cleanest current bounded named differential stress witness
> against the fixed `QUMOND` benchmark: the benchmark pressure is localized to
> a recurring sentinel-stage galaxy whose preserved local row-wise target
> requires a non-flat, sign-changing radius-resolved correction profile across
> 26 rows.

## Use rule

Use this capsule to answer:

- “Do you now have one named reviewer-readable witness?”

Do **not** use it to claim:

- “the whole `MOND/QUMOND` question is finished.”
