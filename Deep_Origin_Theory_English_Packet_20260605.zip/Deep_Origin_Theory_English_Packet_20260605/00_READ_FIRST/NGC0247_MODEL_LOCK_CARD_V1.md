# NGC0247 Model Lock Card

Date: `2026-06-05`

Status: `bounded lock card`

## Purpose

This card freezes the exact visible objects behind the current `NGC0247`
replication stack so the witness cannot drift by silent substitution.

## Fixed-QUMOND comparator lock

The public fixed comparator used in the row table is locked to:

- `a0 = 1.2 × 10^-10 m/s^2`
- `nu(y) = 0.5 + sqrt(0.25 + 1/y)`
- `g_bar = v_bar^2 / R`
- `v_QUMOND = v_bar * sqrt(nu(y))`

This row comparator is intentionally source-locked and bounded.

It is **not** a fitted-`Υ` production comparator.

## Current external predictor lock

The current row-visible external predictor surface is locked to the preserved
migration bundle objects:

- `epic30_predictions_ml.ndjson`
  - SHA256 = `476d578a682eb9e42557c689b90ac784c70fcb34551dffc500355163114bc411`
- stable training script:
  - `train_emulator_poc_FIXED_STABLE.py`
  - SHA256 = `304aef5598a84a04a6cd1a557cdd1e5e771e21b07e104dca56550e36aa297aca`
- local normalization file:
  - `emulator_poc_norm.json`
  - SHA256 = `3b9c02f15d8153f5ae65f4233757da2efab1d67a3f0f40837486ee86853992c1`

Visible schema for the current row surface:

- `delta_1d_current` = dimensionless
- `sigma_delta_1d_current` = dimensionless and positive

Important ceiling:

- the visible current row object is still an external `artifact_emulator`
  surface,
- not a final promoted current-lane `v_QCT_current` velocity table.

## Preserved Phase-2 case-lock lane

One deeper preserved case-run lane for `NGC0247` is also now locked here:

- single-case source file:
  - `src/NGC0247.json`
- single-case predictor surface:
  - `pred_one.ndjson`
- single-case artifact pair:
  - `external_model_v2.npz`
  - `external_meta_v2.json`
- single-case benchmark output:
  - `multiseed_results.ndjson`

Preserved visible audit anchors for that lane:

- `delta_source = artifact_emulator`
- `training_manifest_hash = 989a28dc649a06e15ac4df5bfed717afe7f7b87b37e22cffca04d3e6a7f82aa4`
- `emulator_artifact_hash = ceca66e878ad1651ebd167d3c67a5cd04a7a2df925b8ac4943f21ed8e5cfc3fd`
- `features_hash = 4ba0a31de8ab16e0dfe451748f3de1821774cd47b78aa8b5dfe13353ed9592dd`
- `created_utc = 2026-03-09T08:05:20Z`
- `n_datapoints = 26`

Visible case-level read for that lane:

- `QCT loglike_obs_only = -416.9274550145858`
- `QCT loglike_obs_model = -347.4113136571038`
- `QUMOND loglike_obs_only = -268.4815452508469`
- `ΔAIC_total = 159.85953681251374`
- `ΔBIC_total = 161.11763335053513`

## Forward-model lock

The benchmark code path behind that preserved case-lock lane uses the QCT
forward model:

- `v_model = sqrt(Upsilon) * v_bar * sqrt(1 + Delta)`

with:

- `v_bar` taken from the preserved source rows
- `Delta` taken from the preserved artifact-emulator surface
- and `Upsilon` taken from the benchmark inference layer

So the preserved Phase-2 lane is a real source/artifact/metric chain, not a
detached scoreboard line.

## Historical case-level benchmark bridge lock

The preserved historical case-level benchmark bridge is locked to:

- `QCT_GEMINI_EVIDENCE_MINI.zip`
  - SHA256 = `ded6c6aafbd4c0a044d7f265159adfcaf545e4b862149740a96889e32733a063`
- `QCT_GEMINI_EVIDENCE_MINI_oracle10.zip`
  - SHA256 = `e79649b76b0d40e3a7ff142200cf80108cc406017a6b8ceb35603a1723f51a8e`

Preserved audit fields for the benchmark lane:

- `delta_source = artifact_emulator`
- `emulator_artifact_hash = 54f19180de958fb4e36dbd584b2dd38c670277286abeea217d485c5831f5f7ba`
- `training_manifest_hash = 989a28dc649a06e15ac4df5bfed717afe7f7b87b37e22cffca04d3e6a7f82aa4`
- `n_datapoints = 26`
- preserved five-seed stability:
  - `42`
  - `101`
  - `2022`
  - `5555`
  - `9999`

## Non-collapse rule

Do **not** silently collapse the following into one thing:

- the current row-visible predictor file
- the deeper preserved Phase-2 case-lock lane
- the historical benchmark artifact audited inside the evidence bundle
- and the still-missing final current public `v_QCT_current` row comparator

They are related, but they are not identical published objects.

## Exact public blocker

The last blocker is now narrower than before:

- the preserved benchmark outputs expose the case-level QCT metrics
- but they do not expose the final public row-level best-fit nuisance value
  needed to reconstruct `v_QCT_current / resid_QCT / chi2_QCT` from the
  preserved public outputs alone

So the remaining gap is no longer:

- "is there any QCT benchmark object at all?"

It is now:

- "where is the public row-level best-fit closure object?"

## Late-branch exclusion lock

One deeper repo hunt found two later `NGC0247` branches in
`QCT_Apex_Repo_Run`:

- a scaffold-marked publish-style evidence bundle,
- and a later aggregate internal summary branch with a bounded success read.

Neither is silently imported into the witness here.

Why not?

- the scaffold-marked branch is explicitly `NOT FOR PUBLICATION`,
- and the later internal summary branch still lacks the packet-clean
  row-level public closure surface needed for lawful promotion.

This lock prevents provenance richness from being confused with admissible
public closure.

## Claim lock

Allowed bounded claim:

- one named bounded witness against fixed simple-`QUMOND`
- current row-visible external predictor surface
- preserved historical case-level benchmark support

Forbidden overclaim:

- final current public fitted-`Υ` closure
- final public `v_QCT_current` row comparator
- whole-family `MOND/QUMOND` defeat
