# NGC0247 Current Replication Capsule

Date: `2026-06-05`

Status: `bounded local-public strengthening note`

## Purpose

This capsule pushes the visible `NGC0247` witness one step further toward a
quasi-closed bounded object.

It does so by exposing the strongest current reproducible stack that can be
published **honestly** from the preserved local materials:

- one source-locked fixed-`QUMOND` row comparator,
- one current row-visible external predictor surface,
- one preserved historical case-level benchmark bridge for the same named
  case,
- and one deeper preserved Phase-2 same-case case-lock lane whose benchmark
  wiring is still readable.

## What is newly visible here

This capsule now freezes five linked objects together:

1. `DIFFERENTIAL_WITNESS_APPENDIX__NGC0247__ROW_TABLE__V1.md`
2. `FIXED_QUMOND_COMPARATOR_APPENDIX__NGC0247__SOURCE_LOCKED_V1.md`
3. `CASE_LEVEL_BENCHMARK_APPENDIX__NGC0247__ARTIFACT_EMULATOR_V1.md`
4. `NGC0247_CURRENT_REPLICATION_ROWS_V1.csv`
5. `REPRODUCE_NGC0247_CURRENT_STACK_V1.py`

The new part is not just more wording.

It is the explicit current row-visible replication layer:

- the `26` preserved `NGC0247` rows,
- exact source-side `R`, `v_obs`, `sigma_v`, and `v_bar`,
- the explicit fixed-`QUMOND` comparator fields,
- the oracle `delta_true` target,
- and the current external `delta_1d_current` / `sigma_delta_1d_current`
  predictions carried by the preserved migration bundle.

## Scope rule

This capsule **does** claim:

- `NGC0247` is now visible as a named bounded differential witness against
  fixed simple-`QUMOND`,
- the fixed-`QUMOND` comparator is row-auditable,
- the current external predictor surface is row-visible and reproducible,
- and the same named case also carries preserved historical case-level
  benchmark support,
- and a deeper Phase-2 case-lock lane exists in which the source rows, the
  artifact-emulator surface, and the benchmark metrics are all visibly tied
  together,
- and one explicit late-branch provenance / exclusion note keeps non-promoted
  post-bridge branches visible without laundering them into the public
  witness.

This capsule does **not** claim:

- that a final current public `v_QCT_current` row-velocity comparator has now
  been published,
- that the exact current fitted-`Υ` production benchmark comparator is now
  public,
- or that whole-family `MOND/QUMOND` non-reducibility is finished.

## Frozen summary

- named case = `NGC0247`
- row count = `26`
- fixed-`QUMOND` row residuals = `26 / 26` negative
- `delta_true` sign split = `13` negative, `13` positive
- current `delta_1d_current` range = `0.6808984875679016` to
  `1.9881731271743774`
- current `sigma_delta_1d_current` range = `0.3852384388446808` to
  `0.908456027507782`

Historical case-level bridge for the same named case:

- bounded ML lane:
  - `QCT loglike_obs_only = -260.99900774336845`
  - `QUMOND loglike_obs_only = -268.4815452508469`
  - `ΔAIC_total = -12.965075014956938`
  - `ΔBIC_total = -11.706978476935546`
- bounded `oracle10` ceiling lane:
  - `QCT loglike_obs_only = -237.48017228995866`
  - `QUMOND loglike_obs_only = -268.4815452508469`
  - `ΔAIC_total = -60.00274592177652`
  - `ΔBIC_total = -58.744649383755075`

Deeper preserved Phase-2 case-lock lane for the same named case:

- source rows = `26`
- `delta_source = artifact_emulator`
- `training_manifest_hash = 989a28dc649a06e15ac4df5bfed717afe7f7b87b37e22cffca04d3e6a7f82aa4`
- `emulator_artifact_hash = ceca66e878ad1651ebd167d3c67a5cd04a7a2df925b8ac4943f21ed8e5cfc3fd`
- `QCT loglike_obs_only = -416.9274550145858`
- `QCT loglike_obs_model = -347.4113136571038`
- `QUMOND loglike_obs_only = -268.4815452508469`
- `ΔAIC_total = 159.85953681251374`
- `ΔBIC_total = 161.11763335053513`

## Why this is stronger than before

Before this capsule, the witness already had:

- a named galaxy,
- a sign-changing oracle morphology table,
- a fixed-`QUMOND` row comparator,
- and a preserved historical case-level benchmark note.

Now it also has:

- one explicit current row file joining those surfaces together,
- one explicit lock card,
- one explicit metric-bridge note,
- one deeper Phase-2 case-lock note showing the preserved source/artifact/metric
  chain,
- one explicit late-branch provenance / exclusion note,
- and one small reproduction script that checks the visible claims directly.

So the witness is no longer only:

- "named and clear",

but also:

- "current-stack readable and reproducible at bounded scope".

## The exact remaining gap

The main remaining gap is now narrower and more explicit:

- not "where is the witness?"
- but "where is the final current public `v_QCT_current` row comparator and
  fitted-`Υ` closure object, given that the preserved Phase-2 benchmark surface
  still does not publish the row-level best-fit nuisance value?"

That is why this capsule moves the witness toward quasi-closed bounded scope
without pretending to have crossed into full final current production closure.

## Late-branch honesty

The deeper repo hunt also found later `NGC0247` branches in
`QCT_Apex_Repo_Run`, but they remain intentionally excluded here for two
different reasons:

- one publish-style evidence bundle is visibly scaffold-marked
  `NOT FOR PUBLICATION`,
- and one later aggregate internal summary branch still lacks the packet-clean
  row-level public support surface needed for promotion.

So this capsule is stronger than before, but it still does not hide branch
selection discipline.

## Use rule

Use this capsule to support the following bounded sentence:

> `NGC0247` is now a named, row-auditable, current-stack-readable bounded
> differential witness against fixed simple-`QUMOND`: the fixed comparator is
> one-sided row by row, the oracle morphology is sign-changing across radius,
> and the same case also carries preserved historical case-level benchmark
> support.

Do **not** use it to say:

- "the final current `QCT` row-velocity comparator is already public,"
- "the current fitted-`Υ` production lane is fully closed here,"
- or "the whole `MOND/QUMOND` family question is finished."
