# NGC0247 Phase2 Case-Lock And Forward-Model Note

Date: `2026-06-05`

Status: `bounded strengthening note`

## Purpose

This note records one deeper closure found across the older QCT workspaces.

The visible packet had already shown:

- the fixed-`QUMOND` row comparator,
- the sign-changing oracle witness,
- the current external replication layer,
- and one preserved bounded historical case-level bridge.

What was still easy to miss was whether the named `NGC0247` witness also had a
preserved **same-case, same-source, same-artifact benchmark lane** in which the
QCT forward model itself was visibly wired into the benchmark code.

Short answer:

- `yes`

## What was located

One preserved single-case Phase-2 case-run bundle for `NGC0247` contains all of
the following at once:

- source rows:
  - `src/NGC0247.json`
- one single-case prediction object:
  - `pred_one.ndjson`
- one external artifact pair:
  - `emu_v2_out/external_model_v2.npz`
  - `emu_v2_out/external_meta_v2.json`
- one benchmark result:
  - `multiseed_results.ndjson`

The preserved metadata for that lane keeps visible:

- `delta_source = artifact_emulator`
- `training_manifest_hash = 989a28dc649a06e15ac4df5bfed717afe7f7b87b37e22cffca04d3e6a7f82aa4`
- `emulator_artifact_hash = ceca66e878ad1651ebd167d3c67a5cd04a7a2df925b8ac4943f21ed8e5cfc3fd`
- `features_hash = 4ba0a31de8ab16e0dfe451748f3de1821774cd47b78aa8b5dfe13353ed9592dd`
- `n_datapoints = 26`
- `created_utc = 2026-03-09T08:05:20Z`

## Why this matters

The deeper importance is not only that a benchmark output exists.

The benchmark code itself preserves the exact operational role of the artifact
surface:

- the case source provides `R_grid_m`, `v_obs_ms`, `sigma_v_ms`, and `v_bar_ms`
- the artifact surface provides `delta_1d` and `sigma_delta_1d`
- the QCT forward model is then formed as:
  - `v_model = sqrt(Upsilon) * v_bar * sqrt(1 + Delta)`

So the preserved Phase-2 lane is not just:

- a label,
- a prose claim,
- or a detached scoreboard row

It is a preserved same-case benchmark object in which:

- the source rows are known,
- the artifact-emulator surface is known,
- and the QCT benchmark metrics are produced by the audited benchmark path.

## Preserved Phase-2 case-level read

For this preserved single-case lane, the visible benchmark output is:

- `QCT loglike_obs_only = -416.9274550145858`
- `QCT loglike_obs_model = -347.4113136571038`
- `QCT aic_total = 700.8226273142076`
- `QCT bic_total = 704.596916928272`
- `QUMOND loglike_obs_only = -268.4815452508469`
- `QUMOND aic_total = 540.9630905016938`
- `QUMOND bic_total = 543.4792835777369`
- `ΔAIC_total = 159.85953681251374`
- `ΔBIC_total = 161.11763335053513`

## What this lawfully closes

This note closes a narrower but important question:

- do we have only a row witness and a historical bridge?

Answer:

- no

We also have a preserved Phase-2 case-locked benchmark lane in which:

- `NGC0247` source rows are explicit,
- the artifact-emulator surface is explicit,
- and the QCT benchmark metrics are explicit.

That means the witness is stronger than:

- row-readable only,
- or morphology-readable only,
- or historical-scoreboard-readable only.

It is also:

- `case-lock readable`

## Exact remaining blocker

This deeper closure still stops short of the final public row-level QCT table.

Why?

Because the preserved benchmark output keeps the case-level metrics but does
not preserve the public row-level best-fit nuisance value needed to reconstruct
the final visible row-velocity comparator from the preserved files alone.

In plainer terms:

- the benchmark path uses the fitted `Upsilon`
- but the preserved visible output does not publish that best-fit value here
- so a final public row table of
  - `v_QCT_current`
  - `resid_QCT`
  - `chi2_QCT`
  cannot yet be reconstructed lawfully from the preserved public surfaces
  alone.

## Honest boundary

Allowed bounded claim:

> `NGC0247` now has not only a row-readable fixed-`QUMOND` witness and a
> bounded current replication layer, but also a preserved Phase-2 same-case
> artifact-emulator benchmark lane whose forward-model wiring is visible in the
> benchmark code and whose case-level QCT/QUMOND metrics are explicit.

Forbidden overclaim:

- that the final current public `v_QCT_current` row table is already exposed
- that fitted-`Upsilon` closure is already fully public
- or that whole-family `MOND/QUMOND` closure is finished
