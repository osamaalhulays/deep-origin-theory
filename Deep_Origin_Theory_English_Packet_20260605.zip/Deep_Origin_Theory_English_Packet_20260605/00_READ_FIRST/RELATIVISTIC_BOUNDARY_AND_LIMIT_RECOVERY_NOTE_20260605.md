# Relativistic Boundary And Limit-Recovery Note

Date: `2026-06-05`

This note addresses two linked cold-reader doubts:

- is the packet vague about its non-relativistic / relativistic boundary?
- and does it really show lawful known-limit recovery inside that boundary?

## Short answer

The current packet is narrower and cleaner than the doubt assumes.

It is already explicit that the visible public line is:

- weak-field,
- galaxy/local-response facing,
- and not yet a finished all-regime cosmological theory.

Within that declared scope, the packet already shows:

- weak-field lensing posture,
- Newtonian / Solar local recovery,
- and explicit refusal to inflate that into full all-regime closure.

## 1. The current public scope is already stage-bounded

The packet does not pretend to be:

- full strong-field GR replacement,
- full cosmology,
- or one finished relativistic theory across all scales.

It repeatedly states that the present lawful stage is narrower:

- weak-field,
- response-bearing,
- and pre-final-cosmology.

That means the real question is not:

- "have all regimes been closed?"

but:

- "within the admitted regime, are the boundary and limit rules honest?"

## 2. Weak-field structure is not only implied

The lensing side is not left as a silent guess.

The packet already exposes a weak-field lensing mechanism surface and keeps
that surface distinct from later overreach.

So the relativistic-facing side of the current packet is not:

- absent,

but:

- explicitly bounded to the weak-field admitted layer.

## 3. Newtonian and local recovery are already real gates

The packet already preserves:

- clean Newtonian recovery posture,
- a Solar/local consistency pass,
- and the pinned local tiny-deviation surface represented by `epsilon_1au`.

That is stronger than a mere verbal promise that "the theory probably reduces
correctly."

## 4. What is still not public

What the packet still does **not** claim is:

- one full all-regime SR/GR test surface,
- one final strong-field closure,
- or one finished cosmological relativistic theorem.

Those are later-stage closures.

## 5. Best fair reading

The clean reading is now:

- known-limit recovery inside the admitted regime is already materially
  represented,
- while full all-regime relativistic closure remains deliberately later.

So the fair subtraction should now narrow to:

- downstream all-regime completion,

not:

- vague current boundary control.

## Bottom line

The packet already knows where its `NR/SR` edge is.

It may not yet close the whole relativistic universe-picture, but it does
already separate:

- admitted weak-field scope,
- lawful local recovery,
- and later all-regime relativistic ambition.
