# Second Differential Witness Capsule — NGC6946 vs Fixed QUMOND

Date: `2026-06-05`

Status: `bounded outward-facing capsule`

Purpose:

This capsule answers the next natural reviewer question after `NGC0247`:

- does the packet still reduce to one named galaxy,
- or is there now a second reviewer-readable differential witness against the
  fixed `QUMOND` benchmark?

Short answer:

- `yes, in narrower bounded form`

## Case

- named case = `NGC6946`
- comparator = fixed `QUMOND` benchmark
- stage role = `current holdout spear`

## What is frozen here

The bounded witness claim frozen here is:

- `NGC6946` is the clearest current **second named differential witness**
  against the fixed `QUMOND` benchmark, and the clearest current
  **holdout-spear** object in the preserved pre-`Rank 9` benchmark memory.

This is **not** yet:

- a claim that `NGC6946` has reached the same full bounded maturity as
  `NGC0247`,
- a whole-program victory claim,
- or a full public proof of `MOND/QUMOND` non-reducibility.

## Witness type

Witness type:

- `row-readable fixed-comparator pressure plus sign-changing oracle morphology`

The preserved source-locked surface now shows:

- `58` rows
- fixed-`QUMOND` residuals negative in all `58` rows
- `29` negative `delta_true` rows
- `29` positive `delta_true` rows
- `delta_true_min = -0.25`
- `delta_true_max = 0.25`
- source-locked fixed-`QUMOND` `chi^2_total = 31659.570`
- mean absolute fixed-`QUMOND` residual = `59.968 km/s`
- max absolute fixed-`QUMOND` residual = `82.922 km/s`

The exact row list is now published in:

- `FIXED_QUMOND_COMPARATOR_APPENDIX__NGC6946__SOURCE_LOCKED_V1.md`

So `NGC6946` is no longer only:

- a remembered offender name,
- or a holdout-stage label inside an internal decomposition note.

It now has:

- one named galaxy,
- one fixed comparator,
- one row-readable pressure table,
- one sign-changing oracle profile,
- and one outward-safe bounded role as the current holdout spear.

## Why this case matters

`NGC6946` matters for a different reason than `NGC0247`.

`NGC0247` remains the cleanest current spear because it now carries:

- the row appendix,
- the fixed-`QUMOND` comparator,
- the bounded case-level benchmark bridge,
- and the current bounded replication stack.

But the packet was still vulnerable to one easy cold-reader deduction:

- "perhaps this is still basically a one-galaxy story."

`NGC6946` closes much of that gap.

The packet can now show not only:

- one sentinel spear,

but also:

- one second named holdout spear with its own row-readable fixed comparator
  and sign-changing oracle profile.

## Reviewer-readable localization

The preserved later benchmark decomposition already froze the structured panel:

- sentinel spear = `NGC0247`
- holdout spear = `NGC6946`
- fullset spear = `UGC11914`
- recurrent offender core also includes `NGC5055`

So `NGC6946` is not a newly invented supporting case.

It was already one of the named drivers of the harsh benchmark surface.

What changed now is that the case has become reviewer-readable at row level.

## Why this still remains bounded

`NGC6946` is a real second witness, but it is still **narrower** than
`NGC0247`.

The packet does **not** yet publish for `NGC6946`:

- one current bounded replication stack like the one now visible for
  `NGC0247`,
- one preserved bounded case-level `ΔAIC/ΔBIC` bridge,
- or one final public current `v_QCT_current` row comparator.

So the honest reading is not:

- "`NGC6946` has full parity with `NGC0247`."

The honest reading is:

- the packet now has one first-class named spear,
- plus one second row-readable fixed-`QUMOND` holdout witness,
- which materially strengthens the differential panel beyond one galaxy.

## Current state table

| Field | Current state |
| --- | --- |
| Named case | `closed` |
| Comparator name | `closed` |
| Holdout-spear identity | `closed` |
| Public source-locked fixed-`QUMOND` row comparator | `closed` |
| Radius-resolved sign-changing oracle support | `closed` |
| Multi-galaxy differential panel support | `closed` |
| Current bounded replication stack | `pending` |
| Bounded case-level benchmark bridge | `pending` |
| Final public current `v_QCT_current` row comparator | `pending` |
| Full public `MOND/QUMOND` non-reducibility claim | `pending` |

## Short outward-safe wording

One outward-safe summary sentence is:

> `NGC6946` is the cleanest current second named differential witness against
> the fixed `QUMOND` benchmark: it acts as the packet's holdout spear, and its
> preserved source-locked row table shows one-sided fixed-`QUMOND` residual
> pressure across 58 rows paired with a sign-changing oracle correction
> profile split 29 negative / 29 positive across radius.

## Use rule

Use this capsule to answer:

- "Do you now have a second named differential witness beyond `NGC0247`?"

Do **not** use it to claim:

- that `NGC6946` has reached the same full maturity as `NGC0247`,
- that the whole `MOND/QUMOND` family question is finished,
- or that the current non-`SPARC` holdout front has already closed.
