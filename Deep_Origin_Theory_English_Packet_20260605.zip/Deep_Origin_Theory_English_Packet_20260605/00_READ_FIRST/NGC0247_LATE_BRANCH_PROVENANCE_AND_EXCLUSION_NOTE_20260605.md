# NGC0247 Late-Branch Provenance And Exclusion Note

Date: `2026-06-05`

Status: `bounded provenance / exclusion note`

## Purpose

This note records one important result from the deeper repo hunt:

- there **are** later `NGC0247` benchmark branches beyond the already visible
  historical bridge and Phase-2 case-lock lane,
- but the currently visible late branches do **not** yet qualify as lawful
  public closure surfaces for the packet.

That matters because a careful reader may eventually find these branches in the
older QCT workspaces and ask why they were not promoted here.

## Late branch A: publish-style evidence bundle, but scaffold-only

One later run bundle in `QCT_Apex_Repo_Run/runs/2026-02-22_230436/evidence.zip`
contains:

- `multiseed_results.ndjson`
- `production_capsule.zip`
- `stats_metadata.json`
- `external_model_v2.npz`
- `external_meta_v2.json`
- certification outputs

This is a real late branch, and it keeps `NGC0247` visible under the same
manifest anchor and the same source-file hash family.

However, the visible metadata also says plainly:

> `V2 scaffold (delta=0, sigma=0.01) for pipeline/audit only. NOT FOR PUBLICATION.`

And the publish helper in the same repo states the matching rule:

> publish-mode requires `REAL epic30_predictions.ndjson (no scaffold)`

So this branch is useful as provenance and process evidence, but it is **not**
lawful to promote it into the current public `NGC0247` witness stack as a
scientific closure surface.

## Late branch B: later aggregate run summary, but not packet-clean

The same repo also keeps a later top-level aggregate run summary in:

- `QCT_Apex_Repo_Run/runs/production_summary.csv`

There, `SPARC_NGC0247` appears as:

- `status = SUCCESS`
- `ΔAIC_total = -13.914066963632308`
- `ΔBIC_total = -12.002043958204126`

This is interesting because it points to a later branch in which `NGC0247`
appears to score as a bounded case-level success.

But the visible public surface for that branch is still too thin here.

What is missing from the currently visible late branch is:

- a packet-clean row-level comparator surface,
- a packet-clean visible best-fit nuisance disclosure,
- and a case-specific publication-ready support object that can be audited at
  the same level as the current bounded packet witness.

So this branch is also **not** promoted into the present public claim.

## Why the packet excludes both late branches

The exclusion is not because the later branches are irrelevant.

It is because the packet refuses to collapse three different things into one:

- a lawful current public witness,
- a scaffold-marked pipeline/audit branch,
- and a later aggregate internal summary branch whose visible support surface
  is still thinner than the public witness standard used here.

## What this hunt still proved

The deeper repo hunt did still prove something useful:

- `NGC0247` kept attracting serious later benchmark attention,
- the later QCT workspaces did not abandon the case,
- and the case remained live enough to generate multiple post-bridge branches,
  including one later aggregate branch with a bounded success read.

So the witness is stronger in provenance than a reader might think from the
older packet alone.

## What this does not change

This note does **not** change the exact public blocker.

The remaining lawful blocker is still:

- the final public row-level best-fit closure object for
  - `v_QCT_current`
  - `resid_QCT`
  - `chi2_QCT`

In other words:

- the repo hunt found more history,
- it found more seriousness,
- and it found one tempting later branch,
- but it did **not** yet find the final public row-level closure object.

## Use rule

Use this note to support the narrower statement:

> deeper repo hunting found later `NGC0247` benchmark branches, including one
> scaffold-marked publish-style bundle and one later aggregate internal summary
> branch, but both remain intentionally excluded from the current witness
> because they do not yet surface a lawful public row-level final closure
> object.

Do **not** use this note to claim:

- that the later scaffold branch is publication-grade evidence,
- that the later internal summary branch is already packet-clean public
  closure,
- or that the final public `v_QCT_current` row comparator has now been found.
