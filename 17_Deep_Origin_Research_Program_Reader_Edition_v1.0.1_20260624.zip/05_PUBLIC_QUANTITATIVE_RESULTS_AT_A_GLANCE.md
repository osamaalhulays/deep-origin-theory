# Public Quantitative Results At A Glance

These are headline-safe public quantities with direct public anchors in this
reader edition. Deferred local results are preserved separately and are not
counted here.

| item | value | scope |
|---|---:|---|
| DO-K1 NGC247 prediction rows generated | 0 | terminal pre-prediction closure |
| DO-K1 NGC247 observed-side rows opened | 0 | no observed-side empirical match |
| DO-K1 NGC247 residual or likelihood computations | 0 | no empirical verdict |
| Public DO-K1 NGC247 terminal closure records cited | 1 | Zenodo record `20798016` |
| Public bounded J2R representative no-go records cited | 1 | Zenodo record `20779214` |

Not counted here:

- blind-batch row counts without compact public filename/field locators,
- local NGC1003 materials without compact public capsule extraction,
- fixed-QUMOND sign-topology witnesses without a dedicated public capsule,
- packaging metrics such as file counts or matrix row counts.
