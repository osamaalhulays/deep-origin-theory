# Public References and Prior-Art Boundary

date: 2026-06-23
status: citation and prior-art support surface

This file is not a novelty proof. It is a reader-facing citation map that helps
separate three things:

```text
1. established outside literature
2. Deep Origin/QCT bounded internal results
3. open gates that are not yet achievements
```

## Primary Public Project Records

- Deep Origin public concept DOI: https://doi.org/10.5281/zenodo.20542921
- J2C/J2R result release: https://zenodo.org/records/20779214
- DO-K1 NGC 247 protocol amendment: https://zenodo.org/records/20794856
- DO-K1 NGC 247 terminal pre-prediction closure: https://zenodo.org/records/20798016
- Public GitHub mirror: https://github.com/osamaalhulays/deep-origin-theory

## External Modified-Gravity and MOND-Adjacent References

| topic | reference | why it matters here | boundary for this reader edition |
|---|---|---|---|
| AQUAL / nonlinear Poisson MOND | J. Bekenstein and M. Milgrom, 1984, "Does the missing mass problem signal the breakdown of Newtonian gravity?", Astrophysical Journal 286, 7; DOI: https://doi.org/10.1086/162570 | Baseline action-based nonrelativistic MOND comparator. | Deep Origin does not claim AQUAL-family defeat in this reader edition. |
| QUMOND | M. Milgrom, 2010, "Quasi-linear formulation of MOND", Monthly Notices of the Royal Astronomical Society 403, 886; DOI: https://doi.org/10.1111/j.1365-2966.2009.16184.x | Main quasi-linear MOND comparator and fixed-QUMOND lane context. | Fixed-QUMOND witnesses do not equal MOND-family defeat. |
| TeVeS | J. D. Bekenstein, 2004, "Relativistic gravitation theory for the modified Newtonian dynamics paradigm", Physical Review D 70, 083509; DOI: https://doi.org/10.1103/PhysRevD.70.083509 | Relativistic MOND reference point for metric/lensing claims. | Same-metric lensing remains a gate in Deep Origin rather than a closed triumph. |
| AeST / Skordis-Zlosnik relativistic MOND | C. Skordis and T. Zlosnik, 2021, "New Relativistic Theory for Modified Newtonian Dynamics", Physical Review Letters 127, 161302; arXiv: https://arxiv.org/abs/2007.00082; DOI: https://doi.org/10.1103/PhysRevLett.127.161302 | Shows a modern relativistic MOND route with cosmological ambitions. | Deep Origin does not claim stronger cosmology than this literature without a predictive admitted action. |
| Relativistic Khronon / DBI Khronon | "Relativistic Khronon Theory in agreement with Modified Newtonian Dynamics and Large-Scale Cosmology", arXiv: https://arxiv.org/abs/2404.06584 | Direct prior-art neighborhood for DO-K1 khronon/DBI comparisons. | DO-K1 is not claimed as a successful successor action after the boundary-authority closure. |
| Kinetic gravity braiding | C. Deffayet, O. Pujolas, I. Sawicki, A. Vikman, 2010, "Imperfect Dark Energy from Kinetic Gravity Braiding", JCAP 1010:026; arXiv: https://arxiv.org/abs/1008.0048; DOI: https://doi.org/10.1088/1475-7516/2010/10/026 | Prior-art class for kinetic braiding terminology and scalar-stress behavior. | J2/J2B underdetermination is not a no-go for the whole KGB literature. |
| K-mouflage | E. Babichev, C. Deffayet, R. Ziour, 2009, "k-Mouflage gravity", International Journal of Modern Physics D 18, 2147; arXiv: https://arxiv.org/abs/0905.2943; DOI: https://doi.org/10.1142/S0218271809016107 | Important control class for nonlinear scalar screening. | Deep Origin does not claim K-mouflage is exhausted. |
| Galileon k-mouflage MOND | E. Babichev, C. Deffayet, G. Esposito-Farese, 2011, "Improving relativistic MOND with Galileon k-mouflage", Physical Review D 84, 061502(R); arXiv: https://arxiv.org/abs/1106.2538; DOI: https://doi.org/10.1103/PhysRevD.84.061502 | Prior MOND-oriented k-mouflage construction. | Deep Origin scalar-route no-go statements remain route-specific. |
| Scalar Gauss-Bonnet dark energy | S. Nojiri, S. D. Odintsov, M. Sasaki, 2005, "Gauss-Bonnet dark energy", arXiv: https://arxiv.org/abs/hep-th/0504052 | Historical scalar/curvature-coupling context for old Rank-9 lineage references. | This reader edition does not claim a current source-governed tensor/GB effect. |
| Schwinger-Keldysh / closed-time-path formalism | J. Schwinger, 1961, "Brownian Motion of a Quantum Oscillator", Journal of Mathematical Physics 2, 407; DOI: https://doi.org/10.1063/1.1703727. L. V. Keldysh, 1965, "Diagram technique for nonequilibrium processes", Sov. Phys. JETP 20, 1018. E. Calzetta and B. L. Hu, 1987, "Closed time path functional formalism in curved spacetime", Physical Review D 35, 495; DOI: https://doi.org/10.1103/PhysRevD.35.495 | Baseline lineage for any future 2PI/CTP or nonequilibrium effective-action wording. | This reader edition does not claim a completed 2PI/CTP-derived gravitational action. |
| Dual-time / related mathematical time-structure work | M. Haj Yousef, related mathematical work associated with DOI: https://doi.org/10.3390/math14050853 | Corrects the author attribution for the public dual-time citation lane and keeps it separate from Osama Al-Hulays' Deep Origin materials. | This reference does not establish a Deep Origin physical state selector or a predictive gravitational action. |

## Reader-Safe Novelty Sentence

The reader-safe novelty claim is methodological and bounded:

```text
Deep Origin currently contributes a disciplined sequence of source-governed
locks, candidate-specific no-go surfaces, public pre-execution commitments,
and transparent negative closures. It does not yet contribute a completed
predictive successor action.
```

## Claims Not Licensed By These References

These references do not license the following public claims:

```text
Deep Origin has defeated MOND/QUMOND as a family.
Deep Origin has solved dark matter.
Deep Origin has achieved final cosmic closure.
Deep Origin has a unified predictively admitted action.
DO-K1 was observationally rejected by NGC247.
J2R failure kills all scalar-tensor gravity.
```
