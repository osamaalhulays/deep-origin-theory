# Reproducibility And Provenance Index

Status: `FINAL_READER_EDITION__NOT_PEER_REVIEWED`

This index separates archive integrity, provenance verification, calculation
reproduction, and independent replication.

## Verification Grades

| grade | meaning |
|---|---|
| `PROVENANCE_VERIFIED` | The cited public record, DOI, or package file can be located and inspected. |
| `CALCULATION_REPRODUCED` | A command or calculation was rerun from distributed inputs and matched the expected output. |
| `INDEPENDENTLY_REPLICATED` | A substantively independent party reproduced the result outside the author workflow. |

This reader edition mostly provides `PROVENANCE_VERIFIED` and package integrity
checks. It does not claim broad independent replication.

## Integrity Check

From this directory:

```bash
shasum -a 256 -c SHA256SUMS.txt
```

Expected result:

```text
all listed files OK
```

## Root Files

| file | role |
|---|---|
| `README.md` | reader front door and claim ceiling |
| `01_DEEP_ORIGIN_CURRENT_STATUS_SYNTHESIS_EN.pdf` | English synthesis PDF |
| `02_DEEP_ORIGIN_CURRENT_STATUS_SYNTHESIS_AR.pdf` | Arabic mirror PDF |
| `03_PUBLIC_CLAIM_EVIDENCE_MATRIX.csv` | headline-safe claim matrix |
| `04_PUBLIC_RESULTS_AND_NOGO_ATLAS.csv` | headline-safe result/no-go atlas |
| `05_PUBLIC_QUANTITATIVE_RESULTS_AT_A_GLANCE.md` | bounded quantitative summary |
| `07_PUBLIC_EVIDENCE_POINTER_REGISTRY.csv` | evidence ID registry |
| `08_PUBLIC_REPRODUCIBILITY_LEDGER.csv` | reproduction/control ledger |
| `09_PUBLIC_REFERENCES_AND_PRIOR_ART.md` | references and prior-art context |
| `10_READER_DOCUMENTATION.zip` | PDF build-source and provenance supplement |
| `11_DEFERRED_LOCAL_RESULTS_LEDGER_NOT_HEADLINE.csv` | non-headline local gains |

## What Can Be Reproduced From This Edition

- File integrity for this package.
- Reader navigation and claim ceilings.
- Public pointer mapping for DO-K1 terminal closure and J2R result release.
- Root package checksum verification.
- Separation between headline-safe public claims and deferred local gains.

## What Cannot Yet Be Reproduced From This Edition

- Full cold replay of every historical internal result.
- Complete theorem/proof-spine reconstruction for every local no-go.
- Full empirical rerun of all galaxy or blind-batch work.
- Independent replication of the scientific claims.
- Peer review or external endorsement.

## Cold Reader Gate

A cold reader should be able to answer:

1. What is currently claimed?
2. What is explicitly not claimed?
3. Which results are public and headline-safe?
4. Which results are deferred local gains?
5. Which rows are only `PROVENANCE_VERIFIED` rather than reproduced calculations?
6. What command checks file integrity?
