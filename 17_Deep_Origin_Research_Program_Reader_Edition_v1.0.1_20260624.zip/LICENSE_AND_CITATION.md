# License And Citation

Author: Osama Al-Hulays, Independent Researcher.

Recommended citation before final DOI assignment:

Al-Hulays, O. (2026). Deep Origin Research Program - Reader Edition v1.0.1.
Standalone reader-facing synthesis. Not peer reviewed.

License guidance:

- Original text, tables, and reader-edition metadata: CC BY 4.0 unless a later
  public record states otherwise.
- Code snippets or scripts, if distributed separately: use the repository code
  license stated in that package.
- Third-party papers, public datasets, and external records remain under their
  original licenses and citation requirements.

This reader edition does not transfer rights for third-party data or papers.
