# Changelog

## reader-edition-v1.0.1

- Converted RC5 into final standalone reader edition wording.
- Removed publication-hold and release-candidate text from reader-facing PDFs.
- Removed headline use of deferred results without compact public locators.
- Regenerated PDFs, manifest, SHA ledger, reader documentation supplement, and outer zip.

## reader-edition-v1.0.1

- Corrected the Arabic rendering of the author name to `أسامه الهليس`.
- No scientific claims, evidence ceilings, or public nonclaims changed.
