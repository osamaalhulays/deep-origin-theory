#!/usr/bin/env bash

set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: bash RUN_FAST_WITH_PACKET.sh /path/to/Deep_Origin_Theory_English_Packet_20260605" >&2
  exit 2
fi

RUNTIME_DIR="$(cd "$(dirname "$0")" && pwd)"
export DEEP_ORIGIN_PACKET_DIR="$1"

exec "$RUNTIME_DIR/scripts/REVIEWER_AUDIT_BUNDLE_V1/RUN_AUDIT_FAST.sh"

