#!/usr/bin/env python3
"""Verify the public J2C pre-execution lock without executing J2C."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path


J2C_ROOT = Path(
    "00_READ_FIRST/QCT_J2C_BACKGROUND_ASSISTED_KINETIC_BRAIDING_SCALING_GATE_V1"
)

REQUIRED_PRIMARY_VERDICTS = {
    "J2C_BACKGROUND_ASSISTED_TOTAL_SCALING_ADMITTED__LENSING_STABILITY_GATE_NEXT",
    "J2C_BACKGROUND_COEFFICIENTS_ONLY__TOTAL_PHYSICAL_ACCELERATION_SCALING_NO_GO",
    "J2C_REQUIRES_DATA_TUNED_BACKGROUND__REJECT",
    "J2C_ACTION_REPRESENTATIVE_NOT_FROZEN__NO_PREDICTIVE_ADMISSION",
    "J2C_BACKGROUND_BRANCH_UNDERDETERMINED__NO_PREDICTIVE_ADMISSION",
    "J2C_PHYSICAL_METRIC_COMPLETION_INCOMPLETE__NO_BRANCH_VERDICT",
}


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet-dir", required=True, type=Path)
    parser.add_argument("--capsule-dir", required=True, type=Path)
    args = parser.parse_args()

    packet_root = args.packet_dir / J2C_ROOT
    capsule_root = args.capsule_dir

    gate_status = load_json(packet_root / "05_OUTPUTS/J2C_GATE_STATUS.json")
    contract = load_json(packet_root / "07_VERDICT_CONTRACT/J2C_VERDICT_CONTRACT.json")
    capsule_status = load_json(capsule_root / "05_INTEGRITY/PREEXECUTION_STATUS.json")

    packet_action_lock = packet_root / "01_ACTION_BACKGROUND_LOCK/J2C_ACTION_BACKGROUND_LOCK.md"
    capsule_action_lock = capsule_root / "02_J2C_LOCK/J2_ACTION_IDENTITY_LOCK.md"
    packet_table = packet_root / "03_SCALING_TARGET/J2C_TOTAL_PHYSICAL_ACCELERATION_EXPONENT_TABLE_TEMPLATE.csv"
    capsule_table = capsule_root / "03_EXECUTION/J2C_TOTAL_PHYSICAL_ACCELERATION_EXPONENT_TABLE_TEMPLATE.csv"

    packet_rows = read_csv_rows(packet_table)
    capsule_rows = read_csv_rows(capsule_table)

    packet_primary = set(contract.get("primary_scaling_verdicts", []))
    capsule_primary = set(capsule_status.get("locked_primary_verdicts", []))

    checks = {
        "packet_status_present": gate_status.get("status") == "open_governed_next_gate",
        "packet_action_class_grade": gate_status.get("action_lock_grade")
        == "J2C_STRUCTURAL_ACTION_CLASS_PREREGISTRATION",
        "packet_exact_representative_not_frozen": gate_status.get(
            "exact_action_representative_frozen"
        )
        is False,
        "packet_development_informed_declared": gate_status.get(
            "development_informed_by_prior_galaxy_results"
        )
        is True,
        "packet_no_galaxy_rows_ingested": gate_status.get(
            "galaxy_rows_ingested_in_j2c_execution"
        )
        is False,
        "packet_primary_verdicts_locked": packet_primary == REQUIRED_PRIMARY_VERDICTS,
        "capsule_primary_verdicts_locked": capsule_primary == REQUIRED_PRIMARY_VERDICTS,
        "capsule_no_result_known": capsule_status.get("j2c_result_known") is False,
        "capsule_exact_representative_not_frozen": capsule_status.get(
            "exact_action_representative_frozen"
        )
        is False,
        "capsule_no_galaxy_rows_ingested": capsule_status.get(
            "galaxy_rows_ingested_in_j2c_execution"
        )
        is False,
        "packet_exponent_table_tbd": all(
            any(value == "TBD" for value in row.values()) for row in packet_rows
        ),
        "capsule_exponent_table_tbd": all(
            any(value == "TBD" for value in row.values()) for row in capsule_rows
        ),
        "capsule_publication_commitment_present": (
            capsule_root / "06_BOUNDARY/PUBLICATION_COMMITMENT.md"
        ).exists(),
        "capsule_no_result_boundary_present": (
            capsule_root / "06_BOUNDARY/NO_RESULT_KNOWN.md"
        ).exists(),
    }

    result = {
        "object": "VERIFY_J2C_PREEXECUTION_LOCK",
        "all_checks_pass": all(checks.values()),
        "checks": checks,
        "packet_action_lock_sha256": sha256(packet_action_lock),
        "capsule_action_lock_sha256": sha256(capsule_action_lock),
        "verdict": "J2C_PREEXECUTION_LOCK_VERIFIED"
        if all(checks.values())
        else "J2C_PREEXECUTION_LOCK_CHECK_FAILED",
    }

    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["all_checks_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

