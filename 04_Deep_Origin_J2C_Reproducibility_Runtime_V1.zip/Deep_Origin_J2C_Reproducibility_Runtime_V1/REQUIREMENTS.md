# Runtime Requirements

The reviewer audit runtime expects a standard Unix-like shell environment with:

- `bash`
- `python3`
- `node`
- `unzip`
- `shasum`
- common POSIX utilities: `find`, `grep`, `mktemp`, `cp`, `mkdir`

No private credentials are required. Optional external author-supplied raw data
archives can be supplied through the existing environment variables documented
inside the reviewer audit scripts, but the default public audit path does not
require them.

