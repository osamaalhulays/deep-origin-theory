#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import tempfile
from pathlib import Path


DIRECTF_VERDICT = (
    "DISTINGUISHED_COSMOLOGY_CERT_DOMAIN_CLOSURE_MATERIALIZED__"
    "DIRECTF_SCOPE_FROZEN__CLASS_UPGRADE_BLOCKED"
)
FRONTIER_VERDICT = (
    "DISTINGUISHED_COSMOLOGY_COMPONENT_TRUE_ENCLOSURE_FRONTIER_MATERIALIZED__"
    "STATE_TUBE_BASELINE_CONFIRMED__DIRECTF_X_SIGN_NOT_YET_OPENED"
)


def run_python(script: Path, cwd: Path) -> str:
    completed = subprocess.run(
        ["python3", str(script)],
        cwd=str(cwd),
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def load_json(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet-dir", required=True)
    args = parser.parse_args()

    source_packet = Path(args.packet_dir).resolve()

    with tempfile.TemporaryDirectory(prefix="deep_origin_cosmology_probe_") as tmp:
        cold_root = Path(tmp) / source_packet.name
        shutil.copytree(source_packet, cold_root)

        proof_spine = cold_root / "00_READ_FIRST" / "CURRENT_DISTINGUISHED_COSMOLOGY_PROOF_SPINE_V1"
        directf = cold_root / "00_READ_FIRST" / "DISTINGUISHED_COSMOLOGY_CERT_DOMAIN_CLOSURE_AND_DIRECTF_SCOPE_ADJUDICATION_V1"
        frontier = cold_root / "00_READ_FIRST" / "DISTINGUISHED_COSMOLOGY_COMPONENT_TRUE_ENCLOSURE_FRONTIER_V1"

        proof_stdout = run_python(
            proof_spine / "03_RUN" / "verify_distinguished_cosmology_proof_spine.py",
            cold_root,
        )

        run_python(
            directf / "03_RUN" / "build_distinguished_cosmology_directf_scope_object.py",
            cold_root,
        )
        directf_stdout = run_python(
            directf / "03_RUN" / "verify_distinguished_cosmology_directf_scope_object.py",
            cold_root,
        )

        run_python(
            frontier / "03_RUN" / "build_distinguished_cosmology_component_true_enclosure_frontier_object.py",
            cold_root,
        )
        frontier_stdout = run_python(
            frontier / "03_RUN" / "verify_distinguished_cosmology_component_true_enclosure_frontier_object.py",
            cold_root,
        )

        directf_verdict = load_json(directf / "04_OUTPUTS" / "verdict.json")
        directf_summary = load_json(directf / "04_OUTPUTS" / "status_summary.json")
        directf_manifest = load_json(directf / "04_OUTPUTS" / "input_manifest.json")
        frontier_verdict = load_json(frontier / "04_OUTPUTS" / "verdict.json")
        frontier_summary = load_json(frontier / "04_OUTPUTS" / "status_summary.json")
        frontier_manifest = load_json(frontier / "04_OUTPUTS" / "input_manifest.json")

        manifest_paths = []
        for manifest in (directf_manifest, frontier_manifest):
            for key, value in manifest.items():
                if key.endswith("_path"):
                    manifest_paths.append(str(value))

        absolute_paths = [path for path in manifest_paths if path.startswith("/")]
        author_user = "i" + "mac"
        author_marker = "/" + "/".join(("Users", author_user))
        author_paths = [path for path in manifest_paths if author_marker in path]

        checks = {
            "proof_spine_selftest": proof_stdout == "DISTINGUISHED_COSMOLOGY_PROOF_SPINE_VERIFIED",
            "directf_verdict": directf_verdict.get("verdict") == DIRECTF_VERDICT,
            "directf_scope": directf_verdict.get("claim_scope") == "current_loaded_frozen_trajectory_plus_Aj_cert",
            "directf_trajectory_status_scoped": (
                directf_verdict.get("trajectory_closure_status")
                == "cert_domain_closure_materialized__stronger_validated_trajectory_enclosure_pending"
                and "stronger source-owned trajectory enclosure"
                in str(directf_verdict.get("trajectory_closure_status_scope", ""))
                and "does not demote"
                in str(directf_verdict.get("trajectory_closure_status_scope", ""))
            ),
            "directf_no_class_upgrade": directf_summary.get("class_source_upgrade_claimed") is False,
            "frontier_verdict": frontier_verdict.get("verdict") == FRONTIER_VERDICT,
            "frontier_state_tubes": frontier_verdict.get("state_tube_rows_count") == 301,
            "frontier_no_component_true_enclosure": frontier_summary.get("component_true_enclosure_not_yet_materialized") is True,
            "manifest_paths_are_package_relative": not absolute_paths and not author_paths,
        }

        payload = {
            "object": "DISTINGUISHED_COSMOLOGY_PROOF_SPINE_COLD_REVIEW_PROBE_20260619",
            "all_checks_pass": all(checks.values()),
            "checks": checks,
            "stdout": {
                "proof_spine": proof_stdout,
                "directf": directf_stdout,
                "frontier": frontier_stdout,
            },
            "directf_verdict": directf_verdict.get("verdict"),
            "frontier_verdict": frontier_verdict.get("verdict"),
            "manifest_path_count": len(manifest_paths),
            "absolute_manifest_paths": absolute_paths,
            "author_manifest_paths": author_paths,
        }

    print(json.dumps(payload, indent=2, sort_keys=True))
    if not payload["all_checks_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
