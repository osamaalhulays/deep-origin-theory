#!/usr/bin/env python3
import argparse
import hashlib
import json
from pathlib import Path


CAPSULE_REL = Path(
    "artifacts/SUPPLEMENTAL_FULL_GAIN_PROVENANCE_ARCHIVE_20260619/"
    "06_l2_late_diagnostic_object_recovery_20260619"
)
MATRIX_REL = Path(
    "artifacts/SUPPLEMENTAL_FULL_GAIN_PROVENANCE_ARCHIVE_20260619/"
    "GAIN_COVERAGE_MATRIX.tsv"
)

REQUIRED_PATTERNS = {
    "procurve_rows": "PROCURVE",
    "rowcount_reconciliation": "ROWCOUNT_RECONCILIATION",
    "failure_anatomy": "FAILURE_ANATOMY",
    "heterogeneity": "HETEROGENEITY",
    "source_geometry": "SOURCE_GEOMETRY",
    "nonlocal_evaluator": "NONLOCAL_SOURCE_COMPACTNESS_NUMERIC_EVALUATOR",
    "six_relation": "SIX_RELATION",
    "federated_rows": "FEDERATED",
    "evidence_grade": "EVIDENCE_GRADE",
    "final_seal": "FINAL_SEAL",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_sha_ledger(path: Path):
    entries = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        digest, rel = line.split(maxsplit=1)
        entries.append((digest, rel))
    return entries


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet-dir", required=True)
    args = parser.parse_args()

    packet_dir = Path(args.packet_dir).resolve()
    capsule_dir = packet_dir / CAPSULE_REL
    source_docs = capsule_dir / "source_docs"
    source_tools = capsule_dir / "source_tools"
    status_path = capsule_dir / "CAPSULE_STATUS.json"
    sha_path = capsule_dir / "SHA256SUMS.txt"
    matrix_path = packet_dir / MATRIX_REL
    front_note = (
        packet_dir
        / "00_READ_FIRST/CURRENT_L2_LATE_DIAGNOSTIC_OBJECT_LEVEL_RECOVERY_AND_EG2_NO_CLAIM_BOUNDARY_NOTE_20260619.md"
    )
    start_current = packet_dir / "00_READ_FIRST/START_HERE_FIRST.md"
    start_stale = packet_dir / "00_READ_FIRST/START_HERE_FIRST 2.md"
    start_archived = (
        packet_dir
        / "artifacts/historical_superseded_navigation_20260619/START_HERE_FIRST_20260605_SUPERSEDED.md"
    )
    active_board = packet_dir / "artifacts/debt_board_20260530/ACTIVE_TARGET_BOARD_20260610.md"
    crosswalk = packet_dir / "artifacts/debt_board_20260530/GOAL_BANK_TO_FULL_SCORE_CROSSWALK_20260610.md"

    source_doc_files = sorted(p for p in source_docs.glob("*") if p.is_file())
    source_tool_files = sorted(p for p in source_tools.glob("*") if p.is_file())
    names = "\n".join(p.name for p in source_doc_files + source_tool_files)

    status = json.loads(status_path.read_text(encoding="utf-8"))
    matrix_text = matrix_path.read_text(encoding="utf-8")
    start_text = start_current.read_text(encoding="utf-8")
    board_text = active_board.read_text(encoding="utf-8")
    crosswalk_text = crosswalk.read_text(encoding="utf-8")

    family_presence = {
        label: pattern in names for label, pattern in REQUIRED_PATTERNS.items()
    }

    sha_entries = read_sha_ledger(sha_path)
    sha_clean = True
    sha_failures = []
    for expected_digest, rel in sha_entries:
        candidate = capsule_dir / rel
        if not candidate.exists():
            sha_clean = False
            sha_failures.append({"path": rel, "reason": "missing"})
            continue
        actual_digest = sha256(candidate)
        if actual_digest != expected_digest:
            sha_clean = False
            sha_failures.append(
                {"path": rel, "expected": expected_digest, "actual": actual_digest}
            )

    checks = {
        "capsule_exists": capsule_dir.is_dir(),
        "source_docs_count_is_238": len(source_doc_files) == 238,
        "source_tools_count_is_25": len(source_tool_files) == 25,
        "status_declares_object_recovery": status.get("status")
        == "object_level_sources_recovered__eg2_no_claim_boundary_preserved",
        "status_preserves_no_claim_ceiling": "no L2 victory claim"
        in status.get("claim_ceiling", []),
        "all_required_families_present": all(family_presence.values()),
        "capsule_sha_clean": sha_clean,
        "gain_matrix_updated": (
            "l2_late_diagnostic_eg2_no_claim" in matrix_text
            and "object_level_source_recovery_no_claim" in matrix_text
            and "06_l2_late_diagnostic_object_recovery_20260619" in matrix_text
        ),
        "front_note_present": front_note.exists(),
        "start_here_points_to_l2_recovery_note": front_note.name in start_text,
        "stale_start_removed_from_read_first": not start_stale.exists(),
        "stale_start_archived_with_supersession_banner": (
            start_archived.exists()
            and "HISTORICAL__SUPERSEDED_BY_20260619_START_HERE_FIRST"
            in start_archived.read_text(encoding="utf-8")
        ),
        "active_board_historical": "HISTORICAL__SUPERSEDED_BY_20260619_CANONICAL_BANK"
        in board_text,
        "crosswalk_historical": "HISTORICAL__SUPERSEDED_BY_20260619_FINAL_COSMIC_CLOSURE_BANK"
        in crosswalk_text,
    }

    payload = {
        "surface": "l2_late_object_recovery_and_navigation_cleanup_probe",
        "all_checks_pass": all(checks.values()),
        "capsule": {
            "path": str(CAPSULE_REL),
            "source_docs_count": len(source_doc_files),
            "source_tools_count": len(source_tool_files),
            "family_presence": family_presence,
            "sha_entry_count": len(sha_entries),
            "sha_failures": sha_failures,
        },
        "checks": checks,
    }
    print(json.dumps(payload, indent=2, sort_keys=True))

    if not payload["all_checks_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
