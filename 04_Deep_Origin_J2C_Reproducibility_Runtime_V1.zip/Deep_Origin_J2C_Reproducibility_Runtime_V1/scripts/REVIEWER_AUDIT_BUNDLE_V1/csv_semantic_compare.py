#!/usr/bin/env python3

from __future__ import annotations

import csv
import hashlib
import math
from itertools import zip_longest
from pathlib import Path


def binary_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _float_cell_match(left: str, right: str, *, abs_tol: float) -> bool:
    try:
        left_value = float(left)
        right_value = float(right)
    except ValueError:
        return False

    if math.isnan(left_value) and math.isnan(right_value):
        return True
    if math.isinf(left_value) or math.isinf(right_value):
        return left_value == right_value
    return math.isclose(left_value, right_value, rel_tol=0.0, abs_tol=abs_tol)


def csv_files_match(left_path: Path, right_path: Path, *, abs_tol: float = 1e-12) -> bool:
    if binary_sha256(left_path) == binary_sha256(right_path):
        return True

    with left_path.open("r", encoding="utf-8", newline="") as left_handle, right_path.open(
        "r", encoding="utf-8", newline=""
    ) as right_handle:
        left_reader = csv.reader(left_handle)
        right_reader = csv.reader(right_handle)

        for left_row, right_row in zip_longest(left_reader, right_reader, fillvalue=None):
            if left_row is None or right_row is None:
                return False
            if len(left_row) != len(right_row):
                return False
            for left_cell, right_cell in zip(left_row, right_row):
                if left_cell == right_cell:
                    continue
                if not _float_cell_match(left_cell, right_cell, abs_tol=abs_tol):
                    return False

    return True
