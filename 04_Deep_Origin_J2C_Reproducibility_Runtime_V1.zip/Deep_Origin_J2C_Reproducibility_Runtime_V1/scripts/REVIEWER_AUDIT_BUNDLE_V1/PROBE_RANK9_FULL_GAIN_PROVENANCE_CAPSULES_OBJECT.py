#!/usr/bin/env python3
import argparse
import csv
import json
import subprocess
import tempfile
from pathlib import Path


ARCHIVE_REL = Path("artifacts/SUPPLEMENTAL_FULL_GAIN_PROVENANCE_ARCHIVE_20260619")

REQUIRED_CAPSULES = {
    "07_rank9_tensor_gb_full_provenance_capsule_20260619": [
        "sources/QCT_RANK9_TENSOR_TT_GB_FREQUENCY_GB_PREIBP_RAW_ROW_ID_MATERIALIZATION_NO_DATA_20260501_STATUS_V1.json",
        "sources/QCT_RANK9_TENSOR_TT_GB_FREQUENCY_GB_PREIBP_RAW_ROW_ID_MATERIALIZATION_NO_DATA_20260501_RAW_ROW_ID_ROWS_V1.tsv",
        "sources/QCT_RANK9_TENSOR_TT_GB_FREQUENCY_GB_PREIBP_ROW_CONTENT_MATERIALIZATION_NO_DATA_20260501_STATUS_V1.json",
        "sources/QCT_RANK9_TENSOR_TT_GB_FREQUENCY_GB_PREIBP_ROW_CONTENT_MATERIALIZATION_NO_DATA_20260501_ASSEMBLED_GB_CONTENT_ROWS_V1.tsv",
        "sources/QCT_RANK9_TENSOR_GB_IDENTITY_LEVEL_FINAL_CLOSURE_NO_DATA_20260501_STATUS_V1.json",
        "sources/QCT_RANK9_TENSOR_GB_IDENTITY_LEVEL_FINAL_CLOSURE_NO_DATA_20260501.md",
        "sources/QCT_RANK9_TENSOR_GB_IDENTITY_LEVEL_FINAL_CLOSURE_NO_DATA_20260501_CHECKPOINT_SUMMARY_ROWS_V1.tsv",
        "sources/QCT_RANK9_TENSOR_TT_GB_CHECKPOINT_B_PREIBP_RAW_ROW_ID_CLOSURE_NO_DATA_20260501_STATUS_V1.json",
        "sources/QCT_RANK9_TENSOR_TT_GB_CHECKPOINT_C_POSTIBP_VARIABLE_F_CLOSURE_NO_DATA_20260501_POSTIBP_ROWS_V1.tsv",
        "sources/QCT_RANK9_TENSOR_TT_GB_FREQUENCY_GB_DELTA_COEFFICIENT_FORMULA_ROWS_NO_DATA_20260501_DELTA_COEFFICIENT_FORMULA_ROWS_V1.tsv",
        "sources/QCT_RANK9_TENSOR_TT_GB_FREQUENCY_COEFFICIENT_NUMERIC_ROWS_NO_DATA_20260501_SYMBOLIC_FORMULA_ROWS_V1.tsv",
        "sources/QCT_RANK9_TENSOR_TT_GB_FREQUENCY_COEFFICIENT_DERIVATIVE_ROWS_NO_DATA_20260501_DERIVATIVE_POLICY_ROWS_V1.tsv",
        "sources/QCT_RANK9_TENSOR_TT_MODE_EFFECTIVE_FREQUENCY_SQUARED_NUMERIC_HOST_NO_DATA_20260501_DELTA_OMEGA_GB_IDENTITY_ROWS_V1.tsv",
        "sources/QCT_RANK9_TENSOR_TT_GB_CHECKPOINT_F_OMEGA_EFF_IDENTITY_CLOSURE_NO_DATA_20260501_NONCLAIM_GUARD_ROWS_V1.tsv",
    ],
    "08_rank9_riemann_curvature_rowwise_derivation_capsule_20260619": [
        "sources/QCT_RANK9_FLRW_BACKGROUND_RIEMANN_COMPONENT_ROWS_NO_DATA_20260501_RIEMANN_COMPONENT_ROWS_V1.tsv",
        "sources/QCT_RANK9_FLRW_DELTA2_RIEMANN_0I0J_TT_ROWS_NO_DATA_20260501_DELTA2_R0I0J_TT_ROWS_V1.tsv",
        "sources/QCT_RANK9_FLRW_DELTA2_RIEMANN_0IJK_TT_ROWS_NO_DATA_20260501_AUDIT_ROWS_V1.tsv",
        "sources/QCT_RANK9_FLRW_DELTA2_RIEMANN_IJKL_TT_ROWS_NO_DATA_20260501_CONTRACTION_READINESS_ROWS_V1.tsv",
        "sources/QCT_RANK9_FLRW_SAME_ACTION_PHI_BAR_DELTA2_GB_TT_RIEMANN_SQUARED_ROWS_NO_DATA_20260501.md",
        "sources/QCT_RANK9_FLRW_SAME_ACTION_PHI_BAR_DELTA2_GB_TT_RICCI_SQUARED_ROWS_NO_DATA_20260501_BACKGROUND_RICCI_ROWS_V1.tsv",
        "sources/QCT_RANK9_FLRW_SAME_ACTION_PHI_BAR_DELTA2_GB_TT_SCALAR_CURVATURE_SQUARED_ROWS_NO_DATA_20260501_SECOND_ORDER_R_ROWS_V1.tsv",
        "sources/QCT_RANK9_TENSOR_TT_GB_FREQUENCY_RIEMANN2_DELTAR_DELTAR_PRODUCT_PAIR_PAYLOAD_ROWS_NO_DATA_20260501_PRODUCT_PAIR_PAYLOAD_ROWS_V1.tsv",
        "sources/QCT_RANK9_TENSOR_TT_GB_FREQUENCY_RICCI2_DELTARICCI_DELTARICCI_PRODUCT_PAIR_PAYLOAD_ROWS_NO_DATA_20260501_STATUS_V1.json",
        "sources/QCT_RANK9_TENSOR_TT_GB_FREQUENCY_DELTA_C_M_GB_RIEMANN2_H_H_N_TT_TENSOR_CONTRACTION_NORMALIZATION_NO_DATA_20260501.md",
    ],
    "09_rank9d_anchor_appeal_and_gb_background_forensics_capsule_20260619": [
        "sources/QCT_RANK9D_EXTERNAL_ANCHORED_PANTHEON_REEVALUATION_20260501_STATUS_V1.json",
        "sources/QCT_RANK9D_EXTERNAL_ABSOLUTE_ANCHOR_APPEAL_GATE_20260501_STATUS_V1.json",
        "sources/QCT_RANK9D_EXTERNAL_ABSOLUTE_ANCHOR_POLICY_20260501_POLICY_ROWS_V1.tsv",
        "sources/QCT_RANK9_POST_EXTERNAL_ANCHOR_APPEAL_FINAL_CLOSURE_CARD_20260501_ROWS_V1.tsv",
        "sources/QCT_RANK9_GB_BACKGROUND_HUBBLE_FLOW_PREFLIGHT_NO_DATA_20260501.md",
        "sources/QCT_RANK9_GB_BACKGROUND_HUBBLE_FLOW_PREFLIGHT_NO_DATA_20260501_BACKGROUND_EQUATION_ROWS_V1.tsv",
        "sources/QCT_RANK9_GB_BACKGROUND_STAGE5_PANTHEON_MODELVECTOR_NO_FIT_20260501_BACKGROUND_OBSERVABLE_ROWS_V1.tsv",
        "sources/QCT_RANK9_GB_BACKGROUND_STAGE6_PANTHEON_FULL_COVARIANCE_EVALUATION_NO_FIT_20260501.md",
        "sources/QCT_RANK9_GB_BACKGROUND_STAGE6_PANTHEON_FULL_COVARIANCE_EVALUATION_NO_FIT_20260501_OFFSET_DIAGNOSTIC_ROWS_V1.tsv",
    ],
    "10_rank9_active19_c4_guard_sidecar_20260619": [
        "sources/QCT_OBSERVER_19_MANIFEST_SHELL_READOUT_FREEZE_20260430_STATUS_V1.json",
        "sources/QCT_OBSERVER_19_EVENT_REALIZATION_SLOT_BINDING_AMENDMENT_20260430_STATUS_V1.json",
        "sources/QCT_RANK9D_C4_CUBIC_ORIENTATION_GUARD_INTAKE_20260501_STATUS_V1.json",
    ],
}

REQUIRED_GAIN_IDS = {
    "rank9_tensor_gb_full_provenance_capsule",
    "rank9_riemann_curvature_rowwise_derivation_capsule",
    "rank9d_anchor_appeal_and_gb_background_forensics_capsule",
    "rank9_active19_c4_guard_sidecar",
}

REQUIRED_FRONT_NOTES = [
    "00_READ_FIRST/CURRENT_RANK9_TENSOR_GB_AND_RIEMANN_PROVENANCE_RECONCILIATION_NOTE_20260619.md",
    "00_READ_FIRST/KEYSTONE_I_CROSS_FRONT_CANONICAL_MAP_BOUNDARY_NOTE_20260619.md",
    "00_READ_FIRST/KEYSTONE_II_WHITE_LAW_KERNEL_SCOPE_GUARD_NOTE_20260619.md",
    "02_B_Rank9/B_SHELF_SUPERSESSION_NOTE_20260619.md",
]


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def run_sha_check(capsule_dir: Path):
    completed = subprocess.run(
        ["shasum", "-a", "256", "-c", "SHA256SUMS.txt"],
        cwd=capsule_dir,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    ok_lines = [line for line in completed.stdout.splitlines() if line.endswith(": OK")]
    return {
        "exit_code": completed.returncode,
        "ok_line_count": len(ok_lines),
        "all_ok": completed.returncode == 0 and bool(ok_lines),
    }


def read_gain_ids(matrix_path: Path):
    with matrix_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        return {row.get("gain_id") for row in reader}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet-dir", required=True)
    args = parser.parse_args()

    packet_dir = Path(args.packet_dir).resolve()

    with tempfile.TemporaryDirectory(prefix="rank9_gain_capsules_cold_") as tmp:
        cold_root = Path(tmp)
        cold_packet = cold_root / packet_dir.name
        subprocess.run(["cp", "-R", str(packet_dir), str(cold_root)], check=True)

        archive = cold_packet / ARCHIVE_REL
        capsule_results = {}
        all_capsules_pass = True

        for capsule_id, required_files in REQUIRED_CAPSULES.items():
            capsule_dir = archive / capsule_id
            status_path = capsule_dir / "CAPSULE_STATUS.json"
            status = load_json(status_path) if status_path.exists() else {}
            missing = [
                item for item in required_files
                if not (capsule_dir / item).exists()
            ]
            sha_result = run_sha_check(capsule_dir) if (capsule_dir / "SHA256SUMS.txt").exists() else {
                "exit_code": None,
                "ok_line_count": 0,
                "all_ok": False,
            }
            passed = (
                capsule_dir.exists()
                and status.get("all_must_have_present") is True
                and status.get("no_claim_upgrade") is True
                and (
                    capsule_id != "07_rank9_tensor_gb_full_provenance_capsule_20260619"
                    or status.get("checkpoint_sequence_coverage", {}).get(
                        "A_equivalent_preIBP_raw_row_materialization"
                    ) is True
                )
                and not missing
                and sha_result["all_ok"] is True
            )
            all_capsules_pass = all_capsules_pass and passed
            capsule_results[capsule_id] = {
                "passed": passed,
                "source_file_count": status.get("source_file_count"),
                "tool_file_count": status.get("tool_file_count"),
                "status_all_must_have_present": status.get("all_must_have_present"),
                "checkpoint_a_reading": status.get("checkpoint_a_reading"),
                "missing_required_files": missing,
                "sha_check": sha_result,
            }

        gain_ids = read_gain_ids(archive / "GAIN_COVERAGE_MATRIX.tsv")
        missing_gain_ids = sorted(REQUIRED_GAIN_IDS - gain_ids)

        missing_front_notes = [
            rel for rel in REQUIRED_FRONT_NOTES
            if not (cold_packet / rel).exists()
        ]

        manifest = load_json(archive / "MANIFEST.json")
        manifest_sections = set(manifest.get("sections", []))
        missing_manifest_sections = sorted(set(REQUIRED_CAPSULES) - manifest_sections)

        checks = {
            "all_capsules_present_and_sha_clean": all_capsules_pass,
            "coverage_matrix_contains_rank9_capsules": not missing_gain_ids,
            "front_notes_present": not missing_front_notes,
            "archive_manifest_lists_capsules": not missing_manifest_sections,
            "no_claim_upgrade_status": all(
                result["passed"] for result in capsule_results.values()
            ),
        }

        payload = {
            "surface": "rank9_full_gain_provenance_capsules_probe",
            "all_checks_pass": all(checks.values()),
            "checks": checks,
            "capsules": capsule_results,
            "missing_gain_ids": missing_gain_ids,
            "missing_front_notes": missing_front_notes,
            "missing_manifest_sections": missing_manifest_sections,
        }

    print(json.dumps(payload, indent=2, sort_keys=True))
    if not payload["all_checks_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
