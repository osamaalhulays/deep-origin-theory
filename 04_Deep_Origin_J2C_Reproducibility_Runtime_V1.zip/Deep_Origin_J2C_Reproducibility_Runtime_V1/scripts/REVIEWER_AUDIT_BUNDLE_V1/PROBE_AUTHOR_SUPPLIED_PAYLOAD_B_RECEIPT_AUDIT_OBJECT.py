#!/usr/bin/env python3

from __future__ import annotations

import argparse
import json
import subprocess
import tempfile
from pathlib import Path


OBJECT_DIR_NAME = "AUTHOR_SUPPLIED_PAYLOAD_B_RECEIPT_AUDIT_OBJECT_V1"


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def stable_zip_fingerprint(payload: dict) -> dict:
    fields = ("filename", "sha256", "bytes", "member_file_count")
    return {
        key: {field: payload.get(key, {}).get(field) for field in fields}
        for key in ("observed_zip", "baryons_zip")
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet-dir", required=True)
    parser.add_argument("--observed-zip")
    parser.add_argument("--baryons-zip")
    args = parser.parse_args()

    packet_dir = Path(args.packet_dir).resolve()
    object_dir = packet_dir / "00_READ_FIRST" / OBJECT_DIR_NAME
    outputs_dir = object_dir / "04_OUTPUTS"

    raw_hashes = load_json(outputs_dir / "RAW_ZIP_HASHES.json")
    schema_lock = load_json(outputs_dir / "COLUMN_SCHEMA_LOCK.json")
    summary = load_json(outputs_dir / "PAYLOAD_INTAKE_SUMMARY.json")
    flags = load_json(outputs_dir / "DOWNSTREAM_HYGIENE_FLAGS.json")
    receipt_text = (object_dir / "01_BACKBONE" / "AUTHOR_CHANNEL_RECEIPT.md").read_text(
        encoding="utf-8", errors="ignore"
    )

    bundled_probe = {
        "receipt_mentions_direct_author_payload": "direct-author payload supplied to the user"
        in receipt_text,
        "payload_b_admitted": summary.get("payload_b_admitted") is True,
        "g6_closed": summary.get("g6_closed") is True,
        "d7_closed_at_bounded_scope": summary.get("d7_closed_at_bounded_scope") is True,
        "same_source_coherence_survives": summary.get("same_source_coherence_survives") is True,
        "matched_pair_count": summary.get("matched_pair_count") == 49,
        "observed_row_count": summary.get("observed_row_count") == 1082,
        "baryonic_row_count": summary.get("baryonic_row_count") == 4850,
        "observed_header_locked": schema_lock.get("observed", {}).get("observed_headers")
        == ["rad_kpc vcirc_km/s e_vcirc"],
        "baryonic_header_locked": schema_lock.get("baryons", {}).get("observed_headers")
        == [
            "rad_kpc VHI VH2 Vstars eVstars_low eVstars_high Vbulge eVbulge_low eVbulge_high"
        ],
        "raw_payload_not_republished": flags.get("raw_direct_author_payload_republished_inside_packet")
        is False,
    }

    payload = {
        "surface": "author_supplied_payload_b_receipt_audit_probe",
        "object_dir": str(object_dir),
        "accepted_mode": "bundled_receipt_manifest_and_schema_lock",
        "bundled_probe": bundled_probe,
        "all_bundled_checks_pass": all(bundled_probe.values()),
        "replay_check": {
            "attempted": False,
            "matched_bundled_outputs": None,
        },
    }

    if args.observed_zip and args.baryons_zip:
        replay_script = object_dir / "03_RUN" / "REPRODUCE_AUTHOR_SUPPLIED_PAYLOAD_RECEIPT.py"
        with tempfile.TemporaryDirectory(prefix="author_supplied_payload_replay_") as temp_dir:
            replay_dir = Path(temp_dir)
            subprocess.run(
                [
                    "python3",
                    str(replay_script),
                    "--observed-zip",
                    str(Path(args.observed_zip).resolve()),
                    "--baryons-zip",
                    str(Path(args.baryons_zip).resolve()),
                    "--output-dir",
                    str(replay_dir),
                ],
                check=True,
                text=True,
                capture_output=True,
            )
            replay_hashes = load_json(replay_dir / "RAW_ZIP_HASHES.json")
            replay_schema = load_json(replay_dir / "COLUMN_SCHEMA_LOCK.json")
            replay_summary = load_json(replay_dir / "PAYLOAD_INTAKE_SUMMARY.json")
        payload["accepted_mode"] = "bundled_receipt_manifest_and_external_raw_replay"
        payload["replay_check"] = {
            "attempted": True,
            "matched_bundled_outputs": (
                stable_zip_fingerprint(replay_hashes) == stable_zip_fingerprint(raw_hashes)
                and replay_schema == schema_lock
                and replay_summary == summary
            ),
        }

    print(json.dumps(payload, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
