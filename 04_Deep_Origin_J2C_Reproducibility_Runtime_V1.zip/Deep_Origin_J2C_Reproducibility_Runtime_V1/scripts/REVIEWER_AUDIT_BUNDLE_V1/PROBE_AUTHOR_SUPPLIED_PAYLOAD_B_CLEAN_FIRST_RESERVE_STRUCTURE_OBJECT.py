#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
import tempfile
from pathlib import Path

from csv_semantic_compare import csv_files_match


OBJECT_DIR_NAME = "AUTHOR_SUPPLIED_PAYLOAD_B_CLEAN_FIRST_RESERVE_STRUCTURE_OBJECT_V1"
SOURCE_OBJECT_DIR_NAME = "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_OBJECT_V1"


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def csv_row_count(path: Path) -> int:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        next(reader)
        return sum(1 for _ in reader)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet-dir", required=True)
    args = parser.parse_args()

    packet_dir = Path(args.packet_dir).resolve()
    object_dir = packet_dir / "00_READ_FIRST" / OBJECT_DIR_NAME
    source_dir = packet_dir / "00_READ_FIRST" / SOURCE_OBJECT_DIR_NAME / "04_OUTPUTS"
    outputs_dir = object_dir / "04_OUTPUTS"

    summary = load_json(outputs_dir / "CLEAN_FIRST_RESERVE_SUMMARY.json")
    reserve_row_count = csv_row_count(outputs_dir / "CLEAN_FIRST_RESERVE_LEDGER.csv")
    top3_row_count = csv_row_count(outputs_dir / "TOP3_CLEAN_FIRST_RESERVE.csv")

    bundled_probe = {
        "comparison_scope_is_empirical_gobs_gbar_only": (
            summary.get("comparison_scope") == "empirical_gobs_gbar_only"
        ),
        "clean_first_galaxy_count": summary.get("clean_first_galaxy_count") == 11,
        "clean_first_row_count": summary.get("clean_first_row_count") == 184,
        "top3_clean_first_galaxy_count": summary.get("top3_clean_first_galaxy_count") == 3,
        "top3_clean_first_row_count": summary.get("top3_clean_first_row_count") == 100,
        "first_focused_case_is_ngc1313": summary.get("first_focused_case") == "NGC1313",
        "top3_galaxies_match": summary.get("top3_galaxies") == ["NGC1313", "NGC2541", "NGC7793"],
        "all_reserve_galaxies_comparison_ready": (
            summary.get("all_reserve_galaxies_comparison_ready") is True
        ),
        "all_zero_duplicate_radius_blocks": summary.get("all_zero_duplicate_radius_blocks") is True,
        "all_zero_negative_vh2_rows": summary.get("all_zero_negative_vh2_rows") is True,
        "all_zero_zero_fill_sentinels": summary.get("all_zero_zero_fill_sentinels") is True,
        "theory_side_authoring_eligible_count": (
            summary.get("theory_side_authoring_eligible_count") == 0
        ),
        "reserve_csv_count": reserve_row_count == 11,
        "top3_csv_count": top3_row_count == 3,
    }

    replay_script = (
        object_dir / "03_RUN" / "REPRODUCE_AUTHOR_SUPPLIED_PAYLOAD_B_CLEAN_FIRST_RESERVE_STRUCTURE.py"
    )
    with tempfile.TemporaryDirectory(prefix="author_supplied_clean_first_reserve_") as temp_dir:
        replay_dir = Path(temp_dir)
        subprocess.run(
            [
                "python3",
                str(replay_script),
                "--ledger-csv",
                str(source_dir / "GALAXY_COMPARISON_ADMISSIBILITY_LEDGER.csv"),
                "--shortlist-csv",
                str(source_dir / "CLEAN_FIRST_PRIORITY_SHORTLIST.csv"),
                "--output-dir",
                str(replay_dir),
            ],
            check=True,
            text=True,
            capture_output=True,
        )
        replay_matches = (
            load_json(replay_dir / "CLEAN_FIRST_RESERVE_SUMMARY.json") == summary
            and csv_files_match(
                replay_dir / "CLEAN_FIRST_RESERVE_LEDGER.csv",
                outputs_dir / "CLEAN_FIRST_RESERVE_LEDGER.csv",
            )
            and csv_files_match(
                replay_dir / "TOP3_CLEAN_FIRST_RESERVE.csv",
                outputs_dir / "TOP3_CLEAN_FIRST_RESERVE.csv",
            )
        )

    payload = {
        "surface": "author_supplied_payload_b_clean_first_reserve_structure_probe",
        "object_dir": str(object_dir),
        "bundled_probe": bundled_probe,
        "all_bundled_checks_pass": all(bundled_probe.values()),
        "replay_check": {
            "attempted": True,
            "matched_bundled_outputs": replay_matches,
        },
    }
    print(json.dumps(payload, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
