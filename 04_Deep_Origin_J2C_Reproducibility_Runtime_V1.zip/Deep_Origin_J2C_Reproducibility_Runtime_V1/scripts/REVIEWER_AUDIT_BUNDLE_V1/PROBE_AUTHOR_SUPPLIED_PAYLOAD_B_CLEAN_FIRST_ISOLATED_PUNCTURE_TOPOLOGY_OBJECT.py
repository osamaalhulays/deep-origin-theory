#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
import tempfile
from pathlib import Path

from csv_semantic_compare import csv_files_match


OBJECT_DIR_NAME = "AUTHOR_SUPPLIED_PAYLOAD_B_CLEAN_FIRST_ISOLATED_PUNCTURE_TOPOLOGY_OBJECT_V1"
SOURCE_OBJECT_DIR_NAME = "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_OBJECT_V1"


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def csv_row_count(path: Path) -> int:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        next(reader)
        return sum(1 for _ in reader)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet-dir", required=True)
    args = parser.parse_args()

    packet_dir = Path(args.packet_dir).resolve()
    object_dir = packet_dir / "00_READ_FIRST" / OBJECT_DIR_NAME
    source_dir = packet_dir / "00_READ_FIRST" / SOURCE_OBJECT_DIR_NAME / "04_OUTPUTS"
    outputs_dir = object_dir / "04_OUTPUTS"

    summary = load_json(outputs_dir / "TOPOLOGY_SUMMARY.json")
    ledger_count = csv_row_count(outputs_dir / "CLEAN_FIRST_TOPOLOGY_LEDGER.csv")
    key_row_count = csv_row_count(outputs_dir / "LVHIS055_PUNCTURE_KEY_ROWS.csv")

    bundled_probe = {
        "comparison_scope_is_empirical_gobs_gbar_only": (
            summary.get("comparison_scope") == "empirical_gobs_gbar_only"
        ),
        "clean_first_total_galaxy_count": summary.get("clean_first_total_galaxy_count") == 11,
        "clean_first_total_row_count": summary.get("clean_first_total_row_count") == 184,
        "all_positive_clean_first_galaxy_count": (
            summary.get("all_positive_clean_first_galaxy_count") == 10
        ),
        "all_positive_clean_first_row_count": (
            summary.get("all_positive_clean_first_row_count") == 177
        ),
        "contiguous_all_positive_head_rank": (
            summary.get("contiguous_all_positive_head_rank") == 7
        ),
        "contiguous_all_positive_head_row_count": (
            summary.get("contiguous_all_positive_head_row_count") == 159
        ),
        "first_break_rank": summary.get("first_break_rank") == 8,
        "first_break_galaxy": summary.get("first_break_galaxy") == "LVHIS055",
        "first_break_nonpositive_row_count": (
            summary.get("first_break_nonpositive_row_count") == 1
        ),
        "first_break_first_nonpositive_row_index": (
            summary.get("first_break_first_nonpositive_row_index") == 0
        ),
        "first_break_first_nonpositive_radius_kpc": (
            summary.get("first_break_first_nonpositive_radius_kpc") == 0.29
        ),
        "isolated_puncture_galaxy_count": (
            summary.get("isolated_puncture_galaxy_count") == 1
        ),
        "isolated_puncture_total_nonpositive_rows": (
            summary.get("isolated_puncture_total_nonpositive_rows") == 1
        ),
        "puncture_is_single_row_only": summary.get("puncture_is_single_row_only") is True,
        "puncture_is_innermost_peak_row": summary.get("puncture_is_innermost_peak_row") is True,
        "post_puncture_positive_tail_galaxy_count": (
            summary.get("post_puncture_positive_tail_galaxy_count") == 3
        ),
        "post_puncture_positive_tail_row_count": (
            summary.get("post_puncture_positive_tail_row_count") == 18
        ),
        "post_puncture_positive_tail_galaxies_match": (
            summary.get("post_puncture_positive_tail_galaxies")
            == ["LVHIS026", "LVHIS017", "LVHIS019"]
        ),
        "theory_side_authoring_eligible": summary.get("theory_side_authoring_eligible") is False,
        "ledger_csv_count": ledger_count == 11,
        "key_row_csv_count": key_row_count == 3,
    }

    replay_script = (
        object_dir
        / "03_RUN"
        / "REPRODUCE_AUTHOR_SUPPLIED_PAYLOAD_B_CLEAN_FIRST_ISOLATED_PUNCTURE_TOPOLOGY.py"
    )
    with tempfile.TemporaryDirectory(prefix="author_supplied_clean_first_puncture_topology_") as temp_dir:
        replay_dir = Path(temp_dir)
        subprocess.run(
            [
                "python3",
                str(replay_script),
                "--rowwise-csv",
                str(source_dir / "OBSERVED_ROW_EMPIRICAL_COMPARISON_READY.csv"),
                "--shortlist-csv",
                str(source_dir / "CLEAN_FIRST_PRIORITY_SHORTLIST.csv"),
                "--output-dir",
                str(replay_dir),
            ],
            check=True,
            text=True,
            capture_output=True,
        )
        replay_matches = (
            load_json(replay_dir / "TOPOLOGY_SUMMARY.json") == summary
            and csv_files_match(
                replay_dir / "CLEAN_FIRST_TOPOLOGY_LEDGER.csv",
                outputs_dir / "CLEAN_FIRST_TOPOLOGY_LEDGER.csv",
            )
            and csv_files_match(
                replay_dir / "LVHIS055_PUNCTURE_KEY_ROWS.csv",
                outputs_dir / "LVHIS055_PUNCTURE_KEY_ROWS.csv",
            )
        )

    payload = {
        "surface": "author_supplied_payload_b_clean_first_isolated_puncture_topology_probe",
        "object_dir": str(object_dir),
        "bundled_probe": bundled_probe,
        "all_bundled_checks_pass": all(bundled_probe.values()),
        "replay_check": {
            "attempted": True,
            "matched_bundled_outputs": replay_matches,
        },
    }
    print(json.dumps(payload, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
