#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


NOTE_REL = Path(
    "00_READ_FIRST/"
    "RANK10_POST_SEAL_BACKGROUND_DISTANCE_POLICY_REPAIR_AND_EXECUTION_EXHAUSTION_NOTE_20260608.md"
)
EXPECTED_ARCHIVE_REL = Path(
    "artifacts/SUPPLEMENTAL_FULL_GAIN_PROVENANCE_ARCHIVE_20260619/"
    "02_rank10_h100_distance_ladder_c0_sources"
)
GAIN_MATRIX_REL = Path(
    "artifacts/SUPPLEMENTAL_FULL_GAIN_PROVENANCE_ARCHIVE_20260619/"
    "GAIN_COVERAGE_MATRIX.tsv"
)
EXPECTED_GAIN_ID = "rank10_h100_distance_c0"


def extract_anchor_names(note_text: str):
    anchors = []
    in_anchor_section = False
    for line in note_text.splitlines():
        stripped = line.strip()
        if stripped == "## Anchor surfaces":
            in_anchor_section = True
            continue
        if in_anchor_section and stripped.startswith("## "):
            break
        if in_anchor_section and stripped.startswith("- `") and stripped.endswith("`"):
            name = stripped[3:-1]
            if name.startswith("QCT_RANK10_"):
                anchors.append(name)
    return anchors


def read_gain_ids(matrix_path: Path):
    if not matrix_path.exists():
        return set()
    lines = matrix_path.read_text(encoding="utf-8").splitlines()
    if not lines:
        return set()
    return {line.split("\t", 1)[0] for line in lines[1:] if line.strip()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet-dir", required=True)
    args = parser.parse_args()

    packet_dir = Path(args.packet_dir).resolve()
    note_path = packet_dir / NOTE_REL
    archive_dir = packet_dir / EXPECTED_ARCHIVE_REL
    gain_matrix_path = packet_dir / GAIN_MATRIX_REL

    anchors = extract_anchor_names(note_path.read_text(encoding="utf-8"))
    records = []
    missing = []
    outside_archive = []

    for anchor in anchors:
        hits = sorted(packet_dir.rglob(anchor))
        rel_hits = [str(path.relative_to(packet_dir)) for path in hits]
        archive_hits = [
            rel for rel in rel_hits
            if rel.startswith(str(EXPECTED_ARCHIVE_REL) + "/")
        ]
        if not hits:
            missing.append(anchor)
        if hits and not archive_hits:
            outside_archive.append(anchor)
        records.append(
            {
                "anchor": anchor,
                "classification": "packaged" if hits else "missing_unclassified",
                "hit_count": len(hits),
                "expected_archive_hit_count": len(archive_hits),
                "paths": rel_hits,
            }
        )

    gain_ids = read_gain_ids(gain_matrix_path)
    checks = {
        "anchor_section_present": bool(anchors),
        "anchor_count_is_14": len(anchors) == 14,
        "all_anchors_packaged": not missing,
        "all_packaged_anchors_in_expected_archive": not outside_archive,
        "gain_matrix_contains_rank10_h100_distance_c0": EXPECTED_GAIN_ID in gain_ids,
        "expected_archive_directory_present": archive_dir.is_dir(),
    }
    payload = {
        "surface": "h100_distance_anchor_packaging_probe",
        "all_checks_pass": all(checks.values()),
        "checks": checks,
        "note": str(NOTE_REL),
        "expected_archive": str(EXPECTED_ARCHIVE_REL),
        "anchor_count": len(anchors),
        "missing_anchors": missing,
        "anchors_outside_expected_archive_only": outside_archive,
        "anchors": records,
        "claim_ceiling": "packaging/provenance check only; no H100, distance-ladder, BAO, CMB, or cosmology pass claim",
    }

    print(json.dumps(payload, indent=2, sort_keys=True))
    if not payload["all_checks_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
