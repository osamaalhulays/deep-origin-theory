#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
import tempfile
from pathlib import Path

from csv_semantic_compare import csv_files_match


OBJECT_DIR_NAME = "AUTHOR_SUPPLIED_PAYLOAD_B_NAMED_FRONT6_STRUCTURE_OBJECT_V1"
SOURCE_OBJECT_DIR_NAME = "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_OBJECT_V1"


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def csv_row_count(path: Path) -> int:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        next(reader)
        return sum(1 for _ in reader)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet-dir", required=True)
    args = parser.parse_args()

    packet_dir = Path(args.packet_dir).resolve()
    object_dir = packet_dir / "00_READ_FIRST" / OBJECT_DIR_NAME
    source_dir = packet_dir / "00_READ_FIRST" / SOURCE_OBJECT_DIR_NAME / "04_OUTPUTS"
    outputs_dir = object_dir / "04_OUTPUTS"

    summary = load_json(outputs_dir / "NAMED_FRONT6_SUMMARY.json")
    ledger_count = csv_row_count(outputs_dir / "NAMED_FRONT6_LEDGER.csv")

    bundled_probe = {
        "comparison_scope_is_empirical_gobs_gbar_only": (
            summary.get("comparison_scope") == "empirical_gobs_gbar_only"
        ),
        "named_front_galaxy_count": summary.get("named_front_galaxy_count") == 6,
        "named_front_row_count": summary.get("named_front_row_count") == 147,
        "clean_first_total_galaxy_count": summary.get("clean_first_total_galaxy_count") == 11,
        "clean_first_total_row_count": summary.get("clean_first_total_row_count") == 184,
        "remaining_tail_galaxy_count": summary.get("remaining_tail_galaxy_count") == 5,
        "remaining_tail_row_count": summary.get("remaining_tail_row_count") == 37,
        "front_exact_interpolation_row_count": summary.get("front_exact_interpolation_row_count") == 14,
        "front_linear_interpolation_row_count": summary.get("front_linear_interpolation_row_count") == 133,
        "named_front_galaxies_match": summary.get("named_front_galaxies") == [
            "NGC1313",
            "NGC2541",
            "NGC7793",
            "NGC3992",
            "LVHIS077",
            "LVHIS072",
        ],
        "all_front_rows_comparison_ready": summary.get("all_front_rows_comparison_ready") is True,
        "all_front_rows_clean_first": summary.get("all_front_rows_clean_first") is True,
        "all_front_rows_delta_positive": summary.get("all_front_rows_delta_positive") is True,
        "ledger_csv_count": ledger_count == 6,
    }

    replay_script = object_dir / "03_RUN" / "REPRODUCE_AUTHOR_SUPPLIED_PAYLOAD_B_NAMED_FRONT6_STRUCTURE.py"
    with tempfile.TemporaryDirectory(prefix="author_supplied_front6_") as temp_dir:
        replay_dir = Path(temp_dir)
        subprocess.run(
            [
                "python3",
                str(replay_script),
                "--rowwise-csv",
                str(source_dir / "OBSERVED_ROW_EMPIRICAL_COMPARISON_READY.csv"),
                "--ledger-csv",
                str(source_dir / "GALAXY_COMPARISON_ADMISSIBILITY_LEDGER.csv"),
                "--shortlist-csv",
                str(source_dir / "CLEAN_FIRST_PRIORITY_SHORTLIST.csv"),
                "--output-dir",
                str(replay_dir),
            ],
            check=True,
            text=True,
            capture_output=True,
        )
        replay_matches = (
            load_json(replay_dir / "NAMED_FRONT6_SUMMARY.json") == summary
            and csv_files_match(
                replay_dir / "NAMED_FRONT6_LEDGER.csv",
                outputs_dir / "NAMED_FRONT6_LEDGER.csv",
            )
        )

    payload = {
        "surface": "author_supplied_payload_b_named_front6_structure_probe",
        "object_dir": str(object_dir),
        "bundled_probe": bundled_probe,
        "all_bundled_checks_pass": all(bundled_probe.values()),
        "replay_check": {
            "attempted": True,
            "matched_bundled_outputs": replay_matches,
        },
    }
    print(json.dumps(payload, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
