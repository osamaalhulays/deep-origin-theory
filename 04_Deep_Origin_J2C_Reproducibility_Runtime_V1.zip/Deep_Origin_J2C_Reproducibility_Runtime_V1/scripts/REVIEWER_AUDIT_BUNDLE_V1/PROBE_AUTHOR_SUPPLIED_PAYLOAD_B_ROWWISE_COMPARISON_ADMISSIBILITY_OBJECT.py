#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import json
import subprocess
import tempfile
from pathlib import Path

from csv_semantic_compare import csv_files_match


OBJECT_DIR_NAME = "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_OBJECT_V1"
SOURCE_OBJECT_DIR_NAME = "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_GBAR_DIAGNOSTIC_NORMALIZATION_OBJECT_V1"


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def csv_row_count(path: Path) -> int:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        next(reader)
        return sum(1 for _ in reader)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet-dir", required=True)
    parser.add_argument("--observed-zip")
    parser.add_argument("--baryons-zip")
    args = parser.parse_args()

    packet_dir = Path(args.packet_dir).resolve()
    object_dir = packet_dir / "00_READ_FIRST" / OBJECT_DIR_NAME
    source_dir = packet_dir / "00_READ_FIRST" / SOURCE_OBJECT_DIR_NAME
    outputs_dir = object_dir / "04_OUTPUTS"

    grammar = load_json(outputs_dir / "ADMISSIBILITY_GRAMMAR_LOCK.json")
    summary = load_json(outputs_dir / "ADMISSIBILITY_SUMMARY.json")
    boundary = load_json(outputs_dir / "PUBLIC_BOUNDARY_MANIFEST_20260615.json")
    ledger_count = csv_row_count(outputs_dir / "GALAXY_COMPARISON_ADMISSIBILITY_LEDGER.csv")
    shortlist_count = csv_row_count(outputs_dir / "CLEAN_FIRST_PRIORITY_SHORTLIST.csv")

    bundled_probe = {
        "comparison_scope_is_empirical_gobs_gbar_only": (
            summary.get("comparison_scope") == "empirical_gobs_gbar_only"
        ),
        "matched_galaxy_count": summary.get("matched_galaxy_count") == 49,
        "diagnostic_rowwise_ready_galaxy_count": (
            summary.get("diagnostic_rowwise_ready_galaxy_count") == 49
        ),
        "diagnostic_rowwise_ready_row_count": (
            summary.get("diagnostic_rowwise_ready_row_count") == 1082
        ),
        "clean_first_galaxy_count": summary.get("clean_first_galaxy_count") == 11,
        "clean_first_row_count": summary.get("clean_first_row_count") == 184,
        "first_clean_candidate": summary.get("first_clean_candidate") == "NGC1313",
        "theory_side_authoring_eligible_galaxy_count": (
            summary.get("theory_side_authoring_eligible_galaxy_count") == 0
        ),
        "ledger_row_count": ledger_count == 49,
        "admitted_row_count_from_summary": summary.get("diagnostic_rowwise_ready_row_count") == 1082,
        "shortlist_row_count": shortlist_count == 11,
        "all_49_are_empirical_rowwise_ready": (
            summary.get("all_49_are_empirical_rowwise_ready") is True
        ),
        "grammar_lock_scope": grammar.get("comparison_scope") == "empirical_gobs_gbar_only",
        "public_boundary_status": (
            boundary.get("status")
            == "row_level_or_near_rowwise_direct_author_derivatives_withheld_from_public_packet"
        ),
        "public_boundary_withheld_file_count": boundary.get("withheld_file_count") == 1,
        "public_boundary_withheld_row_csv": boundary.get("withheld_files") == ["OBSERVED_ROW_EMPIRICAL_COMPARISON_READY.csv"],
    }

    payload = {
        "surface": "author_supplied_payload_b_rowwise_comparison_admissibility_probe",
        "object_dir": str(object_dir),
        "bundled_probe": bundled_probe,
        "all_bundled_checks_pass": all(bundled_probe.values()),
        "replay_check": {
            "attempted": False,
            "matched_bundled_summary_surfaces": None,
        },
    }

    if args.observed_zip and args.baryons_zip:
        diagnostic_replay_script = (
            source_dir / "03_RUN" / "REPRODUCE_AUTHOR_SUPPLIED_PAYLOAD_B_GBAR_DIAGNOSTIC_NORMALIZATION.py"
        )
        rowwise_replay_script = (
            object_dir / "03_RUN" / "REPRODUCE_AUTHOR_SUPPLIED_PAYLOAD_B_ROWWISE_COMPARISON_ADMISSIBILITY.py"
        )
        with tempfile.TemporaryDirectory(prefix="author_supplied_payload_b_rowwise_cmp_") as temp_dir:
            temp_root = Path(temp_dir)
            diagnostic_dir = temp_root / "diagnostic"
            rowwise_dir = temp_root / "rowwise"
            subprocess.run(
                [
                    "python3",
                    str(diagnostic_replay_script),
                    "--observed-zip",
                    str(Path(args.observed_zip).resolve()),
                    "--baryons-zip",
                    str(Path(args.baryons_zip).resolve()),
                    "--output-dir",
                    str(diagnostic_dir),
                ],
                check=True,
                text=True,
                capture_output=True,
            )
            subprocess.run(
                [
                    "python3",
                    str(rowwise_replay_script),
                    "--diagnostic-csv",
                    str(diagnostic_dir / "OBSERVED_ROW_GBAR_DIAGNOSTIC.csv"),
                    "--galaxy-status-csv",
                    str(diagnostic_dir / "GALAXY_DIAGNOSTIC_STATUS.csv"),
                    "--output-dir",
                    str(rowwise_dir),
                ],
                check=True,
                text=True,
                capture_output=True,
            )
            replay_row_count = csv_row_count(rowwise_dir / "OBSERVED_ROW_EMPIRICAL_COMPARISON_READY.csv")
            replay_matches = (
                load_json(rowwise_dir / "ADMISSIBILITY_GRAMMAR_LOCK.json") == grammar
                and load_json(rowwise_dir / "ADMISSIBILITY_SUMMARY.json") == summary
                and replay_row_count == summary.get("diagnostic_rowwise_ready_row_count")
                and csv_files_match(
                    rowwise_dir / "GALAXY_COMPARISON_ADMISSIBILITY_LEDGER.csv",
                    outputs_dir / "GALAXY_COMPARISON_ADMISSIBILITY_LEDGER.csv",
                )
                and csv_files_match(
                    rowwise_dir / "CLEAN_FIRST_PRIORITY_SHORTLIST.csv",
                    outputs_dir / "CLEAN_FIRST_PRIORITY_SHORTLIST.csv",
                )
            )
        payload["replay_check"] = {
            "attempted": True,
            "matched_bundled_summary_surfaces": replay_matches,
            "replayed_row_count": replay_row_count,
        }

    print(json.dumps(payload, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
