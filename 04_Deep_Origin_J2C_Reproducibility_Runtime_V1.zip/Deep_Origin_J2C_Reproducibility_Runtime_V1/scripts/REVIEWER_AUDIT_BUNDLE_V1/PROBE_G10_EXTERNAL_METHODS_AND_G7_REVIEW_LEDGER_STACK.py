#!/usr/bin/env python3

from __future__ import annotations

import argparse
import json
from pathlib import Path


def load_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet-dir", required=True)
    args = parser.parse_args()

    packet_dir = Path(args.packet_dir).resolve()

    g10_note = (
        packet_dir
        / "00_READ_FIRST"
        / "CURRENT_G10_NUISANCE_COMPLETE_FAIRNESS_RETIREMENT_NOTE_20260611.md"
    )
    stacy_note = (
        packet_dir
        / "00_READ_FIRST"
        / "EXTERNAL_METHODS_REPLY_STACY_MCGAUGH_MATCHED_NUISANCE_AND_AIC_BOUNDARY_NOTE_20260611.md"
    )
    andrea_note = (
        packet_dir
        / "00_READ_FIRST"
        / "EXTERNAL_METHODS_REPLY_ANDREA_BIVIANO_AIC_BIC_SUPPORT_ONLY_NOTE_20260611.md"
    )
    parity_note = (
        packet_dir
        / "00_READ_FIRST"
        / "NGC0247_HISTORICAL_PHASE2_SAME_CONVENTION_CONTROL_NOTE_20260608.md"
    )
    g7_current_note = (
        packet_dir
        / "00_READ_FIRST"
        / "CURRENT_G7_FORMAL_REVIEW_LAUNCH_GRAMMAR_AND_CURRENT_STATE_NOTE_20260612.md"
    )
    g7_manual_note = (
        packet_dir
        / "00_READ_FIRST"
        / "CURRENT_G7_FORMAL_REVIEW_LAUNCH_MANUAL_DISPATCH_ONLY_NOTE_20260611.md"
    )

    g10_text = load_text(g10_note)
    g7_current_text = load_text(g7_current_note)
    g7_manual_text = load_text(g7_manual_note)

    checks = {
        "g10_note_exists": g10_note.exists(),
        "stacy_note_exists": stacy_note.exists(),
        "andrea_note_exists": andrea_note.exists(),
        "parity_note_exists": parity_note.exists(),
        "g7_current_note_exists": g7_current_note.exists(),
        "g7_manual_note_exists": g7_manual_note.exists(),
        "g10_references_stacy_note": (
            "EXTERNAL_METHODS_REPLY_STACY_MCGAUGH_MATCHED_NUISANCE_AND_AIC_BOUNDARY_NOTE_20260611.md"
            in g10_text
        ),
        "g10_references_andrea_note": (
            "EXTERNAL_METHODS_REPLY_ANDREA_BIVIANO_AIC_BIC_SUPPORT_ONLY_NOTE_20260611.md"
            in g10_text
        ),
        "g10_references_parity_note": (
            "NGC0247_HISTORICAL_PHASE2_SAME_CONVENTION_CONTROL_NOTE_20260608.md" in g10_text
        ),
        "g7_current_mentions_r3": (
            "one bounded outside methods-side clarification `R3` also now exists"
            in g7_current_text
        ),
        "g7_current_classifies_r3_below_launch": (
            "`R3` counts as bounded outside methods-side clarification only"
            in g7_current_text
        ),
        "g7_current_nonlaunch_list_includes_r3": "`R3`" in g7_current_text,
        "g7_manual_mentions_methods_fairness": (
            "outside methods-side fairness clarification" in g7_manual_text
        ),
        "g7_manual_references_stacy_note": (
            "EXTERNAL_METHODS_REPLY_STACY_MCGAUGH_MATCHED_NUISANCE_AND_AIC_BOUNDARY_NOTE_20260611.md"
            in g7_manual_text
        ),
    }

    payload = {
        "surface": "g10_external_methods_and_g7_review_ledger_stack_probe",
        "packet_dir": str(packet_dir),
        "checks": checks,
        "all_bundled_checks_pass": all(checks.values()),
    }
    print(json.dumps(payload, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
