#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

FLOAT_TOLERANCE = 1e-12
WINDOW_ACCEPTED_STATES = {
    (
        "packet_visible_delta_1d_replay_only",
        "skipped_optional_archive_not_bundled",
        False,
    ): "cold_packet_default",
    (
        "V1_fixed_delta_surface",
        "verified_optional_archive",
        False,
    ): "author_side_archival_enrichment",
}
PILOT_VERDICT = (
    "NGC0247_PARITY_READY_PILOT_OBJECT_MATERIALIZED__PROMOTE_THIS_OBJECT_NOT_THE_HISTORICAL_CONTROL_SHELL"
)
POLICY_VERDICT = (
    "NGC0247_MATCHED_NUISANCE_SOURCE_POLICY_LOCK_CLOSED__NEXT_EXECUTION_TOOTH_IS_NUISANCE_SHIFTED_ROW_REMATERIALIZATION"
)
WINDOW_VERDICT = (
    "NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_CLOSED__LAWFUL_DI_BOX_DOES_NOT_RESCUE_QCT"
)
SCORING_VERDICT = (
    "NGC0247_EXECUTED_PARITY_WITNESS_SCORING_SHELL_REPLAY_CLOSED__SUPPORT_RECEIPTS_AND_PACKET_SHELLS_ARE_NUMERICALLY_CONCORDANT"
)
G4_ADJUDICATION_STATUS = (
    "G4_FIRST_NONTOY_FORMD_RUN_REPRODUCED_AND_MATCHED_CANONICAL_PACKET_OUTPUTS"
)
G1_COLD_PORTABLE_VERDICT = (
    "POST_CAGE_BRANCH_U1_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_MATERIALIZED"
)
DISTINGUISHED_COSMOLOGY_DIRECTF_VERDICT = (
    "DISTINGUISHED_COSMOLOGY_CERT_DOMAIN_CLOSURE_MATERIALIZED__DIRECTF_SCOPE_FROZEN__CLASS_UPGRADE_BLOCKED"
)
DISTINGUISHED_COSMOLOGY_FRONTIER_VERDICT = (
    "DISTINGUISHED_COSMOLOGY_COMPONENT_TRUE_ENCLOSURE_FRONTIER_MATERIALIZED__"
    "STATE_TUBE_BASELINE_CONFIRMED__DIRECTF_X_SIGN_NOT_YET_OPENED"
)


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha_check_passes(path: Path):
    lines = [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not lines:
        return False, "sha check file is empty"
    if any("FAILED" in line for line in lines):
        return False, "sha check file contains FAILED lines"
    if any(": OK" not in line for line in lines):
        return False, "sha check file contains non-OK lines"
    return True, f"{len(lines)} OK lines"


def close_enough(left, right):
    return abs(left - right) <= FLOAT_TOLERANCE


def check(checks, name, passed, detail):
    checks[name] = {
        "passed": bool(passed),
        "detail": detail,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-dir", required=True)
    args = parser.parse_args()

    audit_dir = Path(args.audit_dir).resolve()
    checks = {}

    for name in (
        "packet_root_sha_check.txt",
        "shelf_A_sha_check.txt",
        "shelf_B_sha_check.txt",
        "shelf_C_sha_check.txt",
    ):
        passed, detail = sha_check_passes(audit_dir / name)
        check(checks, name, passed, detail)

    full_mode = (audit_dir / "ngc0247_parity_ready_pilot_object.json").exists()
    audit_mode = "full" if full_mode else "fast"

    row_comparator = load_json(audit_dir / "ngc0247_current_row_comparator.json")
    row_comparator_passed = (
        row_comparator.get("surface") == "ngc0247_phase2_current_row_comparator"
        and row_comparator.get("row_count") == 26
        and row_comparator.get("delta_aic_total_abs_error", 1.0) <= 1e-5
        and row_comparator.get("delta_bic_total_abs_error", 1.0) <= 1e-5
    )
    check(
        checks,
        "ngc0247_current_row_comparator",
        row_comparator_passed,
        {
            "surface": row_comparator.get("surface"),
            "row_count": row_comparator.get("row_count"),
            "delta_aic_total_abs_error": row_comparator.get("delta_aic_total_abs_error"),
            "delta_bic_total_abs_error": row_comparator.get("delta_bic_total_abs_error"),
        },
    )

    if full_mode:
        pilot = load_json(audit_dir / "ngc0247_parity_ready_pilot_object.json")
        nested_pilot_gate = pilot.get("parity_readiness_gate", {}).get("numeric_readiness_gate_closed")
        pilot_passed = (
            pilot.get("pilot_object_materialized") is True
            and pilot.get("numeric_readiness_gate_closed") is True
            and nested_pilot_gate is True
            and pilot.get("verdict") == PILOT_VERDICT
        )
        check(
            checks,
            "ngc0247_parity_ready_pilot_object",
            pilot_passed,
            {
                "pilot_object_materialized": pilot.get("pilot_object_materialized"),
                "numeric_readiness_gate_closed": pilot.get("numeric_readiness_gate_closed"),
                "nested_numeric_readiness_gate_closed": nested_pilot_gate,
                "verdict": pilot.get("verdict"),
            },
        )

        policy = load_json(audit_dir / "ngc0247_matched_nuisance_policy_lock.json")
        nested_policy_alignment = policy.get("mask_family", {}).get(
            "count_level_alignment_with_current_rotmod_rows"
        )
        policy_passed = (
            policy.get("policy_lock_closed") is True
            and policy.get("count_level_alignment_with_current_rotmod_rows") is True
            and nested_policy_alignment is True
            and policy.get("verdict") == POLICY_VERDICT
        )
        check(
            checks,
            "ngc0247_matched_nuisance_policy_lock",
            policy_passed,
            {
                "policy_lock_closed": policy.get("policy_lock_closed"),
                "count_level_alignment_with_current_rotmod_rows": policy.get(
                    "count_level_alignment_with_current_rotmod_rows"
                ),
                "nested_count_level_alignment_with_current_rotmod_rows": nested_policy_alignment,
                "verdict": policy.get("verdict"),
            },
        )

        window = load_json(audit_dir / "ngc0247_phase2_matched_nuisance_window_replay.json")
        window_state = (
            window.get("historical_delta_surface_replay_mode"),
            window.get("optional_external_archive_check", {}).get("status"),
            window.get("rescue_seen_within_1sigma_box"),
        )
        accepted_window_mode = WINDOW_ACCEPTED_STATES.get(window_state)
        window_passed = accepted_window_mode is not None and window.get("verdict") == WINDOW_VERDICT
        check(
            checks,
            "ngc0247_phase2_matched_nuisance_window_replay",
            window_passed,
            {
                "accepted_mode": accepted_window_mode,
                "historical_delta_surface_replay_mode": window_state[0],
                "optional_external_archive_check.status": window_state[1],
                "rescue_seen_within_1sigma_box": window_state[2],
                "verdict": window.get("verdict"),
            },
        )

        scoring = load_json(audit_dir / "ngc0247_executed_parity_witness_scoring_shell.json")
        expected_scoring = {
            "faithful_delta_aic_total": -15.398764714420167,
            "component_aware_delta_aic_total": -39.63154845025974,
            "fixed_public_delta_aic_total": -13.914066963632308,
        }
        scoring_passed = (
            scoring.get("scoring_shell_replay_closed") is True
            and scoring.get("verdict") == SCORING_VERDICT
            and all(
                close_enough(scoring.get(key), value) for key, value in expected_scoring.items()
            )
            and all(scoring.get("consistency_checks", {}).values())
        )
        check(
            checks,
            "ngc0247_executed_parity_witness_scoring_shell",
            scoring_passed,
            {
                **{key: scoring.get(key) for key in expected_scoring},
                "scoring_shell_replay_closed": scoring.get("scoring_shell_replay_closed"),
                "all_consistency_checks_pass": all(scoring.get("consistency_checks", {}).values()),
                "verdict": scoring.get("verdict"),
            },
        )

        ngc6946 = load_json(audit_dir / "ngc6946_fixed_qumond_summary.json")
        ngc6946_passed = (
            ngc6946.get("all_QUMOND_residuals_negative") is True
            and ngc6946.get("delta_true_sign_split_label") == "29 negative / 29 positive"
        )
        check(
            checks,
            "ngc6946_fixed_qumond_summary",
            ngc6946_passed,
            {
                "all_QUMOND_residuals_negative": ngc6946.get("all_QUMOND_residuals_negative"),
                "delta_true_sign_split_label": ngc6946.get("delta_true_sign_split_label"),
            },
        )

    else:
        check(
            checks,
            "audit_mode_fast_contract",
            True,
            {
                "audit_mode": audit_mode,
                "full_only_outputs_skipped": [
                    "ngc0247_parity_ready_pilot_object.json",
                    "ngc0247_matched_nuisance_policy_lock.json",
                    "ngc0247_phase2_matched_nuisance_window_replay.json",
                    "ngc0247_executed_parity_witness_scoring_shell.json",
                    "ngc6946_fixed_qumond_summary.json",
                ],
            },
        )

    macs1206 = load_json(audit_dir / "macs1206_public_source_profile.json")
    macs1206_status = macs1206.get("status")
    if macs1206_status == "skipped_external_fits_dependency_not_bundled":
        macs1206_passed = bool(macs1206.get("missing_paths")) and bool(macs1206.get("output_csv"))
        macs1206_detail = {
            "accepted_mode": "skip_safe_external_dependency_not_bundled",
            "status": macs1206_status,
            "missing_path_count": len(macs1206.get("missing_paths", [])),
            "output_csv": macs1206.get("output_csv"),
        }
    else:
        macs1206_passed = macs1206.get("row_count") == 4 and bool(macs1206.get("output_csv"))
        macs1206_detail = {
            "accepted_mode": "full_local_replay_available",
            "status": macs1206_status,
            "row_count": macs1206.get("row_count"),
            "output_csv": macs1206.get("output_csv"),
        }
    check(checks, "macs1206_public_source_profile", macs1206_passed, macs1206_detail)

    g4_adjudication = load_json(audit_dir / "g4_ngc4214_first_nontoy_adjudication.json")
    g4_summary = g4_adjudication.get("reproduced_summary", {})
    g4_checks = g4_adjudication.get("checks", {})
    g4_passed = (
        g4_adjudication.get("all_checks_pass") is True
        and g4_adjudication.get("status") == G4_ADJUDICATION_STATUS
        and g4_summary.get("status") == "D3_FIRST_COMPARISON_STACK_MATERIALIZED"
        and g4_summary.get("form_a_materialized") is True
        and g4_summary.get("prediction_rows_materialized") is True
        and g4_summary.get("comparison_stack_materialized") is True
        and g4_summary.get("row_count") == 14
        and close_enough(g4_summary.get("chi2_total"), 658.7148518641796)
        and close_enough(g4_summary.get("loglike_gaussian_diag"), -305.86832116819267)
        and all(item.get("passed") for item in g4_checks.values())
    )
    check(
        checks,
        "g4_ngc4214_first_nontoy_formd_run",
        g4_passed,
        {
            "status": g4_adjudication.get("status"),
            "all_checks_pass": g4_adjudication.get("all_checks_pass"),
            "reproduced_summary": g4_summary,
            "all_file_checks_pass": all(item.get("passed") for item in g4_checks.values()),
        },
    )

    author_supplied_probe = load_json(audit_dir / "author_supplied_payload_b_receipt_audit_probe.json")
    replay_check = author_supplied_probe.get("replay_check", {})
    author_supplied_passed = (
        author_supplied_probe.get("all_bundled_checks_pass") is True
        and (
            replay_check.get("attempted") is False
            or replay_check.get("matched_bundled_outputs") is True
        )
    )
    check(
        checks,
        "author_supplied_payload_b_receipt_audit_probe",
        author_supplied_passed,
        {
            "accepted_mode": author_supplied_probe.get("accepted_mode"),
            "all_bundled_checks_pass": author_supplied_probe.get("all_bundled_checks_pass"),
            "replay_check": replay_check,
        },
    )

    author_supplied_diag_probe = load_json(audit_dir / "author_supplied_payload_b_gbar_diagnostic_normalization_probe.json")
    author_supplied_diag_replay = author_supplied_diag_probe.get("replay_check", {})
    author_supplied_diag_passed = (
        author_supplied_diag_probe.get("all_bundled_checks_pass") is True
        and (
            author_supplied_diag_replay.get("attempted") is False
            or author_supplied_diag_replay.get("matched_bundled_summary_surfaces") is True
        )
    )
    check(
        checks,
        "author_supplied_payload_b_gbar_diagnostic_normalization_probe",
        author_supplied_diag_passed,
        {
            "all_bundled_checks_pass": author_supplied_diag_probe.get("all_bundled_checks_pass"),
            "replay_check": author_supplied_diag_replay,
        },
    )

    author_supplied_cmp_probe = load_json(audit_dir / "author_supplied_payload_b_rowwise_comparison_admissibility_probe.json")
    author_supplied_cmp_replay = author_supplied_cmp_probe.get("replay_check", {})
    author_supplied_cmp_passed = (
        author_supplied_cmp_probe.get("all_bundled_checks_pass") is True
        and (
            author_supplied_cmp_replay.get("attempted") is False
            or author_supplied_cmp_replay.get("matched_bundled_summary_surfaces") is True
        )
    )
    check(
        checks,
        "author_supplied_payload_b_rowwise_comparison_admissibility_probe",
        author_supplied_cmp_passed,
        {
            "all_bundled_checks_pass": author_supplied_cmp_probe.get("all_bundled_checks_pass"),
            "replay_check": author_supplied_cmp_replay,
        },
    )

    triad_probe = load_json(
        audit_dir / "mond_qumond_clean_front_positive_triad_grade2_court_object_probe.json"
    )
    triad_replay = triad_probe.get("replay_check", {})
    triad_passed = (
        triad_probe.get("all_bundled_checks_pass") is True
        and triad_replay.get("attempted") is True
        and triad_replay.get("matched_bundled_outputs") is True
    )
    check(
        checks,
        "mond_qumond_clean_front_positive_triad_grade2_court_object_probe",
        triad_passed,
        {
            "all_bundled_checks_pass": triad_probe.get("all_bundled_checks_pass"),
            "replay_check": triad_replay,
        },
    )

    g10_methods_probe = load_json(
        audit_dir / "g10_external_methods_and_g7_review_ledger_stack_probe.json"
    )
    g10_methods_passed = g10_methods_probe.get("all_bundled_checks_pass") is True
    check(
        checks,
        "g10_external_methods_and_g7_review_ledger_stack_probe",
        g10_methods_passed,
        {
            "all_bundled_checks_pass": g10_methods_probe.get("all_bundled_checks_pass"),
            "checks": g10_methods_probe.get("checks", {}),
        },
    )

    cosmology_probe = load_json(audit_dir / "distinguished_cosmology_proof_spine_probe.json")
    cosmology_checks = cosmology_probe.get("checks", {})
    cosmology_passed = (
        cosmology_probe.get("all_checks_pass") is True
        and cosmology_probe.get("directf_verdict") == DISTINGUISHED_COSMOLOGY_DIRECTF_VERDICT
        and cosmology_probe.get("frontier_verdict") == DISTINGUISHED_COSMOLOGY_FRONTIER_VERDICT
        and cosmology_checks.get("proof_spine_selftest") is True
        and cosmology_checks.get("manifest_paths_are_package_relative") is True
    )
    check(
        checks,
        "distinguished_cosmology_proof_spine_cold_probe",
        cosmology_passed,
        {
            "all_checks_pass": cosmology_probe.get("all_checks_pass"),
            "directf_verdict": cosmology_probe.get("directf_verdict"),
            "frontier_verdict": cosmology_probe.get("frontier_verdict"),
            "checks": cosmology_checks,
            "absolute_manifest_paths": cosmology_probe.get("absolute_manifest_paths"),
            "author_manifest_paths": cosmology_probe.get("author_manifest_paths"),
        },
    )

    h100_distance_probe = load_json(audit_dir / "h100_distance_anchor_packaging_probe.json")
    h100_distance_passed = (
        h100_distance_probe.get("all_checks_pass") is True
        and h100_distance_probe.get("anchor_count") == 14
        and h100_distance_probe.get("missing_anchors") == []
        and h100_distance_probe.get("anchors_outside_expected_archive_only") == []
    )
    check(
        checks,
        "h100_distance_anchor_packaging_probe",
        h100_distance_passed,
        {
            "all_checks_pass": h100_distance_probe.get("all_checks_pass"),
            "anchor_count": h100_distance_probe.get("anchor_count"),
            "missing_anchors": h100_distance_probe.get("missing_anchors"),
            "anchors_outside_expected_archive_only": h100_distance_probe.get(
                "anchors_outside_expected_archive_only"
            ),
            "claim_ceiling": h100_distance_probe.get("claim_ceiling"),
        },
    )

    path_precision_probe = load_json(audit_dir / "path_portability_and_precision_probe.json")
    path_precision_checks = path_precision_probe.get("checks", {})
    path_precision = path_precision_probe.get("min_F_low_raw_precision_guard", {})
    path_precision_passed = (
        path_precision_probe.get("all_checks_pass") is True
        and path_precision_checks.get("total_tsv_scan_materialized") is True
        and path_precision_checks.get("historical_author_paths_declared") is True
        and path_precision_checks.get("per_file_location_index_declared") is True
        and path_precision_checks.get("per_section_summary_materialized") is True
        and path_precision_checks.get("new_rank9_capsules_in_scope") is True
        and path_precision_checks.get("rewrite_policy_preserves_source_rows") is True
        and path_precision_checks.get("min_f_low_raw_records_found") is True
        and path_precision_checks.get("min_f_low_raw_all_strings") is True
        and path_precision_checks.get("min_f_low_raw_decimal_parse_ok") is True
    )
    check(
        checks,
        "path_portability_and_precision_cold_probe",
        path_precision_passed,
        {
            "all_checks_pass": path_precision_probe.get("all_checks_pass"),
            "checks": path_precision_checks,
            "tsv_scan": path_precision_probe.get("tsv_scan", {}),
            "new_rank9_capsule_scan": path_precision_probe.get("new_rank9_capsule_scan", []),
            "min_F_low_raw_precision_guard": path_precision,
        },
    )

    rank9_gain_probe = load_json(audit_dir / "rank9_full_gain_provenance_capsules_probe.json")
    rank9_gain_checks = rank9_gain_probe.get("checks", {})
    rank9_gain_capsules = rank9_gain_probe.get("capsules", {})
    rank9_gain_passed = (
        rank9_gain_probe.get("all_checks_pass") is True
        and rank9_gain_checks.get("all_capsules_present_and_sha_clean") is True
        and rank9_gain_checks.get("coverage_matrix_contains_rank9_capsules") is True
        and rank9_gain_checks.get("front_notes_present") is True
        and rank9_gain_checks.get("archive_manifest_lists_capsules") is True
        and rank9_gain_checks.get("no_claim_upgrade_status") is True
        and all(item.get("passed") for item in rank9_gain_capsules.values())
    )
    check(
        checks,
        "rank9_full_gain_provenance_capsules_cold_probe",
        rank9_gain_passed,
        {
            "all_checks_pass": rank9_gain_probe.get("all_checks_pass"),
            "checks": rank9_gain_checks,
            "capsule_count": len(rank9_gain_capsules),
            "missing_gain_ids": rank9_gain_probe.get("missing_gain_ids"),
            "missing_front_notes": rank9_gain_probe.get("missing_front_notes"),
            "missing_manifest_sections": rank9_gain_probe.get("missing_manifest_sections"),
        },
    )

    l2_recovery_probe = load_json(
        audit_dir / "l2_late_object_recovery_and_navigation_cleanup_probe.json"
    )
    l2_recovery_checks = l2_recovery_probe.get("checks", {})
    l2_recovery_capsule = l2_recovery_probe.get("capsule", {})
    l2_recovery_passed = (
        l2_recovery_probe.get("all_checks_pass") is True
        and l2_recovery_capsule.get("source_docs_count") == 238
        and l2_recovery_capsule.get("source_tools_count") == 25
        and all(l2_recovery_capsule.get("family_presence", {}).values())
        and l2_recovery_checks.get("capsule_sha_clean") is True
        and l2_recovery_checks.get("gain_matrix_updated") is True
        and l2_recovery_checks.get("front_note_present") is True
        and l2_recovery_checks.get("start_here_points_to_l2_recovery_note") is True
        and l2_recovery_checks.get("stale_start_removed_from_read_first") is True
        and l2_recovery_checks.get("stale_start_archived_with_supersession_banner") is True
        and l2_recovery_checks.get("active_board_historical") is True
        and l2_recovery_checks.get("crosswalk_historical") is True
    )
    check(
        checks,
        "l2_late_object_recovery_and_navigation_cleanup_probe",
        l2_recovery_passed,
        {
            "all_checks_pass": l2_recovery_probe.get("all_checks_pass"),
            "checks": l2_recovery_checks,
            "capsule": l2_recovery_capsule,
        },
    )

    g1_cold_status = load_json(audit_dir / "g1_selected_cold_portable_status_summary.json")
    g1_cold_verdict = load_json(audit_dir / "g1_selected_cold_portable_verdict.json")
    g1_cold_passed = (
        g1_cold_status.get("verdict") == G1_COLD_PORTABLE_VERDICT
        and g1_cold_status.get("all_note_checks_pass") is True
        and g1_cold_verdict.get("verdict") == G1_COLD_PORTABLE_VERDICT
    )
    check(
        checks,
        "g1_selected_cold_portable_replay",
        g1_cold_passed,
        {
            "status_verdict": g1_cold_status.get("verdict"),
            "all_note_checks_pass": g1_cold_status.get("all_note_checks_pass"),
            "verdict_json": g1_cold_verdict.get("verdict"),
        },
    )

    payload = {
        "surface": "reviewer_audit_contract_check",
        "audit_dir": str(audit_dir),
        "audit_mode": audit_mode,
        "all_checks_pass": all(item["passed"] for item in checks.values()),
        "checks": checks,
    }
    print(json.dumps(payload, indent=2, sort_keys=True))

    if not payload["all_checks_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
