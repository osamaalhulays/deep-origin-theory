#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
import tempfile
from pathlib import Path

from csv_semantic_compare import csv_files_match


OBJECT_DIR_NAME = "MOND_QUMOND_CLEAN_FRONT_POSITIVE_TRIAD_GRADE2_COURT_OBJECT_V1"
EXPECTED_CASES = ["NGC3992", "LVHIS077", "LVHIS072"]


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_case_table(path: Path) -> dict[str, dict]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        return {row["case_id"]: row for row in reader}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet-dir", required=True)
    args = parser.parse_args()

    packet_dir = Path(args.packet_dir).resolve()
    object_dir = packet_dir / "00_READ_FIRST" / OBJECT_DIR_NAME
    outputs_dir = object_dir / "04_OUTPUTS"

    verdict = load_json(outputs_dir / "TRIAD_VERDICT.json")
    ladder = load_json(outputs_dir / "TRIAD_GRADE_LADDER.json")
    case_rows = load_case_table(outputs_dir / "TRIAD_CASE_TABLE.csv")

    lvhis077 = case_rows.get("LVHIS077", {})
    lvhis072 = case_rows.get("LVHIS072", {})
    ngc3992 = case_rows.get("NGC3992", {})

    bundled_probe = {
        "triad_cases_match": verdict.get("triad_cases") == EXPECTED_CASES,
        "same_nuisance": verdict.get("same_nuisance") is True,
        "grade1_all_three": verdict.get("grade1_all_three") is True,
        "m2_non_rescue_all_three": verdict.get("m2_non_rescue_all_three") is True,
        "m3_non_rescue_all_three": verdict.get("m3_non_rescue_all_three") is True,
        "m4_not_admitted_all_three": verdict.get("m4_not_admitted_all_three") is True,
        "grade2_by_admitted_lane_exhaustion_all_three": (
            verdict.get("grade2_by_admitted_lane_exhaustion_all_three") is True
        ),
        "triad_level_family_verdict_materialized": (
            verdict.get("triad_level_family_verdict_materialized") is True
        ),
        "triad_level_family_verdict_grade": (
            verdict.get("triad_level_family_verdict_grade")
            == "GRADE2_LAWFUL_FAMILY_NON_RESCUE"
        ),
        "grade3_claim_absent": verdict.get("grade3_claim") is False,
        "whole_family_claim_absent": verdict.get("whole_mond_qumond_defeat_claim") is False,
        "cosmic_closure_claim_absent": verdict.get("cosmic_closure_claim") is False,
        "case_table_row_count": len(case_rows) == 3,
        "ladder_grade2_case_count": ladder.get("grade2_case_count") == 3,
        "ladder_m4_not_admitted_case_count": ladder.get("m4_not_admitted_case_count") == 3,
        "ngc3992_grade1_delta_loglike": (
            ngc3992.get("delta_loglike_qct_minus_qumond_obs_only") == "28.278080087647098"
        ),
        "lvhis077_grade1_delta_loglike": (
            lvhis077.get("delta_loglike_qct_minus_qumond_obs_only") == "23.731041042619225"
        ),
        "lvhis077_m2_family_best_member": lvhis077.get("m2_family_best_member") == "standard",
        "lvhis077_m3_family_best_member": lvhis077.get("m3_family_best_member") == "standard",
        "lvhis077_m3_best_a0_m_s2": lvhis077.get("m3_best_a0_m_s2") == "1.27e-10",
        "lvhis072_grade1_delta_loglike": (
            lvhis072.get("delta_loglike_qct_minus_qumond_obs_only") == "14.007753762883397"
        ),
        "lvhis072_m2_family_best_member": lvhis072.get("m2_family_best_member") == "standard",
        "lvhis072_m3_family_best_member": lvhis072.get("m3_family_best_member") == "standard",
        "lvhis072_m3_best_a0_m_s2": lvhis072.get("m3_best_a0_m_s2") == "1.27e-10",
    }

    replay_script = (
        object_dir / "03_RUN" / "REPRODUCE_MOND_QUMOND_CLEAN_FRONT_POSITIVE_TRIAD_GRADE2_COURT.py"
    )
    with tempfile.TemporaryDirectory(prefix="mond_qumond_triad_grade2_") as temp_dir:
        replay_dir = Path(temp_dir)
        subprocess.run(
            [
                "python3",
                str(replay_script),
                "--object-dir",
                str(object_dir),
                "--output-dir",
                str(replay_dir),
            ],
            check=True,
            text=True,
            capture_output=True,
        )
        replay_matches = (
            load_json(replay_dir / "TRIAD_VERDICT.json") == verdict
            and load_json(replay_dir / "TRIAD_GRADE_LADDER.json") == ladder
            and csv_files_match(
                replay_dir / "TRIAD_CASE_TABLE.csv",
                outputs_dir / "TRIAD_CASE_TABLE.csv",
            )
        )

    payload = {
        "surface": "mond_qumond_clean_front_positive_triad_grade2_court_object_probe",
        "object_dir": str(object_dir),
        "bundled_probe": bundled_probe,
        "all_bundled_checks_pass": all(bundled_probe.values()),
        "replay_check": {
            "attempted": True,
            "matched_bundled_outputs": replay_matches,
        },
    }
    print(json.dumps(payload, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
