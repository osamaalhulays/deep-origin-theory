#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import tempfile
from pathlib import Path


def run_builder(script: Path, cwd: Path) -> dict[str, object]:
    completed = subprocess.run(
        ["python3", str(script)],
        cwd=str(cwd),
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(completed.stdout)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet-dir", required=True)
    args = parser.parse_args()

    source_packet = Path(args.packet_dir).resolve()

    with tempfile.TemporaryDirectory(prefix="deep_origin_path_portability_probe_") as tmp:
        cold_root = Path(tmp) / source_packet.name
        shutil.copytree(source_packet, cold_root)
        audit_dir = cold_root / "artifacts" / "path_portability_audit_20260619"
        payload = run_builder(
            audit_dir / "build_path_portability_and_precision_audit.py",
            cold_root,
        )

        tsv_scan = payload.get("tsv_author_path_scan", {})
        text_scan = payload.get("all_text_author_path_scan", {})
        runtime_spotcheck = payload.get("active_runtime_package_relative_spotcheck", {})
        precision = payload.get("min_F_low_raw_precision_guard", {})
        section_summary = audit_dir / "TSV_AUTHOR_PATH_SECTION_SUMMARY_20260619.tsv"
        text_section_summary = audit_dir / "TEXT_AUTHOR_PATH_SECTION_SUMMARY_20260619.tsv"
        checks = {
            "total_tsv_scan_materialized": tsv_scan.get("total_tsv_files_scanned", 0) > 0,
            "historical_author_paths_declared": tsv_scan.get("tsv_files_with_author_path_strings", 0) > 0,
            "per_file_location_index_declared": tsv_scan.get("per_file_location_index") == "TSV_AUTHOR_PATH_SCAN_20260619.tsv",
            "per_section_summary_materialized": section_summary.exists() and section_summary.stat().st_size > 0,
            "all_text_scan_materialized": text_scan.get("total_text_files_scanned", 0) > 0,
            "all_text_author_paths_declared": text_scan.get("text_files_with_author_path_strings", 0) > 0,
            "read_first_author_paths_closed": text_scan.get("read_first_text_files_with_author_path_strings") == 0,
            "runtime_or_output_author_paths_closed": text_scan.get("runtime_or_output_text_files_with_author_path_strings") == 0,
            "publication_facing_portability_verdict_closed": payload.get("publication_facing_portability_verdict") == "all_00_read_first_text_surfaces_are_free_of_author_local_path_markers",
            "active_runtime_output_portability_verdict_closed": payload.get("active_runtime_output_portability_verdict") == "all_detected_runtime_or_output_author_path_markers_are_closed",
            "text_section_summary_materialized": text_section_summary.exists() and text_section_summary.stat().st_size > 0,
            "active_runtime_spotchecks_pass": runtime_spotcheck.get("all_spotchecks_pass") is True,
            "new_rank9_capsules_in_scope": tsv_scan.get("new_rank9_capsules_are_in_scope") is True,
            "rewrite_policy_preserves_source_rows": tsv_scan.get("rewrite_policy") == "do_not_rewrite_historical_tsv_rows",
            "min_f_low_raw_records_found": precision.get("records_found") == 2,
            "min_f_low_raw_all_strings": precision.get("all_values_are_strings") is True,
            "min_f_low_raw_decimal_parse_ok": precision.get("all_strings_parse_as_decimal") is True,
        }

        result = {
            "object": "PATH_PORTABILITY_AND_PRECISION_COLD_REVIEW_PROBE_20260619",
            "all_checks_pass": all(checks.values()),
            "checks": checks,
            "tsv_scan": tsv_scan,
            "all_text_scan": text_scan,
            "active_runtime_package_relative_spotcheck": runtime_spotcheck,
            "new_rank9_capsule_scan": tsv_scan.get("new_rank9_capsule_scan", []),
            "min_F_low_raw_precision_guard": {
                "records_found": precision.get("records_found"),
                "all_values_are_strings": precision.get("all_values_are_strings"),
                "all_strings_parse_as_decimal": precision.get("all_strings_parse_as_decimal"),
                "precision_policy": precision.get("precision_policy"),
            },
        }

    print(json.dumps(result, indent=2, sort_keys=True))
    if not result["all_checks_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
