#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import json
import subprocess
import tempfile
from pathlib import Path

from csv_semantic_compare import csv_files_match


OBJECT_DIR_NAME = "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_GBAR_DIAGNOSTIC_NORMALIZATION_OBJECT_V1"


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def csv_row_count(path: Path) -> int:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        next(reader)
        return sum(1 for _ in reader)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet-dir", required=True)
    parser.add_argument("--observed-zip")
    parser.add_argument("--baryons-zip")
    args = parser.parse_args()

    packet_dir = Path(args.packet_dir).resolve()
    object_dir = packet_dir / "00_READ_FIRST" / OBJECT_DIR_NAME
    outputs_dir = object_dir / "04_OUTPUTS"

    policy = load_json(outputs_dir / "NORMALIZATION_POLICY_LOCK.json")
    summary = load_json(outputs_dir / "NORMALIZATION_SUMMARY.json")
    audit = load_json(outputs_dir / "NORMALIZATION_AUDIT.json")
    boundary = load_json(outputs_dir / "PUBLIC_BOUNDARY_MANIFEST_20260615.json")
    galaxy_count = csv_row_count(outputs_dir / "GALAXY_DIAGNOSTIC_STATUS.csv")

    bundled_probe = {
        "all_five_choices_frozen": policy.get("all_five_choices_frozen") is True,
        "diagnostic_lane_is_gbar_only": summary.get("diagnostic_lane") == "observed_row_gbar_only",
        "matched_galaxy_count": summary.get("matched_galaxy_count") == 49,
        "observed_row_count": summary.get("observed_row_count") == 1082,
        "materialized_diagnostic_row_count": summary.get("materialized_diagnostic_row_count") == 1082,
        "galaxy_status_row_count": galaxy_count == 49,
        "rho_b_authoring_not_materialized": summary.get("rho_b_authoring_materialized") is False,
        "theory_side_authoring_not_promoted": summary.get("theory_side_authoring_promotion") is False,
        "all_signed_total_baryonic_powers_positive": (
            summary.get("all_signed_total_baryonic_powers_positive") is True
        ),
        "public_boundary_status": (
            boundary.get("status")
            == "row_level_or_near_rowwise_direct_author_derivatives_withheld_from_public_packet"
        ),
        "public_boundary_withheld_file_count": boundary.get("withheld_file_count") == 1,
        "public_boundary_withheld_row_csv": boundary.get("withheld_files") == ["OBSERVED_ROW_GBAR_DIAGNOSTIC.csv"],
    }

    payload = {
        "surface": "author_supplied_payload_b_gbar_diagnostic_normalization_probe",
        "object_dir": str(object_dir),
        "bundled_probe": bundled_probe,
        "all_bundled_checks_pass": all(bundled_probe.values()),
        "replay_check": {
            "attempted": False,
            "matched_bundled_summary_surfaces": None,
        },
    }

    if args.observed_zip and args.baryons_zip:
        replay_script = (
            object_dir / "03_RUN" / "REPRODUCE_AUTHOR_SUPPLIED_PAYLOAD_B_GBAR_DIAGNOSTIC_NORMALIZATION.py"
        )
        with tempfile.TemporaryDirectory(prefix="author_supplied_payload_b_gbar_diag_") as temp_dir:
            replay_dir = Path(temp_dir)
            subprocess.run(
                [
                    "python3",
                    str(replay_script),
                    "--observed-zip",
                    str(Path(args.observed_zip).resolve()),
                    "--baryons-zip",
                    str(Path(args.baryons_zip).resolve()),
                    "--output-dir",
                    str(replay_dir),
                ],
                check=True,
                text=True,
                capture_output=True,
            )
            replay_policy = load_json(replay_dir / "NORMALIZATION_POLICY_LOCK.json")
            replay_summary = load_json(replay_dir / "NORMALIZATION_SUMMARY.json")
            replay_audit = load_json(replay_dir / "NORMALIZATION_AUDIT.json")
            replay_row_count = csv_row_count(replay_dir / "OBSERVED_ROW_GBAR_DIAGNOSTIC.csv")
            replay_matches = (
                replay_policy == policy
                and replay_summary == summary
                and replay_audit == audit
                and replay_row_count == summary.get("materialized_diagnostic_row_count")
                and csv_files_match(
                    replay_dir / "GALAXY_DIAGNOSTIC_STATUS.csv",
                    outputs_dir / "GALAXY_DIAGNOSTIC_STATUS.csv",
                )
            )
        payload["replay_check"] = {
            "attempted": True,
            "matched_bundled_summary_surfaces": replay_matches,
            "replayed_row_count": replay_row_count,
        }

    print(json.dumps(payload, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
