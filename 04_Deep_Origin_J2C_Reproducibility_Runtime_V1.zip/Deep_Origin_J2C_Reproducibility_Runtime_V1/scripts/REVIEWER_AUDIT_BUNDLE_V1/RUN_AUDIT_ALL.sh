#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
if [[ -n "${DEEP_ORIGIN_PACKET_DIR:-}" ]]; then
  PACKET_DIR="$(cd "$DEEP_ORIGIN_PACKET_DIR" && pwd)"
else
  PACKET_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
fi
AUDIT_DIR="$(mktemp -d "${TMPDIR:-/tmp}/deep_origin_reviewer_audit_XXXXXX")"
export PYTHONDONTWRITEBYTECODE=1
export QCT_COLD_REVIEW="${QCT_COLD_REVIEW:-1}"
export QCT_ALLOW_OPTIONAL_EXTERNAL_ARCHIVE="${QCT_ALLOW_OPTIONAL_EXTERNAL_ARCHIVE:-0}"
export AUTHOR_SUPPLIED_OBS_ZIP="${AUTHOR_SUPPLIED_OBS_ZIP:-}"
export AUTHOR_SUPPLIED_BARYONS_ZIP="${AUTHOR_SUPPLIED_BARYONS_ZIP:-}"

print_audit_dir() {
  local exit_code=$?
  echo
  if [[ $exit_code -eq 0 ]]; then
    echo "Outputs saved under:"
  else
    echo "Audit stopped early. Partial outputs saved under:"
  fi
  echo "$AUDIT_DIR"
}

trap print_audit_dir EXIT

verify_inner_zip() {
  local zip_path="$1"
  local label="$2"
  local extract_dir="$AUDIT_DIR/$label"
  local ledger_path
  local ledger_dir

  mkdir -p "$extract_dir"
  unzip -q "$zip_path" -d "$extract_dir"

  ledger_path="$(find_first_file "$extract_dir" "SHA256SUMS.txt")"
  if [[ -z "$ledger_path" ]]; then
    echo "Could not find SHA256SUMS.txt inside $label." >&2
    exit 1
  fi

  assert_clean_tree "$extract_dir" "$label"
  ledger_dir="$(cd "$(dirname "$ledger_path")" && pwd)"
  assert_portable_ledger "$ledger_path" "$label"

  (
    cd "$ledger_dir"
    shasum -a 256 -c SHA256SUMS.txt
  ) > "$AUDIT_DIR/${label}_sha_check.txt"
}

assert_portable_ledger() {
  local ledger_path="$1"
  local label="$2"

  if grep -nE '^[0-9a-fA-F]{64}[[:space:]]+/' "$ledger_path" > "$AUDIT_DIR/${label}_absolute_path_ledger_entries.txt"; then
    echo "$label ledger contains absolute-path entries and is not portable." >&2
    exit 1
  fi
  rm -f "$AUDIT_DIR/${label}_absolute_path_ledger_entries.txt"

  if grep -nE '(^|/)(__pycache__)(/|$)|\.pyc$' "$ledger_path" > "$AUDIT_DIR/${label}_derived_artifact_ledger_entries.txt"; then
    echo "$label ledger contains derived-artifact entries and is not cold-review clean." >&2
    exit 1
  fi
  rm -f "$AUDIT_DIR/${label}_derived_artifact_ledger_entries.txt"
}

assert_clean_tree() {
  local root_dir="$1"
  local label="$2"

  find "$root_dir" \( -type d -name '__pycache__' -o -type f -name '*.pyc' \) -print > "$AUDIT_DIR/${label}_derived_tree_artifacts.txt"
  if [[ -s "$AUDIT_DIR/${label}_derived_tree_artifacts.txt" ]]; then
    echo "$label tree contains derived artifacts and is not cold-review clean." >&2
    exit 1
  fi
  rm -f "$AUDIT_DIR/${label}_derived_tree_artifacts.txt"
}

find_first_file() {
  local root_dir="$1"
  local target_name="$2"

  find "$root_dir" -type f -name "$target_name" -print -quit
}

echo "[1/23] Verifying packet-root SHA256 ledger"
assert_clean_tree "$PACKET_DIR" "packet_root"
assert_portable_ledger "$PACKET_DIR/SHA256SUMS.txt" "packet_root"
(
  cd "$PACKET_DIR"
  shasum -a 256 -c SHA256SUMS.txt
) > "$AUDIT_DIR/packet_root_sha_check.txt"

echo "[2/23] Verifying inner shelf ledgers for A, B, and C"
verify_inner_zip \
  "$PACKET_DIR/01_A_PreRank9/Deep_Origin_Theory_English_Package_A_PreRank9_20260603.zip" \
  "shelf_A"
verify_inner_zip \
  "$PACKET_DIR/02_B_Rank9/Deep_Origin_Theory_English_Public_Wave_20260603.zip" \
  "shelf_B"
verify_inner_zip \
  "$PACKET_DIR/03_C_Cluster/Deep_Origin_Theory_C_Cluster_Dossier_20260605.zip" \
  "shelf_C"

echo "[3/23] Rebuilding the current NGC0247 stack"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC0247_CURRENT_STACK_V1.py" \
  > "$AUDIT_DIR/ngc0247_current_stack.json"

echo "[4/23] Rebuilding the current NGC0247 row comparator"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC0247_PHASE2_CURRENT_QCT_ROW_COMPARATOR_V1.py" \
  > "$AUDIT_DIR/ngc0247_current_row_comparator.json"

echo "[5/23] Rebuilding the NGC0247 parity-ready pilot object"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC0247_PARITY_READY_PILOT_OBJECT_V1.py" \
  > "$AUDIT_DIR/ngc0247_parity_ready_pilot_object.json"

echo "[6/23] Rebuilding the NGC0247 matched-nuisance policy lock"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC0247_MATCHED_NUISANCE_POLICY_LOCK_V1.py" \
  > "$AUDIT_DIR/ngc0247_matched_nuisance_policy_lock.json"

echo "[7/23] Replaying the NGC0247 matched-nuisance window"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_V1.py" \
  > "$AUDIT_DIR/ngc0247_phase2_matched_nuisance_window_replay.json"

echo "[8/23] Replaying the NGC0247 executed parity witness scoring shell"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC0247_EXECUTED_PARITY_WITNESS_SCORING_SHELL_V1.py" \
  > "$AUDIT_DIR/ngc0247_executed_parity_witness_scoring_shell.json"

echo "[9/23] Auditing the second named fixed-QUMOND witness"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC6946_FIXED_QUMOND_SUMMARY_V1.py" \
  > "$AUDIT_DIR/ngc6946_fixed_qumond_summary.json"

echo "[10/23] Probing the MACS1206 public-source replay contract"

C_SCRIPT_PATH="$(find_first_file "$AUDIT_DIR/shelf_C" "REPRODUCE_MACS1206_PUBLIC_SOURCE_PROFILE_V1.cjs")"

if [[ -z "$C_SCRIPT_PATH" ]]; then
  echo "Could not find REPRODUCE_MACS1206_PUBLIC_SOURCE_PROFILE_V1.cjs inside extracted shelf C." >&2
  exit 1
fi

node \
  "$C_SCRIPT_PATH" \
  > "$AUDIT_DIR/macs1206_public_source_profile.json"

echo "[11/23] Replaying the first non-toy G4 NGC4214 crossing object"
python3 \
  "$PACKET_DIR/00_READ_FIRST/G4_NGC4214_FIRST_NONTOY_FORMD_RUN_V1/03_RUN/REPRODUCE_G4_NGC4214_FIRST_NONTOY_RUN.py" \
  --output-dir "$AUDIT_DIR/g4_ngc4214_first_nontoy_run" \
  > "$AUDIT_DIR/g4_ngc4214_first_nontoy_adjudication.json"

echo '[12/23] Probing the author-supplied `PAYLOAD_B` receipt object'
if [[ -n "$AUTHOR_SUPPLIED_OBS_ZIP" && -n "$AUTHOR_SUPPLIED_BARYONS_ZIP" ]]; then
  python3 \
    "$SCRIPT_DIR/PROBE_AUTHOR_SUPPLIED_PAYLOAD_B_RECEIPT_AUDIT_OBJECT.py" \
    --packet-dir "$PACKET_DIR" \
    --observed-zip "$AUTHOR_SUPPLIED_OBS_ZIP" \
    --baryons-zip "$AUTHOR_SUPPLIED_BARYONS_ZIP" \
    > "$AUDIT_DIR/author_supplied_payload_b_receipt_audit_probe.json"
else
  python3 \
    "$SCRIPT_DIR/PROBE_AUTHOR_SUPPLIED_PAYLOAD_B_RECEIPT_AUDIT_OBJECT.py" \
    --packet-dir "$PACKET_DIR" \
    > "$AUDIT_DIR/author_supplied_payload_b_receipt_audit_probe.json"
fi

echo "[13/23] Probing the author-supplied 49-galaxy gbar diagnostic normalization object"
if [[ -n "$AUTHOR_SUPPLIED_OBS_ZIP" && -n "$AUTHOR_SUPPLIED_BARYONS_ZIP" ]]; then
  python3 \
    "$SCRIPT_DIR/PROBE_AUTHOR_SUPPLIED_PAYLOAD_B_GBAR_DIAGNOSTIC_NORMALIZATION_OBJECT.py" \
    --packet-dir "$PACKET_DIR" \
    --observed-zip "$AUTHOR_SUPPLIED_OBS_ZIP" \
    --baryons-zip "$AUTHOR_SUPPLIED_BARYONS_ZIP" \
    > "$AUDIT_DIR/author_supplied_payload_b_gbar_diagnostic_normalization_probe.json"
else
  python3 \
    "$SCRIPT_DIR/PROBE_AUTHOR_SUPPLIED_PAYLOAD_B_GBAR_DIAGNOSTIC_NORMALIZATION_OBJECT.py" \
    --packet-dir "$PACKET_DIR" \
    > "$AUDIT_DIR/author_supplied_payload_b_gbar_diagnostic_normalization_probe.json"
fi

echo "[14/23] Probing the author-supplied 49-galaxy rowwise comparison admissibility object"
if [[ -n "$AUTHOR_SUPPLIED_OBS_ZIP" && -n "$AUTHOR_SUPPLIED_BARYONS_ZIP" ]]; then
  python3 \
    "$SCRIPT_DIR/PROBE_AUTHOR_SUPPLIED_PAYLOAD_B_ROWWISE_COMPARISON_ADMISSIBILITY_OBJECT.py" \
    --packet-dir "$PACKET_DIR" \
    --observed-zip "$AUTHOR_SUPPLIED_OBS_ZIP" \
    --baryons-zip "$AUTHOR_SUPPLIED_BARYONS_ZIP" \
    > "$AUDIT_DIR/author_supplied_payload_b_rowwise_comparison_admissibility_probe.json"
else
  python3 \
    "$SCRIPT_DIR/PROBE_AUTHOR_SUPPLIED_PAYLOAD_B_ROWWISE_COMPARISON_ADMISSIBILITY_OBJECT.py" \
    --packet-dir "$PACKET_DIR" \
    > "$AUDIT_DIR/author_supplied_payload_b_rowwise_comparison_admissibility_probe.json"
fi

echo "[15/23] Probing the bounded MOND/QUMOND clean-front triad Grade-2 court object"
python3 \
  "$SCRIPT_DIR/PROBE_MOND_QUMOND_CLEAN_FRONT_POSITIVE_TRIAD_GRADE2_COURT_OBJECT.py" \
  --packet-dir "$PACKET_DIR" \
  > "$AUDIT_DIR/mond_qumond_clean_front_positive_triad_grade2_court_object_probe.json"

echo "[16/23] Probing the G10 external-methods and G7 review-ledger stack"
python3 \
  "$SCRIPT_DIR/PROBE_G10_EXTERNAL_METHODS_AND_G7_REVIEW_LEDGER_STACK.py" \
  --packet-dir "$PACKET_DIR" \
  > "$AUDIT_DIR/g10_external_methods_and_g7_review_ledger_stack_probe.json"

echo "[17/23] Probing the distinguished cosmology proof spine from a standalone cold packet copy"
python3 \
  "$SCRIPT_DIR/PROBE_DISTINGUISHED_COSMOLOGY_PROOF_SPINE_OBJECT.py" \
  --packet-dir "$PACKET_DIR" \
  > "$AUDIT_DIR/distinguished_cosmology_proof_spine_probe.json"

echo "[18/23] Probing H100 and distance-ladder cited-anchor packaging from a standalone cold packet copy"
python3 \
  "$SCRIPT_DIR/PROBE_H100_DISTANCE_ANCHOR_PACKAGING_OBJECT.py" \
  --packet-dir "$PACKET_DIR" \
  > "$AUDIT_DIR/h100_distance_anchor_packaging_probe.json"

echo "[19/23] Probing path portability and high-precision decimal policy from a standalone cold packet copy"
python3 \
  "$SCRIPT_DIR/PROBE_PATH_PORTABILITY_AND_PRECISION_AUDIT_OBJECT.py" \
  --packet-dir "$PACKET_DIR" \
  > "$AUDIT_DIR/path_portability_and_precision_probe.json"

echo "[20/23] Probing Rank9 full-gain provenance capsules from a standalone cold packet copy"
python3 \
  "$SCRIPT_DIR/PROBE_RANK9_FULL_GAIN_PROVENANCE_CAPSULES_OBJECT.py" \
  --packet-dir "$PACKET_DIR" \
  > "$AUDIT_DIR/rank9_full_gain_provenance_capsules_probe.json"

echo "[21/23] Probing L2 late object recovery and navigation cleanup from a standalone cold packet copy"
python3 \
  "$SCRIPT_DIR/PROBE_L2_LATE_OBJECT_RECOVERY_AND_NAVIGATION_CLEANUP_OBJECT.py" \
  --packet-dir "$PACKET_DIR" \
  > "$AUDIT_DIR/l2_late_object_recovery_and_navigation_cleanup_probe.json"

echo "[22/23] Replaying the selected G1 runner from a standalone cold packet copy"
mkdir -p "$AUDIT_DIR/cold_packet"
cp -R "$PACKET_DIR" "$AUDIT_DIR/cold_packet/"
PACKET_BASENAME="$(basename "$PACKET_DIR")"
python3 \
  "$AUDIT_DIR/cold_packet/$PACKET_BASENAME/00_READ_FIRST/POST_CAGE_BRANCH_U1_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_V1/03_RUN/REPRODUCE_POST_CAGE_BRANCH_U1_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_CHECKS.py"
cp \
  "$AUDIT_DIR/cold_packet/$PACKET_BASENAME/00_READ_FIRST/POST_CAGE_BRANCH_U1_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_V1/04_OUTPUTS/status_summary.json" \
  "$AUDIT_DIR/g1_selected_cold_portable_status_summary.json"
cp \
  "$AUDIT_DIR/cold_packet/$PACKET_BASENAME/00_READ_FIRST/POST_CAGE_BRANCH_U1_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_V1/04_OUTPUTS/verdict.json" \
  "$AUDIT_DIR/g1_selected_cold_portable_verdict.json"

echo "[23/23] Verifying semantic expectations against runtime outputs"
python3 \
  "$SCRIPT_DIR/VERIFY_EXPECTED_OUTPUTS.py" \
  --audit-dir "$AUDIT_DIR" \
  > "$AUDIT_DIR/reviewer_audit_contract_check.json"

echo
echo "Audit complete."
