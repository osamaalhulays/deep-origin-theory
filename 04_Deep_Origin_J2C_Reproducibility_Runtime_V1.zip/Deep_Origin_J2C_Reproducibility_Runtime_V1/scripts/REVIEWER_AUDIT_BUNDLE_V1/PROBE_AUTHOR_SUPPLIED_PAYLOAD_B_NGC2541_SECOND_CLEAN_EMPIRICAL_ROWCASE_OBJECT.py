#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
import tempfile
from pathlib import Path

from csv_semantic_compare import csv_files_match


OBJECT_DIR_NAME = "AUTHOR_SUPPLIED_PAYLOAD_B_NGC2541_SECOND_CLEAN_EMPIRICAL_ROWCASE_OBJECT_V1"
SOURCE_OBJECT_DIR_NAME = "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_OBJECT_V1"


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def csv_row_count(path: Path) -> int:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        next(reader)
        return sum(1 for _ in reader)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet-dir", required=True)
    args = parser.parse_args()

    packet_dir = Path(args.packet_dir).resolve()
    object_dir = packet_dir / "00_READ_FIRST" / OBJECT_DIR_NAME
    source_dir = packet_dir / "00_READ_FIRST" / SOURCE_OBJECT_DIR_NAME / "04_OUTPUTS"
    outputs_dir = object_dir / "04_OUTPUTS"

    summary = load_json(outputs_dir / "ROWCASE_SUMMARY.json")
    row_count = csv_row_count(outputs_dir / "NGC2541_EMPIRICAL_ROWCASE.csv")
    key_row_count = csv_row_count(outputs_dir / "NGC2541_KEY_ROWS.csv")

    bundled_probe = {
        "target_is_ngc2541": summary.get("galaxy") == "NGC2541",
        "comparison_scope_is_empirical_gobs_gbar_only": (
            summary.get("comparison_scope") == "empirical_gobs_gbar_only"
        ),
        "clean_first_priority_rank": summary.get("clean_first_priority_rank") == 2,
        "observed_row_count": summary.get("observed_row_count") == 31,
        "exact_interpolation_row_count": summary.get("exact_interpolation_row_count") == 2,
        "linear_interpolation_row_count": summary.get("linear_interpolation_row_count") == 29,
        "all_rows_comparison_ready": summary.get("all_rows_comparison_ready") is True,
        "all_rows_clean_first": summary.get("all_rows_clean_first") is True,
        "all_delta_positive": summary.get("all_delta_positive") is True,
        "gbar_peak_radius_kpc": summary.get("gbar_peak_radius_kpc") == 1.07,
        "gbar_nonincreasing_after_peak": summary.get("gbar_nonincreasing_after_peak") is True,
        "rowcase_csv_count": row_count == 31,
        "key_row_csv_count": key_row_count == 3,
        "theory_side_authoring_eligible": summary.get("theory_side_authoring_eligible") is False,
    }

    replay_script = (
        object_dir / "03_RUN" / "REPRODUCE_AUTHOR_SUPPLIED_PAYLOAD_B_NGC2541_SECOND_CLEAN_EMPIRICAL_ROWCASE.py"
    )
    with tempfile.TemporaryDirectory(prefix="author_supplied_ngc2541_rowcase_") as temp_dir:
        replay_dir = Path(temp_dir)
        subprocess.run(
            [
                "python3",
                str(replay_script),
                "--rowwise-csv",
                str(source_dir / "OBSERVED_ROW_EMPIRICAL_COMPARISON_READY.csv"),
                "--ledger-csv",
                str(source_dir / "GALAXY_COMPARISON_ADMISSIBILITY_LEDGER.csv"),
                "--shortlist-csv",
                str(source_dir / "CLEAN_FIRST_PRIORITY_SHORTLIST.csv"),
                "--output-dir",
                str(replay_dir),
            ],
            check=True,
            text=True,
            capture_output=True,
        )
        replay_matches = (
            load_json(replay_dir / "ROWCASE_SUMMARY.json") == summary
            and csv_files_match(
                replay_dir / "NGC2541_EMPIRICAL_ROWCASE.csv",
                outputs_dir / "NGC2541_EMPIRICAL_ROWCASE.csv",
            )
            and csv_files_match(
                replay_dir / "NGC2541_KEY_ROWS.csv",
                outputs_dir / "NGC2541_KEY_ROWS.csv",
            )
        )

    payload = {
        "surface": "author_supplied_payload_b_ngc2541_second_clean_empirical_rowcase_probe",
        "object_dir": str(object_dir),
        "bundled_probe": bundled_probe,
        "all_bundled_checks_pass": all(bundled_probe.values()),
        "replay_check": {
            "attempted": True,
            "matched_bundled_outputs": replay_matches,
        },
    }
    print(json.dumps(payload, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
