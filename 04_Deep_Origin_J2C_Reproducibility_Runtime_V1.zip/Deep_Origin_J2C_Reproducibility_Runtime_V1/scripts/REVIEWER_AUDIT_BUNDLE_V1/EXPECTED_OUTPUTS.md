# Reviewer Audit Bundle Expected Outputs

Date: `2026-06-15`

This mini-bundle is meant for one cold reviewer pass through the current
English packet without requiring a long narrative read first.

## Run order

For a quick bounded reviewer pass, run:

- `REVIEWER_AUDIT_BUNDLE_V1/RUN_AUDIT_FAST.sh`

The final semantic checker can be run on either a fast-audit output directory
or a full-audit output directory:

- `REVIEWER_AUDIT_BUNDLE_V1/VERIFY_EXPECTED_OUTPUTS.py --audit-dir <FAST_OUTPUT_DIR>`
- `REVIEWER_AUDIT_BUNDLE_V1/VERIFY_EXPECTED_OUTPUTS.py --audit-dir <FULL_OUTPUT_DIR>`

It auto-detects `audit_mode = fast` versus `audit_mode = full`. The fast path
does not produce the full-only NGC0247 pilot/policy/window/scoring/NGC6946
outputs, so the checker validates the common fast contract and records those
full-only files as intentionally skipped.

For the full contract audit, run:

- `REVIEWER_AUDIT_BUNDLE_V1/RUN_AUDIT_FULL.sh`

Backward-compatible alias:

- `REVIEWER_AUDIT_BUNDLE_V1/RUN_AUDIT_ALL.sh`

The detailed expected-output list below describes the **full** audit path.
The fast audit is a bounded subset plus the same cold-copy provenance probes.

## Expected success shape

The run is healthy if all of the following happen:

1. `packet_root_sha_check.txt` is produced and contains only `OK` lines.
2. `shelf_A_sha_check.txt` is produced and contains only `OK` lines.
3. `shelf_B_sha_check.txt` is produced and contains only `OK` lines.
4. `shelf_C_sha_check.txt` is produced and contains only `OK` lines.
5. `ngc0247_current_stack.json` is produced and is valid JSON.
6. `ngc0247_current_row_comparator.json` is produced and is valid JSON.
7. `ngc0247_parity_ready_pilot_object.json` is produced and is valid JSON.
8. `ngc0247_matched_nuisance_policy_lock.json` is produced and is valid JSON.
9. `ngc0247_phase2_matched_nuisance_window_replay.json` is produced and is valid JSON.
10. `ngc0247_executed_parity_witness_scoring_shell.json` is produced and is valid JSON.
11. `ngc6946_fixed_qumond_summary.json` is produced and is valid JSON.
12. `macs1206_public_source_profile.json` is produced.
13. `g4_ngc4214_first_nontoy_adjudication.json` is produced and is valid JSON.
14. `g4_ngc4214_first_nontoy_run/G4_CROSSING_ADJUDICATION.json` is produced.
15. `author_supplied_payload_b_receipt_audit_probe.json` is produced and is valid JSON.
16. `author_supplied_payload_b_gbar_diagnostic_normalization_probe.json` is produced and is valid JSON.
17. `author_supplied_payload_b_rowwise_comparison_admissibility_probe.json` is produced and is valid JSON.
18. `mond_qumond_clean_front_positive_triad_grade2_court_object_probe.json` is produced and is valid JSON.
19. `g10_external_methods_and_g7_review_ledger_stack_probe.json` is produced and is valid JSON.
20. `distinguished_cosmology_proof_spine_probe.json` is produced and is valid JSON.
21. `h100_distance_anchor_packaging_probe.json` is produced and is valid JSON.
22. `path_portability_and_precision_probe.json` is produced and is valid JSON.
23. `rank9_full_gain_provenance_capsules_probe.json` is produced and is valid JSON.
24. `l2_late_object_recovery_and_navigation_cleanup_probe.json` is produced and is valid JSON.
25. `g1_selected_cold_portable_status_summary.json` is produced and is valid JSON.
26. `g1_selected_cold_portable_verdict.json` is produced and is valid JSON.
27. `reviewer_audit_contract_check.json` is produced and is valid JSON.
28. the run prints one unique temporary audit-directory path at the end.

The run is also healthy only if the packet-root and inner-shelf ledgers are:

- relative-path portable
- free of absolute-path entries
- free of derived artifacts such as `__pycache__` or `.pyc`
- and the semantic checker reports `all_checks_pass = true`

## Bounded audit expectations

For the `NGC0247` pilot-object bounded audit surface, also expect:

- `pilot_object_materialized = true`
- `numeric_readiness_gate_closed = true`
- verdict =
  `NGC0247_PARITY_READY_PILOT_OBJECT_MATERIALIZED__PROMOTE_THIS_OBJECT_NOT_THE_HISTORICAL_CONTROL_SHELL`

For the `NGC0247` matched-nuisance policy-lock bounded audit surface, also
expect:

- `policy_lock_closed = true`
- `count_level_alignment_with_current_rotmod_rows = true`
- verdict =
  `NGC0247_MATCHED_NUISANCE_SOURCE_POLICY_LOCK_CLOSED__NEXT_EXECUTION_TOOTH_IS_NUISANCE_SHIFTED_ROW_REMATERIALIZATION`

For the `NGC0247` matched-nuisance window replay bounded audit surface, two
outcomes are acceptable:

- cold packet default:
  - `historical_delta_surface_replay_mode = packet_visible_delta_1d_replay_only`
  - `optional_external_archive_check.status = skipped_optional_archive_not_bundled`
  - `rescue_seen_within_1sigma_box = false`
  - verdict =
    `NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_CLOSED__LAWFUL_DI_BOX_DOES_NOT_RESCUE_QCT`
- author-side archival enrichment opt-in:
  - `historical_delta_surface_replay_mode = V1_fixed_delta_surface`
  - `optional_external_archive_check.status = verified_optional_archive`
  - `rescue_seen_within_1sigma_box = false`
  - verdict =
    `NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_CLOSED__LAWFUL_DI_BOX_DOES_NOT_RESCUE_QCT`

For the `NGC0247` executed parity witness scoring-shell replay surface, also
expect:

- `faithful_delta_aic_total = -15.398764714420167`
- `component_aware_delta_aic_total = -39.63154845025974`
- `fixed_public_delta_aic_total = -13.914066963632308`
- `scoring_shell_replay_closed = true`
- verdict =
  `NGC0247_EXECUTED_PARITY_WITNESS_SCORING_SHELL_REPLAY_CLOSED__SUPPORT_RECEIPTS_AND_PACKET_SHELLS_ARE_NUMERICALLY_CONCORDANT`

For the `NGC6946` bounded audit surface, also expect:

- `all_QUMOND_residuals_negative = true`
- `delta_true_sign_split_label = 29 negative / 29 positive`

For the first non-toy `G4` / `NGC4214` bounded audit surface, also expect:

- adjudication status =
  `G4_FIRST_NONTOY_FORMD_RUN_REPRODUCED_AND_MATCHED_CANONICAL_PACKET_OUTPUTS`
- `all_checks_pass = true`
- reproduced status = `D3_FIRST_COMPARISON_STACK_MATERIALIZED`
- `form_a_materialized = true`
- `prediction_rows_materialized = true`
- `comparison_stack_materialized = true`
- `row_count = 14`
- `chi2_total = 658.7148518641796`
- `loglike_gaussian_diag = -305.86832116819267`

## Direct-author payload expectations

For the author-supplied `PAYLOAD_B` receipt object, also expect:

- bundled receipt / manifest / schema checks all pass
- `matched_pair_count = 49`
- `observed_row_count = 1082`
- `baryonic_row_count = 4850`
- the accepted cold-review mode may stop at bundled receipt / manifest verification
  if the raw author zips are not republished inside the packet
- if the reviewer supplies the raw zips separately, one exact replay match is
  also acceptable and stronger

For the author-supplied `49`-galaxy `gbar` diagnostic normalization object,
also expect:

- the five local downstream choices are frozen explicitly
- `matched_galaxy_count = 49`
- `observed_row_count = 1082`
- `materialized_diagnostic_row_count = 1082`
- the lane is explicit `gbar`-only diagnostics at observed radii
- `rho_b(r)` authoring remains false
- theory-side promotion remains false
- all signed total baryonic powers stay positive at observed radii
- the public packet now withholds the row-level diagnostic CSV while keeping
  the summary, policy, audit, and galaxy-ledger surfaces
- if the reviewer supplies the raw zips separately, one exact replay match
  against the bundled summary surfaces is also acceptable and stronger

For the author-supplied `49`-galaxy rowwise comparison-admissibility object,
also expect:

- `comparison_scope = empirical_gobs_gbar_only`
- `diagnostic_rowwise_ready_galaxy_count = 49`
- `diagnostic_rowwise_ready_row_count = 1082`
- `clean_first_galaxy_count = 11`
- `clean_first_row_count = 184`
- `first_clean_candidate = NGC1313`
- theory-side eligible galaxy count = `0`
- the public packet now withholds the row-level comparison-ready CSV while
  keeping the summary, ledger, shortlist, and grammar-lock surfaces
- if the reviewer supplies the raw zips separately, one exact replay match
  against the bundled summary surfaces is also acceptable and stronger

For the bounded MOND/QUMOND clean-front triad Grade-2 court object, also
expect:

- one clean-front triad court object is bundled and replayable
- its bundled checks pass
- its replay match passes

For the `G10` external-methods and `G7` review-ledger stack, also expect:

- bundled checks pass
- the external-methods boundary and review-ledger surfaces remain present

For the distinguished cosmology proof-spine cold replay, also expect:

- `all_checks_pass = true`
- proof-spine selftest output =
  `DISTINGUISHED_COSMOLOGY_PROOF_SPINE_VERIFIED`
- Direct-F scope object verdict =
  `DISTINGUISHED_COSMOLOGY_CERT_DOMAIN_CLOSURE_MATERIALIZED__DIRECTF_SCOPE_FROZEN__CLASS_UPGRADE_BLOCKED`
- component true-enclosure frontier verdict =
  `DISTINGUISHED_COSMOLOGY_COMPONENT_TRUE_ENCLOSURE_FRONTIER_MATERIALIZED__STATE_TUBE_BASELINE_CONFIRMED__DIRECTF_X_SIGN_NOT_YET_OPENED`
- the generated input-manifest paths are package-relative, not author-machine absolute paths

For the path portability and precision audit, also expect:

- the all-TSV author-path scan is materialized
- the per-file location index is declared as
  `TSV_AUTHOR_PATH_SCAN_20260619.tsv`
- the per-section summary is materialized as
  `TSV_AUTHOR_PATH_SECTION_SUMMARY_20260619.tsv`
- the four new Rank9 provenance capsules are explicitly inside the TSV scan
- historical author-machine path strings are declared, not rewritten
- rewrite policy =
  `do_not_rewrite_historical_tsv_rows`
- `min_F_low_raw` has two records in the current packet
- all `min_F_low_raw` values remain strings
- all `min_F_low_raw` strings parse as decimal values

For the H100 / distance-ladder cited-anchor packaging probe, also expect:

- `anchor_count = 14`
- every anchor named in
  `RANK10_POST_SEAL_BACKGROUND_DISTANCE_POLICY_REPAIR_AND_EXECUTION_EXHAUSTION_NOTE_20260608.md`
  is packaged inside
  `artifacts/SUPPLEMENTAL_FULL_GAIN_PROVENANCE_ARCHIVE_20260619/02_rank10_h100_distance_ladder_c0_sources/`
- `missing_anchors = []`
- `anchors_outside_expected_archive_only = []`
- the probe remains packaging/provenance-only and does not claim any H100,
  distance-ladder, BAO, CMB, or cosmology pass

For the Rank9 full-gain provenance capsules probe, also expect:

- all four capsules exist and pass their capsule-local SHA checks
- tensor/GB provenance capsule has all required preIBP, postIBP, `delta_C`,
  coefficient, derivative, `omega_eff`, and identity-closure files
- Riemann/Ricci/R2 rowwise derivation capsule has the required curvature row
  files and contraction-normalization files
- Rank9D anchor appeal and GB-background forensics capsule has the required
  anchor, background-equation, model-vector, and Stage-6 rejection files
- Active19/C4 sidecar has the observer-19 and C4 guard status files
- `GAIN_COVERAGE_MATRIX.tsv` contains the four new gain IDs
- the archive manifest lists the four new capsule directories
- front notes for Rank9 provenance, Keystone I canonical-map boundary,
  Keystone II kernel scope, and B-shelf supersession are present

For the L2 late object-recovery and navigation-cleanup probe, also expect:

- the L2 object-level recovery capsule exists
- `source_docs_count = 238`
- `source_tools_count = 25`
- all required late-L2 families are present:
  procurve rows, row-count reconciliation, failure anatomy, heterogeneity,
  source-geometry, nonlocal evaluator, six-relation, federated rows,
  evidence-grade, and final seal
- the capsule-local checksum ledger passes
- `GAIN_COVERAGE_MATRIX.tsv` no longer marks L2 as summary-only
- the new L2 object-recovery front note is present and listed by
  `START_HERE_FIRST.md`
- stale `START_HERE_FIRST 2.md` is absent from `00_READ_FIRST` and archived
  with a supersession banner
- `ACTIVE_TARGET_BOARD_20260610.md` and
  `GOAL_BANK_TO_FULL_SCORE_CROSSWALK_20260610.md` are marked historical /
  superseded rather than live current surfaces

For the selected cold-portable `G1` replay, also expect:

- the cold replay status verdict =
  `POST_CAGE_BRANCH_U1_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_MATERIALIZED`
- `all_note_checks_pass = true`
- the standalone verdict JSON matches the same verdict string
