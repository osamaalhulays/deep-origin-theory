# Deep Origin J2C Reproducibility Runtime V1

Date: 2026-06-20

This runtime package is a reviewer-facing execution helper for the public
Deep Origin Theory release. It is not a scientific result packet and does not
claim a J2C result.

Use it next to an extracted copy of:

`01_Deep_Origin_Updated_Scientific_Packet_EN_20260620.zip`

## Purpose

The runtime provides portable launchers for the reviewer audit bundle. It is
kept as a separate sibling file so the scientific packet remains readable while
the executable review path stays easy to find.

## Quick Use

1. Extract the English scientific packet.
2. Extract this runtime package.
3. Run the fast audit by passing the extracted English packet directory:

```bash
bash RUN_FAST_WITH_PACKET.sh /path/to/Deep_Origin_Theory_English_Packet_20260605
```

For the full audit:

```bash
bash RUN_FULL_WITH_PACKET.sh /path/to/Deep_Origin_Theory_English_Packet_20260605
```

The scripts write their outputs to a temporary audit directory and print that
directory at the end.

To verify the `J2C` pre-execution lock itself, extract the `J2C` capsule and
run:

```bash
python3 VERIFY_J2C_PREEXECUTION_LOCK.py \
  --packet-dir /path/to/Deep_Origin_Theory_English_Packet_20260605 \
  --capsule-dir /path/to/Deep_Origin_Live_Checkpoint_J2C_Preexecution_Lock_20260620
```

The verifier checks that the packet and capsule agree on the structural
action-class lock, no `J2C` result is present, the exact finite action
representative is not claimed as frozen, the verdict grammar is locked, and
the exponent table remains `TBD`.

## Boundary

This runtime does not:

- execute J2C
- fit galaxy data
- select a cosmological background
- add a new G3 function
- claim MOND/QUMOND defeat
- claim final cosmic closure

It only verifies public packet integrity and replayable reviewer-facing audit
surfaces.

## Expected Runtime

- Python: tested with Python 3.
- Node: not required by the `J2C` lock verifier.
- Fast audit: normally a few minutes on a desktop machine.
- Full audit: longer; allow several minutes and temporary disk space for audit
  outputs.
