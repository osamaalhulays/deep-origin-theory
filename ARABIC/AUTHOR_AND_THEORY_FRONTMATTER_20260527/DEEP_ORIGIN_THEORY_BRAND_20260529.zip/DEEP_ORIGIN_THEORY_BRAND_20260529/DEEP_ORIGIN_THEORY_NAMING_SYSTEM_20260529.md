# Deep Origin Theory Naming System

## 1. Governing Layer

- `Deep Origin`
- `Deep Origin Theory`
- `A Source-Governed Generative Theory of Cosmology`

## 2. Internal Lineages

- `Keystone`
- `Deep Origin`
- `Firstlight`
- `Applied`

## 3. Sequence Rules

### Keystone

- `Keystone I: The First Bearing`
- `Keystone II: The Governing Bridge Law`
- `Keystone III: The Carrying Threshold`

### Deep Origin

- `Deep Origin I: The Governed State`
- `Deep Origin II: The Renormalized Route`
- `Deep Origin III: The Gradient Bears`
- `Deep Origin IV: The Hidden Mass`

### Firstlight

- `Firstlight I: The Horizon Opens`
- `Firstlight II: The Visible Law`
- `Firstlight III: The Carrying Sky`

## 4. QCT Rule

`QCT` لا تختفي، لكنها تهبط إلى مستوى:

- formal engine
- calculus
- technical sector name

لا مستوى:

- title page supreme name
- website governing brand
- publication umbrella

## 5. Overlap Rule

`Deep Origin` يجوز أن تعمل كـ:

- brand name for the theory
- deep-source sequence name inside the theory

وهذا مقصود لأنه يربط الاسم الحي بجذعه البنيوي الحقيقي بدل اختراع طبقة وسيطة مصطنعة.
