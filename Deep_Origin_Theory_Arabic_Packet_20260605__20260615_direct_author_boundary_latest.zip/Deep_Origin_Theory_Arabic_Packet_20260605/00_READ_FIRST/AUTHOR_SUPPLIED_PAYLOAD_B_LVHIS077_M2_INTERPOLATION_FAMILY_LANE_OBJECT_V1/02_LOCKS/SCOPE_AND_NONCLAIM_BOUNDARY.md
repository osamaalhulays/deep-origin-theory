# Scope And Nonclaim Boundary

Date: `2026-06-13`

This object is one bounded `M2` family-lane surface only.

Allowed:

- same-case `LVHIS077`
- same one-parameter stellar/bulge nuisance treatment on both sides
- same `obs-only` likelihood objective on both sides
- same runtime-locked bounded historical `QCT` `artifact_emulator` lane
- one declared global interpolation-family roster with no galaxy-specific retuning
- one family-best member selection
- one exact decision on whether `M2` rescues or fails to rescue the case

Not allowed:

- silent promotion from `M2` execution to full-ladder `Grade 2`
- silent promotion from `M2` execution to `Grade 3`
- silent insertion of undeclared interpolation members
- galaxy-specific interpolation retuning
- silent reopening of `M3` or `M4`
- theory-side promotion
- whole-family `MOND/QUMOND` defeat language
- cosmology completion
