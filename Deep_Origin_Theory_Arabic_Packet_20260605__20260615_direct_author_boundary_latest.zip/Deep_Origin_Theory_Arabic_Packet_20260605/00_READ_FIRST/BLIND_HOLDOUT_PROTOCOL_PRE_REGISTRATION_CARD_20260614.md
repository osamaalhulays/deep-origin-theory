# Blind Holdout Protocol Pre-Registration Card

Date: `2026-06-14`

Purpose:

Freeze one exact pre-unblind publication/timestamp rule for the next truthful
blind-holdout run.

## Short verdict

The scientifically stronger route is **not**:

- run blind holdout privately
- then publish only if the result is favorable

The governed route is:

- lock protocol first
- timestamp or externally escrow the lock package before unblind
- then publish the post-unblind result package whatever the verdict is

## Exact pre-unblind lock bundle

Before observed rows enter, the real run must freeze:

- `TARGET_LOCK`
- `PREDICTION_LOCK`
- `COMPARATOR_PROTOCOL_LOCK`
- packet hash
- timestamp or external escrow receipt

## Exact post-unblind result bundle

After observed rows enter and adjudication lands, the result bundle may carry:

- `COMPARISON_STACK`
- `BLIND_HOLDOUT_ADJUDICATION`
- bounded verdict
- failure modes if any

## Governing boundary

This card does **not** require that:

- the result be favorable
- `QCT` win every case
- or whole-family language be released

It requires only:

- prediction-before-unblind discipline
- and no success-only selective publication

## Read with

- `CURRENT_ABOVE_BANK_BLIND_HOLDOUT_STRIKE_NOTE_20260614.md`
- `CURRENT_BLIND_HOLDOUT_QCT_VS_MOND_PROGRAM_OBJECT_MATERIALIZED_NOTE_20260614.md`
- `CURRENT_BLIND_HOLDOUT_AUTHOR_SUPPLIED_PAYLOAD_B_PUBLIC_EXPOSURE_EXCLUSION_NOTE_20260614.md`
