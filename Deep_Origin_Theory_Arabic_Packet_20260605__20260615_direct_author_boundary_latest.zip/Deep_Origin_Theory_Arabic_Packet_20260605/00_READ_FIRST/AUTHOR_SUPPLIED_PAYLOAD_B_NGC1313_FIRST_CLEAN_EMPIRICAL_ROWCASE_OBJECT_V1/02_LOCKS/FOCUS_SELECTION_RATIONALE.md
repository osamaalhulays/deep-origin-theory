# Focus Selection Rationale

Date: `2026-06-13`

The target chosen here is not picked by taste.

It is picked by the already frozen clean-first shortlist rule from:

- `AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_OBJECT_V1`

## Exact rule

The target must:

1. already pass the clean-first gate
2. then rank highest by observed-row count
3. then rank highest by `gbar` dynamic span
4. then use lexical galaxy name only as a tie-break

## Exact present result

Under that rule:

- `NGC1313` is rank `1`
- observed-row count = `40`
- `gbar` span = `0.9572509353175267` dex

So the focused case is:

- lawful
- reproducible
- and procedurally chosen rather than rhetorically chosen
