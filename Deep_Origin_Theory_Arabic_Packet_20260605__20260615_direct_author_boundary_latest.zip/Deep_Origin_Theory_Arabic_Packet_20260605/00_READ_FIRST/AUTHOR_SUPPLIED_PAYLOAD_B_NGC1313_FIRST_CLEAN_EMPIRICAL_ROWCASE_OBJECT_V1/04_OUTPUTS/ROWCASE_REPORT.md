# Author-Supplied `PAYLOAD_B` `NGC1313` First Clean Empirical Rowcase Report

Date: `2026-06-13`

## Short verdict

`NGC1313` is now materialized as the first focused clean empirical case above
the landed author-supplied `PAYLOAD_B` family.

## Exact present shape

- target galaxy: `NGC1313`
- clean-first shortlist rank: `1`
- observed rows: `40`
- radius range: `0.14` to `11.21` kpc
- exact interpolation rows: `6`
- linear interpolation rows: `34`
- all rows stay comparison-ready: `true`
- all rows keep clean-first status: `true`
- all rows keep positive `log10(gobs) - log10(gbar)`: `true`
- `delta` range: `0.19955408170893918` to `1.0441321624537672`
- `delta` median: `0.6133288585909309`
- `gbar` peak radius: `0.99` kpc
- `gbar` is nonincreasing after its peak: `true`

## Exact current ceiling

This object gives one focused empirical rowcase only.

It does not yet give:

- one theory-side promotion
- one matched-nuisance comparison
- one competitor verdict
