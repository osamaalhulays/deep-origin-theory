# Author-Supplied `PAYLOAD_B` Receipt Audit Object

Date: `2026-06-13`

Purpose:

Freeze one reviewer-visible receipt object for the first real author-supplied
direct-author `L2` payload landing without republishing the raw attachment
files inside the packet.

This object exists to make the `G6/D7` closure operational rather than note-only.

## What this object carries

- one author-channel receipt note
- raw zip hashes for the landed external payload
- one exact galaxy-pair index
- one exact column-schema lock
- one intake summary
- one downstream hygiene-flag surface
- one bounded reproduce script that accepts the external zip pair

## What this object does not carry

- the raw direct-author zip attachments themselves
- one silent redistribution of author-supplied files
- one `PAYLOAD_A` promotion
- one downstream normalization choice for gas signs, duplicate radii, or
  `rho_b(r)` conversion
- one theory-side promotion into `G4`

## Exact public reading

This object closes only the receipt/documentation wound:

- real direct-author payload arrival is now receipt-grade and audit-grade
- the lawful class freeze is `PAYLOAD_B`
- the downstream-use boundary remains explicit and bounded
