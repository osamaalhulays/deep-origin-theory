# Author-Channel Receipt

Date: `2026-06-13`

Receipt class:

- direct-author payload supplied to the user

Bounded receipt facts:

- the author reply is from Pavel
- the landed payload date is `2026-06-12`
- the payload arrives as two zip attachments:
  - `vcirc_obs.zip`
  - `vcirc_baryons.zip`
- the reply explicitly states that the requested parameters exist and are being
  shared
- the reply also states that the baryonic component files are oversampled
  relative to the observed rotation-curve rows
- the reply warns that stellar and bulge component amplitudes are tied to the
  author's best-fitting mass-to-light ratio and may be renormalized if one
  runs a separate dynamical analysis
- the reply also warns that the `HI` component may retain limited model
  dependence for some dwarf galaxies

Redistribution boundary:

- this packet records the receipt, hashes, and intake verdict
- it does not republish the raw author-supplied zip payload

Exact use rule:

- use this object to verify arrival, file identity, pair identity, schema, and
  bounded intake class
- do not silently convert this receipt into one downstream signed-gas rule,
  one duplicate-radius rule, or one `rho_b(r)` construction rule
