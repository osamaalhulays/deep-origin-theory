#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import zipfile
from pathlib import Path


OBSERVED_SUFFIX = "_vcirc.dat"
BARYON_SUFFIX = "_vbaryons.dat"
OBSERVED_HEADER = "rad_kpc vcirc_km/s e_vcirc"
BARYON_HEADER = (
    "rad_kpc VHI VH2 Vstars eVstars_low eVstars_high Vbulge eVbulge_low eVbulge_high"
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def nonblank_lines(text: str) -> list[str]:
    return [line.strip() for line in text.splitlines() if line.strip()]


def normalize_header(header: str) -> str:
    cleaned = header.strip()
    if cleaned.startswith("#"):
        cleaned = cleaned[1:].strip()
    return " ".join(cleaned.split())


def parse_member(name: str, text: str) -> dict:
    lines = nonblank_lines(text)
    if not lines:
        raise ValueError(f"member is empty: {name}")
    header = normalize_header(lines[0])
    row_count = len(lines) - 1
    return {
        "member_name": name,
        "header": header,
        "row_count": row_count,
    }


def galaxy_name_from_member(member_name: str, suffix: str) -> str:
    if not member_name.endswith(suffix):
        raise ValueError(f"unexpected member name: {member_name}")
    return Path(member_name).name[: -len(suffix)]


def read_zip_members(zip_path: Path, suffix: str) -> dict[str, dict]:
    records: dict[str, dict] = {}
    with zipfile.ZipFile(zip_path) as archive:
        for member_name in sorted(archive.namelist()):
            if member_name.endswith("/") or not member_name.endswith(suffix):
                continue
            with archive.open(member_name) as handle:
                text = handle.read().decode("utf-8")
            galaxy = galaxy_name_from_member(member_name, suffix)
            record = parse_member(member_name, text)
            record["galaxy"] = galaxy
            records[galaxy] = record
    return records


def build_schema_lock(observed_records: dict[str, dict], baryon_records: dict[str, dict]) -> dict:
    observed_headers = sorted({item["header"] for item in observed_records.values()})
    baryon_headers = sorted({item["header"] for item in baryon_records.values()})
    return {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_COLUMN_SCHEMA_LOCK_20260613",
        "observed": {
            "uniform": len(observed_headers) == 1,
            "expected_header": OBSERVED_HEADER,
            "observed_headers": observed_headers,
            "columns": OBSERVED_HEADER.split(),
        },
        "baryons": {
            "uniform": len(baryon_headers) == 1,
            "expected_header": BARYON_HEADER,
            "observed_headers": baryon_headers,
            "columns": BARYON_HEADER.split(),
        },
    }


def write_pair_index(
    path: Path,
    observed_records: dict[str, dict],
    baryon_records: dict[str, dict],
) -> dict:
    fieldnames = [
        "galaxy",
        "observed_member",
        "baryonic_member",
        "observed_rows",
        "baryonic_rows",
        "observed_header",
        "baryonic_header",
        "baryonic_oversampled",
    ]
    matched = sorted(set(observed_records) & set(baryon_records))
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for galaxy in matched:
            obs = observed_records[galaxy]
            bar = baryon_records[galaxy]
            writer.writerow(
                {
                    "galaxy": galaxy,
                    "observed_member": obs["member_name"],
                    "baryonic_member": bar["member_name"],
                    "observed_rows": obs["row_count"],
                    "baryonic_rows": bar["row_count"],
                    "observed_header": obs["header"],
                    "baryonic_header": bar["header"],
                    "baryonic_oversampled": str(bar["row_count"] > obs["row_count"]).lower(),
                }
            )
    oversampled_count = sum(
        1 for galaxy in matched if baryon_records[galaxy]["row_count"] > observed_records[galaxy]["row_count"]
    )
    return {
        "matched_pairs": len(matched),
        "oversampled_pairs": oversampled_count,
    }


def downstream_hygiene_flags() -> dict:
    return {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_DOWNSTREAM_HYGIENE_FLAGS_20260613",
        "payload_class": "PAYLOAD_B",
        "flags_scope": "intake_stage_only_pre_normalization",
        "clarification": (
            "These booleans describe what is not yet chosen inside the intake object itself. "
            "They do not override the later explicit downstream policy locks materialized in the "
            "49-galaxy gbar diagnostic normalization and rowwise comparison-admissibility objects."
        ),
        "raw_direct_author_payload_republished_inside_packet": False,
        "gas_component_uncertainty_surface_complete": False,
        "gas_is_supplied_in_split_component_form": True,
        "stellar_and_bulge_uncertainties_present_but_not_full_component_uncertainty_surface": True,
        "duplicate_radius_compression_rule_chosen": False,
        "signed_gas_component_rule_chosen": False,
        "optional_bulge_nan_rule_chosen": False,
        "rho_b_conversion_rule_chosen": False,
        "theory_side_authoring_promotion_chosen": False,
        "later_downstream_policy_lock_materialized": True,
        "later_downstream_policy_lock_refs": [
            "CURRENT_G6_D7_PAYLOAD_B_49_GALAXY_GBAR_DIAGNOSTIC_LANE_NOTE_20260613.md",
            "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_GBAR_DIAGNOSTIC_NORMALIZATION_OBJECT_V1",
            "CURRENT_G6_D7_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_NOTE_20260613.md",
            "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_OBJECT_V1",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--observed-zip", required=True)
    parser.add_argument("--baryons-zip", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    observed_zip = Path(args.observed_zip).resolve()
    baryons_zip = Path(args.baryons_zip).resolve()
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    observed_records = read_zip_members(observed_zip, OBSERVED_SUFFIX)
    baryon_records = read_zip_members(baryons_zip, BARYON_SUFFIX)
    schema_lock = build_schema_lock(observed_records, baryon_records)

    observed_only = sorted(set(observed_records) - set(baryon_records))
    baryons_only = sorted(set(baryon_records) - set(observed_records))
    matched = sorted(set(observed_records) & set(baryon_records))

    pair_index_path = output_dir / "GALAXY_PAIR_INDEX.csv"
    pair_stats = write_pair_index(pair_index_path, observed_records, baryon_records)

    raw_zip_hashes = {
        "object": "AUTHOR_SUPPLIED_RAW_ZIP_HASHES_20260613",
        "observed_zip": {
            "filename": observed_zip.name,
            "sha256": sha256(observed_zip),
            "bytes": observed_zip.stat().st_size,
            "member_file_count": len(observed_records),
        },
        "baryons_zip": {
            "filename": baryons_zip.name,
            "sha256": sha256(baryons_zip),
            "bytes": baryons_zip.stat().st_size,
            "member_file_count": len(baryon_records),
        },
    }
    (output_dir / "RAW_ZIP_HASHES.json").write_text(
        json.dumps(raw_zip_hashes, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    (output_dir / "COLUMN_SCHEMA_LOCK.json").write_text(
        json.dumps(schema_lock, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    flags = downstream_hygiene_flags()
    (output_dir / "DOWNSTREAM_HYGIENE_FLAGS.json").write_text(
        json.dumps(flags, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    summary = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_RECEIPT_SUMMARY_20260613",
        "lawful_channel": "direct_author_payload_supplied_to_user",
        "arrival_date": "2026-06-12",
        "payload_class": "PAYLOAD_B",
        "payload_a_admitted": False,
        "payload_b_admitted": True,
        "g6_closed": True,
        "d7_closed_at_bounded_scope": True,
        "observed_file_count": len(observed_records),
        "baryonic_file_count": len(baryon_records),
        "matched_pair_count": len(matched),
        "observed_only_count": len(observed_only),
        "baryons_only_count": len(baryons_only),
        "observed_only": observed_only,
        "baryons_only": baryons_only,
        "observed_row_count": sum(item["row_count"] for item in observed_records.values()),
        "baryonic_row_count": sum(item["row_count"] for item in baryon_records.values()),
        "all_observed_headers_uniform": schema_lock["observed"]["uniform"],
        "all_baryonic_headers_uniform": schema_lock["baryons"]["uniform"],
        "observed_header": schema_lock["observed"]["observed_headers"][0]
        if schema_lock["observed"]["observed_headers"]
        else None,
        "baryonic_header": schema_lock["baryons"]["observed_headers"][0]
        if schema_lock["baryons"]["observed_headers"]
        else None,
        "baryonic_oversampled_pair_count": pair_stats["oversampled_pairs"],
        "same_source_coherence_survives": len(observed_only) == 0 and len(baryons_only) == 0,
        "redistribution_inside_packet": False,
    }
    (output_dir / "PAYLOAD_INTAKE_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    status = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_RECEIPT_AUDIT_OBJECT_REPRODUCTION_20260613",
        "status": "PAYLOAD_B_INTAKE_MATERIALIZED",
        "output_dir_ref": output_dir.name,
        "summary_file": "PAYLOAD_INTAKE_SUMMARY.json",
        "pair_index_file": pair_index_path.name,
        "schema_lock_file": "COLUMN_SCHEMA_LOCK.json",
        "same_source_coherence_survives": summary["same_source_coherence_survives"],
        "matched_pair_count": len(matched),
        "observed_row_count": summary["observed_row_count"],
        "baryonic_row_count": summary["baryonic_row_count"],
    }
    (output_dir / "reproduction_status.json").write_text(
        json.dumps(status, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(status, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
