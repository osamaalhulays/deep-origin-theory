# Redistribution And Scope Boundary

Date: `2026-06-13`

This object is one receipt audit object only.

It lawfully records:

- landed zip-file identity
- landed file counts
- exact observed/baryonic pair matching
- landed schema
- bounded class freeze at `PAYLOAD_B`

It does **not** lawfully do any of the following by itself:

- republish the raw author-supplied data
- promote the payload into `PAYLOAD_A`
- choose one signed-square rule for negative gas rows
- choose one duplicate-radius compression rule
- choose one optional-bulge `nan` normalization rule
- choose one hidden conversion from circular-speed components into `rho_b(r)`
- promote the empirical payload into theory-side authoring
