# Author-Supplied `NGC1313` Historical `QCT` Matched-Nuisance Report

Date: `2026-06-13`

## Short verdict

The first clean-first author-supplied case now also carries one bounded historical
`QCT` mirror lane:

- same case: `NGC1313`
- same stellar/bulge nuisance grammar as the already-materialized `QUMOND`
  anchor
- same `obs-only` likelihood objective for the matched-nuisance comparison

This does **not** promote the lane into theory-side current authority.

It materializes one narrower result:

- the historical `artifact_emulator` lane can now be confronted fairly
  against the already-landed `QUMOND` anchor on this same clean-first case

## Historical-lane scope

- `delta_source = artifact_emulator`
- no `G4` / `Form A/B/C/D` promotion
- no theory-side authoring claim
- no family-scale superiority claim

## `QCT` matched-nuisance result

- best stellar/bulge speed scale `s_best` = `1.541148500000`
- fixed lane `s_fixed` = `1.000000000000`
- `ll_fixed_obs_only` = `-708.243773022592`
- `ll_best_obs_only` = `-240.930937446785`
- `ll_fixed_obs_model` = `-540.948522848071`
- `ll_best_obs_model` = `-442.322895454612`
- `chi2_fixed_obs_only` = `1200.720144022253`
- `chi2_best_obs_only` = `266.094472870640`

## First same-case differential result

- `QCT` best `obs-only` loglike = `-240.930937446785`
- `QUMOND` best `obs-only` loglike = `-199.428203954239`
- `Δloglike(QCT-QUMOND)` = `-41.502733492546`
- `ΔAIC(QCT-QUMOND)` = `83.005466985092`
- `ΔBIC(QCT-QUMOND)` = `83.005466985092`

So under the same one-parameter matched-nuisance treatment and the same
`obs-only` objective, the current bounded historical `QCT` lane is **not**
preferred on `NGC1313`.

## Exact value of this object

This object is still a real gain.

It removes one local ambiguity:

- the first clean-first author-supplied case is no longer waiting on a guessed
  historical `QCT` reading
- and it is no longer waiting on an unperformed first same-case fair
  confrontation

The answer is now explicit and reviewer-checkable.

## What this object does not authorize

- no silent promotion from historical bounded lane to current theorem-side
  authority
- no positive reviewer-facing `QCT > QUMOND` sentence on `NGC1313`
- no extension of this single-case result to the whole `49`-galaxy author-supplied
  family
