# Current `G10` Nuisance-Complete Fairness Retirement Note

Date: `2026-06-11`

Purpose:

State the exact packet-facing reread after the claim-standard boundary,
the Stacy methods reply,
the Andrea support-only reply,
and the fenced `equal_free_obs_only` control are all in hand together.

## Short verdict

No live nuisance-complete fairness blocker remains at the current packet
ceiling.

The current differential sentence is already explicitly narrowed to:

- procedural preference under symmetric matched-nuisance `MLE` treatment

and explicitly blocked from becoming:

- Bayesian evidence,
- unconditional physical superiority,
- or one final `AIC/BIC` oracle.

So the stronger nuisance-complete Bayesian route is no longer one live bank
head here.

It remains one later optional strengthening route only.

## What this does not claim

This note does **not** claim:

- Bayesian-evidence closure
- unconditional physical-superiority closure
- erasure of the negative `equal_free_obs_only` control
- whole-family `MOND/QUMOND` defeat

It claims something narrower:

- the current packet's actual differential sentence sits below the threshold
  that would require the stronger nuisance-complete route

## Read with

- `DIFFERENTIAL_CLAIM_STANDARD_AND_MATCHED_NUISANCE_BOUNDARY_NOTE_20260610.md`
- `EXTERNAL_METHODS_REPLY_STACY_MCGAUGH_MATCHED_NUISANCE_AND_AIC_BOUNDARY_NOTE_20260611.md`
- `EXTERNAL_METHODS_REPLY_ANDREA_BIVIANO_AIC_BIC_SUPPORT_ONLY_NOTE_20260611.md`
- `NGC0247_HISTORICAL_PHASE2_SAME_CONVENTION_CONTROL_NOTE_20260608.md`
