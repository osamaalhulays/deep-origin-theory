# Blind Holdout Charter

## Sovereign purpose

The purpose of this object is to prevent post-hoc victory language. It forces the project to choose targets, freeze QCT predictions, freeze comparator rules, and only then unblind observed rows.

## Lane / goal / deduction / object

- Lane: Comparator and family-verdict lane, with observational opening support.
- Governing goal: above-bank blind holdout strike supporting the MOND/QUMOND family court and G4/D3 observed-row discipline.
- Deduction family killed if successful: cherry-picking / post-hoc comparator / non-predictive residual-fitting pressure.
- Reviewer-visible object: target lock, prediction lock, unblind comparison stack, and adjudication JSON.

## Non-negotiable rules

1. Target selection cannot use QCT/MOND/QUMOND outcomes.
2. QCT predictions must be hash-locked before unblind.
3. Comparator protocol must be hash-locked before unblind.
4. The pre-unblind lock bundle must be timestamped or externally escrowed before observed-row import.
5. Observed rows enter only after selection, prediction, and comparator locks.
6. Post-unblind publication cannot be success-only selective publication.
7. AIC/BIC are receipts only; they are not sovereignty.
8. Whole-family MOND/QUMOND language is forbidden unless all declared family lanes are executed and no-rescue survives.
9. Toy self-test output is never a scientific claim.

## Success condition

A successful real run produces:

- TARGET_LOCK.json
- PREDICTION_LOCK.json
- COMPARISON_STACK.csv
- BLIND_HOLDOUT_ADJUDICATION.json

and a verdict that is bounded to the declared holdout, lanes, nuisance policy, and observed rows.

It also preserves:

- a pre-unblind timestamp or escrow trail
- and one publishable post-unblind result package whatever the bounded verdict is
