# No-Peek Card

Forbidden inputs before target lock:

- QCT win/loss columns
- MOND/QUMOND win/loss columns
- chi2/loglike/AIC/BIC from either side
- residuals
- delta_true
- observed rotation-curve fit quality
- fitted MOND/QUMOND nuisance results
- hidden ranking from previous court runs

Allowed inputs before target lock:

- coordinates
- redshift / distance category
- morphology class
- inclination category
- environment category
- data availability flags
- clean-front eligibility flags
- quality flags not derived from model outcomes

If a candidate catalog contains forbidden columns, the selection script fails.
