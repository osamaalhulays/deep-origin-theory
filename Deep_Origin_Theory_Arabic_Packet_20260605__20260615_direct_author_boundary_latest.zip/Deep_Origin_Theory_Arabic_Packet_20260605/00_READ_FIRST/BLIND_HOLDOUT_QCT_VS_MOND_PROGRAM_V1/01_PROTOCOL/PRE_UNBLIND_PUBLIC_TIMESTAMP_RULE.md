# Pre-Unblind Public Timestamp Rule

The next truthful blind-holdout real run must not be:

- one secret internal execution
- followed by selective publication only if favorable

The governed route is:

1. freeze the pre-unblind lock bundle
2. timestamp it or externally escrow it
3. only then unblind observed rows
4. publish the post-unblind result bundle whatever the bounded verdict is

## Exact pre-unblind lock bundle

- `TARGET_LOCK.json`
- `PREDICTION_LOCK.json`
- locked comparator protocol
- packet hash
- timestamp or escrow receipt

## Exact post-unblind result bundle

- `COMPARISON_STACK.csv`
- `BLIND_HOLDOUT_ADJUDICATION.json`
- bounded verdict language
- failure modes if any

This rule exists to kill:

- success-only selective revelation
- and the charge that the project may have tried multiple blind runs but only
  showed the winner

