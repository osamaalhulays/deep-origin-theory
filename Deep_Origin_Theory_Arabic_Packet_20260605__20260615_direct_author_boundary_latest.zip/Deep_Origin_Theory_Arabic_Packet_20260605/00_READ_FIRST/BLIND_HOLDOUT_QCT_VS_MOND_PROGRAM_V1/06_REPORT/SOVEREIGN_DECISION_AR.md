# القرار السيادي — Blind Holdout

لا تُفتح لغة انتصار واسعة ضد MOND/QUMOND من counting أو من case-picked wins.

الضربة الجديدة هي:

```text
pre-selected blind holdout
+ pre-registered QCT prediction
+ locked MOND/QUMOND comparator protocol
+ unblind observed-row comparison
```

إذا نجحت، تصبح النتيجة predictive لا retrospective.

القرار:

1. لا نستخدم الكتالوج الضخم كدليل عددي خام.
2. نستخدمه لاختيار holdout أعمى morphology/environment-conditioned.
3. نجمّد العينة قبل الرؤية.
4. نجمّد توقع QCT قبل الرؤية.
5. نجمّد comparator protocol قبل الرؤية.
6. بعد unblind، نحكم فقط بالـ verdict grammar المسموح.
7. أي family victory language تحتاج family lanes كاملة، لا toy ولا حالة واحدة.

الجسم الناتج من هذا القرار هو:

```text
BLIND_HOLDOUT_QCT_VS_MOND_PROGRAM_V1
```
