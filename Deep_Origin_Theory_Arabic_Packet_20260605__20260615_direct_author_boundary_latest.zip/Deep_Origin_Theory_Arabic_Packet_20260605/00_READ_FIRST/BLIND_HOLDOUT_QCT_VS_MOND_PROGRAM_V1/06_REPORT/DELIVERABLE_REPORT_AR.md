# تقرير التسليم — Blind Holdout Program V1

## الحكم

تم تصنيع خط blind holdout كامل قابل للتشغيل:

```text
candidate catalog
  -> target lock
  -> QCT prediction lock
  -> MOND/QUMOND comparator protocol lock
  -> observed-row unblind
  -> comparison stack
  -> blind adjudication
```

## ما الذي أُغلق؟

أُغلق الفراغ العملي بين الاستراتيجية والتنفيذ. لم يعد blind holdout مجرد فكرة. أصبح جسمًا له:

- schema
- scripts
- target lock
- prediction lock
- unblind adjudication
- toy self-test
- SHA-ready package surface

## ما الذي لم يُغلق؟

هذا الجسم لا يدعي:

- أن QCT فازت على MOND/QUMOND؛
- أن whole-family verdict تحقق؛
- أن cosmic closure تحقق؛
- أن G7/G8 أُغلقا؛
- أن MACS1206 carrier وصل.

## أقوى استخدام حقيقي

1. أدخل candidate catalog من الكتالوج الكبير أو من author-supplied/direct-author pool.
2. اختر selection seed سياديًا قبل النتائج.
3. شغّل select_and_lock_targets.py.
4. أدخل QCT predictions قبل unblind.
5. شغّل lock_prediction_package.py.
6. بعد وصول observed rows وcomparator rows، شغّل unblind_and_adjudicate.py.
7. لا تسمح بأي لغة انتصار عائلي إلا إذا نُفذت كل lanes المعلنة.

## أقوى نتيجة ممكنة

إذا خرجت عينة holdout حقيقية بنتيجة:

```text
BLIND_HOLDOUT_QCT_HIT_SET_MATERIALIZED
```

مع lanes كافية، تصبح النظرية أصعب بكثير على التجاهل لأن النتيجة لم تعد تفسيرًا بعديًا.
