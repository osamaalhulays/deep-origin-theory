# Toy Expected Outputs

Running:

```bash
bash 05_SELFTEST/run_toy_selftest.sh
```

should emit:

```text
TARGET_LOCK_MATERIALIZED
PREDICTION_LOCK_MATERIALIZED
BLIND_HOLDOUT_QCT_HIT_SET_MATERIALIZED
BLIND_HOLDOUT_TOY_PIPELINE_PASSED
```

The toy adjudication should contain:

```json
{
  "status": "materialized",
  "program_verdict": "BLIND_HOLDOUT_QCT_HIT_SET_MATERIALIZED",
  "case_count": 3,
  "cosmic_closure_claim": false,
  "whole_family_claim": false
}
```

Toy output is not scientific evidence. It only proves the blind-holdout machinery is executable.
