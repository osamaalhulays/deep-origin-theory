# Real Run Success Criteria

A real blind holdout run is considered landed only if all are true:

1. TARGET_LOCK.json exists before prediction lock.
2. PREDICTION_LOCK.json exists before observed-row import.
3. Observed rows are supplied after target/prediction locks.
4. COMPARISON_STACK.csv is produced from locked targets only.
5. BLIND_HOLDOUT_ADJUDICATION.json has `status = materialized`.
6. `whole_family_claim = false` unless all declared family lanes are executed.
7. `cosmic_closure_claim = false` always for this package.
8. All files are hashable and archived.

A true high-value result requires more than QCT improving chi2: it requires pre-registered predictions, locked comparator protocol, and adversarial unblind discipline.
