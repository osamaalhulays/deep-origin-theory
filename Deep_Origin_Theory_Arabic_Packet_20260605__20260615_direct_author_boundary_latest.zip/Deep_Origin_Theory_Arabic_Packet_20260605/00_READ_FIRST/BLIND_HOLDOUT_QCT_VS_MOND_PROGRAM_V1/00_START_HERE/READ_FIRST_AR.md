# BLIND_HOLDOUT_QCT_VS_MOND_PROGRAM_V1

الغرض: قطع شوط الـ blind holdout كاملًا كجسم تشغيل، لا كمذكرة استراتيجية.

هذا الجسم ينشئ خطًا جديدًا فوق سقف البنك الحالي:

1. اختيار عينة holdout قبل رؤية نتائج الديناميك.
2. قفل العينة والـ seed والـ selection rule بالـ hash.
3. قفل توقع QCT قبل unblind.
4. قفل بروتوكول MOND/QUMOND comparator قبل unblind.
5. بعد وصول observed rows، تشغيل comparison stack.
6. إصدار verdict محدود: hit / rescue / no-rescue / inconclusive.

لا يدعي هذا الجسم أن QCT فازت أو أن MOND/QUMOND انتهت. هو يصنع الآلة التي تجعل claim كهذا ممكنًا فقط إذا نجح تشغيل blinded holdout الحقيقي.

ابدأ بالتجربة:

```bash
bash 05_SELFTEST/run_toy_selftest.sh
```

إذا نجحت، سترى:

```text
BLIND_HOLDOUT_TOY_PIPELINE_PASSED
```

ثم استخدم نفس المسار على catalog حقيقي.
