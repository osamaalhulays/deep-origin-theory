# Blind Holdout QCT vs MOND Program V1

This object materializes one bounded blind-holdout program as a runnable
reviewer-visible surface.

It exists to stop post-hoc target-picking and after-seeing-the-result victory
language.

The enforced sequence is:

```text
candidate catalog
-> target lock
-> QCT prediction lock
-> comparator protocol lock
-> observed-row unblind
-> comparison stack
-> adjudication JSON
```

The governed real-run publication order is:

```text
protocol / target / prediction / comparator lock first
-> timestamp or escrow before unblind
-> unblind
-> result package published whatever the bounded verdict is
```

## What this object gives you

- one locked target-selection step,
- one locked `QCT` prediction package before unblind,
- one locked comparator protocol before unblind,
- one unblind-and-adjudicate step,
- and one toy self-test proving the program runs end to end.

## What it does not give you

This object does not itself claim:

- whole-family `MOND/QUMOND` closure,
- cosmic closure,
- formal-review success,
- or that any toy output is a scientific result.

## First files to read

- `../01_PROTOCOL/BLIND_HOLDOUT_CHARTER.md`
- `../01_PROTOCOL/NO_PEEK_CARD.md`
- `../01_PROTOCOL/CLAIM_BOUNDARY_CARD.md`
- `../01_PROTOCOL/PRE_UNBLIND_PUBLIC_TIMESTAMP_RULE.md`
- `../06_REPORT/DELIVERABLE_REPORT_AR.md`
- `../07_EXPECTED_OUTPUTS/REAL_RUN_SUCCESS_CRITERIA.md`

## Runtime entrypoints

- `../03_RUN/select_and_lock_targets.py`
- `../03_RUN/lock_prediction_package.py`
- `../03_RUN/unblind_and_adjudicate.py`
- `../05_SELFTEST/run_toy_selftest.sh`

## Current packet role

Inside the current packet, this object should be read as:

- one above-bank scientific strike,
- not one substitute for the live `G1/G5/G7/G8` tetrad,
- and one way to turn future `QCT` versus `MOND/QUMOND` pressure from
  retrospective reading into pre-registered predictive pressure.

The current same-family author-supplied pool is not admissible for that next blind run.
Read:

- `../../CURRENT_BLIND_HOLDOUT_AUTHOR_SUPPLIED_PAYLOAD_B_PUBLIC_EXPOSURE_EXCLUSION_NOTE_20260614.md`
