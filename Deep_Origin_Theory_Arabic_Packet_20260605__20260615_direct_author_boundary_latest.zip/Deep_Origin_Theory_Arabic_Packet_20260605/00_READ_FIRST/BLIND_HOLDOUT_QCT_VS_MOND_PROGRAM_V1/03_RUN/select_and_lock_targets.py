#!/usr/bin/env python3
import argparse
from collections import defaultdict
from pathlib import Path
from common import read_csv, write_csv, read_json, write_json, sha256_file, boolish, stable_rank

FORBIDDEN_DEFAULT = [
    'qct','mond','qumond','chi2','chisq','aic','bic','loglike','residual',
    'delta_true','winner','score_model','fit_result','gobs','vcirc'
]
REQUIRED = ['target_id','ra_deg','dec_deg','morphology_class','environment_class','quality_score','clean_front_eligible']


def main():
    ap = argparse.ArgumentParser(description='Select blind holdout targets and lock them by hash.')
    ap.add_argument('--candidate-catalog', required=True)
    ap.add_argument('--config', required=True)
    ap.add_argument('--output-dir', required=True)
    args = ap.parse_args()

    cat_path = Path(args.candidate_catalog)
    cfg_path = Path(args.config)
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    rows = read_csv(cat_path)
    cfg = read_json(cfg_path)
    if not rows:
        raise SystemExit('candidate catalog is empty')
    cols = set(rows[0].keys())
    missing = [c for c in REQUIRED if c not in cols]
    if missing:
        raise SystemExit(f'missing required columns: {missing}')

    forbidden = cfg.get('forbidden_column_substrings', FORBIDDEN_DEFAULT)
    bad_cols = [c for c in cols if any(s in c.lower() for s in forbidden)]
    if bad_cols:
        raise SystemExit(f'forbidden result/leakage columns present: {bad_cols}')

    min_q = float(cfg.get('min_quality_score', 0.0))
    require_clean = bool(cfg.get('require_clean_front_eligible', True))
    eligible = []
    for r in rows:
        try:
            q = float(r.get('quality_score', 'nan'))
        except Exception:
            continue
        if q < min_q:
            continue
        if require_clean and not boolish(r.get('clean_front_eligible')):
            continue
        eligible.append(r)
    if not eligible:
        raise SystemExit('no eligible blind candidates after filters')

    seed = str(cfg.get('selection_seed', 'MISSING_SEED'))
    holdout_n = int(cfg.get('holdout_n', 1))
    strata_cols = cfg.get('strata_columns', [])

    # Deterministic stratified selection: choose one per stratum pass, then fill by global stable hash.
    selected = []
    used = set()
    groups = defaultdict(list)
    for r in eligible:
        key = tuple(r.get(c, '') for c in strata_cols) if strata_cols else ('ALL',)
        groups[key].append(r)
    for key in sorted(groups, key=lambda k: str(k)):
        group = sorted(groups[key], key=lambda r: stable_rank(seed, r['target_id']))
        if group and len(selected) < holdout_n:
            selected.append(group[0]); used.add(group[0]['target_id'])
    if len(selected) < holdout_n:
        rest = [r for r in eligible if r['target_id'] not in used]
        rest = sorted(rest, key=lambda r: stable_rank(seed, r['target_id']))
        for r in rest:
            if len(selected) >= holdout_n:
                break
            selected.append(r); used.add(r['target_id'])

    selected = selected[:holdout_n]
    target_rows = []
    for idx, r in enumerate(selected, 1):
        target_rows.append({
            'lock_order': idx,
            'target_id': r['target_id'],
            'morphology_class': r.get('morphology_class',''),
            'environment_class': r.get('environment_class',''),
            'quality_score': r.get('quality_score',''),
            'selection_rank_hash': stable_rank(seed, r['target_id'])
        })

    write_csv(out / 'TARGET_LOCK.csv', target_rows, ['lock_order','target_id','morphology_class','environment_class','quality_score','selection_rank_hash'])
    payload = {
        'object': 'BLIND_HOLDOUT_TARGET_LOCK',
        'status': 'materialized',
        'candidate_catalog_sha256': sha256_file(cat_path),
        'config_sha256': sha256_file(cfg_path),
        'selection_seed_sha256': stable_rank('seed-hash', seed),
        'holdout_n_requested': holdout_n,
        'eligible_count': len(eligible),
        'selected_count': len(target_rows),
        'selected_targets': [r['target_id'] for r in target_rows],
        'no_peek_columns_passed': True,
        'selection_rule': 'deterministic_stratified_stable_hash',
        'whole_family_claim_allowed': False
    }
    write_json(out / 'TARGET_LOCK.json', payload)
    print('TARGET_LOCK_MATERIALIZED')

if __name__ == '__main__':
    main()
