#!/usr/bin/env python3
import argparse
from pathlib import Path
from common import read_csv, write_csv, read_json, write_json, sha256_file

REQUIRED_PRED = ['target_id','bin_id','x_i','qct_log10_gobs_pred','qct_delta_pred','qct_shape_class']
FORBIDDEN_PRED = ['observed','residual','chi2','aic','bic','loglike','winner']


def main():
    ap = argparse.ArgumentParser(description='Lock QCT predictions and comparator protocol before unblind.')
    ap.add_argument('--target-lock-json', required=True)
    ap.add_argument('--qct-predictions', required=True)
    ap.add_argument('--comparator-protocol', required=True)
    ap.add_argument('--output-dir', required=True)
    args = ap.parse_args()
    lock_path = Path(args.target_lock_json)
    pred_path = Path(args.qct_predictions)
    protocol_path = Path(args.comparator_protocol)
    out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)

    lock = read_json(lock_path)
    selected = set(lock['selected_targets'])
    rows = read_csv(pred_path)
    if not rows:
        raise SystemExit('qct prediction table empty')
    cols = set(rows[0].keys())
    missing = [c for c in REQUIRED_PRED if c not in cols]
    if missing:
        raise SystemExit(f'missing QCT prediction columns: {missing}')
    bad = [c for c in cols if any(s in c.lower() for s in FORBIDDEN_PRED)]
    if bad:
        raise SystemExit(f'prediction table contains forbidden post-unblind columns: {bad}')

    filtered = [r for r in rows if r['target_id'] in selected]
    have = {r['target_id'] for r in filtered}
    missing_targets = sorted(selected - have)
    if missing_targets:
        raise SystemExit(f'missing predictions for selected targets: {missing_targets}')

    write_csv(out / 'QCT_PREDICTIONS_LOCKED.csv', filtered, REQUIRED_PRED)
    protocol = read_json(protocol_path)
    protocol_out = out / 'COMPARATOR_PROTOCOL_LOCKED.json'
    write_json(protocol_out, protocol)
    payload = {
        'object': 'BLIND_HOLDOUT_PREDICTION_LOCK',
        'status': 'materialized',
        'target_lock_sha256': sha256_file(lock_path),
        'qct_prediction_source_sha256': sha256_file(pred_path),
        'qct_predictions_locked_sha256': sha256_file(out / 'QCT_PREDICTIONS_LOCKED.csv'),
        'comparator_protocol_sha256': sha256_file(protocol_path),
        'selected_targets': sorted(selected),
        'selected_prediction_row_count': len(filtered),
        'no_observed_rows_used': True,
        'whole_family_claim_allowed': False
    }
    write_json(out / 'PREDICTION_LOCK.json', payload)
    print('PREDICTION_LOCK_MATERIALIZED')

if __name__ == '__main__':
    main()
