#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/05_SELFTEST/toy_outputs"
rm -rf "$OUT"
mkdir -p "$OUT"
python3 "$ROOT/03_RUN/select_and_lock_targets.py" \
  --candidate-catalog "$ROOT/05_SELFTEST/toy_inputs/candidate_catalog_toy.csv" \
  --config "$ROOT/05_SELFTEST/toy_inputs/run_config_toy.json" \
  --output-dir "$OUT/01_target_lock"
python3 "$ROOT/03_RUN/lock_prediction_package.py" \
  --target-lock-json "$OUT/01_target_lock/TARGET_LOCK.json" \
  --qct-predictions "$ROOT/05_SELFTEST/toy_inputs/qct_predictions_toy.csv" \
  --comparator-protocol "$ROOT/05_SELFTEST/toy_inputs/comparator_protocol_toy.json" \
  --output-dir "$OUT/02_prediction_lock"
python3 "$ROOT/03_RUN/unblind_and_adjudicate.py" \
  --target-lock-json "$OUT/01_target_lock/TARGET_LOCK.json" \
  --prediction-lock-json "$OUT/02_prediction_lock/PREDICTION_LOCK.json" \
  --qct-predictions-locked "$OUT/02_prediction_lock/QCT_PREDICTIONS_LOCKED.csv" \
  --observed-rows "$ROOT/05_SELFTEST/toy_inputs/observed_rows_toy.csv" \
  --comparator-rows "$ROOT/05_SELFTEST/toy_inputs/comparator_rows_toy.csv" \
  --config "$ROOT/05_SELFTEST/toy_inputs/run_config_toy.json" \
  --output-dir "$OUT/03_unblind"
python3 - <<'PY' "$OUT/03_unblind/BLIND_HOLDOUT_ADJUDICATION.json"
import json, sys
p=json.load(open(sys.argv[1]))
assert p["status"] == "materialized"
assert p["case_count"] >= 1
print("BLIND_HOLDOUT_TOY_PIPELINE_PASSED")
print(json.dumps(p, indent=2, sort_keys=True))
PY
