#!/usr/bin/env python3
import argparse
from collections import defaultdict
from pathlib import Path
from common import read_csv, write_csv, read_json, write_json, sha256_file

OBS_REQ = ['target_id','bin_id','x_i','log10_gobs_observed','sigma_log10_gobs']
COMP_REQ = ['target_id','bin_id','x_i','comparator_id','comparator_lane','comparator_log10_gobs_pred','admissible']
QCT_REQ = ['target_id','bin_id','x_i','qct_log10_gobs_pred','qct_delta_pred','qct_shape_class']


def f(x):
    return float(str(x).strip())


def boolish(x):
    return str(x).strip().lower() in {'1','true','yes','y','t'}


def sign(v):
    if v > 0: return '+'
    if v < 0: return '-'
    return '0'


def main():
    ap = argparse.ArgumentParser(description='Unblind observed rows and adjudicate blind holdout.')
    ap.add_argument('--target-lock-json', required=True)
    ap.add_argument('--prediction-lock-json', required=True)
    ap.add_argument('--qct-predictions-locked', required=True)
    ap.add_argument('--observed-rows', required=True)
    ap.add_argument('--comparator-rows', required=True)
    ap.add_argument('--config', required=True)
    ap.add_argument('--output-dir', required=True)
    args = ap.parse_args()

    out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)
    target_lock = read_json(Path(args.target_lock_json))
    pred_lock = read_json(Path(args.prediction_lock_json))
    cfg = read_json(Path(args.config))
    selected = set(target_lock['selected_targets'])

    qct_rows = read_csv(Path(args.qct_predictions_locked))
    obs_rows = [r for r in read_csv(Path(args.observed_rows)) if r['target_id'] in selected]
    comp_rows = [r for r in read_csv(Path(args.comparator_rows)) if r['target_id'] in selected and boolish(r.get('admissible','true'))]

    for rows, req, name in [(qct_rows,QCT_REQ,'QCT'),(obs_rows,OBS_REQ,'observed'),(comp_rows,COMP_REQ,'comparator')]:
        if not rows:
            raise SystemExit(f'{name} rows empty after target filtering')
        missing = [c for c in req if c not in rows[0].keys()]
        if missing:
            raise SystemExit(f'{name} rows missing columns: {missing}')

    obs_by_key = {(r['target_id'], r['bin_id']): r for r in obs_rows}
    qct_by_key = {(r['target_id'], r['bin_id']): r for r in qct_rows}
    missing_obs = sorted(set(qct_by_key) - set(obs_by_key))
    if missing_obs:
        raise SystemExit(f'observed rows missing for QCT prediction bins: {missing_obs[:5]}')

    # QCT stack
    qct_stats = defaultdict(lambda: {'chi2':0.0,'n':0,'signs':[]})
    qct_stack_rows = []
    for key, qr in sorted(qct_by_key.items()):
        ob = obs_by_key[key]
        res = f(ob['log10_gobs_observed']) - f(qr['qct_log10_gobs_pred'])
        sig = f(ob['sigma_log10_gobs'])
        chi = (res/sig)**2
        tid = qr['target_id']
        qct_stats[tid]['chi2'] += chi; qct_stats[tid]['n'] += 1; qct_stats[tid]['signs'].append(sign(res))
        qct_stack_rows.append({
            'target_id': tid, 'bin_id': qr['bin_id'], 'x_i': qr['x_i'],
            'model_id': 'QCT_LOCKED', 'lane': 'QCT_PRE_REGISTERED',
            'prediction': qr['qct_log10_gobs_pred'], 'observed': ob['log10_gobs_observed'],
            'sigma': ob['sigma_log10_gobs'], 'residual': f'{res:.12g}', 'chi2': f'{chi:.12g}'
        })

    comp_stats = defaultdict(lambda: {'chi2':0.0,'n':0,'signs':[],'lane':''})
    comp_stack_rows = []
    for cr in comp_rows:
        key = (cr['target_id'], cr['bin_id'])
        if key not in obs_by_key:
            continue
        ob = obs_by_key[key]
        res = f(ob['log10_gobs_observed']) - f(cr['comparator_log10_gobs_pred'])
        sig = f(ob['sigma_log10_gobs'])
        chi = (res/sig)**2
        cid = cr['comparator_id']
        comp_stats[(cr['target_id'], cid)]['chi2'] += chi
        comp_stats[(cr['target_id'], cid)]['n'] += 1
        comp_stats[(cr['target_id'], cid)]['signs'].append(sign(res))
        comp_stats[(cr['target_id'], cid)]['lane'] = cr['comparator_lane']
        comp_stack_rows.append({
            'target_id': cr['target_id'], 'bin_id': cr['bin_id'], 'x_i': cr['x_i'],
            'model_id': cid, 'lane': cr['comparator_lane'],
            'prediction': cr['comparator_log10_gobs_pred'], 'observed': ob['log10_gobs_observed'],
            'sigma': ob['sigma_log10_gobs'], 'residual': f'{res:.12g}', 'chi2': f'{chi:.12g}'
        })

    all_stack = qct_stack_rows + comp_stack_rows
    write_csv(out / 'COMPARISON_STACK.csv', all_stack, ['target_id','bin_id','x_i','model_id','lane','prediction','observed','sigma','residual','chi2'])

    threshold = float(cfg.get('qct_hit_delta_chi2_threshold', -9.0))
    required_lanes = set(cfg.get('required_comparator_lanes_for_family_language', []))
    case_rows = []
    verdict_counts = defaultdict(int)
    for tid in sorted(selected):
        q = qct_stats.get(tid)
        if not q:
            continue
        comps = [(key, val) for key, val in comp_stats.items() if key[0] == tid]
        if not comps:
            verdict = 'NO_ADMISSIBLE_COMPARATOR'
            best_id = ''; best_lane = ''; best_chi = ''
            delta = ''
        else:
            best_key, best_val = sorted(comps, key=lambda kv: kv[1]['chi2'])[0]
            best_id = best_key[1]
            best_lane = best_val['lane']
            best_chi = best_val['chi2']
            delta = q['chi2'] - best_chi
            if delta <= threshold:
                verdict = 'QCT_BLIND_HIT'
            elif delta > 0:
                verdict = 'COMPARATOR_RESCUED'
            else:
                verdict = 'INCONCLUSIVE_LOW_POWER'
        lanes_seen = {val['lane'] for key, val in comps}
        family_complete = required_lanes.issubset(lanes_seen) if required_lanes else False
        verdict_counts[verdict] += 1
        case_rows.append({
            'target_id': tid,
            'qct_chi2': f"{q['chi2']:.12g}",
            'qct_n': q['n'],
            'qct_residual_sign_pattern': ''.join(q['signs']),
            'best_comparator_id': best_id,
            'best_comparator_lane': best_lane,
            'best_comparator_chi2': f"{best_chi:.12g}" if best_chi != '' else '',
            'delta_chi2_qct_minus_best_comparator': f"{delta:.12g}" if delta != '' else '',
            'required_family_lanes_complete': str(family_complete).lower(),
            'case_verdict': verdict
        })

    write_csv(out / 'CASE_VERDICT_TABLE.csv', case_rows, ['target_id','qct_chi2','qct_n','qct_residual_sign_pattern','best_comparator_id','best_comparator_lane','best_comparator_chi2','delta_chi2_qct_minus_best_comparator','required_family_lanes_complete','case_verdict'])

    program_verdict = 'BLIND_HOLDOUT_INCONCLUSIVE'
    if verdict_counts['QCT_BLIND_HIT'] > 0 and verdict_counts['COMPARATOR_RESCUED'] == 0:
        program_verdict = 'BLIND_HOLDOUT_QCT_HIT_SET_MATERIALIZED'
    elif verdict_counts['COMPARATOR_RESCUED'] > 0 and verdict_counts['QCT_BLIND_HIT'] == 0:
        program_verdict = 'BLIND_HOLDOUT_COMPARATOR_RESCUE_SET_MATERIALIZED'
    elif verdict_counts['QCT_BLIND_HIT'] > 0 and verdict_counts['COMPARATOR_RESCUED'] > 0:
        program_verdict = 'BLIND_HOLDOUT_MIXED_RESULT_MATERIALIZED'

    summary = {
        'object': 'BLIND_HOLDOUT_ADJUDICATION',
        'status': 'materialized',
        'program_verdict': program_verdict,
        'selected_targets': sorted(selected),
        'case_count': len(case_rows),
        'verdict_counts': dict(verdict_counts),
        'target_lock_sha256': sha256_file(Path(args.target_lock_json)),
        'prediction_lock_sha256': sha256_file(Path(args.prediction_lock_json)),
        'observed_rows_sha256': sha256_file(Path(args.observed_rows)),
        'comparator_rows_sha256': sha256_file(Path(args.comparator_rows)),
        'comparison_stack_sha256': sha256_file(out / 'COMPARISON_STACK.csv'),
        'case_verdict_table_sha256': sha256_file(out / 'CASE_VERDICT_TABLE.csv'),
        'whole_family_claim': False,
        'cosmic_closure_claim': False,
        'claim_boundary': 'bounded blind holdout only; no whole-family or cosmic closure claim'
    }
    write_json(out / 'BLIND_HOLDOUT_ADJUDICATION.json', summary)
    print(program_verdict)

if __name__ == '__main__':
    main()
