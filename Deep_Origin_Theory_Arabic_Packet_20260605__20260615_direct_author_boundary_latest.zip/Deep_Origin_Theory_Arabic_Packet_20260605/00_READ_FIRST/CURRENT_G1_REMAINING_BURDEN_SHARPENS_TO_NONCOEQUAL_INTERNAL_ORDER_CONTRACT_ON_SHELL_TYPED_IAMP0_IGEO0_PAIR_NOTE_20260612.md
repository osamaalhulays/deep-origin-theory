# Current `G1` Remaining Burden Sharpens To One Noncoequal Internal-Order Contract On The Shell-Typed `(I_amp^(0), I_geo^(0))` Pair

Date: `2026-06-12`

Purpose:

State the next exact reread after the remaining `G1` burden had already been
sharpened to one transport-leading carrier subbinding on the shell-typed
`(I_amp^(0), I_geo^(0))` pair.

## Short verdict

That burden no longer sits on the pair as one flat carrier-subbinding
problem.

The repo already fixes:

- one carrier-side image map
  `(I_amp, I_geo) -> (A_Q, M_Q)`
- `I_geo -> A_Q` as the transport-leading certification lane
- `J_lin := I_amp` on the support-side source-amplitude lane
- and one downstream carrier order with `A_Q` first and `M_Q` later

So the remaining first live burden now sharpens to:

- one reviewer-visible lawful noncoequal internal-order contract on the
  shell-typed `(I_amp^(0), I_geo^(0))` pair,
  strong enough to keep `I_geo^(0)` as the transport-leading face and
  `I_amp^(0)` as the support amplitude face,
  without yet claiming one final pairwise coefficient law

## What this does not claim

This note does **not** claim:

- that the required internal-order contract is already materialized
- that the final pairwise coefficient law is already known
- full `G1` closure

It claims something narrower:

- the remaining burden is now more exact than pair-level carrier-subbinding
  language.

## Read with

- `CURRENT_G1_REMAINING_BURDEN_SHARPENS_TO_TRANSPORT_LEADING_CARRIER_SUBBINDING_ON_SHELL_TYPED_IAMP0_IGEO0_PAIR_NOTE_20260612.md`
- `POST_CAGE_BRANCH_U1_RR0_BS1_JLIN_REGISTER_BINDING_FREEZE_AND_ACTIVE_DYAD_NOTE_20260608.md`
- `POST_CAGE_BRANCH_U1_RR0_BS1_AQ_EXACT_TARGET_LOCALIZES_TO_TQ_TRANSPORT_OWNERSHIP_PIVOT_NOTE_20260608.md`
