# Form A Kill Conditions

Date: `2026-06-10`

Status: `failure semantics lock`

## What counts as honest failure

`Form A` fails cleanly if one of the following is established:

1. no lawful benchmark-bin roster can be bound from the frozen current route
2. no source-governed ownership statement can be supplied for the rowwise
   `Delta_QCT_L2(x_i)` values
3. value emission requires observational borrowing, fit, or post-hoc
   calibration
4. table-level values are not the natural primitive and the route can only
   speak lawfully in a higher form such as one evaluator family

## What failure does not authorize

Failure at `Form A` does **not** authorize:

- empirical `RAR` rescue
- `MOND` rescue
- halo fit rescue
- baryonic tuning rescue
- likelihood rescue
- claim inflation

## What failure would change

Failure would justify:

1. one cleaner jump to `Form B` only if the representation issue is genuine
2. one cleaner jump to `Form C` if evaluator-level emission is truly prior
3. stronger pressure against the present source-governed route if no lawful
   content emission can be shown even at table level

## Bottom line

`Form A` is selected first precisely because it can fail cleanly and teach us
something exact.

