# Form A Conversion And Escalation Map

Date: `2026-06-10`

Status: `upgrade map`

## Immediate role

`Form A` is the minimum direct-value first strike.

## Allowed upward moves

1. `Form A -> Form B`
   if the `Xi_QCT_L2(gbar_i)` representation is lawfully derived through the
   already frozen conversion rule and is cleaner for later comparison.

2. `Form A -> Form C`
   if one source-governed evaluator function becomes available and the table
   can be recognized as one sampled boundary of that evaluator.

3. `Form C -> Form D`
   if one real operator engine is materialized rather than merely named.

## Disallowed fake upgrades

- naming `Form C` without one lawful evaluator
- naming `Form D` without one lawful engine
- relabeling one fit shell as `Form A`
- treating symbolic operator grammar alone as if it were `Form D`

## Bottom line

`Form A` is not the final form.

It is the smallest lawful entry point into the same frozen form ladder.

