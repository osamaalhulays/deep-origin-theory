# Form A Selection Rationale

Date: `2026-06-10`

Status: `scope lock`

## Selection

Selected first lawful strike:

- `Form A`

Deferred but preserved:

- `Form B`
- `Form C`
- `Form D`

## Why `Form A` comes first

1. The surviving named wound already points to missing numeric
   `Delta_QCT_L2(x_i)` authority at the frozen benchmark bins.
2. `Form A` attacks that wound directly without adding a conversion layer.
3. `Form A` avoids fake generality before one lawful rowwise value pack
   exists.
4. `Form A` is the strongest local kill test for whether the present route
   can emit promotable content at all.

## What this selection is not

This is not a claim that:

- `Form A` is already solved,
- `Form B/C/D` are impossible,
- or one table automatically yields one true `L0` crossing.

## Bottom line

`Form A` is selected first because it is the smallest direct attack on the
currently named live absence.

