# Form A Minimum Content Schema

Date: `2026-06-10`

Status: `content lock`

## Required package class

`Form A = direct Delta_QCT_L2(x_i) table at the frozen benchmark bins`

## Minimum required fields

Each lawful row pack must supply:

1. `benchmark_bin_id`
2. `x_i`
3. `delta_qct_l2`
4. `operator_authority_ref`
5. `source_to_total_rule_ref`
6. `source_governed_authority_note`
7. `no_borrowing_declaration`

## Required package-level declarations

The package must also declare:

1. the benchmark-bin roster used
2. the source-governed owner of the values
3. that no observational borrowing was used
4. that the table is not a fit product
5. that the table does not by itself claim crossing, fit, or cosmology
   closure

## Forbidden substitutes

The following do **not** count as `Form A`:

- one symbolic formula without values
- one residual-derived table
- one `RAR`-derived table
- one `MOND` interpolation table
- one tuned halo or baryonic fit table
- one likelihood-optimized table
- one observed-`gobs` relabeling

## Template

See:

- `FORM_A_DELTA_TABLE_TEMPLATE.csv`

