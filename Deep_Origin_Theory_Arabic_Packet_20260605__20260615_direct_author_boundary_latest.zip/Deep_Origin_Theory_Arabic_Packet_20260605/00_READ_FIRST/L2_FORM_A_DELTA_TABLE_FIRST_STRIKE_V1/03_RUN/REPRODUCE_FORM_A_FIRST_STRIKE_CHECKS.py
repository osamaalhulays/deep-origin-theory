from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
LOCKS = ROOT / "02_LOCKS"
BACKBONE = ROOT / "01_BACKBONE" / "MANUSCRIPT.md"
OUTPUTS = ROOT / "04_OUTPUTS"


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def has_all(text: str, needles: list[str]) -> bool:
    return all(needle in text for needle in needles)


def main() -> None:
    manuscript = read_text(BACKBONE)
    rationale = read_text(LOCKS / "FORM_A_SELECTION_RATIONALE.md")
    schema = read_text(LOCKS / "FORM_A_MINIMUM_CONTENT_SCHEMA.md")
    escalation = read_text(LOCKS / "FORM_A_CONVERSION_AND_ESCALATION_MAP.md")
    kill = read_text(LOCKS / "FORM_A_KILL_CONDITIONS.md")
    source_map = read_text(LOCKS / "SOURCE_MAP.md")
    template = read_text(LOCKS / "FORM_A_DELTA_TABLE_TEMPLATE.csv").strip()

    summary = {
        "object_name": "L2_FORM_A_DELTA_TABLE_FIRST_STRIKE_V1",
        "selected_form_is_A": "Selected first lawful strike:\n\n- `Form A`" in rationale,
        "selection_rationale_materialized": has_all(
            rationale,
            [
                "missing numeric",
                "currently named live absence",
            ],
        ),
        "minimum_content_schema_materialized": has_all(
            schema,
            [
                "benchmark_bin_id",
                "x_i",
                "delta_qct_l2",
                "no_borrowing_declaration",
            ],
        ),
        "conversion_and_escalation_map_materialized": has_all(
            escalation,
            ["`Form A -> Form B`", "`Form A -> Form C`", "`Form C -> Form D`"],
        ),
        "kill_conditions_materialized": has_all(
            kill,
            [
                "no lawful benchmark-bin roster can be bound",
                "Failure at `Form A` does **not** authorize",
            ],
        ),
        "source_map_materialized": has_all(
            source_map,
            [
                "RANK10_CURRENT_MATERIALS_FINAL_COMPRESSION_TO_SINGLE_L2_AUTHORING_TARGET_NOTE_20260608.md",
                "POST_CAGE_O4_O5_KREIB_CROSS_REPO_REFINEMENT_AFTER_RULE_AND_OPERATOR_SUPPLY_20260608.md",
            ],
        ),
        "template_header_materialized": template
        == "benchmark_bin_id,x_i,delta_qct_l2,operator_authority_ref,source_to_total_rule_ref,source_governed_authority_note,no_borrowing_declaration",
        "claims_numeric_values_already_exist": "lawful `Delta_QCT_L2(x_i)` values already exist" in manuscript,
        "claims_l0_crossing": False,
        "claims_fit_or_cosmology_closure": "full cosmology closure is now near" in manuscript,
    }

    verdict = {
        "status": "materialized",
        "selected_first_form": "Form A",
        "first_strike_object_materialized": all(
            [
                summary["selected_form_is_A"],
                summary["selection_rationale_materialized"],
                summary["minimum_content_schema_materialized"],
                summary["conversion_and_escalation_map_materialized"],
                summary["kill_conditions_materialized"],
                summary["source_map_materialized"],
                summary["template_header_materialized"],
            ]
        ),
        "numeric_value_pack_already_materialized": False,
        "l0_crossing_claimed": False,
        "fit_or_cosmology_closure_claimed": False,
    }

    report = [
        "# Form A First Strike Report",
        "",
        "Date: `2026-06-10`",
        "",
        "## Verdict",
        "",
        f"- first-strike object materialized = `{str(verdict['first_strike_object_materialized']).lower()}`",
        "- selected first form = `Form A`",
        "- numeric value pack already materialized = `false`",
        "- `L0` crossing claimed = `false`",
        "- fit or cosmology closure claimed = `false`",
        "",
        "## What is now explicit",
        "",
        "- why `Form A` is the first lawful strike",
        "- the minimum lawful rowwise schema",
        "- the upgrade path toward `Form B/C/D`",
        "- and the exact failure semantics if `Form A` cannot be supplied lawfully",
        "",
        "## What remains open",
        "",
        "- one lawful `Delta_QCT_L2(x_i)` value pack",
        "- or one honest `Form A` no-go verdict",
    ]

    OUTPUTS.mkdir(parents=True, exist_ok=True)
    (OUTPUTS / "status_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=True) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "verdict.json").write_text(
        json.dumps(verdict, indent=2, ensure_ascii=True) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "FORM_A_FIRST_STRIKE_REPORT.md").write_text(
        "\n".join(report) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()

