# Current Direct-Author Public Derivative Boundary Note

Date: `2026-06-15`

Purpose:

Freeze the exact outward-public boundary after the direct-author `PAYLOAD_B`
lane has already landed, so the packet keeps the scientific gain while not
silently republishing row-level or near-rowwise derivative tables built from
that source payload.

## Short verdict

The fair current reading is:

- the direct-author arrival remains fully real,
- the receipt, hashes, schema floor, intake class, and bounded summary/ledger
  consequences remain public,
- row-level or near-rowwise derivative tables built from that payload are now
  withheld from the outward packet unless separate source-release permission is
  made explicit,
- and this is publication-boundary hardening rather than scientific retreat.

## Publicly retained layers

The packet still keeps visible:

- the exact outside-contact receipt and intake class,
- the `49 / 49` matched-galaxy landing fact,
- the `1082` observed-row and `4850` baryonic-row intake totals,
- the downstream normalization policy lock,
- the `gbar` diagnostic summary and galaxy-level ledger surfaces,
- the comparison-admissibility summary, galaxy ledger, and clean-first
  shortlist surfaces,
- and focused case reports that do not republish row tables.

## Withheld from the outward packet

The outward packet now withholds:

- the raw zip payload itself,
- row-level `gbar` diagnostic tables,
- row-level empirical comparison-ready tables,
- focused case row tables and key-row extracts,
- component-at-observed-radii tables,
- and comparator tables built directly from those same direct-author rows.

## Effect on the scientific reading

This boundary does **not**:

- undo the real `G6` / `D7` landing,
- erase the bounded diagnostic and admissibility gains,
- withdraw the clean-first selection logic,
- or convert the lane back into one inferred public-link hunt.

It does:

- keep attribution cleaner,
- separate landed intake from outward republication,
- and preserve one public packet that is easier to defend if a cold reader asks
  what was landed, what was derived locally, and what is being republished.

## Read with

- `EXTERNAL_DIRECT_AUTHOR_EMPIRICAL_PAYLOAD__PAVEL_MANCERA_PINA_NOTE_20260614.md`
- `CURRENT_G6_D7_PAYLOAD_B_DOWNSTREAM_USE_BOUNDARY_NOTE_20260612.md`
- `CURRENT_G6_D7_PAYLOAD_B_49_GALAXY_GBAR_DIAGNOSTIC_LANE_NOTE_20260613.md`
- `CURRENT_G6_D7_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_NOTE_20260613.md`
