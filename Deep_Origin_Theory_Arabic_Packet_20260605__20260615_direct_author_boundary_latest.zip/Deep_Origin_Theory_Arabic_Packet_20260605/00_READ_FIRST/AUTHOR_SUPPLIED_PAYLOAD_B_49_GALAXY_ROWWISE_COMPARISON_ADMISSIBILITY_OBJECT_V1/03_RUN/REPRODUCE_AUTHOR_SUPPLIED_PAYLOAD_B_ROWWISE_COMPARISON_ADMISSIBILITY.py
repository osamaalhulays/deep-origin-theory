#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def tf(value: bool) -> str:
    return "true" if value else "false"


def build_report(summary: dict) -> str:
    return f"""# Author-Supplied `PAYLOAD_B` 49-Galaxy Rowwise Comparison Admissibility Report

Date: `2026-06-13`

## Short verdict

The landed `49`-galaxy family is now stronger than one normalized receipt lane.

It is now:

- one explicit empirical rowwise comparison family at `gobs/gbar` scope

Inside that family there is now one stricter subfamily:

- `11` clean-first galaxies

And the current rank-1 clean-first candidate is:

- `{summary["first_clean_candidate"]}`

## Exact counts

- matched galaxies: `{summary["matched_galaxy_count"]}`
- rowwise comparison-ready galaxies: `{summary["diagnostic_rowwise_ready_galaxy_count"]}`
- rowwise comparison-ready rows: `{summary["diagnostic_rowwise_ready_row_count"]}`
- clean-first galaxies: `{summary["clean_first_galaxy_count"]}`
- clean-first rows: `{summary["clean_first_row_count"]}`
- duplicate-radius galaxies: `{summary["duplicate_radius_galaxy_count"]}`
- negative `VH2` galaxies: `{summary["negative_vh2_galaxy_count"]}`
- zero-fill sentinel galaxies: `{summary["zero_fill_sentinel_galaxy_count"]}`
- universal negative `VHI` baseline galaxies: `{summary["universal_negative_vhi_baseline_galaxy_count"]}`
- theory-side eligible galaxies: `{summary["theory_side_authoring_eligible_galaxy_count"]}`

## Exact current ceiling

This object gives:

- empirical rowwise `gobs/gbar` comparison readiness
- one strict clean-first shortlist

This object still does not give:

- one `rho_b(r)` source profile pack
- one theory-side authoring move
- one `QCT` / `QUMOND` superiority claim
- one matched-nuisance execution
"""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--diagnostic-csv", required=True)
    parser.add_argument("--galaxy-status-csv", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    diagnostic_rows = load_csv(Path(args.diagnostic_csv).resolve())
    galaxy_rows = load_csv(Path(args.galaxy_status_csv).resolve())
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    rows_by_galaxy: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in diagnostic_rows:
        rows_by_galaxy[row["galaxy"]].append(row)

    ledger_rows = []
    shortlist_rows = []
    rowwise_rows = []

    duplicate_radius_galaxy_count = 0
    negative_vh2_galaxy_count = 0
    zero_fill_sentinel_galaxy_count = 0
    universal_negative_vhi_baseline_galaxy_count = 0
    diagnostic_rowwise_ready_galaxy_count = 0
    diagnostic_rowwise_ready_row_count = 0
    clean_first_galaxy_count = 0
    clean_first_row_count = 0

    ranking_seed = []

    for galaxy_row in galaxy_rows:
        galaxy = galaxy_row["galaxy"]
        galaxy_diag_rows = rows_by_galaxy.get(galaxy, [])
        observed_rows = int(galaxy_row["observed_rows"])
        materialized_rows = int(galaxy_row["materialized_diagnostic_rows"])
        duplicate_blocks = int(galaxy_row["duplicate_radius_block_count"])
        negative_vhi_rows = int(galaxy_row["negative_vhi_rows"])
        negative_vh2_rows = int(galaxy_row["negative_vh2_rows"])
        zero_fill_vstars_rows = int(galaxy_row["zero_fill_vstars_rows"])
        zero_fill_vbulge_rows = int(galaxy_row["zero_fill_vbulge_rows"])
        min_gbar = float(galaxy_row["min_gbar_m_s2"])
        max_gbar = float(galaxy_row["max_gbar_m_s2"])

        if len(galaxy_diag_rows) != observed_rows or materialized_rows != observed_rows:
            raise ValueError(f"{galaxy}: row-count mismatch between status and diagnostic table")

        rowwise_ready = (
            galaxy_row["status"] == "diagnostic_gbar_materialized"
            and observed_rows > 0
            and min_gbar > 0.0
            and max_gbar > 0.0
        )
        clean_first = (
            rowwise_ready
            and duplicate_blocks == 0
            and negative_vh2_rows == 0
            and zero_fill_vstars_rows == 0
            and zero_fill_vbulge_rows == 0
        )

        current_scope_class = (
            "empirical_rowwise_comparison_ready__clean_first_priority"
            if clean_first
            else "empirical_rowwise_comparison_ready__normalized_family"
            if rowwise_ready
            else "not_rowwise_ready"
        )

        duplicate_radius_galaxy_count += int(duplicate_blocks > 0)
        negative_vh2_galaxy_count += int(negative_vh2_rows > 0)
        zero_fill_sentinel_galaxy_count += int(
            zero_fill_vstars_rows > 0 or zero_fill_vbulge_rows > 0
        )
        universal_negative_vhi_baseline_galaxy_count += int(negative_vhi_rows > 0)
        diagnostic_rowwise_ready_galaxy_count += int(rowwise_ready)
        diagnostic_rowwise_ready_row_count += observed_rows if rowwise_ready else 0
        clean_first_galaxy_count += int(clean_first)
        clean_first_row_count += observed_rows if clean_first else 0

        gbar_span_dex = math.log10(max_gbar) - math.log10(min_gbar)

        ledger_rows.append(
            {
                "galaxy": galaxy,
                "observed_rows": observed_rows,
                "duplicate_radius_block_count": duplicate_blocks,
                "negative_vhi_rows": negative_vhi_rows,
                "negative_vh2_rows": negative_vh2_rows,
                "zero_fill_vstars_rows": zero_fill_vstars_rows,
                "zero_fill_vbulge_rows": zero_fill_vbulge_rows,
                "rowwise_empirical_comparison_ready": tf(rowwise_ready),
                "clean_first_gate_pass": tf(clean_first),
                "theory_side_authoring_eligible": "false",
                "gbar_span_dex": gbar_span_dex,
                "current_scope_class": current_scope_class,
            }
        )

        if clean_first:
            ranking_seed.append(
                {
                    "galaxy": galaxy,
                    "observed_rows": observed_rows,
                    "gbar_span_dex": gbar_span_dex,
                    "duplicate_radius_block_count": duplicate_blocks,
                    "negative_vh2_rows": negative_vh2_rows,
                    "zero_fill_vstars_rows": zero_fill_vstars_rows,
                    "zero_fill_vbulge_rows": zero_fill_vbulge_rows,
                }
            )

    ranking_seed.sort(
        key=lambda row: (-row["observed_rows"], -row["gbar_span_dex"], row["galaxy"])
    )

    clean_rank_map = {}
    for rank, row in enumerate(ranking_seed, start=1):
        clean_rank_map[row["galaxy"]] = rank
        shortlist_rows.append(
            {
                "rank": rank,
                "galaxy": row["galaxy"],
                "observed_rows": row["observed_rows"],
                "gbar_span_dex": row["gbar_span_dex"],
                "duplicate_radius_block_count": row["duplicate_radius_block_count"],
                "negative_vh2_rows": row["negative_vh2_rows"],
                "zero_fill_vstars_rows": row["zero_fill_vstars_rows"],
                "zero_fill_vbulge_rows": row["zero_fill_vbulge_rows"],
                "selection_rule": "rows_desc_then_gbar_span_desc_then_name",
            }
        )

    for row in diagnostic_rows:
        galaxy = row["galaxy"]
        ledger = next(item for item in ledger_rows if item["galaxy"] == galaxy)
        rowwise_rows.append(
            {
                "galaxy": galaxy,
                "observed_row_index": row["observed_row_index"],
                "r_kpc_observed": row["r_kpc_observed"],
                "vobs_km_s": row["vobs_km_s"],
                "e_vobs_km_s": row["e_vobs_km_s"],
                "interpolation_mode": row["interpolation_mode"],
                "vbar2_signed_km2_s2": row["vbar2_signed_km2_s2"],
                "gbar_m_s2": row["gbar_m_s2"],
                "log10_gbar_m_s2": row["log10_gbar_m_s2"],
                "gobs_m_s2": row["gobs_m_s2"],
                "log10_gobs_m_s2": row["log10_gobs_m_s2"],
                "delta_log10_gobs_minus_gbar": row["delta_log10_gobs_minus_gbar"],
                "rowwise_empirical_comparison_ready": ledger["rowwise_empirical_comparison_ready"],
                "current_scope_class": ledger["current_scope_class"],
                "clean_first_gate_pass": ledger["clean_first_gate_pass"],
                "clean_first_priority_rank": clean_rank_map.get(galaxy, ""),
                "theory_side_authoring_eligible": "false",
                "comparison_scope": "empirical_gobs_gbar_only",
            }
        )

    first_clean_candidate = shortlist_rows[0]["galaxy"] if shortlist_rows else ""
    first_clean_candidate_rows = shortlist_rows[0]["observed_rows"] if shortlist_rows else 0

    summary = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_SUMMARY_20260613",
        "comparison_scope": "empirical_gobs_gbar_only",
        "matched_galaxy_count": len(galaxy_rows),
        "diagnostic_rowwise_ready_galaxy_count": diagnostic_rowwise_ready_galaxy_count,
        "diagnostic_rowwise_ready_row_count": diagnostic_rowwise_ready_row_count,
        "clean_first_galaxy_count": clean_first_galaxy_count,
        "clean_first_row_count": clean_first_row_count,
        "duplicate_radius_galaxy_count": duplicate_radius_galaxy_count,
        "negative_vh2_galaxy_count": negative_vh2_galaxy_count,
        "zero_fill_sentinel_galaxy_count": zero_fill_sentinel_galaxy_count,
        "universal_negative_vhi_baseline_galaxy_count": universal_negative_vhi_baseline_galaxy_count,
        "theory_side_authoring_eligible_galaxy_count": 0,
        "first_clean_candidate": first_clean_candidate,
        "first_clean_candidate_observed_rows": first_clean_candidate_rows,
        "all_49_are_empirical_rowwise_ready": diagnostic_rowwise_ready_galaxy_count == len(galaxy_rows),
        "verdict": (
            "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_MATERIALIZED__ALL_49_GALAXIES_ARE_NOW_EMPIRICAL_COMPARISON_READY_AT_GOBS_GBAR_SCOPE_WITH_11_CLEAN_FIRST_CASES"
        ),
    }

    grammar_lock = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_GRAMMAR_LOCK_20260613",
        "comparison_scope": "empirical_gobs_gbar_only",
        "rowwise_ready_gate": {
            "status": "chosen",
            "value": "diagnostic_gbar_materialized_plus_rowcount_match_plus_positive_gbar_support",
        },
        "clean_first_gate": {
            "status": "chosen",
            "value": "no_duplicate_radius_blocks_no_negative_vh2_no_zero_fill_sentinels",
        },
        "negative_vhi_clean_first_policy": {
            "status": "chosen",
            "value": "visible_and_normalized_but_not_used_as_clean_first_discriminator_because_it_is_sample_wide_baseline_behavior",
        },
        "theory_side_boundary": {
            "status": "chosen",
            "value": "no_theory_side_authoring_promotion",
        },
        "verdict": (
            "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_GRAMMAR_LOCK_CLOSED__SAMPLE_WIDE_AND_CLEAN_FIRST_GATES_ARE_NOW_EXPLICIT"
        ),
    }

    write_csv(
        output_dir / "GALAXY_COMPARISON_ADMISSIBILITY_LEDGER.csv",
        [
            "galaxy",
            "observed_rows",
            "duplicate_radius_block_count",
            "negative_vhi_rows",
            "negative_vh2_rows",
            "zero_fill_vstars_rows",
            "zero_fill_vbulge_rows",
            "rowwise_empirical_comparison_ready",
            "clean_first_gate_pass",
            "theory_side_authoring_eligible",
            "gbar_span_dex",
            "current_scope_class",
        ],
        ledger_rows,
    )
    write_csv(
        output_dir / "OBSERVED_ROW_EMPIRICAL_COMPARISON_READY.csv",
        [
            "galaxy",
            "observed_row_index",
            "r_kpc_observed",
            "vobs_km_s",
            "e_vobs_km_s",
            "interpolation_mode",
            "vbar2_signed_km2_s2",
            "gbar_m_s2",
            "log10_gbar_m_s2",
            "gobs_m_s2",
            "log10_gobs_m_s2",
            "delta_log10_gobs_minus_gbar",
            "rowwise_empirical_comparison_ready",
            "current_scope_class",
            "clean_first_gate_pass",
            "clean_first_priority_rank",
            "theory_side_authoring_eligible",
            "comparison_scope",
        ],
        rowwise_rows,
    )
    write_csv(
        output_dir / "CLEAN_FIRST_PRIORITY_SHORTLIST.csv",
        [
            "rank",
            "galaxy",
            "observed_rows",
            "gbar_span_dex",
            "duplicate_radius_block_count",
            "negative_vh2_rows",
            "zero_fill_vstars_rows",
            "zero_fill_vbulge_rows",
            "selection_rule",
        ],
        shortlist_rows,
    )
    (output_dir / "ADMISSIBILITY_GRAMMAR_LOCK.json").write_text(
        json.dumps(grammar_lock, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (output_dir / "ADMISSIBILITY_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (output_dir / "COMPARISON_ADMISSIBILITY_REPORT.md").write_text(
        build_report(summary),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
