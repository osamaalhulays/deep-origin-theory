# Admissibility Grammar

Date: `2026-06-13`

## Lane owner

This object governs only:

- empirical rowwise comparison readiness at current `gobs/gbar` scope

It does **not** govern:

- `rho_b(r)` authoring
- theory-side authoring
- `Form A/B/C/D`

## Inputs

This object is driven only by packet-local outputs from:

- `AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_GBAR_DIAGNOSTIC_NORMALIZATION_OBJECT_V1`

Required packet-local inputs:

- `OBSERVED_ROW_GBAR_DIAGNOSTIC.csv`
- `GALAXY_DIAGNOSTIC_STATUS.csv`

## Comparison-ready gate

One galaxy is admitted as:

- `empirical_rowwise_comparison_ready`

iff all of the following hold:

1. its normalized diagnostic status is `diagnostic_gbar_materialized`
2. its observed-row count matches its materialized row count
3. every row now carries both `gobs` and `gbar`
4. the normalized lane remains inside explicit observed-row `gbar` scope only

This gate is sample-wide and survives for all `49` landed galaxies.

## Clean-first gate

One comparison-ready galaxy is also admitted into the stricter subfamily:

- `empirical_rowwise_comparison_ready__clean_first_priority`

iff all of the following hold:

1. duplicate-radius block count = `0`
2. negative `VH2` row count = `0`
3. zero-filled stellar sentinel row count = `0`
4. zero-filled bulge sentinel row count = `0`

## Why negative `VHI` is not used as the clean-first discriminator

Negative `VHI` rows are preserved openly by the frozen sign rule, but they are
not used to separate the clean-first subfamily because they are sample-wide
baseline behavior across the landed family rather than one local outlier
feature.

So:

- negative `VHI` remains visible
- negative `VHI` remains normalized explicitly
- but it does not rank one galaxy as cleaner than another inside this object

## First-candidate ranking rule

The clean-first shortlist is ranked by:

1. larger observed-row count
2. larger `gbar` dynamic span in dex
3. lexical galaxy name as final tie-break

The current first candidate is the rank-1 galaxy under that fixed order only.
