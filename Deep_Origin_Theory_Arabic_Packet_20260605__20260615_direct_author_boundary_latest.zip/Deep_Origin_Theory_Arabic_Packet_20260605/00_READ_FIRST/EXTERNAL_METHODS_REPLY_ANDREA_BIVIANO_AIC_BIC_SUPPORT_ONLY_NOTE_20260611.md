# External Methods Reply — Andrea Biviano — AIC/BIC Support-Only Note

Date: `2026-06-11`

## Short verdict

This outside reply is useful,
but narrower than the Stacy McGaugh methods reply.

It gives one support-only clarification:

- `AIC/BIC`-style penalized likelihood comparison between models with
  different parameter counts is methodologically recognizable

It does **not** by itself settle:

- matched-nuisance fairness,
- nuisance symmetry procedure,
- unequal effective parameter-space concerns,
- or unconditional superiority language.

## Exact use

Use it only to support the narrow sentence that the packet's penalized
comparison shell is not methodologically outlandish on its face.

Do not use it as:

- endorsement of `QCT`,
- endorsement of the exact current differential sentence,
- or endorsement of stronger superiority claims.

## Relative weight

- Andrea = support-only for basic `AIC/BIC` legitimacy
- Stacy = sharper for fairness boundary and overclaim control
