# Current `G6` / `D7` author-supplied `NGC2541` Second Clean Empirical Rowcase Note

Date: `2026-06-13`

Purpose:

Freeze the exact current reading after the rank-`2` clean-first candidate from
the landed author-supplied `PAYLOAD_B` family has now been materialized as one second
focused reviewer-visible empirical case.

## Short verdict

The fair current reading is:

- `NGC2541` is no longer only the second name on the clean-first shortlist
- it is now one second focused empirical rowcase at `gobs/gbar` scope
- the case carries `31` observed rows
- all rows preserve clean-first status
- all rows preserve positive `log10(gobs) - log10(gbar)`
- theory-side promotion is still not claimed

## Exact current gain

This now gives:

- one second focused clean-first case
- one reviewer-visible extracted row table
- one compact key-row table
- one replayable summary surface for the second case

## Exact current ceiling

This still does **not** give:

- one theory-side authoring move
- one matched-nuisance execution
- one named competitor verdict

## Read with

- `CURRENT_G6_D7_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_NGC1313_FIRST_CLEAN_EMPIRICAL_ROWCASE_NOTE_20260613.md`
- `AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_OBJECT_V1`
- `AUTHOR_SUPPLIED_PAYLOAD_B_NGC2541_SECOND_CLEAN_EMPIRICAL_ROWCASE_OBJECT_V1`
