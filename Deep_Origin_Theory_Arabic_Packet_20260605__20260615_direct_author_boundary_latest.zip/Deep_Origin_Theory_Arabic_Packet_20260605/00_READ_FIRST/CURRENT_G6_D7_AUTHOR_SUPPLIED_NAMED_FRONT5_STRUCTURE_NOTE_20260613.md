# Current `G6` / `D7` author-supplied Named Front-`5` Structure Note

Date: `2026-06-13`

Purpose:

Freeze the exact current reading after the visible named empirical head inside
the landed author-supplied `PAYLOAD_B` lane is no longer only a front of four.

## Short verdict

The fair current reading is:

- the named clean-first head now contains `5` focused empirical cases
- those five cases are `NGC1313`, `NGC2541`, `NGC7793`, `NGC3992`, and `LVHIS077`
- together they currently carry `135` of `184` clean-first rows
- the remaining tail still contains `6` galaxies and `49` rows
- the whole front remains empirical `gobs/gbar` only
- theory-side promotion is still not claimed

## Exact current gain

This now gives:

- one named front-`5` ledger
- one front-versus-tail split above the clean-first reserve
- one visible named head that now covers nearly three quarters of clean-first
  rows

## Exact current ceiling

This still does **not** give:

- one theory-side authoring move
- one `QCT` prediction family
- one matched-nuisance execution
- one named competitor verdict

## Read with

- `CURRENT_G6_D7_AUTHOR_SUPPLIED_TOP3_CLEAN_FOCUSED_TRIO_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_NGC3992_FOURTH_CLEAN_EMPIRICAL_ROWCASE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_LVHIS077_FIFTH_CLEAN_EMPIRICAL_ROWCASE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_CLEAN_FIRST_RESERVE_STRUCTURE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_NAMED_FRONT4_STRUCTURE_NOTE_20260613.md`
- `AUTHOR_SUPPLIED_PAYLOAD_B_NAMED_FRONT5_STRUCTURE_OBJECT_V1`
- `NAMED_FRONT5_STRUCTURE_CAPSULE__AUTHOR_SUPPLIED_PAYLOAD_B__V1.md`
