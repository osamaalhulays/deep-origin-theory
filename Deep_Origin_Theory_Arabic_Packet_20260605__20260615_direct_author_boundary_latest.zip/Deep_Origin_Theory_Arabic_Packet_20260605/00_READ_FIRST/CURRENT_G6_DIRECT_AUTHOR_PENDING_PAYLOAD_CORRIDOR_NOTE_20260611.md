# Current `G6` Direct-Author Pending Payload Corridor Note

Date: `2026-06-11`

## Short verdict

`G6` is still open,
but it is no longer just generic waiting.

One direct-author corridor is now explicitly pending:

- requested parameters stated to exist,
- near promised window ending `2026-06-12`,
- fallback promised window ending `2026-06-22`.

This does **not** count as arrival yet.

It does count as one live date-bounded direct-author corridor.

## Exact consequence

The next honest move is:

- wait on this exact corridor first,
- and if files land, run intake verification and classify exactly as
  `PAYLOAD_A` or `PAYLOAD_B` immediately.
