# G4 `NGC4214` First Non-Toy `Form D` Run

Date: `2026-06-12`

Status: `reviewer-facing first non-toy observed-row crossing object`

## Purpose

This object does **not** claim:

- that the packet has reached `H0`,
- that cosmology is complete,
- that one successful-looking comparison was obtained,
- or that the first non-toy run launders poor confrontation into victory.

It does something narrower and reviewer-useful:

1. it freezes the exact non-toy `NGC4214` input pack that was actually used,
2. it bundles one packet-local replay engine,
3. it bundles one packet-local reproduction runner,
4. it preserves the emitted `Form A`, prediction-row, comparison-stack, and
   likelihood outputs,
5. and it turns the packet's `G4 retired / D3 retired / D4 awake` statement
   into one cold-auditable object.

## Short verdict

One lawful non-toy `NGC4214` run is now reviewer-visible inside the packet
itself.

That run already carries:

- one frozen baryonic source profile,
- one frozen benchmark-bin roster,
- one frozen production `m_inv`,
- one frozen observed-row file,
- one emitted `Form A` table,
- one emitted `QCT` prediction-row table,
- one emitted comparison stack,
- and one emitted likelihood summary.

So the packet no longer asks a reviewer to trust the `G4` / `D3` retirement
statement by note alone.

The run object now exists locally and can be replayed cold.

## Exact boundary

The run already proves only the following bounded statements:

- `G4` no longer remains open as "missing first observed-row crossing"
- `D3` no longer remains open as "missing first comparison stack"
- `D4` is the next live observational gate

It does **not** prove:

- that the confrontation is good,
- that `QCT` won this case,
- that one absolute-scale ascent has landed,
- or that anything above the first comparison stack is now closed.

## Why this object matters

Before this object, the packet had a real internal result but not yet one
reviewer-facing artifact layer that directly carried it.

After this object, the packet contains:

- the locked non-toy inputs,
- the canonical emitted outputs,
- and one reproduction runner that replays the run and checks that the
  reproduced outputs match the canonical packet outputs.

That is the exact gap a cold reviewer would otherwise complain about.

## What to read first

Read in this order:

1. `02_LOCKS/FROZEN_PRODUCTION_INPUT_TRIPLE_LOCK.json`
2. `04_OUTPUTS/G4_FIRST_NONTOY_FORMD_RUN_REPORT.md`
3. `04_OUTPUTS/G4_CROSSING_ADJUDICATION.json`

Then, if desired, rerun:

- `03_RUN/REPRODUCE_G4_NGC4214_FIRST_NONTOY_RUN.py`

with one fresh output directory.

## Bottom line

The packet now carries the first non-toy `NGC4214` crossing object as one
reviewer-facing artifact rather than one narrated consequence.
