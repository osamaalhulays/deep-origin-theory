#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import json
import math
import subprocess
import sys
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
LOCK_ROOT = OBJECT_ROOT / "02_LOCKS"
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"
ENGINE_PATH = OBJECT_ROOT / "03_RUN" / "g4_l0_crossing_engine.py"
FLOAT_TOLERANCE = 1e-12

CANONICAL_FILES = {
    "RADIAL_DIAGNOSTIC_ROWS.csv": {
        "type": "csv",
        "numeric_fields": {
            "row_id",
            "r_m",
            "rho_b_kg_m3",
            "gbar_m_s2",
            "x_of_r",
            "phi",
            "delta_qct_l2_of_r",
        },
    },
    "FORM_A_DELTA_TABLE.csv": {
        "type": "csv",
        "numeric_fields": {
            "x_i",
            "delta_qct_l2",
        },
    },
    "QCT_L2_PREDICTION_ROWS.csv": {
        "type": "csv",
        "numeric_fields": {
            "x_i",
            "delta_qct_l2",
            "log10_gobs_qct_pred",
            "gobs_qct_pred_m_s2",
        },
    },
    "COMPARISON_STACK.csv": {
        "type": "csv",
        "numeric_fields": {
            "x_i",
            "log10_gobs_observed",
            "sigma_log10_gobs",
            "log10_gobs_qct_pred",
            "residual_log10",
            "chi2",
        },
    },
    "LIKELIHOOD_SUMMARY.json": {
        "type": "json",
    },
    "G4_CROSSING_STATUS.json": {
        "type": "json",
    },
}


def load_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def parse_numeric(value: str | None):
    if value is None:
        return None
    stripped = value.strip()
    if stripped == "":
        return None
    return float(stripped)


def compare_csv(path_a: Path, path_b: Path, numeric_fields: set[str]) -> tuple[bool, dict]:
    rows_a = load_csv(path_a)
    rows_b = load_csv(path_b)
    if len(rows_a) != len(rows_b):
        return False, {"reason": "row_count_mismatch", "left": len(rows_a), "right": len(rows_b)}
    if rows_a and list(rows_a[0].keys()) != list(rows_b[0].keys()):
        return False, {
            "reason": "header_mismatch",
            "left": list(rows_a[0].keys()),
            "right": list(rows_b[0].keys()),
        }
    for index, (row_a, row_b) in enumerate(zip(rows_a, rows_b)):
        for key in row_a.keys():
            if key in numeric_fields:
                left = parse_numeric(row_a[key])
                right = parse_numeric(row_b[key])
                if left is None or right is None:
                    if left != right:
                        return False, {
                            "reason": "numeric_none_mismatch",
                            "row": index,
                            "field": key,
                            "left": row_a[key],
                            "right": row_b[key],
                        }
                elif not math.isclose(left, right, rel_tol=0.0, abs_tol=FLOAT_TOLERANCE):
                    return False, {
                        "reason": "numeric_mismatch",
                        "row": index,
                        "field": key,
                        "left": left,
                        "right": right,
                    }
            elif row_a[key] != row_b[key]:
                return False, {
                    "reason": "string_mismatch",
                    "row": index,
                    "field": key,
                    "left": row_a[key],
                    "right": row_b[key],
                }
    return True, {"row_count": len(rows_a)}


def compare_json_values(left, right, path: str = "$") -> tuple[bool, dict | None]:
    if isinstance(left, bool) or isinstance(right, bool):
        if left is right:
            return True, None
        return False, {"reason": "bool_mismatch", "path": path, "left": left, "right": right}
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        if math.isclose(float(left), float(right), rel_tol=0.0, abs_tol=FLOAT_TOLERANCE):
            return True, None
        return False, {
            "reason": "numeric_mismatch",
            "path": path,
            "left": left,
            "right": right,
        }
    if isinstance(left, str) and isinstance(right, str):
        if left == right:
            return True, None
        return False, {"reason": "string_mismatch", "path": path, "left": left, "right": right}
    if left is None or right is None:
        if left is right:
            return True, None
        return False, {"reason": "none_mismatch", "path": path, "left": left, "right": right}
    if isinstance(left, list) and isinstance(right, list):
        if len(left) != len(right):
            return False, {
                "reason": "list_length_mismatch",
                "path": path,
                "left": len(left),
                "right": len(right),
            }
        for index, (item_left, item_right) in enumerate(zip(left, right)):
            passed, detail = compare_json_values(item_left, item_right, f"{path}[{index}]")
            if not passed:
                return False, detail
        return True, None
    if isinstance(left, dict) and isinstance(right, dict):
        if set(left.keys()) != set(right.keys()):
            return False, {
                "reason": "dict_key_mismatch",
                "path": path,
                "left_only": sorted(set(left.keys()) - set(right.keys())),
                "right_only": sorted(set(right.keys()) - set(left.keys())),
            }
        for key in sorted(left.keys()):
            passed, detail = compare_json_values(left[key], right[key], f"{path}.{key}")
            if not passed:
                return False, detail
        return True, None
    if left == right:
        return True, None
    return False, {"reason": "type_or_value_mismatch", "path": path, "left": left, "right": right}


def compare_json(path_a: Path, path_b: Path) -> tuple[bool, dict]:
    left = json.loads(path_a.read_text(encoding="utf-8"))
    right = json.loads(path_b.read_text(encoding="utf-8"))
    passed, detail = compare_json_values(left, right)
    if passed:
        return True, {"keys": sorted(left.keys()) if isinstance(left, dict) else None}
    return False, detail or {"reason": "unknown_json_mismatch"}


def run_engine(output_dir: Path) -> None:
    command = [
        sys.executable,
        str(ENGINE_PATH),
        "--source-profile",
        str(LOCK_ROOT / "SOURCE_PROFILE_AUTHOR_FROZEN.csv"),
        "--m-inv-lock",
        str(LOCK_ROOT / "M_INV_LOCK_AUTHOR_FROZEN.json"),
        "--x-bins",
        str(LOCK_ROOT / "FROZEN_X_BINS_AUTHOR_FROZEN.txt"),
        "--observed-rows",
        str(LOCK_ROOT / "OBSERVED_ROWS_AUTHOR_FROZEN.csv"),
        "--output-dir",
        str(output_dir),
    ]
    subprocess.run(command, check=True, capture_output=True, text=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    run_engine(output_dir)

    checks = {}
    all_checks_pass = True

    for name, spec in CANONICAL_FILES.items():
        canonical_path = OUTPUT_ROOT / name
        reproduced_path = output_dir / name
        if not reproduced_path.exists():
            passed = False
            detail = {"reason": "missing_reproduced_file"}
        elif spec["type"] == "csv":
            passed, detail = compare_csv(
                canonical_path, reproduced_path, spec["numeric_fields"]
            )
        else:
            passed, detail = compare_json(canonical_path, reproduced_path)
        checks[name] = {"passed": passed, "detail": detail}
        all_checks_pass = all_checks_pass and passed

    status_payload = json.loads((output_dir / "G4_CROSSING_STATUS.json").read_text(encoding="utf-8"))
    likelihood_payload = json.loads(
        (output_dir / "LIKELIHOOD_SUMMARY.json").read_text(encoding="utf-8")
    )

    adjudication = {
        "object": "G4_NGC4214_FIRST_NONTOY_FORMD_RUN_V1",
        "status": (
            "G4_FIRST_NONTOY_FORMD_RUN_REPRODUCED_AND_MATCHED_CANONICAL_PACKET_OUTPUTS"
            if all_checks_pass
            else "G4_FIRST_NONTOY_FORMD_RUN_REPRODUCTION_OR_MATCH_FAILED"
        ),
        "all_checks_pass": all_checks_pass,
        "checks": checks,
        "reproduced_summary": {
            "status": status_payload.get("status"),
            "form_a_materialized": status_payload.get("form_a_materialized"),
            "prediction_rows_materialized": status_payload.get("prediction_rows_materialized"),
            "comparison_stack_materialized": status_payload.get("comparison_stack_materialized"),
            "row_count": likelihood_payload.get("row_count"),
            "chi2_total": likelihood_payload.get("chi2_total"),
            "loglike_gaussian_diag": likelihood_payload.get("loglike_gaussian_diag"),
        },
    }

    adjudication_path = output_dir / "G4_CROSSING_ADJUDICATION.json"
    adjudication_path.write_text(
        json.dumps(adjudication, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(adjudication, indent=2, sort_keys=True))

    if not all_checks_pass:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
