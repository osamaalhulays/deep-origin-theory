#!/usr/bin/env python3
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import argparse
import csv
import json
import math
import sys
from typing import Iterable


G_SI = 6.67430e-11
C_SI = 299792458.0
KAPPA_SI = 8.0 * math.pi * G_SI / (C_SI ** 2)


@dataclass(frozen=True)
class Config:
    m_inv_m1: float
    beta: float = 1.0
    beta_alpha: float = 1.0
    kappa: float = KAPPA_SI

    def validate(self) -> None:
        if not math.isfinite(self.m_inv_m1) or self.m_inv_m1 < 0:
            raise ValueError("m_inv_m1 must be finite and non-negative")
        if self.beta != 1.0 or self.beta_alpha != 1.0:
            raise ValueError("V1 forbids beta/beta_alpha variation")
        if self.kappa <= 0:
            raise ValueError("kappa must be positive")


@dataclass(frozen=True)
class SourceProfile:
    r_m: list[float]
    rho_b_kg_m3: list[float]
    gbar_m_s2: list[float]

    def validate(self) -> None:
        if not (len(self.r_m) == len(self.rho_b_kg_m3) == len(self.gbar_m_s2)):
            raise ValueError("r_m, rho_b_kg_m3, and gbar_m_s2 must have equal length")
        if len(self.r_m) < 4:
            raise ValueError("at least four radial nodes are required")
        if any(not math.isfinite(v) for v in self.r_m + self.rho_b_kg_m3 + self.gbar_m_s2):
            raise ValueError("all source-profile values must be finite")
        if any(v <= 0 for v in self.r_m):
            raise ValueError("r_m must be positive")
        if any(self.r_m[i + 1] <= self.r_m[i] for i in range(len(self.r_m) - 1)):
            raise ValueError("r_m must be strictly increasing")
        if any(v < 0 for v in self.rho_b_kg_m3):
            raise ValueError("rho_b_kg_m3 must be non-negative")
        if any(v <= 0 for v in self.gbar_m_s2):
            raise ValueError("gbar_m_s2 must be positive")


def read_csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        filtered = (line for line in handle if not line.lstrip().startswith("#"))
        return list(csv.DictReader(filtered))


def load_source_profile(path: Path) -> SourceProfile:
    rows = read_csv_rows(path)
    if not rows:
        raise ValueError("source profile has no data rows")
    required = {"r_m", "rho_b_kg_m3", "gbar_m_s2"}
    missing = required - set(rows[0].keys())
    if missing:
        raise ValueError(f"source profile missing columns: {sorted(missing)}")
    forbidden = {"g_obs", "gobs", "residual", "qumond_residual", "halo", "chi2", "likelihood"}
    present_lower = {key.lower() for key in rows[0].keys()}
    bad = [key for key in present_lower if any(token in key for token in forbidden)]
    if bad:
        raise ValueError(f"forbidden empirical/fit columns in source profile: {bad}")
    profile = SourceProfile(
        r_m=[float(row["r_m"]) for row in rows],
        rho_b_kg_m3=[float(row["rho_b_kg_m3"]) for row in rows],
        gbar_m_s2=[float(row["gbar_m_s2"]) for row in rows],
    )
    profile.validate()
    return profile


def load_m_inv_lock(path: Path, allow_toy: bool) -> tuple[Config, dict]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    status = payload.get("status")
    if status != "author_frozen":
        if not (allow_toy and status == "toy_selftest"):
            raise ValueError(
                "m_inv lock must have status='author_frozen' unless --allow-toy and status='toy_selftest'"
            )
    if payload.get("no_fit_backsolving") is not True:
        raise ValueError("m_inv lock must declare no_fit_backsolving=true")
    if payload.get("m_inv_m1") is None:
        raise ValueError("m_inv_m1 is missing in m_inv lock")
    cfg = Config(m_inv_m1=float(payload["m_inv_m1"]))
    cfg.validate()
    return cfg, payload


def load_x_bins(path: Path) -> list[float]:
    values = []
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        values.append(float(stripped))
    if not values:
        raise ValueError("x bins file has no numeric bins")
    if any(not math.isfinite(v) for v in values):
        raise ValueError("x bins must be finite")
    return values


def cell_faces(r_values: list[float]) -> list[float]:
    faces = [0.0] * (len(r_values) + 1)
    for index in range(1, len(r_values)):
        faces[index] = 0.5 * (r_values[index - 1] + r_values[index])
    faces[0] = 0.0
    faces[-1] = r_values[-1] + 0.5 * (r_values[-1] - r_values[-2])
    return faces


def solve_linear_system(matrix: list[list[float]], vector: list[float]) -> list[float]:
    n = len(vector)
    a = [row[:] for row in matrix]
    b = vector[:]

    for pivot_index in range(n):
        pivot_row = max(range(pivot_index, n), key=lambda idx: abs(a[idx][pivot_index]))
        pivot_value = a[pivot_row][pivot_index]
        if pivot_value == 0.0:
            raise ValueError("singular linear system in G4 crossing engine")
        if pivot_row != pivot_index:
            a[pivot_index], a[pivot_row] = a[pivot_row], a[pivot_index]
            b[pivot_index], b[pivot_row] = b[pivot_row], b[pivot_index]

        for row_index in range(pivot_index + 1, n):
            factor = a[row_index][pivot_index] / a[pivot_index][pivot_index]
            if factor == 0.0:
                continue
            for col_index in range(pivot_index, n):
                a[row_index][col_index] -= factor * a[pivot_index][col_index]
            b[row_index] -= factor * b[pivot_index]

    solution = [0.0] * n
    for row_index in range(n - 1, -1, -1):
        rhs = b[row_index]
        for col_index in range(row_index + 1, n):
            rhs -= a[row_index][col_index] * solution[col_index]
        solution[row_index] = rhs / a[row_index][row_index]
    return solution


def solve_phi(profile: SourceProfile, cfg: Config) -> list[float]:
    profile.validate()
    cfg.validate()

    r_values = profile.r_m
    rho_values = profile.rho_b_kg_m3
    faces = cell_faces(r_values)
    n = len(r_values)
    matrix = [[0.0 for _ in range(n)] for _ in range(n)]
    vector = [0.0 for _ in range(n)]

    for index in range(n - 1):
        rlo = faces[index]
        rhi = faces[index + 1]
        vol_over_4pi = (rhi**3 - rlo**3) / 3.0
        if vol_over_4pi <= 0:
            raise ValueError("invalid finite-volume shell volume")

        dr_up = r_values[index + 1] - r_values[index]
        cup = (rhi**2) / (vol_over_4pi * dr_up)
        matrix[index][index] -= cup
        matrix[index][index + 1] += cup

        if index > 0:
            dr_dn = r_values[index] - r_values[index - 1]
            cdn = (rlo**2) / (vol_over_4pi * dr_dn)
            matrix[index][index] -= cdn
            matrix[index][index - 1] += cdn

        m_eff2 = cfg.m_inv_m1**2 + cfg.beta_alpha * cfg.kappa * rho_values[index]
        matrix[index][index] -= m_eff2
        vector[index] = cfg.beta * cfg.kappa * rho_values[index]

    matrix[n - 1][n - 1] = 1.0
    vector[n - 1] = 0.0

    return solve_linear_system(matrix, vector)


def evaluate_delta(profile: SourceProfile, cfg: Config) -> tuple[list[float], list[float]]:
    phi = solve_phi(profile, cfg)
    return phi, [-value for value in phi]


def monotone_projection(
    profile: SourceProfile, delta_values: list[float], x_bins: Iterable[float]
) -> tuple[list[dict] | None, dict | None]:
    x_values = [math.log10(value) for value in profile.gbar_m_s2]
    diffs = [x_values[index + 1] - x_values[index] for index in range(len(x_values) - 1)]
    increasing = all(diff > 0 for diff in diffs)
    decreasing = all(diff < 0 for diff in diffs)
    if not (increasing or decreasing):
        return None, {
            "no_go_reason": "NON_MONOTONE_X_OF_R",
            "smallest_extra_freedom_if_blocked": "explicit author-frozen branch/fiber projection rule",
        }

    if decreasing:
        xp = list(reversed(x_values))
        fp = list(reversed(delta_values))
    else:
        xp = x_values
        fp = delta_values

    xmin = min(xp)
    xmax = max(xp)
    rows = []
    outside = []
    for index, x_bin in enumerate(x_bins):
        x_bin = float(x_bin)
        if x_bin < xmin or x_bin > xmax:
            rows.append(
                {
                    "benchmark_bin_id": f"bin_{index:03d}",
                    "x_i": x_bin,
                    "delta_qct_l2": None,
                    "status": "outside_source_x_range",
                    "source_governance": "SPEC205_FormC_radial_source_evaluator_V1",
                    "branch_rule": "monotone_source_branch_required",
                }
            )
            outside.append(x_bin)
            continue

        interp_value = interpolate_linear(xp, fp, x_bin)
        rows.append(
            {
                "benchmark_bin_id": f"bin_{index:03d}",
                "x_i": x_bin,
                "delta_qct_l2": interp_value,
                "status": "emitted_from_source_governed_evaluator",
                "source_governance": "SPEC205_FormC_radial_source_evaluator_V1",
                "branch_rule": "monotone_source_branch_required",
            }
        )

    if outside:
        return rows, {
            "no_go_reason": "BENCHMARK_BINS_OUTSIDE_SOURCE_X_RANGE",
            "outside_bins": outside,
            "source_x_range": [xmin, xmax],
            "smallest_extra_freedom_if_blocked": "frozen source profile with wider x coverage or narrower frozen benchmark-bin roster",
        }
    return rows, None


def interpolate_linear(x_values: list[float], y_values: list[float], target: float) -> float:
    if target <= x_values[0]:
        return y_values[0]
    if target >= x_values[-1]:
        return y_values[-1]
    for index in range(len(x_values) - 1):
        left_x = x_values[index]
        right_x = x_values[index + 1]
        if left_x <= target <= right_x:
            weight = (target - left_x) / (right_x - left_x)
            return y_values[index] * (1.0 - weight) + y_values[index + 1] * weight
    raise ValueError("target outside interpolation range")


def write_csv_dicts(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key) for key in fieldnames})


def prediction_rows(delta_rows: list[dict]) -> list[dict]:
    rows = []
    for row in delta_rows:
        delta_value = row["delta_qct_l2"]
        x_value = row["x_i"]
        if delta_value is None:
            pred = None
            gobs = None
            status = "no_prediction_outside_range"
        else:
            pred = float(x_value + delta_value)
            gobs = float(10 ** pred)
            status = "qct_side_prediction_materialized"
        rows.append(
            {
                "benchmark_bin_id": row["benchmark_bin_id"],
                "x_i": x_value,
                "delta_qct_l2": delta_value,
                "log10_gobs_qct_pred": pred,
                "gobs_qct_pred_m_s2": gobs,
                "status": status,
            }
        )
    return rows


def load_observed(path: Path) -> list[dict]:
    rows = read_csv_rows(path)
    if not rows:
        raise ValueError("observed rows file has no data rows")
    required = {"x_i", "log10_gobs_observed", "sigma_log10_gobs"}
    missing = required - set(rows[0].keys())
    if missing:
        raise ValueError(f"observed rows missing columns: {sorted(missing)}")

    output_rows = []
    for index, row in enumerate(rows):
        sigma = float(row["sigma_log10_gobs"])
        if sigma <= 0:
            raise ValueError("sigma_log10_gobs must be positive")
        output_rows.append(
            {
                "benchmark_bin_id": row.get("benchmark_bin_id") or f"bin_{index:03d}",
                "x_i": float(row["x_i"]),
                "log10_gobs_observed": float(row["log10_gobs_observed"]),
                "sigma_log10_gobs": sigma,
            }
        )
    return output_rows


def comparison_stack(pred_rows: list[dict], observed_rows: list[dict]) -> tuple[list[dict], dict]:
    predictions_by_id = {row["benchmark_bin_id"]: row for row in pred_rows}
    rows = []
    chi2_sum = 0.0
    loglike = 0.0
    for obs in observed_rows:
        pred = predictions_by_id.get(obs["benchmark_bin_id"])
        if pred is None or pred["log10_gobs_qct_pred"] is None:
            raise ValueError(f"missing prediction for observed row {obs['benchmark_bin_id']}")
        if abs(float(obs["x_i"]) - float(pred["x_i"])) > 1e-10:
            raise ValueError(f"x_i mismatch for {obs['benchmark_bin_id']}")
        residual = float(obs["log10_gobs_observed"] - pred["log10_gobs_qct_pred"])
        sigma = float(obs["sigma_log10_gobs"])
        chi2 = (residual / sigma) ** 2
        chi2_sum += chi2
        loglike += -0.5 * (chi2 + math.log(2 * math.pi * sigma * sigma))
        rows.append(
            {
                "benchmark_bin_id": obs["benchmark_bin_id"],
                "x_i": obs["x_i"],
                "log10_gobs_observed": obs["log10_gobs_observed"],
                "sigma_log10_gobs": sigma,
                "log10_gobs_qct_pred": pred["log10_gobs_qct_pred"],
                "residual_log10": residual,
                "chi2": chi2,
            }
        )
    return rows, {
        "row_count": len(rows),
        "chi2_total": chi2_sum,
        "loglike_gaussian_diag": loglike,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-profile", required=True, type=Path)
    parser.add_argument("--m-inv-lock", required=True, type=Path)
    parser.add_argument("--x-bins", required=True, type=Path)
    parser.add_argument("--observed-rows", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--allow-toy", action="store_true")
    args = parser.parse_args()

    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    status = {
        "object": "G4_L0_FIRST_CROSSING_ENGINE_V1",
        "claim_boundary": "tooling bridge only unless author-frozen non-toy inputs and observed rows are supplied",
        "form_a_materialized": False,
        "prediction_rows_materialized": False,
        "comparison_stack_materialized": False,
        "cosmic_closure_claim": False,
    }

    try:
        profile = load_source_profile(args.source_profile)
        cfg, lock = load_m_inv_lock(args.m_inv_lock, allow_toy=args.allow_toy)
        x_bins = load_x_bins(args.x_bins)
        phi_values, delta_values = evaluate_delta(profile, cfg)
        delta_rows, blocker = monotone_projection(profile, delta_values, x_bins)

        radial_rows = []
        for index in range(len(profile.r_m)):
            radial_rows.append(
                {
                    "row_id": index,
                    "r_m": float(profile.r_m[index]),
                    "rho_b_kg_m3": float(profile.rho_b_kg_m3[index]),
                    "gbar_m_s2": float(profile.gbar_m_s2[index]),
                    "x_of_r": float(math.log10(profile.gbar_m_s2[index])),
                    "phi": float(phi_values[index]),
                    "delta_qct_l2_of_r": float(delta_values[index]),
                }
            )
        write_csv_dicts(
            output_dir / "RADIAL_DIAGNOSTIC_ROWS.csv",
            radial_rows,
            [
                "row_id",
                "r_m",
                "rho_b_kg_m3",
                "gbar_m_s2",
                "x_of_r",
                "phi",
                "delta_qct_l2_of_r",
            ],
        )

        if blocker is not None:
            status.update(blocker)
            status["status"] = "G4_NO_GO_AT_FORM_A_PROJECTION"
        else:
            write_csv_dicts(
                output_dir / "FORM_A_DELTA_TABLE.csv",
                delta_rows,
                [
                    "benchmark_bin_id",
                    "x_i",
                    "delta_qct_l2",
                    "status",
                    "source_governance",
                    "branch_rule",
                ],
            )
            pred_rows = prediction_rows(delta_rows)
            write_csv_dicts(
                output_dir / "QCT_L2_PREDICTION_ROWS.csv",
                pred_rows,
                [
                    "benchmark_bin_id",
                    "x_i",
                    "delta_qct_l2",
                    "log10_gobs_qct_pred",
                    "gobs_qct_pred_m_s2",
                    "status",
                ],
            )
            status.update(
                {
                    "status": "FORM_A_AND_QCT_PREDICTION_ROWS_MATERIALIZED",
                    "form_a_materialized": True,
                    "prediction_rows_materialized": True,
                    "row_count": len(pred_rows),
                    "source_profile_row_count": len(profile.r_m),
                    "m_inv_status": lock.get("status"),
                }
            )
            if args.observed_rows is not None:
                observed_rows = load_observed(args.observed_rows)
                comp_rows, likelihood = comparison_stack(pred_rows, observed_rows)
                write_csv_dicts(
                    output_dir / "COMPARISON_STACK.csv",
                    comp_rows,
                    [
                        "benchmark_bin_id",
                        "x_i",
                        "log10_gobs_observed",
                        "sigma_log10_gobs",
                        "log10_gobs_qct_pred",
                        "residual_log10",
                        "chi2",
                    ],
                )
                (output_dir / "LIKELIHOOD_SUMMARY.json").write_text(
                    json.dumps(likelihood, indent=2, sort_keys=True) + "\n",
                    encoding="utf-8",
                )
                status.update(
                    {
                        "status": "D3_FIRST_COMPARISON_STACK_MATERIALIZED",
                        "comparison_stack_materialized": True,
                        "likelihood_summary": likelihood,
                        "cosmic_closure_claim": False,
                        "closure_note": "This is a first comparison stack, not full H0/BAO/CMB closure.",
                    }
                )

        (output_dir / "G4_CROSSING_STATUS.json").write_text(
            json.dumps(status, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        print(json.dumps(status, indent=2, sort_keys=True))
    except Exception as exc:
        status.update(
            {
                "status": "G4_NO_GO_RUNTIME_BLOCKED",
                "no_go_reason": str(exc),
                "smallest_extra_freedom_if_blocked": "supply the missing/invalid frozen input without fit-derived reverse engineering",
            }
        )
        (output_dir / "G4_CROSSING_STATUS.json").write_text(
            json.dumps(status, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        print(json.dumps(status, indent=2, sort_keys=True))
        sys.exit(2)


if __name__ == "__main__":
    main()
