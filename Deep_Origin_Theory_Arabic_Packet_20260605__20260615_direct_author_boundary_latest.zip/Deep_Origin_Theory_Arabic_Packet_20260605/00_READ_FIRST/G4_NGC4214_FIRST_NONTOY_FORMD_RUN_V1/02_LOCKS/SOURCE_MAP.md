# Source Map

This packet-local object is derived from already frozen local materials only.

## Canonical packet-local inputs

1. `02_LOCKS/SOURCE_PROFILE_AUTHOR_FROZEN.csv`
2. `02_LOCKS/FROZEN_X_BINS_AUTHOR_FROZEN.txt`
3. `02_LOCKS/M_INV_LOCK_AUTHOR_FROZEN.json`
4. `02_LOCKS/OBSERVED_ROWS_AUTHOR_FROZEN.csv`

## Packet-local replay engine

5. `03_RUN/g4_l0_crossing_engine.py`

## Canonical packet-local outputs

6. `04_OUTPUTS/RADIAL_DIAGNOSTIC_ROWS.csv`
7. `04_OUTPUTS/FORM_A_DELTA_TABLE.csv`
8. `04_OUTPUTS/QCT_L2_PREDICTION_ROWS.csv`
9. `04_OUTPUTS/COMPARISON_STACK.csv`
10. `04_OUTPUTS/LIKELIHOOD_SUMMARY.json`
11. `04_OUTPUTS/G4_CROSSING_STATUS.json`
12. `04_OUTPUTS/G4_CROSSING_ADJUDICATION.json`

## Original local provenance anchors

These are provenance anchors only. They are not required for the cold replay
once this reviewer object is bundled:

1. `artifacts/debt_board_20260530/G4_NGC4214_PRIMARY_CASE_SOURCE_AND_BIN_AUTHOR_FREEZE_NOTE_20260611.md`
2. `artifacts/debt_board_20260530/G4_NGC4214_PRIMARY_CASE_SOURCE_AND_BIN_AUTHOR_FREEZE_20260611.json`
3. `artifacts/debt_board_20260530/G4_D3_RETIREMENT_AND_D4_WAKE_RESULT_20260611.md`
4. `artifacts/debt_board_20260530/g4_external_intake/G4_L0_FIRST_CROSSING_ENGINE_V1/03_RUN/g4_l0_crossing_engine.py`
