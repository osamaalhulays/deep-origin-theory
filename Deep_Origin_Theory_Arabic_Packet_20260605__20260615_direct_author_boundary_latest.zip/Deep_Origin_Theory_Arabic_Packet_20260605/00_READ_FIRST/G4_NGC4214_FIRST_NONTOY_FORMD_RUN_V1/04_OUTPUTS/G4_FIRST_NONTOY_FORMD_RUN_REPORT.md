# G4 `NGC4214` First Non-Toy `Form D` Run Report

Date: `2026-06-12`

## Verdict

- frozen production input triple bundled = `true`
- frozen observed-row file bundled = `true`
- packet-local replay engine bundled = `true`
- first non-toy comparison stack bundled = `true`
- cold packet-local reproduction runner bundled = `true`

## Canonical emitted run state

- status = `D3_FIRST_COMPARISON_STACK_MATERIALIZED`
- `form_a_materialized = true`
- `prediction_rows_materialized = true`
- `comparison_stack_materialized = true`
- `row_count = 14`
- `chi2_total = 658.7148518641796`
- `loglike_gaussian_diag = -305.86832116819267`

## What this object now settles

- the packet no longer carries the `G4 retired / D3 retired / D4 awake`
  move as notes alone
- the non-toy `NGC4214` run itself is now packet-visible
- the bundled runner can replay the run from the bundled frozen inputs and
  check that the replay matches the canonical packet outputs

## What this object still does not claim

- no absolute-scale ascent
- no `H0`
- no `BAO/CMB`
- no cosmology completion
- no claim that the confrontation is favorable

This is one harsh first comparison stack only, preserved honestly.
