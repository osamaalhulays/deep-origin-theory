#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import json
import statistics
from pathlib import Path


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def build_report(summary: dict, ledger_rows: list[dict[str, object]]) -> str:
    lines = "\n".join(
        [
            f"- rank `{row['rank']}` / `{row['galaxy']}`: role `{row['topology_role']}`, rows `{row['observed_rows']}`, "
            f"`delta_min = {row['delta_min']}`, `nonpositive_row_count = {row['nonpositive_row_count']}`"
            for row in ledger_rows
        ]
    )
    return f"""# Author-Supplied `PAYLOAD_B` Clean-First Isolated Puncture Topology Report

Date: `2026-06-13`

## Short verdict

The current clean-first empirical topology is now frozen more honestly than
either a simple winning head or a collapsing tail.

It is:

- one contiguous all-positive head through rank `{summary["contiguous_all_positive_head_rank"]}`
- one isolated puncture at rank `{summary["first_break_rank"]}` on `{summary["first_break_galaxy"]}`
- and one positive tail that still survives after that puncture

## Exact present shape

- clean-first total galaxy count: `{summary["clean_first_total_galaxy_count"]}`
- clean-first total row count: `{summary["clean_first_total_row_count"]}`
- all-positive clean-first galaxy count: `{summary["all_positive_clean_first_galaxy_count"]}`
- all-positive clean-first row count: `{summary["all_positive_clean_first_row_count"]}`
- contiguous all-positive head rank: `{summary["contiguous_all_positive_head_rank"]}`
- contiguous all-positive head row count: `{summary["contiguous_all_positive_head_row_count"]}`
- first break rank: `{summary["first_break_rank"]}`
- first break galaxy: `{summary["first_break_galaxy"]}`
- first break nonpositive row count: `{summary["first_break_nonpositive_row_count"]}`
- first break first nonpositive row index: `{summary["first_break_first_nonpositive_row_index"]}`
- first break first nonpositive radius: `{summary["first_break_first_nonpositive_radius_kpc"]}` kpc
- puncture is one-row only: `{str(summary["puncture_is_single_row_only"]).lower()}`
- puncture sits on the `gbar` peak row: `{str(summary["puncture_is_innermost_peak_row"]).lower()}`
- positive tail after the puncture: `{summary["post_puncture_positive_tail_galaxy_count"]}` galaxies / `{summary["post_puncture_positive_tail_row_count"]}` rows

## Topology ledger

{lines}

## Exact current ceiling

This object gives one bounded empirical topology only.

It does not yet give:

- one theory-side authoring move
- one `QCT` prediction family
- one matched-nuisance execution
- one physical explanation for the puncture
"""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rowwise-csv", required=True)
    parser.add_argument("--shortlist-csv", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    rowwise_rows = load_csv(Path(args.rowwise_csv).resolve())
    shortlist_rows = load_csv(Path(args.shortlist_csv).resolve())
    shortlist_rows.sort(key=lambda row: int(row["rank"]))
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    ledger_rows: list[dict[str, object]] = []
    first_break_rank: int | None = None
    first_break_galaxy: str | None = None
    first_break_case_rows: list[dict[str, str]] | None = None
    first_break_peak_index: int | None = None
    first_break_nonpositive_indices: list[int] = []

    total_row_count = 0
    all_positive_galaxy_count = 0
    all_positive_row_count = 0
    head_row_count = 0
    positive_tail_row_count = 0
    positive_tail_galaxies: list[str] = []

    for shortlist in shortlist_rows:
        rank = int(shortlist["rank"])
        galaxy = shortlist["galaxy"]
        case_rows = [row for row in rowwise_rows if row["galaxy"] == galaxy]
        if not case_rows:
            raise ValueError(f"{galaxy}: missing rowwise case rows")

        deltas = [float(row["delta_log10_gobs_minus_gbar"]) for row in case_rows]
        gbar = [float(row["gbar_m_s2"]) for row in case_rows]
        radii = [float(row["r_kpc_observed"]) for row in case_rows]
        nonpositive_indices = [index for index, delta in enumerate(deltas) if delta <= 0.0]
        peak_index = max(range(len(gbar)), key=gbar.__getitem__)
        all_delta_positive = not nonpositive_indices

        if all_delta_positive:
            all_positive_galaxy_count += 1
            all_positive_row_count += len(case_rows)

        if first_break_rank is None and not all_delta_positive:
            first_break_rank = rank
            first_break_galaxy = galaxy
            first_break_case_rows = case_rows
            first_break_peak_index = peak_index
            first_break_nonpositive_indices = nonpositive_indices

        topology_role = (
            "pre_break_contiguous_all_positive_head"
            if first_break_rank is None
            else "first_isolated_puncture"
            if rank == first_break_rank
            else "post_puncture_positive_tail"
            if all_delta_positive
            else "post_puncture_nonpositive_tail"
        )

        row_count = len(case_rows)
        total_row_count += row_count
        if topology_role == "pre_break_contiguous_all_positive_head":
            head_row_count += row_count
        if topology_role == "post_puncture_positive_tail":
            positive_tail_row_count += row_count
            positive_tail_galaxies.append(galaxy)

        ledger_rows.append(
            {
                "rank": rank,
                "galaxy": galaxy,
                "topology_role": topology_role,
                "observed_rows": row_count,
                "all_delta_positive": all_delta_positive,
                "nonpositive_row_count": len(nonpositive_indices),
                "first_nonpositive_row_index": (
                    nonpositive_indices[0] if nonpositive_indices else ""
                ),
                "first_nonpositive_radius_kpc": (
                    radii[nonpositive_indices[0]] if nonpositive_indices else ""
                ),
                "delta_min": min(deltas),
                "delta_median": statistics.median(deltas),
                "gbar_peak_row_index": peak_index,
                "gbar_peak_radius_kpc": radii[peak_index],
                "gbar_nonincreasing_after_peak": all(
                    gbar[i + 1] <= gbar[i] for i in range(peak_index, len(gbar) - 1)
                ),
            }
        )

    if first_break_rank is None or first_break_galaxy is None or first_break_case_rows is None:
        raise ValueError("expected one first break inside the clean-first shortlist")

    isolated_puncture_count = sum(
        row["topology_role"] == "first_isolated_puncture" for row in ledger_rows
    )
    head_galaxy_count = sum(
        row["topology_role"] == "pre_break_contiguous_all_positive_head" for row in ledger_rows
    )
    positive_tail_galaxy_count = len(positive_tail_galaxies)
    first_nonpositive_index = first_break_nonpositive_indices[0]
    puncture_key_rows: list[dict[str, object]] = []

    recovery_index = next(
        (
            index
            for index, row in enumerate(first_break_case_rows)
            if float(row["delta_log10_gobs_minus_gbar"]) > 0.0 and index > first_nonpositive_index
        ),
        None,
    )
    for role, index in [
        ("first_nonpositive_row", first_nonpositive_index),
        ("first_positive_recovery_row", recovery_index if recovery_index is not None else first_nonpositive_index),
        ("last_row", len(first_break_case_rows) - 1),
    ]:
        row = first_break_case_rows[index]
        puncture_key_rows.append(
            {
                "key_role": role,
                "galaxy": first_break_galaxy,
                "observed_row_index": row["observed_row_index"],
                "r_kpc_observed": row["r_kpc_observed"],
                "log10_gbar_m_s2": row["log10_gbar_m_s2"],
                "log10_gobs_m_s2": row["log10_gobs_m_s2"],
                "delta_log10_gobs_minus_gbar": row["delta_log10_gobs_minus_gbar"],
                "interpolation_mode": row["interpolation_mode"],
            }
        )

    summary = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_CLEAN_FIRST_ISOLATED_PUNCTURE_TOPOLOGY_SUMMARY_20260613",
        "comparison_scope": "empirical_gobs_gbar_only",
        "clean_first_total_galaxy_count": len(shortlist_rows),
        "clean_first_total_row_count": total_row_count,
        "all_positive_clean_first_galaxy_count": all_positive_galaxy_count,
        "all_positive_clean_first_row_count": all_positive_row_count,
        "contiguous_all_positive_head_rank": first_break_rank - 1,
        "contiguous_all_positive_head_galaxy_count": head_galaxy_count,
        "contiguous_all_positive_head_row_count": head_row_count,
        "first_break_rank": first_break_rank,
        "first_break_galaxy": first_break_galaxy,
        "first_break_nonpositive_row_count": len(first_break_nonpositive_indices),
        "first_break_first_nonpositive_row_index": first_nonpositive_index,
        "first_break_first_nonpositive_radius_kpc": float(
            first_break_case_rows[first_nonpositive_index]["r_kpc_observed"]
        ),
        "isolated_puncture_galaxy_count": isolated_puncture_count,
        "isolated_puncture_total_nonpositive_rows": len(first_break_nonpositive_indices),
        "puncture_is_single_row_only": len(first_break_nonpositive_indices) == 1,
        "puncture_is_innermost_peak_row": first_break_peak_index == first_nonpositive_index,
        "post_puncture_positive_tail_galaxy_count": positive_tail_galaxy_count,
        "post_puncture_positive_tail_row_count": positive_tail_row_count,
        "post_puncture_positive_tail_galaxies": positive_tail_galaxies,
        "topology_class": (
            "front7_contiguous_all_positive_head__single_rank8_lvhis055_puncture__positive_tail_persists"
        ),
        "theory_side_authoring_eligible": False,
        "verdict": (
            "AUTHOR_SUPPLIED_PAYLOAD_B_CLEAN_FIRST_TOPOLOGY_MATERIALIZED__THE_CURRENT_CLEAN_FIRST_FIELD_IS_ONE_FRONT7_HEAD_PLUS_ONE_LVHIS055_PUNCTURE_PLUS_ONE_POSITIVE_TAIL"
        ),
    }

    write_csv(
        output_dir / "CLEAN_FIRST_TOPOLOGY_LEDGER.csv",
        [
            "rank",
            "galaxy",
            "topology_role",
            "observed_rows",
            "all_delta_positive",
            "nonpositive_row_count",
            "first_nonpositive_row_index",
            "first_nonpositive_radius_kpc",
            "delta_min",
            "delta_median",
            "gbar_peak_row_index",
            "gbar_peak_radius_kpc",
            "gbar_nonincreasing_after_peak",
        ],
        ledger_rows,
    )
    write_csv(
        output_dir / "LVHIS055_PUNCTURE_KEY_ROWS.csv",
        [
            "key_role",
            "galaxy",
            "observed_row_index",
            "r_kpc_observed",
            "log10_gbar_m_s2",
            "log10_gobs_m_s2",
            "delta_log10_gobs_minus_gbar",
            "interpolation_mode",
        ],
        puncture_key_rows,
    )
    (output_dir / "TOPOLOGY_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (output_dir / "TOPOLOGY_REPORT.md").write_text(
        build_report(summary, ledger_rows),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
