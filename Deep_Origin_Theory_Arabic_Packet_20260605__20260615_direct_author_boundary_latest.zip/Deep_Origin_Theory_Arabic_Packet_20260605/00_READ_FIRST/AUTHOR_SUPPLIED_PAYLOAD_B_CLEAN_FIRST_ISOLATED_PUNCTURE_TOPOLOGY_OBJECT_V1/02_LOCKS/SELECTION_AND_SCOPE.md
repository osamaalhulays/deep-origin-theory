# Selection And Scope

Date: `2026-06-13`

This object is not selecting `LVHIS055` rhetorically.

It is selecting the exact current topology implied by the already frozen
clean-first shortlist and rowwise empirical comparison table.

## Exact selection rule

1. keep the clean-first shortlist ordered exactly by the packet-local rule
   `rows_desc_then_gbar_span_desc_then_name`
2. mark which shortlisted galaxies keep all rowwise
   `log10(gobs) - log10(gbar) > 0`
3. find the first ordered break
4. classify what remains after that break

## Present bounded reading

The present reading is only about topology inside the clean-first shortlist:

- contiguous positive head
- first puncture
- positive or nonpositive continuation after that puncture

It does **not** promote the topology into:

- one theory-side source rule
- one `QCT` prediction family
- one fairness-grade differential claim
- one physical explanation theorem
