# Author-Supplied `PAYLOAD_B` Clean-First Isolated Puncture Topology Report

Date: `2026-06-13`

## Short verdict

The current clean-first empirical topology is now frozen more honestly than
either a simple winning head or a collapsing tail.

It is:

- one contiguous all-positive head through rank `7`
- one isolated puncture at rank `8` on `LVHIS055`
- and one positive tail that still survives after that puncture

## Exact present shape

- clean-first total galaxy count: `11`
- clean-first total row count: `184`
- all-positive clean-first galaxy count: `10`
- all-positive clean-first row count: `177`
- contiguous all-positive head rank: `7`
- contiguous all-positive head row count: `159`
- first break rank: `8`
- first break galaxy: `LVHIS055`
- first break nonpositive row count: `1`
- first break first nonpositive row index: `0`
- first break first nonpositive radius: `0.29` kpc
- puncture is one-row only: `true`
- puncture sits on the `gbar` peak row: `true`
- positive tail after the puncture: `3` galaxies / `18` rows

## Topology ledger

- rank `1` / `NGC1313`: role `pre_break_contiguous_all_positive_head`, rows `40`, `delta_min = 0.19955408170893918`, `nonpositive_row_count = 0`
- rank `2` / `NGC2541`: role `pre_break_contiguous_all_positive_head`, rows `31`, `delta_min = 0.207124258777581`, `nonpositive_row_count = 0`
- rank `3` / `NGC7793`: role `pre_break_contiguous_all_positive_head`, rows `29`, `delta_min = 0.21689352579817012`, `nonpositive_row_count = 0`
- rank `4` / `NGC3992`: role `pre_break_contiguous_all_positive_head`, rows `20`, `delta_min = 0.16450494754325362`, `nonpositive_row_count = 0`
- rank `5` / `LVHIS077`: role `pre_break_contiguous_all_positive_head`, rows `15`, `delta_min = 0.3588836196376004`, `nonpositive_row_count = 0`
- rank `6` / `LVHIS072`: role `pre_break_contiguous_all_positive_head`, rows `12`, `delta_min = 0.21278765723040038`, `nonpositive_row_count = 0`
- rank `7` / `LVHIS011`: role `pre_break_contiguous_all_positive_head`, rows `12`, `delta_min = 0.41271075539437163`, `nonpositive_row_count = 0`
- rank `8` / `LVHIS055`: role `first_isolated_puncture`, rows `7`, `delta_min = -9.191637233385563e-05`, `nonpositive_row_count = 1`
- rank `9` / `LVHIS026`: role `post_puncture_positive_tail`, rows `7`, `delta_min = 0.6496663058192684`, `nonpositive_row_count = 0`
- rank `10` / `LVHIS017`: role `post_puncture_positive_tail`, rows `6`, `delta_min = 0.7384232683893472`, `nonpositive_row_count = 0`
- rank `11` / `LVHIS019`: role `post_puncture_positive_tail`, rows `5`, `delta_min = 0.5218931505765347`, `nonpositive_row_count = 0`

## Exact current ceiling

This object gives one bounded empirical topology only.

It does not yet give:

- one theory-side authoring move
- one `QCT` prediction family
- one matched-nuisance execution
- one physical explanation for the puncture
