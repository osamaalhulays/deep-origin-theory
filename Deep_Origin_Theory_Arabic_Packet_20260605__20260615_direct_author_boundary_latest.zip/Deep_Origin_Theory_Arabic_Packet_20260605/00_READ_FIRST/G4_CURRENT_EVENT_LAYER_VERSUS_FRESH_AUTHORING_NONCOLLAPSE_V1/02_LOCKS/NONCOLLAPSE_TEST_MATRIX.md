# Noncollapse Test Matrix

1. current event-layer exhaustion object is materialized.
2. fresh-event intake gate is materialized.
3. `L2` authoring gate still reads:
   `reopen_allowed_if = one_lawful_Form_A_B_C_or_D_package_materialized`.
4. `Form A` first-strike object still reads:
   `Form A` is the preferred first lawful strike.

## Pass condition

- all four checks pass.

## Failure meaning

- current event-layer exhaustion and upstream fresh authoring are no longer
  cleanly distinguishable by the present record.
