# Evidence Map

1. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EVENT_LAYER_INTAKE_GATED_EXHAUSTION_AND_WATCH_ONLY_STATE_V1/04_OUTPUTS/CURRENT_ROUTE_EVENT_LAYER_INTAKE_GATED_EXHAUSTION_AND_WATCH_ONLY_STATE_REPORT.md`
   - fixes the current local event layer as exhausted under present materials
2. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_FRESH_EVENT_REOPENER_INTAKE_GATE_V1/04_OUTPUTS/FRESH_EVENT_REOPENER_INTAKE_GATE_REPORT.md`
   - fixes current local replay as rejected and upper-event intake as fail-fast
3. `artifacts/debt_board_20260530/L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/01_BACKBONE/MANUSCRIPT.md`
   - keeps fresh upstream restart open via `Form A/B/C/D`
4. `artifacts/debt_board_20260530/L2_FORM_A_DELTA_TABLE_FIRST_STRIKE_V1/01_BACKBONE/MANUSCRIPT.md`
   - keeps `Form A` as the smallest preferred fresh strike
