from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[4]
OBJECT_ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = OBJECT_ROOT / "04_OUTPUTS"
OUTPUTS.mkdir(parents=True, exist_ok=True)


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


event_layer_report = read_text(
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EVENT_LAYER_INTAKE_GATED_EXHAUSTION_AND_WATCH_ONLY_STATE_V1/04_OUTPUTS/CURRENT_ROUTE_EVENT_LAYER_INTAKE_GATED_EXHAUSTION_AND_WATCH_ONLY_STATE_REPORT.md"
)
fresh_intake_report = read_text(
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_FRESH_EVENT_REOPENER_INTAKE_GATE_V1/04_OUTPUTS/FRESH_EVENT_REOPENER_INTAKE_GATE_REPORT.md"
)
authoring_gate = read_text(
    ROOT
    / "artifacts/debt_board_20260530/L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/01_BACKBONE/MANUSCRIPT.md"
)
form_a_first_strike = read_text(
    ROOT
    / "artifacts/debt_board_20260530/L2_FORM_A_DELTA_TABLE_FIRST_STRIKE_V1/01_BACKBONE/MANUSCRIPT.md"
)

checks = [
    {
        "name": "current_event_layer_exhausted",
        "passed": "current local repo-visible event layer is now exhausted under present materials" in event_layer_report,
    },
    {
        "name": "fresh_event_intake_gate_materialized",
        "passed": "Verdict: `POST_CAGE_BRANCH_U1_FRESH_EVENT_REOPENER_INTAKE_GATE_MATERIALIZED`" in fresh_intake_report
        and "current route intake result: `reject_local_replay`" in fresh_intake_report,
    },
    {
        "name": "upstream_authoring_restart_still_open",
        "passed": "`reopen_allowed_if = one_lawful_Form_A_B_C_or_D_package_materialized`" in authoring_gate,
    },
    {
        "name": "form_a_still_smallest_preferred_strike",
        "passed": "the strongest first lawful strike is `Form A`" in form_a_first_strike,
    },
]

materialized = all(item["passed"] for item in checks)
generated_at = datetime.now(timezone.utc).isoformat()

verdict = {
    "object": "G4_CURRENT_EVENT_LAYER_VERSUS_FRESH_AUTHORING_NONCOLLAPSE_V1",
    "generated_at": generated_at,
    "materialized": materialized,
    "relation": (
        "current_event_layer_exhausted_but_upstream_fresh_authoring_still_open"
        if materialized
        else "relation_unstable"
    ),
}

status_summary = {
    "verdict": (
        "G4_CURRENT_EVENT_LAYER_VERSUS_FRESH_AUTHORING_NONCOLLAPSE_MATERIALIZED"
        if materialized
        else "G4_CURRENT_EVENT_LAYER_VERSUS_FRESH_AUTHORING_NONCOLLAPSE_NOT_MATERIALIZED"
    ),
    "relation": verdict["relation"],
}

report_lines = [
    "# G4 Current Event Layer Versus Fresh Authoring Noncollapse Report",
    "",
    f"Generated at: `{generated_at}`",
    "",
    f"Verdict: `{status_summary['verdict']}`",
    "",
    "## Summary",
    "",
]
report_lines.extend([f"- {item['name']}: `{item['passed']}`" for item in checks])
report_lines.extend(
    [
        "",
        "## Reading",
        "",
        "- the current local event layer is exhausted under present materials,",
        "- but the upstream L2 fresh-authoring gate still lawfully reopens on one fresh Form A/B/C/D package,",
        "- with Form A still remaining the smallest preferred fresh strike.",
        "",
        "## Bottom line",
        "",
        "- current event-layer exhaustion and upstream fresh authoring remain distinct and must not be collapsed.",
    ]
)

(OUTPUTS / "checks.json").write_text(json.dumps(checks, indent=2), encoding="utf-8")
(OUTPUTS / "verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")
(OUTPUTS / "status_summary.json").write_text(json.dumps(status_summary, indent=2), encoding="utf-8")
(OUTPUTS / "G4_CURRENT_EVENT_LAYER_VERSUS_FRESH_AUTHORING_NONCOLLAPSE_REPORT.md").write_text(
    "\n".join(report_lines) + "\n",
    encoding="utf-8",
)
