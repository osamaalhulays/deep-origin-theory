# Current `G6` / `D7` `PAYLOAD_B` 49-Galaxy `gbar` Diagnostic Lane Note

Date: `2026-06-13`

Purpose:

Freeze the exact current reading after the five local downstream normalization
choices have now been materialized for one bounded lane above the author-supplied
`PAYLOAD_B` family.

## Short verdict

The fair current reading is:

- the `49` landed galaxies are no longer only receipt-grade
- they are now one explicit `gbar`-only diagnostic lane at observed radii
  with public summary and galaxy-ledger surfaces
- the five local normalization choices are now frozen for that lane
- `rho_b(r)` authoring is still not claimed
- theory-side promotion is still not claimed

## The five now-frozen local choices

1. duplicate rounded radii:
   signed-power mean compression inside each same-radius block
2. negative gas rows:
   sign-preserving square for `VHI` and `VH2`
3. optional `nan` stellar / bulge sentinel rows:
   zero-fill only when the associated uncertainties are zero
4. component-curve to source-density boundary:
   no `rho_b(r)` authoring;
   current lane emits `gbar` only
5. theory-side promotion boundary:
   no direct promotion into `G4` / `Form A/B/C/D`

## Exact visible gain

This now gives one real current gain:

- `49` matched galaxies
- `1082` observed rows
- one reproducible bounded diagnostic family whose public packet exposure now
  stays at summary and galaxy-ledger grade
- one later explicit rowwise comparison-admissibility layer above the same
  normalized family

## Exact current ceiling

This still does **not** give:

- one lawful `rho_b(r)` source profile pack
- one theory-side authoring object
- one `G4` crossing
- one theory-side comparator claim

## Read with

- `CURRENT_G6_D7_PAYLOAD_B_DOWNSTREAM_USE_BOUNDARY_NOTE_20260612.md`
- `CURRENT_DIRECT_AUTHOR_PUBLIC_DERIVATIVE_BOUNDARY_NOTE_20260615.md`
- `CURRENT_D7_L2_PAYLOAD_B_ADMIT_BOUNDED_VERDICT_NOTE_20260612.md`
- `AUTHOR_SUPPLIED_PAYLOAD_B_RECEIPT_AUDIT_OBJECT_V1`
- `AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_GBAR_DIAGNOSTIC_NORMALIZATION_OBJECT_V1`
- `CURRENT_G6_D7_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_NOTE_20260613.md`
- `AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_OBJECT_V1`
