#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from zipfile import ZipFile


CASE_ID = "NGC3992"
THIS_OBJECT = "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_M4_LAWFUL_EFE_ADMISSION_AUDIT_OBJECT_V1"
BOARD_ROOT = Path(__file__).resolve().parents[2]
OBJECT_ROOT = Path(__file__).resolve().parents[1]
GRADE1_VERDICT = (
    BOARD_ROOT
    / "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_RUNTIME_LOCKED_FIRST_STRONGER_COURT_GRADE1_OBJECT_V1"
    / "04_OUTPUTS"
    / "VERDICT.json"
)
M2_VERDICT = (
    BOARD_ROOT
    / "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_M2_INTERPOLATION_FAMILY_LANE_OBJECT_V1"
    / "04_OUTPUTS"
    / "VERDICT.json"
)
M3_SUMMARY = (
    BOARD_ROOT
    / "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_M3_GLOBAL_A0_LANE_OBJECT_V1"
    / "04_OUTPUTS"
    / "NGC3992_M3_GLOBAL_A0_DIFFERENTIAL_SUMMARY.json"
)
GRADE_LADDER = (
    BOARD_ROOT
    / "MOND_QUMOND_FAMILY_COURT_V1"
    / "02_PROTOCOL"
    / "COURT_VERDICT_GRADE_LADDER.md"
)

TEXT_SUFFIXES = {".md", ".json", ".py", ".txt", ".csv"}
EFE_PATTERNS = [
    re.compile(r"\befe\b"),
    re.compile(r"external[ _-]?field"),
    re.compile(r"\bg[ _-]?ext\b"),
    re.compile(r"\baext\b"),
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--observed-zip", type=Path, required=True)
    parser.add_argument("--baryons-zip", type=Path, required=True)
    parser.add_argument("--court-protocol", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def find_case_member(zip_path: Path, suffix: str) -> str:
    with ZipFile(zip_path) as archive:
        matches = sorted(
            name for name in archive.namelist() if name.startswith(f"{CASE_ID}_") and name.endswith(suffix)
        )
        if len(matches) != 1:
            raise RuntimeError(f"expected exactly one {suffix} member for {CASE_ID}, found {matches}")
        return matches[0]


def read_header(zip_path: Path, member: str) -> str:
    with ZipFile(zip_path) as archive:
        with archive.open(member) as handle:
            first_line = handle.readline().decode("utf-8").strip()
    return first_line


def header_has_external_field_channel(header: str) -> bool:
    lowered = header.lower()
    return any(pattern.search(lowered) for pattern in EFE_PATTERNS)


def scan_case_owned_m4_materials() -> dict:
    candidate_paths = []
    runner_paths = []
    prior_paths = []
    output_paths = []
    content_hits = []

    for path in BOARD_ROOT.rglob("*"):
        if (
            str(path).startswith(str(OBJECT_ROOT))
            or THIS_OBJECT in str(path)
            or "M4_LAWFUL_EFE_ADMISSION_AUDIT" in str(path)
        ):
            continue
        name_lower = path.name.lower()
        full_lower = str(path).lower()
        if CASE_ID.lower() not in full_lower:
            continue
        if path.is_dir() and path.name.startswith(f"AUTHOR_SUPPLIED_PAYLOAD_B_{CASE_ID}_") and "m4" in name_lower:
            candidate_paths.append(str(path))
        if path.suffix == ".py" and any(token in name_lower for token in ("efe", "m4")):
            runner_paths.append(str(path))
        if path.suffix in {".json", ".md"} and "prior" in name_lower and any(
            token in name_lower for token in ("efe", "m4")
        ):
            prior_paths.append(str(path))
        if "04_outputs" in full_lower and any(token in name_lower for token in ("efe", "m4")):
            output_paths.append(str(path))

        if path.is_file() and path.suffix.lower() in TEXT_SUFFIXES:
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            lower_text = text.lower()
            if CASE_ID.lower() in lower_text and any(
                pattern.search(lower_text) for pattern in EFE_PATTERNS
            ):
                content_hits.append(str(path))

    return {
        "candidate_paths": sorted(candidate_paths),
        "runner_paths": sorted(runner_paths),
        "prior_paths": sorted(prior_paths),
        "output_paths": sorted(output_paths),
        "content_hits": sorted(content_hits),
    }


def build_report(summary: dict) -> str:
    observed_header = summary["observed_header"]
    baryons_header = summary["baryons_header"]
    inventory = summary["case_owned_inventory"]
    return f"""# Author-Supplied `NGC3992` `M4` Lawful `EFE` Admission Audit Report

## Short verdict

`M4` is **not** admitted on `NGC3992` under the current packet-visible materials.

Why:

- the protocol contains the conditional `M4` clause
- `Grade 2` is defined over **admitted lanes**
- `M1`, `M2`, and `M3` are already materially landed
- but no case-owned replayable `M4` lane is present
- no case-owned `EFE` prior basis is present
- and the delivered `NGC3992` payload headers expose no external-field channel

So the present admitted-lane court consequence is:

- `Grade 2` materializes by admitted-lane exhaustion on `NGC3992`

## Protocol anchors

- conditional `M4` clause present: `{summary["protocol_m4_condition_present"]}`
- `Grade 2` admitted-lane clause present: `{summary["protocol_grade2_admitted_lane_clause_present"]}`

## Payload header snapshot

- observed header: `{observed_header}`
- baryons header: `{baryons_header}`
- external-field header channel present: `{summary["payload_external_field_column_present"]}`

## Case-owned material inventory

- `M4`-named candidate paths: `{len(inventory["candidate_paths"])}`
- `EFE/M4` runner paths: `{len(inventory["runner_paths"])}`
- `EFE/M4` prior-basis paths: `{len(inventory["prior_paths"])}`
- `EFE/M4` output paths: `{len(inventory["output_paths"])}`
- text content hits with both `NGC3992` and `EFE` vocabulary: `{len(inventory["content_hits"])}`

## Landing summary

- `Grade 1` landed: `{summary["grade1_materialized"]}`
- `M2` landed: `{summary["m2_execution_materialized"]}`
- `M3` landed: `{summary["m3_execution_materialized"]}`
- `M4` admitted now: `{summary["m4_admitted_under_current_packet_visible_materials"]}`
- `Grade 2` materialized by admitted-lane exhaustion: `{summary["grade2_materialized_by_admitted_lane_exhaustion"]}`
"""


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    protocol_text = args.court_protocol.read_text(encoding="utf-8").lower()
    grade_ladder_text = GRADE_LADDER.read_text(encoding="utf-8").lower()

    observed_member = find_case_member(args.observed_zip, "_vcirc.dat")
    baryons_member = find_case_member(args.baryons_zip, "_vbaryons.dat")
    observed_header = read_header(args.observed_zip, observed_member)
    baryons_header = read_header(args.baryons_zip, baryons_member)

    inventory = scan_case_owned_m4_materials()

    grade1_verdict = read_json(GRADE1_VERDICT)
    m2_verdict = read_json(M2_VERDICT)
    m3_summary = read_json(M3_SUMMARY)

    protocol_m4_condition_present = (
        "m4" in protocol_text
        and "only if its admission rule and prior basis are" in protocol_text
    )
    protocol_grade2_admitted_lane_clause_present = "admitted lanes" in grade_ladder_text
    payload_external_field_column_present = header_has_external_field_channel(
        observed_header
    ) or header_has_external_field_channel(baryons_header)

    case_owned_m4_object_present = len(inventory["candidate_paths"]) > 0
    case_owned_efe_runner_present = len(inventory["runner_paths"]) > 0
    case_owned_efe_prior_basis_present = len(inventory["prior_paths"]) > 0
    case_owned_efe_output_present = len(inventory["output_paths"]) > 0

    m4_admitted_under_current_packet_visible_materials = all(
        [
            protocol_m4_condition_present,
            case_owned_m4_object_present,
            case_owned_efe_runner_present,
            case_owned_efe_prior_basis_present,
            case_owned_efe_output_present,
            payload_external_field_column_present,
        ]
    )

    grade1_materialized = bool(grade1_verdict["grade1_materialized"])
    m2_execution_materialized = bool(m2_verdict["m2_execution_materialized"])
    m3_execution_materialized = bool(m3_summary["m3_execution_materialized"])

    grade2_materialized_by_admitted_lane_exhaustion = all(
        [
            protocol_grade2_admitted_lane_clause_present,
            grade1_materialized,
            m2_execution_materialized,
            m3_execution_materialized,
            not m4_admitted_under_current_packet_visible_materials,
        ]
    )

    summary = {
        "object_class": "M4_LAWFUL_EFE_ADMISSION_AUDIT",
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_M4_ADMISSION_AUDIT_SUMMARY_20260613",
        "date": "2026-06-13",
        "case_id": CASE_ID,
        "protocol_m4_condition_present": protocol_m4_condition_present,
        "protocol_grade2_admitted_lane_clause_present": protocol_grade2_admitted_lane_clause_present,
        "observed_member": observed_member,
        "baryons_member": baryons_member,
        "observed_header": observed_header,
        "baryons_header": baryons_header,
        "payload_external_field_column_present": payload_external_field_column_present,
        "case_owned_inventory": inventory,
        "case_owned_m4_object_present": case_owned_m4_object_present,
        "case_owned_efe_runner_present": case_owned_efe_runner_present,
        "case_owned_efe_prior_basis_present": case_owned_efe_prior_basis_present,
        "case_owned_efe_output_present": case_owned_efe_output_present,
        "grade1_materialized": grade1_materialized,
        "m2_execution_materialized": m2_execution_materialized,
        "m3_execution_materialized": m3_execution_materialized,
        "m4_admitted_under_current_packet_visible_materials": m4_admitted_under_current_packet_visible_materials,
        "grade2_materialized_by_admitted_lane_exhaustion": grade2_materialized_by_admitted_lane_exhaustion,
        "verdict": (
            "M4_NOT_ADMITTED_ON_NGC3992_UNDER_CURRENT_PACKET_VISIBLE_MATERIALS__GRADE2_MATERIALIZED_BY_ADMITTED_LANE_EXHAUSTION"
            if grade2_materialized_by_admitted_lane_exhaustion
            else "M4_AUDITED_BUT_GRADE2_NOT_MATERIALIZED_FROM_CURRENT_ADMITTED_LANE_READING"
        ),
        "cosmic_closure_claim": False,
    }

    (args.output_dir / "NGC3992_M4_ADMISSION_AUDIT_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (args.output_dir / "VERDICT.json").write_text(
        json.dumps(
            {
                "case_id": CASE_ID,
                "m4_admitted_under_current_packet_visible_materials": m4_admitted_under_current_packet_visible_materials,
                "grade2_materialized_by_admitted_lane_exhaustion": grade2_materialized_by_admitted_lane_exhaustion,
                "verdict": summary["verdict"],
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    (args.output_dir / "NGC3992_M4_ADMISSION_AUDIT_REPORT.md").write_text(
        build_report(summary),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
