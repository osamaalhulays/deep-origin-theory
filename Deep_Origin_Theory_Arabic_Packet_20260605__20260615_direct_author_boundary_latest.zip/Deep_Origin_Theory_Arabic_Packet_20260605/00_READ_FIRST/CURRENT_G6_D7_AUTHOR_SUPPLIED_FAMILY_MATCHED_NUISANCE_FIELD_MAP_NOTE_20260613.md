# Current `G6/D7` author-supplied Family Matched-Nuisance Field Map Note

Date: `2026-06-13`

Purpose:

State the exact current packet reading after the old stored historical
`artifact_emulator` family field map was rerun under one explicit runtime
lock and replaced by the runtime-locked result.

## Short verdict

The governing field is now the runtime-locked one, not the stale inherited
one.

Across the landed `49`-galaxy family under the explicit runtime lock:

- `7` cases favor the bounded historical `QCT` lane
- `42` cases favor `QUMOND`
- `4` are decisive for `QCT`
- `37` are decisive for `QUMOND`

So the packet still does **not** support one honest family-wide
`QCT > QUMOND` sentence here.

But it now supports one sharper and cleaner packet-side positive localization:

- the clean-front positive triad is `NGC3992`, `LVHIS077`, and `LVHIS072`
- the first clean-front truthful spear is `NGC3992`
- and that same triad is now already fully landed as three runtime-locked
  `Grade 2` stronger-court consumers

That still does **not** authorize one broad family-wide victory sentence.

It authorizes something narrower:

- keep `NGC3992` as the first landed `Grade 2` spear
- keep `LVHIS077` as the second landed `Grade 2` spear
- keep `LVHIS072` as the third landed `Grade 2` spear
- read that same three-spear set together as one already-landed bounded
  triad-level family-court verdict
- and reopen any extra-shape-freedom / `Grade 3` route only if still needed
  above that landed verdict

## Clean-first translation

The clean-first head does not translate into broad superiority.

Among the current top-`11` clean-first cases under the runtime-locked map:

- `3` cases favor `QCT`
- they are `NGC3992`, `LVHIS077`, and `LVHIS072`
- `NGC1313` is negative for the bounded historical `QCT` lane
- `NGC2541` is decisively negative after runtime-locked replay
- `NGC7793` is also negative

So the clean-first field is no longer one blind serial route.

It is one structured map with:

- one clean-front positive triad
- several near-tie pockets
- and multiple real losses

## Why `NGC3992` now matters

`NGC3992` is now the first truthful clean-front spear because:

- `NGC3992` is already rank `4` in the clean-first head
- all its current empirical rows remain `gobs > gbar`
- both best nuisance scales are interior rather than ceiling-hit
- the matched-nuisance differential is strongly positive for the bounded
  historical `QCT` lane

That is why the packet could lawfully consume it first as one focused positive
case-owned consumer under the same bounded historical lane.

That consumer is now no longer hypothetical:

- one runtime-locked `Grade 2` spear has now been landed on `NGC3992`
- and the sister consumers `LVHIS077` and `LVHIS072` are now also landed
  through the same stronger court

## Boundary caution

This runtime-locked field map also still shows where the current nuisance
window is ceiling-sensitive:

- `QCT` hits the upper scan ceiling in `8` cases
- `QUMOND` hits the upper scan ceiling in `2` cases
- `QUMOND` hits the lower scan floor in `12` cases

That caution is real, but it does **not** undermine the `NGC3992` spear,
because `NGC3992` is not a boundary-hit case.

## What this note does not claim

This note does **not** claim:

- one family-wide public `QCT > QUMOND` victory
- theory-side promotion of the bounded historical lane
- `G4` / `Form A/B/C/D` closure
- or cosmology completion

It claims something narrower:

- the current packet now has one explicit runtime-locked mixed differential
  map,
- one stale inherited positive spear has been retired honestly,
- and one new clean-front positive triad is now localized with `NGC3992`
  first among it and all three members already landed through `Grade 2`
- while `AIC/BIC` remain receipts only and shape-space no-rescue is the
  sovereignty criterion for any stronger later family verdict

## Read with

- `CURRENT_G6_D7_PAYLOAD_B_CURRENT_LOCAL_PACKET_EXHAUSTION_AND_WATCH_ONLY_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_NGC1313_FIRST_MATCHED_NUISANCE_DIFFERENTIAL_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_HISTORICAL_ARTIFACT_EMULATOR_RUNTIME_REPRO_AUDIT_AND_FIELD_RESET_NOTE_20260613.md`
- `AUTHOR_SUPPLIED_PAYLOAD_B_FAMILY_QCT_VS_QUMOND_MATCHED_NUISANCE_SCAN_RUNTIME_LOCKED_OBJECT_V1`
- `CURRENT_NGC3992_GRADE2_MOND_QUMOND_COURT_SPEAR_CARD_NOTE_20260613.md`
- `CURRENT_LVHIS077_GRADE2_MOND_QUMOND_COURT_SPEAR_CARD_NOTE_20260613.md`
- `CURRENT_LVHIS072_GRADE2_MOND_QUMOND_COURT_SPEAR_CARD_NOTE_20260613.md`
- `CURRENT_MOND_QUMOND_CLEAN_FRONT_POSITIVE_TRIAD_BOUNDED_FAMILY_COURT_VERDICT_NOTE_20260614.md`
- `CURRENT_MOND_QUMOND_POST_NGC3992_GRADE2_STRATEGIC_ROUTE_NOTE_20260613.md`
