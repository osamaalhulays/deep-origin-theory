# Current `G4` `NGC4214` Primary-Case Author Freeze Note

Date: `2026-06-11`

## Short verdict

`NGC4214` is now the first selected local production case on the live
`G4` route.

Its source profile and case-native benchmark-bin roster are now
author-frozen locally.

This is an execution-priority choice.

It is **not** promoted here into one formal scientific superiority claim over
`NGC1705`.

## What this changes

The local `G4` blocker is now narrower.

It is no longer:

- choose between the two monotone-ready pairs,
- then freeze source and bins,
- then freeze `m_inv`.

It is now:

- freeze production `m_inv`,
- then run the admitted non-toy `Form D` engine once on the frozen
  `NGC4214` pair.

## Reserve status

`NGC1705` remains one monotone-ready reserve case.

## Bottom line

`G4` is still open.

But the local production-input wound is now down to the production `m_inv`
tooth above one already-frozen source/bin pair.
