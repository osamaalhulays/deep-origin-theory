# Author-Supplied `PAYLOAD_B` Clean-First Reserve Structure Report

Date: `2026-06-13`

## Short verdict

The first focused empirical case is no longer one standalone named case.

It now sits on one reviewer-visible clean-first reserve inside the landed
author-supplied `PAYLOAD_B` family.

## Exact present shape

- clean-first reserve galaxy count: `11`
- clean-first reserve observed-row count: `184`
- top-3 reserve galaxy count: `3`
- top-3 reserve observed-row count: `100`
- first focused case: `NGC1313`
- all reserve galaxies remain comparison-ready: `true`
- all reserve galaxies keep zero duplicate-radius blocks: `true`
- all reserve galaxies keep zero negative `VH2` rows: `true`
- all reserve galaxies keep zero zero-fill sentinels: `true`
- theory-side authoring eligible reserve galaxies: `0`

## Top-3 reserve

- rank 1: `NGC1313` with `40` rows and `gbar` span `0.9572509353175267` dex
- rank 2: `NGC2541` with `31` rows and `gbar` span `0.9672575574046256` dex
- rank 3: `NGC7793` with `29` rows and `gbar` span `0.6702950071501252` dex

## Exact current ceiling

This object gives one reserve structure only.

It does not yet give:

- one theory-side promotion
- one `QCT` prediction family
- one matched-nuisance fairness comparison
- one named competitor verdict
