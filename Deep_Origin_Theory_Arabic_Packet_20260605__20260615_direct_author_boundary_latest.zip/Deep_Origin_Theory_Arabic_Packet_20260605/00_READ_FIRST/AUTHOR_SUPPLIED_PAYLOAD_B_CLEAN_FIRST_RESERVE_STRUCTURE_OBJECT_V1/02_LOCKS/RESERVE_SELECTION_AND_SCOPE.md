# Reserve Selection And Scope

Date: `2026-06-13`

This object does not invent a new reserve by taste.

It reuses the already frozen packet-local clean-first shortlist exactly as it
stands.

## Source rule

The reserve is defined only by:

- `CLEAN_FIRST_PRIORITY_SHORTLIST.csv`
- `GALAXY_COMPARISON_ADMISSIBILITY_LEDGER.csv`

No new scientific rule is introduced here.

## What counts as the reserve

The reserve consists of every galaxy that already satisfies all of the
following packet-local conditions:

- rowwise empirical comparison-ready
- clean-first gate pass
- no duplicate-radius block burden
- no negative-`VH2` burden
- no zero-fill stellar sentinel burden
- no zero-fill bulge sentinel burden

The shortlist rank then orders that reserve by the already frozen rule:

- `rows_desc_then_gbar_span_desc_then_name`

## Present bounded role

The present role is narrow:

- show that the first named case sits inside one visible reserve
- show how large that reserve currently is
- show who the top reserve cases are

It does **not** promote the reserve into:

- theory-side authoring
- one `QCT` prediction family
- one fairness-grade comparator family
- or one superiority verdict
