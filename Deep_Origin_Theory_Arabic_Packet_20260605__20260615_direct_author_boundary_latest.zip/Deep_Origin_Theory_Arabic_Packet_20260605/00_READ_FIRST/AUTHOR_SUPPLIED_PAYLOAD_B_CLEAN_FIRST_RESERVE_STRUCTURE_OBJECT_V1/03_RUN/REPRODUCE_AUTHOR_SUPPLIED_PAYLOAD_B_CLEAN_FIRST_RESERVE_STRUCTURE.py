#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def build_report(summary: dict, top3_rows: list[dict[str, object]]) -> str:
    top3_lines = "\n".join(
        [
            f"- rank {row['rank']}: `{row['galaxy']}` with `{row['observed_rows']}` rows and `gbar` span `{row['gbar_span_dex']}` dex"
            for row in top3_rows
        ]
    )
    return f"""# Author-Supplied `PAYLOAD_B` Clean-First Reserve Structure Report

Date: `2026-06-13`

## Short verdict

The first focused empirical case is no longer one standalone named case.

It now sits on one reviewer-visible clean-first reserve inside the landed
author-supplied `PAYLOAD_B` family.

## Exact present shape

- clean-first reserve galaxy count: `{summary["clean_first_galaxy_count"]}`
- clean-first reserve observed-row count: `{summary["clean_first_row_count"]}`
- top-3 reserve galaxy count: `{summary["top3_clean_first_galaxy_count"]}`
- top-3 reserve observed-row count: `{summary["top3_clean_first_row_count"]}`
- first focused case: `{summary["first_focused_case"]}`
- all reserve galaxies remain comparison-ready: `{str(summary["all_reserve_galaxies_comparison_ready"]).lower()}`
- all reserve galaxies keep zero duplicate-radius blocks: `{str(summary["all_zero_duplicate_radius_blocks"]).lower()}`
- all reserve galaxies keep zero negative `VH2` rows: `{str(summary["all_zero_negative_vh2_rows"]).lower()}`
- all reserve galaxies keep zero zero-fill sentinels: `{str(summary["all_zero_zero_fill_sentinels"]).lower()}`
- theory-side authoring eligible reserve galaxies: `{summary["theory_side_authoring_eligible_count"]}`

## Top-3 reserve

{top3_lines}

## Exact current ceiling

This object gives one reserve structure only.

It does not yet give:

- one theory-side promotion
- one `QCT` prediction family
- one matched-nuisance fairness comparison
- one named competitor verdict
"""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ledger-csv", required=True)
    parser.add_argument("--shortlist-csv", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    ledger_rows = load_csv(Path(args.ledger_csv).resolve())
    shortlist_rows = load_csv(Path(args.shortlist_csv).resolve())
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    ledger_by_galaxy = {row["galaxy"]: row for row in ledger_rows}
    reserve_rows: list[dict[str, object]] = []

    for shortlist in shortlist_rows:
        galaxy = shortlist["galaxy"]
        ledger = ledger_by_galaxy.get(galaxy)
        if ledger is None:
            raise ValueError(f"{galaxy}: missing admissibility ledger row")
        if ledger["clean_first_gate_pass"] != "true":
            raise ValueError(f"{galaxy}: does not pass clean-first gate in ledger")
        if ledger["rowwise_empirical_comparison_ready"] != "true":
            raise ValueError(f"{galaxy}: is not comparison-ready in ledger")

        reserve_rows.append(
            {
                "rank": int(shortlist["rank"]),
                "galaxy": galaxy,
                "observed_rows": int(shortlist["observed_rows"]),
                "gbar_span_dex": float(shortlist["gbar_span_dex"]),
                "duplicate_radius_block_count": int(ledger["duplicate_radius_block_count"]),
                "negative_vhi_rows": int(ledger["negative_vhi_rows"]),
                "negative_vh2_rows": int(ledger["negative_vh2_rows"]),
                "zero_fill_vstars_rows": int(ledger["zero_fill_vstars_rows"]),
                "zero_fill_vbulge_rows": int(ledger["zero_fill_vbulge_rows"]),
                "rowwise_empirical_comparison_ready": ledger["rowwise_empirical_comparison_ready"],
                "clean_first_gate_pass": ledger["clean_first_gate_pass"],
                "theory_side_authoring_eligible": ledger["theory_side_authoring_eligible"],
                "current_scope_class": ledger["current_scope_class"],
                "selection_rule": shortlist["selection_rule"],
            }
        )

    reserve_rows.sort(key=lambda row: int(row["rank"]))
    top3_rows = reserve_rows[:3]

    summary = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_CLEAN_FIRST_RESERVE_STRUCTURE_SUMMARY_20260613",
        "comparison_scope": "empirical_gobs_gbar_only",
        "clean_first_galaxy_count": len(reserve_rows),
        "clean_first_row_count": sum(int(row["observed_rows"]) for row in reserve_rows),
        "top3_clean_first_galaxy_count": len(top3_rows),
        "top3_clean_first_row_count": sum(int(row["observed_rows"]) for row in top3_rows),
        "first_focused_case": reserve_rows[0]["galaxy"] if reserve_rows else None,
        "top3_galaxies": [str(row["galaxy"]) for row in top3_rows],
        "all_reserve_galaxies_comparison_ready": all(
            row["rowwise_empirical_comparison_ready"] == "true" for row in reserve_rows
        ),
        "all_zero_duplicate_radius_blocks": all(
            int(row["duplicate_radius_block_count"]) == 0 for row in reserve_rows
        ),
        "all_zero_negative_vh2_rows": all(
            int(row["negative_vh2_rows"]) == 0 for row in reserve_rows
        ),
        "all_zero_zero_fill_vstars_rows": all(
            int(row["zero_fill_vstars_rows"]) == 0 for row in reserve_rows
        ),
        "all_zero_zero_fill_vbulge_rows": all(
            int(row["zero_fill_vbulge_rows"]) == 0 for row in reserve_rows
        ),
        "all_zero_zero_fill_sentinels": all(
            int(row["zero_fill_vstars_rows"]) == 0 and int(row["zero_fill_vbulge_rows"]) == 0
            for row in reserve_rows
        ),
        "negative_vhi_baseline_present_in_all": all(
            int(row["negative_vhi_rows"]) > 0 for row in reserve_rows
        ),
        "theory_side_authoring_eligible_count": sum(
            row["theory_side_authoring_eligible"] == "true" for row in reserve_rows
        ),
        "selection_rule": reserve_rows[0]["selection_rule"] if reserve_rows else None,
        "verdict": (
            "AUTHOR_SUPPLIED_PAYLOAD_B_CLEAN_FIRST_RESERVE_STRUCTURE_MATERIALIZED__THE_FIRST_FOCUSED_CASE_NOW_SITS_ON_ONE_REVIEWER_VISIBLE_11_GALAXY_CLEAN_FIRST_RESERVE"
        ),
    }

    reserve_fieldnames = [
        "rank",
        "galaxy",
        "observed_rows",
        "gbar_span_dex",
        "duplicate_radius_block_count",
        "negative_vhi_rows",
        "negative_vh2_rows",
        "zero_fill_vstars_rows",
        "zero_fill_vbulge_rows",
        "rowwise_empirical_comparison_ready",
        "clean_first_gate_pass",
        "theory_side_authoring_eligible",
        "current_scope_class",
        "selection_rule",
    ]

    write_csv(output_dir / "CLEAN_FIRST_RESERVE_LEDGER.csv", reserve_fieldnames, reserve_rows)
    write_csv(output_dir / "TOP3_CLEAN_FIRST_RESERVE.csv", reserve_fieldnames, top3_rows)
    (output_dir / "CLEAN_FIRST_RESERVE_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (output_dir / "CLEAN_FIRST_RESERVE_REPORT.md").write_text(
        build_report(summary, top3_rows),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
