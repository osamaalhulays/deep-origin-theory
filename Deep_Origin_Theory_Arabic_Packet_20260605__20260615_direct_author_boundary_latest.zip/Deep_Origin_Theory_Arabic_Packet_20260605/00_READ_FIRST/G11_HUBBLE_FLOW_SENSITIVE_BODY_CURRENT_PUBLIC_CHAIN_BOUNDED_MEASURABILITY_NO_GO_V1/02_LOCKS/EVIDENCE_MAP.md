# Evidence Map

1. Current `G11` wound statement:
   `Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/CURRENT_G11_HUBBLE_FLOW_SENSITIVE_BODY_CLASSIFICATION_IS_EMPIRICAL_ONLY_UNTIL_ONE_QCT_INTERNAL_FAILURE_THEOREM_OR_BOUNDED_NO_GO_NOTE_20260612.md`

2. Public source-governed `Form C` schema:
   `Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/G4_FORM_C_SOURCE_GOVERNED_L2_EVALUATOR_V1/02_SCHEMA/INPUT_OUTPUT_SCHEMA.md`

3. Public `Form D` production-input schema:
   `artifacts/debt_board_20260530/g4_external_intake/G4_L0_FIRST_CROSSING_ENGINE_V1/02_SCHEMA/AUTHOR_FREEZE_INPUT_TRIPLE_SCHEMA.md`

4. Governing anti-`QCT` investigation protocol:
   `Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/ANTI_QCT_CASE_INVESTIGATION_PROTOCOL_AND_FIRST_PASS_TOPOLOGY_NOTE_20260608.md`

5. Named Hubble-flow-sensitive body morphology note:
   `Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/NAMED_EXECUTED_MATCHED_NUISANCE_COURT_MORPHOLOGY_PARTITION_NOTE_20260609.md`
