# Scope And Boundary

## What this object is allowed to claim

- one bounded current-public-chain no-go for `G11`,
- one exact distinction between empirical classification and internal
  source-side derivation,
- one information-layer / measurability mismatch on current public materials,
- and one honest closure of `G11` through the bounded no-go branch.

## What this object is forbidden to claim

- no claim that `QCT` can never explain the Hubble-flow-sensitive body,
- no claim that the body is unreal or methodologically dirty,
- no reopening of `G9` blunt family-scale defeat,
- no reopening of `G10` nuisance-complete fairness,
- no claim that all future parity / flow enriched public chains are blocked,
- no cosmology completion,
- no silent promotion from current-chain no-go to eternal theory no-go.

## Domain restriction

This object is about the **present public packet chain** only:

- present admitted `Form C` / `Form D` source-governed route,
- present admitted matched-nuisance / parity topology notes,
- present admitted empirical Hubble-flow-sensitive body classification.

It is not a statement about private notes, future expansions, or unpublished
source enrichments.
