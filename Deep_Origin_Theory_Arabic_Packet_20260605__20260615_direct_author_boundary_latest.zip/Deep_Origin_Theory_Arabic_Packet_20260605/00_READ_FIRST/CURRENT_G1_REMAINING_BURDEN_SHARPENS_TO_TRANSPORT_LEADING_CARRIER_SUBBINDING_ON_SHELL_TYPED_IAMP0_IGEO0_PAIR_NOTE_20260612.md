# Current `G1` Remaining Burden Sharpens To One Transport-Leading Carrier Subbinding On The Shell-Typed `(I_amp^(0), I_geo^(0))` Pair

Date: `2026-06-12`

Purpose:

State the next exact reread after the remaining `G1` burden had already been
sharpened to one lawful shared-source dependence binding through the
shell-typed `IR1` register.

## Short verdict

That burden no longer sits on the full shell-typed `IR1` triad as one flat
shared-source dependence problem.

The repo already fixes:

- one shell-typed `IR1` triad
- one carrier-side image map
  `(I_amp, I_geo) -> (A_Q, M_Q)`
- one south singleton owner
  `I_mix -> w_lin`
- and one transport-pivot order with `A_Q` first and `M_Q` co-carried later

So the remaining first live burden now sharpens to:

- one reviewer-visible lawful transport-leading carrier subbinding carrying
  the single-`Q` reduced-action kinetic coefficient through the already
  shell-typed `(I_amp^(0), I_geo^(0))` pair inside `I_src^(IR1,0)`,
  with `I_geo^(0)` preserved as the transport-leading face,
  `I_amp^(0)` preserved as the support amplitude face,
  and `I_mix^(0)` no longer competing as one coequal first carrier-side
  burden

## What this does not claim

This note does **not** claim:

- that the required carrier subbinding is already materialized
- that the final pairwise coefficient law is already known
- full `G1` closure

It claims something narrower:

- the remaining burden is now more exact than full-triad shared-source
  dependence language.

## Read with

- `CURRENT_G1_REMAINING_BURDEN_SHARPENS_TO_SHARED_SOURCE_DEPENDENCE_BINDING_ON_SHELL_TYPED_IR1_REGISTER_NOTE_20260612.md`
- `POST_CAGE_BRANCH_U1_RR0_BS1_VCAP1_IR1_VERTICAL_IMAGE_DECOMPOSITION_AND_122_FREEZE_ORDER_NOTE_20260608.md`
- `POST_CAGE_BRANCH_U1_IAMP_SOURCE_PURITY_GATE_LOCALIZES_TO_METRIC_MATTER_ONLY_AMPLITUDE_SHELL_NOTE_20260608.md`
- `POST_CAGE_BRANCH_U1_IMIX_SOURCE_PURITY_GATE_LOCALIZES_TO_BOUNDED_METRIC_MATTER_ONLY_MIXTURE_SHELL_NOTE_20260608.md`
