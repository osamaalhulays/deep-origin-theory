# Author-Supplied `LVHIS072` `M3` Global-`a0` Lane Report

Date: `2026-06-13`

## Short verdict

One case-owned `M3` global-`a0` lane is now materially executed on `LVHIS072`.

The declared global roster was executed without per-galaxy fitting.

The best family-plus-`a0` combo is:

- `standard` @ `a0 = 1.27e-10 m/s^2`

## Scoreboard

- `simple` @ `a0=1.20e-10`: best scale = `1.449323875010`; best `obs-only` loglike = `-142.232226892576`
- `simple` @ `a0=1.22e-10`: best scale = `1.437795250010`; best `obs-only` loglike = `-141.273502872471`
- `simple` @ `a0=1.27e-10`: best scale = `1.409726500011`; best `obs-only` loglike = `-138.943450853784`
- `standard` @ `a0=1.20e-10`: best scale = `1.711031875003`; best `obs-only` loglike = `-137.405978364185`
- `standard` @ `a0=1.22e-10`: best scale = `1.696167000003`; best `obs-only` loglike = `-136.560447285201`
- `standard` @ `a0=1.27e-10`: best scale = `1.659984000004`; best `obs-only` loglike = `-134.525345114403`

## Best-combo differential result

- `QCT` best `obs-only` loglike = `-128.224473129692`
- global-best `QUMOND` loglike = `-134.525345114403`
- `Δloglike(QCT-global_best)` = `6.300871984711`
- `ΔAIC(QCT-global_best)` = `-12.601743969422`
- `ΔBIC(QCT-global_best)` = `-12.601743969422`

## Court consequence

- `M3` execution = `true`
- `M3` non-rescue = `true`
- full-ladder `Grade 2` already materialized = `false`

## Exact ceiling

This object does **not** claim:

- `M4`
- full-ladder `Grade 2`
- `Grade 3`
- per-galaxy `a0` fitting
- whole-family `MOND/QUMOND` defeat
