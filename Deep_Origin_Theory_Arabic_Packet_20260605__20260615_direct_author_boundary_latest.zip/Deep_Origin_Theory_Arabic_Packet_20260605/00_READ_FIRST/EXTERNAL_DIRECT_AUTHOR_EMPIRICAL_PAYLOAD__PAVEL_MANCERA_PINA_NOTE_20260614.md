# External Direct-Author Empirical Payload — author-supplied Mancera Piña

Date: `2026-06-14`

Status: `outside direct-author empirical payload digested with bounded packet consequence`

## Purpose

Digest the direct-author empirical payload arrival into one exact
packet-useful surface without laundering it into endorsement, one packet-owned
upstream data product, or one automatic scientific win.

This note does **not** claim:

- one full `49`-galaxy `QCT` victory,
- one unique downstream normalization law,
- one `PAYLOAD_A` arrival,
- or endorsement of `QCT` by the source author.

It claims something narrower and useful:

- the non-`SPARC` `L2` rowwise lane is no longer only one public-link hunt or
  one inferred reconstruction corridor,
- because one direct-author machine-readable payload really landed and is now
  frozen with hashes, schema, and exact intake class.

## Short digest

The direct-author reply gives seven usable points:

1. `author-supplied Mancera Piña` replied on `2026-06-12` with two zip attachments:
   `vcirc_obs.zip` and `vcirc_baryons.zip`,
2. the reply explicitly states that the requested parameters exist and are
   being shared,
3. the observed side carries `49` machine-readable galaxy files,
4. the baryonic side also carries `49` machine-readable galaxy files, with the
   same galaxy-name set,
5. the baryonic files are oversampled relative to the observed rotation-curve
   rows,
6. the reply warns that stellar and bulge component amplitudes are tied to the
   author's best-fitting mass-to-light ratio and may be renormalized for a
   separate dynamical analysis,
7. the reply also warns that the `HI` component may retain limited model
   dependence for some dwarf galaxies even though the broader landed class
   still remains usable at the weaker component-curve level.

## Exact landed local footing

The exact local raw holding for the landed payload is:

- `artifacts/debt_board_20260530/author_supplied_payload_b_raw_20260613/vcirc_obs.zip`
- `artifacts/debt_board_20260530/author_supplied_payload_b_raw_20260613/vcirc_baryons.zip`

The packet now already carries the exact receipt floor through:

- `CURRENT_G6_L2_DIRECT_AUTHOR_PAYLOAD_ARRIVED_AND_CLASSIFIED_AS_PAYLOAD_B_NOTE_20260612.md`
- `AUTHOR_SUPPLIED_PAYLOAD_B_RECEIPT_AUDIT_OBJECT_V1`

That floor freezes:

- `49 / 49` exact matched galaxy pairs,
- `1082` observed rows,
- `4850` baryonic rows,
- stable zip hashes,
- exact schema locks,
- and the lawful intake class `PAYLOAD_B`.

## What this strengthens

This outside direct-author arrival strengthens the packet in four exact ways:

1. it blocks the false reading that the current `L2` rowwise lane still rests
   only on public scraping or proxy reconstruction,
2. it fixes one exact direct-author arrival floor for the `MP21a/3DBarolo`
   family lane,
3. it cleanly separates upstream author-supplied component curves from the
   packet's own downstream normalization, audit, and diagnostic choices,
4. it keeps attribution honest:
   the source author owns the upstream payload,
   while the packet owns the intake audit and bounded diagnostic framing.

## What this does **not** do

This arrival does **not** do any of the following:

- choose one final signed-gas rule,
- choose one final duplicate-radius compression rule,
- choose one final `rho_b(r)` construction rule,
- convert `PAYLOAD_B` into `PAYLOAD_A`,
- turn the reply into one endorsement,
- or grant authorship of downstream `QCT` diagnostic results to the source
  author.

## Exact operational consequence

The outward-safe packet reading for this lane should now remain:

- one direct-author machine-readable empirical payload really landed,
- the landed class is exactly `PAYLOAD_B`,
- the exact receipt and intake floor is already frozen locally,
- every stronger downstream comparison or normalization object must still
  state its own rules rather than borrowing authority silently from the mail
  arrival alone,
- and outward-public derivative exposure must remain separately governed from
  the mere fact of landed arrival.

## Local-holding and public-derivative boundary

The raw zip payload remains one local artifact-vault holding.

This packet does **not** promote those raw zips into one packet-owned
scientific result, and it does **not** outwardly republish row-level or
near-rowwise derivative tables built from them without a separate source-release
permission surface.

Instead, it reuses only:

- the receipt facts,
- the file hashes,
- the schema floor,
- the bounded intake consequence,
- and bounded summary / ledger / report surfaces that do not republish the
  withheld derivative tables.

That outward boundary is now frozen separately here:

- `CURRENT_DIRECT_AUTHOR_PUBLIC_DERIVATIVE_BOUNDARY_NOTE_20260615.md`

## Bottom line

This is one real outside direct-author empirical payload win.

It does **not** create one automatic scientific closure.

It does remove one important source-arrival ambiguity, and it fixes the
current `L2` non-`SPARC` rowwise lane as one author-supplied machine-readable
payload lane with explicit local receipt, hashes, and intake class.
