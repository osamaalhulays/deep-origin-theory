# First Clean Empirical Gap Witness Capsule — NGC1313

Date: `2026-06-13`

Status: `bounded outward-facing capsule`

Purpose:

This capsule answers one narrow reviewer question directly:

Do we now have one named, reviewer-readable **empirical** non-`SPARC` case
above the landed author-supplied payload, rather than only one receipt object and one
sample-wide admissibility grammar?

Short answer:

- `yes, in bounded form`

## Case

- named case = `NGC1313`
- source lane = direct-author author-supplied `PAYLOAD_B`
- scope = empirical `gobs/gbar` only
- selection role = `rank-1 clean-first case`

## What is frozen here

The bounded witness claim frozen here is:

- `NGC1313` is the cleanest current first named empirical gap witness inside
  the landed author-supplied `PAYLOAD_B` family at present `gobs/gbar` scope.

This is **not** yet:

- one theory-side witness,
- one `QCT` prediction-case closure,
- one `QUMOND` fairness verdict,
- or one differential superiority claim.

## Witness type

Witness type:

- `rowwise all-positive empirical gobs-vs-gbar gap under clean-first direct-author payload conditions`

The packet-local focused case now shows:

- `40` rows
- all `40` rows are comparison-ready
- all `40` rows preserve clean-first status
- `6` exact interpolation rows
- `34` linear interpolation rows
- `delta = log10(gobs) - log10(gbar)` is positive in all `40` rows
- `delta_min = 0.19955408170893918`
- `delta_max = 1.0441321624537672`
- `delta_median = 0.6133288585909309`
- `gbar` peaks at `r = 0.99 kpc`
- `gbar` is nonincreasing after that peak

The exact extracted row table is now published in:

- `AUTHOR_SUPPLIED_PAYLOAD_B_NGC1313_FIRST_CLEAN_EMPIRICAL_ROWCASE_OBJECT_V1/04_OUTPUTS/NGC1313_EMPIRICAL_ROWCASE.csv`

And the compact key-row snapshot is now published in:

- `AUTHOR_SUPPLIED_PAYLOAD_B_NGC1313_FIRST_CLEAN_EMPIRICAL_ROWCASE_OBJECT_V1/04_OUTPUTS/NGC1313_KEY_ROWS.csv`

So the case is no longer only:

- one first-place rank label,
- or one abstract “clean-first” shortlist member,
- or one broad sample-level admissibility statement.

It now has:

- one named galaxy,
- one direct-author payload lane,
- one focused rowwise empirical table,
- one bounded outward-safe claim,
- and one exact packet-local replay path.

## Why this case matters

`NGC1313` is not selected arbitrarily.

The already frozen selection rule makes it rank `1` because it combines:

- clean-first gate pass,
- the largest observed-row count inside that clean-first subfamily,
- and one strong `gbar` dynamic span.

The focused empirical lane is therefore no longer faceless.

It already contains one named first case whose selection is procedural rather
than rhetorical.

## Reviewer-readable localization

The broader sample-wide object already shows:

- `49` rowwise comparison-ready galaxies
- `1082` rowwise comparison-ready observed rows
- `11` clean-first galaxies
- `184` clean-first rows

Inside that wider family:

- `NGC1313` = rank-1 clean-first case
- `NGC2541` = rank-2 clean-first case
- `NGC7793` = rank-3 clean-first case

So `NGC1313` is not a newly invented showcase.

It is simply the first lawful focused extraction from the already frozen
sample-wide rule.

## Why this still remains bounded

`NGC1313` is a real first focused empirical witness, but it remains **strictly
bounded**.

The packet does **not** yet publish for `NGC1313`:

- one theory-side source profile pack,
- one `QCT` prediction row family,
- one matched-nuisance fairness comparison,
- or one named competitor verdict.

So the honest reading is not:

- “`NGC1313` already proves the theory-side lane.”

The honest reading is:

- the packet now has one first focused empirical case above the landed author-supplied `PAYLOAD_B` family
  family,
- and that case is reader-visible row by row,
- while still remaining empirical-only.

## Current state table

| Field | Current state |
| --- | --- |
| Named case | `closed` |
| Direct-author payload lane | `closed` |
| Rank-1 clean-first selection | `closed` |
| Public focused row table | `closed` |
| Public key-row table | `closed` |
| All-positive empirical gap support | `closed` |
| Packet-local replay path | `closed` |
| Theory-side promotion | `pending` |
| Matched-nuisance fairness comparison | `pending` |
| Named competitor verdict | `pending` |

## Short outward-safe wording

One outward-safe summary sentence is:

> `NGC1313` is the cleanest current first named empirical gap witness inside
> the landed author-supplied `PAYLOAD_B` family: under the direct-author non-`SPARC`
> rowwise lane, all 40 observed rows remain comparison-ready and clean-first,
> and every row preserves a positive empirical `log10(gobs) - log10(gbar)`
> gap while the packet now carries the exact focused row table and replay path
> for that case.

## Use rule

Use this capsule to answer:

- “Do you now have one named focused empirical case above the author-supplied landing?”

Do **not** use it to claim:

- one theory-side closure,
- one fairness-grade comparator result,
- or one whole-program victory.
