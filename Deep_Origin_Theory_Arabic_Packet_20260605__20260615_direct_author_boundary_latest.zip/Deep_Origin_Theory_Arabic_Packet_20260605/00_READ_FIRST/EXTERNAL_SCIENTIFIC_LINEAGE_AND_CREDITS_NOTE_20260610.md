# External Scientific Lineage And Credits Note

Date: `2026-06-10`

This note exists to keep one outward-facing point cold and explicit:

the packet contains original `QCT` claims, synthesis, and packet-side
diagnostic framing, but it also stands on public datasets, comparator
families, source-hosted releases, and outside clarifications produced by other
scientists.

## What belongs to this packet

This packet owns:

- its `QCT` derivations and bounded claims,
- its packet architecture and shelf assembly,
- its reproduction and audit surfaces,
- and its local diagnostic synthesis built on top of the cited outside lines.

## What this packet does not own

This packet does **not** own:

- the `SPARC` benchmark data line,
- the `MOND/QUMOND` comparator family,
- the `MP21a/3DBarolo` source releases,
- or the upstream cluster data and author-side clarifications used in
  provenance or authority lanes.

## Named lineage visible in the current packet

### 1. `SPARC` galaxy benchmark lane

The named galaxy cases carried by the packet, including `NGC0247` and the
wider `O6/O7` family, depend on the public `SPARC` benchmark line associated
with `Federico Lelli`, `Stacy McGaugh`, `James Schombert`, and collaborators.

The packet also carries one narrower methods-side clarification from
`Stacy McGaugh`, frozen in
`EXTERNAL_METHODS_REPLY_STACY_MCGAUGH_MATCHED_NUISANCE_AND_AIC_BOUNDARY_NOTE_20260611.md`.
That clarification belongs to packet-use grammar around fairness and
superiority wording, not to one endorsement of `QCT`.

When citing galaxy-level row tables or `SPARC`-case outcomes from this packet,
the fair outward pattern is:

- cite the packet for the `QCT` side,
- and cite the `SPARC` source line for the galaxy benchmark/data side.

### 2. `QUMOND / MOND` comparator lane

The fixed-`QUMOND` comparator lane belongs to the broader `MOND/QUMOND`
comparison literature, especially the `QUMOND` family associated with
`Mordehai Milgrom`.

The packet uses one locked public benchmark form as a comparator.
It does **not** claim authorship of that comparator family.

### 3. `MP21a / 3DBarolo` non-`SPARC` lane

The public non-`SPARC` rowwise lane highlighted in `L2` is based on
author-hosted `3DBarolo`-family releases associated with `author-supplied Mancera Piña`
and collaborators, with relevant public corridor material also tied to the
`Fraternali` side where appropriate.

The packet's contribution there is source procurement, audit, and bounded
diagnostic framing, not ownership of the upstream source products.

The exact current bounded direct-author arrival consequence is now frozen in
`EXTERNAL_DIRECT_AUTHOR_EMPIRICAL_PAYLOAD__PAVEL_MANCERA_PINA_NOTE_20260614.md`.
That note keeps the raw payload as one local artifact-vault holding identified
by stable zip hashes, rather than silently rebranding the upstream files as
one packet-owned public scientific source product.

### 4. Cluster provenance and source-touch lanes

The cluster-side provenance and authority lanes also depend on outside
scientific inputs that are not packet-owned:

- `A209` processed-input clarification benefited from outside provenance
  clarification from `Andrea Biviano` and `Lorenzo Pizzuti`.
  The exact current bounded consequence is frozen in
  `EXTERNAL_A209_PROCESSED_INPUT_AUTHORITY__LORENZO_PIZZUTI_AND_ANDREA_BIVIANO_NOTE_20260614.md`,
  including the mirrored `A209_members.dat` footing,
  the mirrored `parsgT_A209.txt` footing,
  and the fixed `153 km/s` velocity-error rule.
- `MACS1206` current-version source-touch clarification benefited from direct
  reply and followup clarification from `Lorenzo Pizzuti`.
- `A370` provenance clarification is treated inside the packet as one
  clarification lane on upstream material rather than as one packet-native
  data product.
  The exact current bounded consequence is frozen in
  `EXTERNAL_PROVENANCE_REPLY_LILIYA_WILLIAMS_A370_SYSTEM31_AND_SUPPLEMENTARY_AUTHORITY_NOTE_20260614.md`,
  including the rule that `system 31` should not be treated as one
  Williams/Ghosh label on that line.

### 5. Theory-side outside reading

One outside technically informed human theory-side reading came from
`Dr. Mohamed Haj Yousef`.

That counts as outside technical reading.
It does **not** count as peer review, co-authorship, or public endorsement.

## Use rule

If you reuse this packet in writing, pair packet citation with the upstream
scientific line you actually used:

- `SPARC` case or row table -> cite the packet + the `SPARC` line
- fixed-`QUMOND` comparator point -> cite the packet + the `QUMOND/MOND` line
- `MP21a/3DBarolo` public-family point -> cite the packet + the relevant
  upstream release line
- `A209` / `MACS1206` provenance or authority point -> cite the packet + the
  named upstream clarification lane when relevant

## Boundary

Nothing in this note converts outside data providers, correspondents, or
method owners into endorsers of `QCT`.

Its purpose is narrower:

- keep the packet's own contribution visible,
- keep outside scientific lineage visible,
- and prevent under-attribution or ownership blur in outward reading.
