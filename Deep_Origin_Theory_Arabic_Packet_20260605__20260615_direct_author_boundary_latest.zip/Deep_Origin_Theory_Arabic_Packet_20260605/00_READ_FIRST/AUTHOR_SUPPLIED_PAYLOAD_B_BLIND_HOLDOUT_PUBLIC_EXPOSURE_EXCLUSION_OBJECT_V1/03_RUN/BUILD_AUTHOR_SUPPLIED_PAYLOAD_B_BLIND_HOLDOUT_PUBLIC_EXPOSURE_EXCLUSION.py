#!/usr/bin/env python3

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path


THIS_OBJECT = "AUTHOR_SUPPLIED_PAYLOAD_B_BLIND_HOLDOUT_PUBLIC_EXPOSURE_EXCLUSION_OBJECT_V1"
THIS_DATE = "2026-06-14"
THIS_VERDICT = (
    "CURRENT_AUTHOR_SUPPLIED_PAYLOAD_B_FAMILY_IS_PUBLIC_WITNESS_VALID_BUT_BLIND_HOLDOUT_"
    "INADMISSIBLE_UNDER_CURRENT_PACKET_VISIBLE_EXPOSURE"
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    object_dir = Path(__file__).resolve().parents[1]
    read_first_dir = Path(__file__).resolve().parents[2]
    adapter_root = Path(__file__).resolve().parents[4]
    output_dir = object_dir / "04_OUTPUTS"
    output_dir.mkdir(parents=True, exist_ok=True)

    field_summary_csv = (
        read_first_dir
        / "AUTHOR_SUPPLIED_PAYLOAD_B_FAMILY_QCT_VS_QUMOND_MATCHED_NUISANCE_SCAN_RUNTIME_LOCKED_OBJECT_V1"
        / "CASE_LEVEL_SUMMARY.csv"
    )
    named_front7_json = (
        read_first_dir
        / "AUTHOR_SUPPLIED_PAYLOAD_B_NAMED_FRONT7_STRUCTURE_OBJECT_V1"
        / "04_OUTPUTS"
        / "NAMED_FRONT7_SUMMARY.json"
    )
    triad_verdict_json = (
        adapter_root
        / "Cosmic_Closure_Goal_Bank_20260610__20260613_latest"
        / "MOND_QUMOND_CLEAN_FRONT_POSITIVE_TRIAD_BOUNDED_FAMILY_COURT_VERDICT_20260614.json"
    )

    with field_summary_csv.open("r", encoding="utf-8", newline="") as handle:
        field_rows = list(csv.DictReader(handle))
    front7_summary = load_json(named_front7_json)
    triad_summary = load_json(triad_verdict_json)

    front7_cases = set(front7_summary["named_front_galaxies"])
    triad_cases = set(triad_summary["triad_cases"])

    manifest_rows = []
    for row in field_rows:
        case_id = row["case_id"]
        public_case_level_outcome_exposed = True
        public_named_front7_exposed = case_id in front7_cases
        public_triad_family_court_exposed = case_id in triad_cases
        blind_holdout_admissible = False
        reasons = [
            "packet-visible case-level matched-nuisance outcome already materialized"
        ]
        if public_named_front7_exposed:
            reasons.append("named front-7 empirical head already public")
        if public_triad_family_court_exposed:
            reasons.append("triad-level family-court verdict already public")
        manifest_rows.append(
            {
                "case_id": case_id,
                "preferred_side": row["preferred_side"],
                "delta_aic_qct_minus_qumond_obs_only": row[
                    "delta_aic_qct_minus_qumond_obs_only"
                ],
                "clean_first_priority_rank": row["clean_first_priority_rank"],
                "public_case_level_outcome_exposed": str(
                    public_case_level_outcome_exposed
                ).lower(),
                "public_named_front7_exposed": str(public_named_front7_exposed).lower(),
                "public_triad_family_court_exposed": str(
                    public_triad_family_court_exposed
                ).lower(),
                "blind_holdout_admissible": str(blind_holdout_admissible).lower(),
                "exclusion_reason": " | ".join(reasons),
            }
        )

    manifest_path = output_dir / "EXCLUSION_MANIFEST.csv"
    with manifest_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "case_id",
                "preferred_side",
                "delta_aic_qct_minus_qumond_obs_only",
                "clean_first_priority_rank",
                "public_case_level_outcome_exposed",
                "public_named_front7_exposed",
                "public_triad_family_court_exposed",
                "blind_holdout_admissible",
                "exclusion_reason",
            ],
        )
        writer.writeheader()
        writer.writerows(manifest_rows)

    sources = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_BLIND_HOLDOUT_PUBLIC_EXPOSURE_SOURCES_20260614",
        "field_summary_csv": {
            "path": str(field_summary_csv.relative_to(adapter_root)),
            "sha256": sha256(field_summary_csv),
            "case_count": len(field_rows),
        },
        "named_front7_summary_json": {
            "path": str(named_front7_json.relative_to(adapter_root)),
            "sha256": sha256(named_front7_json),
            "case_count": len(front7_cases),
        },
        "triad_verdict_json": {
            "path": str(triad_verdict_json.relative_to(adapter_root)),
            "sha256": sha256(triad_verdict_json),
            "case_count": len(triad_cases),
        },
    }
    (output_dir / "PUBLIC_EXPOSURE_SOURCES.json").write_text(
        json.dumps(sources, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    summary = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_BLIND_HOLDOUT_PUBLIC_EXPOSURE_EXCLUSION_SUMMARY_20260614",
        "date": THIS_DATE,
        "family_case_count": len(field_rows),
        "public_case_level_outcome_exposed_case_count": len(field_rows),
        "named_front7_case_count": len(front7_cases),
        "public_triad_family_court_case_count": len(triad_cases),
        "blind_holdout_admissible_case_count": 0,
        "public_wins_retained_in_repo": True,
        "non_erasure_rule": True,
        "fresh_unexposed_pool_required_for_real_blind_holdout": True,
        "current_same_family_blind_rerun_honest": False,
        "verdict": THIS_VERDICT,
    }
    (output_dir / "EXCLUSION_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    report = f"""# Author-Supplied `PAYLOAD_B` Blind-Holdout Public-Exposure Exclusion Report

Date: `{THIS_DATE}`

## Short verdict

The current author-supplied family stays valid as public packet evidence.

It does **not** stay admissible as the input pool for one new honest blind
holdout run.

Why:

- packet-visible case-level matched-nuisance outcomes already exist on all
  `{len(field_rows)}` family cases
- the named empirical head already publicly localizes `{len(front7_cases)}`
  cases
- the stronger family-court triad already publicly localizes
  `{len(triad_cases)}` cases

## Exact consequence

- public wins stay public
- same-family blind-court intake is closed
- admissible current author-supplied blind-holdout candidates: `0`
- one fresh unexposed pool is required for the next truthful blind run

## Scope boundary

This report does **not** erase:

- the field-wide matched-nuisance scan
- the named front structure
- or the triad family-court verdict

It excludes only one move:

- re-entering already public same-family outcomes into a new blind court
"""
    (output_dir / "EXCLUSION_REPORT.md").write_text(report, encoding="utf-8")

    status = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_BLIND_HOLDOUT_PUBLIC_EXPOSURE_EXCLUSION_REPRODUCTION_20260614",
        "status": "CURRENT_AUTHOR_SUPPLIED_PAYLOAD_B_FAMILY_BLIND_HOLDOUT_EXCLUSION_MATERIALIZED",
        "summary_file": "EXCLUSION_SUMMARY.json",
        "manifest_file": "EXCLUSION_MANIFEST.csv",
        "report_file": "EXCLUSION_REPORT.md",
    }
    (output_dir / "reproduction_status.json").write_text(
        json.dumps(status, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()

