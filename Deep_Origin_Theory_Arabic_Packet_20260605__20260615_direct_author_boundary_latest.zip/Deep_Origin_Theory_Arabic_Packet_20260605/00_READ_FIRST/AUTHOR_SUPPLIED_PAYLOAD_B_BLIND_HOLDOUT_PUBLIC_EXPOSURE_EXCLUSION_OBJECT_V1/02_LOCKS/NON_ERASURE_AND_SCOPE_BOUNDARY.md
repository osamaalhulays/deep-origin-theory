# Non-Erasure And Scope Boundary

The exclusion carried by this object is narrow.

It means only:

- do not reuse the current author-supplied family as a fresh blind-holdout candidate
  pool

It does **not** mean:

- delete the named front objects
- delete the field-wide matched-nuisance scan
- delete the triad family-court verdict
- or pretend those public wins never landed

The governing split is:

- `public witness grammar` remains active
- `blind court intake grammar` is closed on the current same family

The exact trigger for reopening blind-court intake is:

- one fresh pool whose target identities and case-level outcomes have not
  already been materialized inside the public packet stack

