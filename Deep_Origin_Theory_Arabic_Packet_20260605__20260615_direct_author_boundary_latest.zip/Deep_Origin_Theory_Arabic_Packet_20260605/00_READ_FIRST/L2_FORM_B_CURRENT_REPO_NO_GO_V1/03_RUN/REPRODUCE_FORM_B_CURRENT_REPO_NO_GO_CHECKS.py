from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


SCRIPT_PATH = Path(__file__).resolve()
OBJECT_ROOT = SCRIPT_PATH.parents[1]
ROOT = SCRIPT_PATH.parents[4]
OUTPUTS = OBJECT_ROOT / "04_OUTPUTS"

IGNORE_FRAGMENTS = (
    "/node_modules/",
    "/tmp_",
    "/L2_FORM_B_CURRENT_REPO_NO_GO_V1/",
)
DATA_SUFFIXES = {".csv", ".json", ".ndjson"}

DATA_TOKENS = (
    "Xi_QCT_L2",
    "xi_qct_l2",
    "gbar_i",
)

NOTE_CHECKS = [
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_EVALUATOR_CONTENT_TARGET_AFTER_RULE_AND_OPERATOR_SUPPLY_20260608.md",
        "fragments": [
            "one promotable source-governed `Delta_QCT_L2(x_i)` or",
            "`Xi_QCT_L2(gbar_i)` authority still does not",
        ],
        "meaning": "the route itself still records the missing promotable Xi authority",
    },
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/02_LOCKS/ALLOWED_AUTHORING_FORMS.md",
        "fragments": [
            "`Form B`",
            "`Xi_QCT_L2(gbar_i)` response table with exact conversion rule",
        ],
        "meaning": "Form B is frozen only as Xi rows with exact conversion discipline",
    },
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/L2_FORM_A_DELTA_TABLE_FIRST_STRIKE_V1/02_LOCKS/FORM_A_CONVERSION_AND_ESCALATION_MAP.md",
        "fragments": [
            "`Form A -> Form B`",
            "already frozen conversion rule and is cleaner",
        ],
        "meaning": "Form B is not owned merely by naming; it needs lawful conversion discipline",
    },
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_KREIB_Q_PREFILL_AND_U1_SEED_CLASS_NOTE_20260608.md",
        "fragments": [
            "treating third-generation `C0_NO_CLAIM_EXPORT` probes as promotable",
            "These are the main false-rescue traps.",
        ],
        "meaning": "bounded no-claim probes may not be promoted into Xi authority by inflation",
    },
]


def relative(path: Path) -> str:
    return str(path.relative_to(ROOT))


def include(path: Path) -> bool:
    path_str = str(path)
    return path.is_file() and not any(fragment in path_str for fragment in IGNORE_FRAGMENTS)


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def classify_data_hit(path: Path, text: str) -> tuple[str, int]:
    rel = relative(path)
    if rel.endswith("L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/04_OUTPUTS/status_summary.json"):
        return "form_registry_only", 0
    if (
        "L2_FORM_A_CURRENT_REPO_NO_GO_V1/" in rel
        or "L2_FORM_C_CURRENT_REPO_NO_GO_V1/" in rel
    ):
        return "report_only", 0
    if path.suffix.lower() == ".csv":
        lines = [line for line in text.splitlines() if line.strip()]
        if lines:
            header = lines[0].lower()
            if "gbar" in header and "xi" in header:
                row_count = max(0, len(lines) - 1)
                return ("schema_only" if row_count == 0 else "candidate_xi_table_surface", row_count)
    return "mention_only", 0


def collect_data_hits() -> list[dict]:
    hits: list[dict] = []
    for path in sorted(ROOT.rglob("*")):
        if not include(path) or path.suffix.lower() not in DATA_SUFFIXES:
            continue
        text = read_text(path)
        matched_lines = []
        for index, line in enumerate(text.splitlines(), start=1):
            if any(token in line for token in DATA_TOKENS):
                matched_lines.append({"line": index, "text": line.strip()})
        if not matched_lines:
            continue
        classification, row_count = classify_data_hit(path, text)
        hits.append(
            {
                "path": relative(path),
                "classification": classification,
                "row_count": row_count,
                "matches": matched_lines,
            }
        )
    return hits


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {
            fragment: (fragment in text) for fragment in item["fragments"]
        }
        results.append(
            {
                "path": relative(item["path"]),
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def build_report(status: dict, note_checks: list[dict], hits: list[dict]) -> str:
    lines = [
        "# Form B Current-Repo No-Go Report",
        "",
        f"Generated at: `{status['generated_at_utc']}`",
        "",
        f"Verdict: `{status['verdict']}`",
        "",
        "## Summary",
        "",
        f"- direct populated Xi candidate surfaces found: `{status['candidate_xi_table_surface_count']}`",
        f"- schema-only Xi surfaces found: `{status['schema_only_count']}`",
        f"- registry/report/mention-only Xi hits found: `{status['non_authority_hit_count']}`",
        f"- populated Xi rows found: `{status['populated_xi_row_count_total']}`",
        f"- exact conversion-rule scope confirmed: `{str(status['exact_conversion_rule_scope_confirmed']).lower()}`",
        f"- bounded-probe promotion fence confirmed: `{str(status['bounded_probe_promotion_fence_confirmed']).lower()}`",
        "",
        "## Data-bearing hits",
        "",
    ]
    if not hits:
        lines.append("- none")
    else:
        for hit in hits:
            lines.append(
                f"- `{hit['classification']}`: `{hit['path']}`"
            )
    lines.extend(
        [
            "",
            "## Note checks",
            "",
        ]
    )
    for check in note_checks:
        lines.append(
            f"- `{check['path']}` -> `{str(check['passed']).lower()}`"
        )
    lines.extend(
        [
            "",
            "## Reading",
            "",
            "- the current route already carries rule/operator/probe grammar and a typed `Form B` allowance,",
            "- but the repo-visible data-bearing surfaces still do not carry one populated `Xi_QCT_L2(gbar_i)` authority pack,",
            "- so current lawful `Form B` materialization is absent.",
            "",
            "## Next exact move",
            "",
            "- stop hidden-`Form B` hunting on the same frozen route",
            "- reopen only through one explicit Xi authority package, one genuinely prior Xi primitive, or one stronger same-route reopening above table level",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    OUTPUTS.mkdir(parents=True, exist_ok=True)

    hits = collect_data_hits()
    note_checks = collect_note_checks()

    candidate_hits = [
        hit for hit in hits if hit["classification"] == "candidate_xi_table_surface"
    ]
    schema_hits = [hit for hit in hits if hit["classification"] == "schema_only"]
    non_authority_hits = [
        hit
        for hit in hits
        if hit["classification"] in {"form_registry_only", "report_only", "mention_only"}
    ]

    status = {
        "object_kind": "form_b_current_repo_no_go_status",
        "generated_at_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "scope": "current_repo_visible_frozen_route_only",
        "candidate_xi_table_surface_count": len(candidate_hits),
        "schema_only_count": len(schema_hits),
        "non_authority_hit_count": len(non_authority_hits),
        "populated_xi_row_count_total": sum(hit["row_count"] for hit in schema_hits + candidate_hits),
        "all_note_checks_pass": all(check["passed"] for check in note_checks),
        "exact_conversion_rule_scope_confirmed": any(
            "conversion rule" in fragment and present
            for check in note_checks
            for fragment, present in check["fragments"].items()
        ),
        "bounded_probe_promotion_fence_confirmed": any(
            "promotable" in fragment and present
            for check in note_checks
            for fragment, present in check["fragments"].items()
        ),
        "direct_form_b_value_pack_present": len(candidate_hits) > 0,
        "xi_benchmark_table_materialized": any(hit["row_count"] > 0 for hit in schema_hits + candidate_hits),
        "verdict": "FORM_B_CURRENT_REPO_VISIBLE_ROUTE_NO_GO_MATERIALIZED",
    }

    verdict = {
        "verdict": status["verdict"],
        "scope": status["scope"],
        "why": [
            "rule/operator/probe ladder is present",
            "Form B is allowed only as Xi rows with exact conversion discipline",
            "bounded probes are already fenced below promotable authority",
            "data-bearing surfaces expose only registry/report mentions, not one populated Xi authority table",
        ],
        "next_exact_move": "EXPLICIT_XI_AUTHORITY_PACKAGE_OR_LAWFULLY_PRIOR_XI_PRIMITIVE_OR_STRONGER_SAME_ROUTE_REOPENING",
        "ceiling": [
            "not a permanent impossibility theorem",
            "not a rejection of lawfully prior Xi primitivity in principle",
            "not a rejection of Form C/D in principle",
            "not a full-program failure verdict",
        ],
    }

    report = build_report(status, note_checks, hits)

    (OUTPUTS / "data_surface_hits.json").write_text(
        json.dumps(hits, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "note_checks.json").write_text(
        json.dumps(note_checks, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "status_summary.json").write_text(
        json.dumps(status, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "verdict.json").write_text(
        json.dumps(verdict, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "FORM_B_CURRENT_REPO_NO_GO_REPORT.md").write_text(
        report,
        encoding="utf-8",
    )

    if candidate_hits:
        raise SystemExit("unexpected candidate Xi table surface found")
    if any(hit["row_count"] > 0 for hit in schema_hits):
        raise SystemExit("unexpected populated Xi schema rows found")
    if not all(check["passed"] for check in note_checks):
        raise SystemExit("required note evidence check failed")


if __name__ == "__main__":
    main()
