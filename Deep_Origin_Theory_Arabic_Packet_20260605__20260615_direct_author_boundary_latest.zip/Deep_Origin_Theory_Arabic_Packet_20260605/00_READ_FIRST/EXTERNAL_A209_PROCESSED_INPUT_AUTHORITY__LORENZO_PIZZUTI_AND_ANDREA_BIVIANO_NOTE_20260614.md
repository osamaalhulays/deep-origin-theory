# External `A209` Processed-Input Authority — Lorenzo Pizzuti And Andrea Biviano

Date: `2026-06-14`

Status: `outside processed-input clarification digested with explicit local mirrors`

## Purpose

Digest the outside `A209` processed-input clarification lane into one exact
packet-useful surface.

This note does **not** claim:

- one new north scientific closure,
- one new likelihood result,
- one new published `A209` analysis,
- or endorsement of `QCT`.

It claims something narrower and operationally useful:

- the `A209` MG-MAMPOSSt-ready input floor is no longer one guess inferred
  from public hooks only,
- because the mailbox-side authority chain now resolves the processed
  member-catalog footing,
  the native parameter-file footing,
  and the operative velocity-error rule.

## Short digest

The combined outside thread gives six usable points:

1. `Lorenzo Pizzuti` clarified that publicly available clusters like `A209`
   require one processing step beyond the raw public `CLASH-VLT` release,
2. he pointed to `Biviano et al. 2026` as the post-interloper processed
   stage needed for MG-MAMPOSSt-ready use,
3. he said he did not have permission to share the post-processed `A209`
   table himself and directed the request to `Andrea Biviano`,
4. `Andrea Biviano` sent `A209_members.dat`,
5. `Lorenzo Pizzuti` later surfaced `parsgT_A209.txt`,
6. `Andrea Biviano` fixed the velocity-error rule at `153 km/s` for all
   galaxies because the spectra came from the low-resolution `VLT/VIMOS`
   setup, with repeated-measurement support cited there.

## Exact mirrored local floor

The packet now carries explicit local mirrors of the two input-side files:

- `00_READ_FIRST/EXTERNAL_SOURCE_MIRRORS/PIZZUTI_BIVIANO_A209_20260413_20260416/A209_members.dat`
- `00_READ_FIRST/EXTERNAL_SOURCE_MIRRORS/PIZZUTI_BIVIANO_A209_20260413_20260416/parsgT_A209.txt`

The mirrored `A209_members.dat` surface carries:

- one comment header naming `Annunziatella et al. (2016)`,
- one clustercentric-distance column in `kpc`,
- one rest-frame-velocity column in `km/s`,
- and `926` non-comment member rows.

The mirrored `parsgT_A209.txt` surface carries:

- the native target-specific parameter grammar for the `A209` run,
- including the cluster redshift, radius bounds, model selections,
  parameter-step structure, and lensing-prior switches.

## What this strengthens

This outside clarification strengthens the packet in four exact ways:

1. it blocks the false reading that raw public `CLASH-VLT` alone is already
   the MG-MAMPOSSt-ready `A209` kinematic input,
2. it fixes one exact three-part local reproducibility floor for `A209`:
   `A209_members.dat` + `parsgT_A209.txt` + uniform `153 km/s`,
3. it turns the `A209` input lane from one inferred reconstruction problem
   into one explicit author-touch input surface,
4. it removes one major ambiguity in how the `A209` phase-space input should
   be read.

## What this does **not** do

This clarification does **not** do any of the following:

- produce one new cluster-likelihood consumer,
- produce one new target-side scientific result,
- close the broader north certification gap,
- or convert source-touch clarification into endorsement.

## Exact operational consequence

The outward-safe packet reading for `A209` should now remain:

- raw public `CLASH-VLT` = not yet the final processed MG-MAMPOSSt-ready
  member catalog,
- `A209_members.dat` = the interloper-free member-side footing,
- `parsgT_A209.txt` = the native target-specific parameter footing,
- `153 km/s` uniform velocity error = the operative phase-space uncertainty
  rule for the spectroscopic sample.

## Mirror integrity note

Two separate local raw-source holdings of `A209_members.dat` were found and
they match exactly at the file-hash level.

So this packet does not rely only on one mailbox memory sentence about that
catalog; it now carries one stable local mirrored copy of the same table.

## Bottom line

This is one real outside processed-input clarification win.

It does **not** create one new scientific closure.

It does remove one major `A209` input-authority ambiguity, and it now carries
the mirrored processed member table, the mirrored native parameter file, and
the fixed velocity-error rule together as one explicit runtime-input floor.
