# Current Sovereign Final Open State Card

Date: `2026-06-14`

Purpose:

Expose the final live-bank reread in one reviewer-readable front-door note.

## Short verdict

The remaining live bank is now:

- `G1`
- `G5`
- `G7`
- `G8`

This is an event-owned tetrad.

It is not one still-spendable internal packet field below the current
declared ceiling.

## Dependent reading

The dependent gates are only:

- `D6` under `G5`
- `D8` under `G7`
- `D9` above `G7/G8`

## Execution consequence

The current execution consequence is:

1. run `G7` now
2. prepare `G5` now
3. time-box `G1`
4. launch `G8` after the first real `G7` dispatch
5. treat blind holdout as one above-bank strike

## Read with

- `CURRENT_REMAINING_OPEN_BANK_IS_EVENT_OWNED_TETRAD_AFTER_G1_G11_G6_D7_AND_TRIAD_LANDING_NOTE_20260614.md`
- `CURRENT_ABOVE_BANK_BLIND_HOLDOUT_STRIKE_NOTE_20260614.md`
- `CURRENT_BLIND_HOLDOUT_QCT_VS_MOND_PROGRAM_OBJECT_MATERIALIZED_NOTE_20260614.md`
- `CURRENT_G5_MACS1206_TERMINAL_CARRIER_ARRIVAL_GRAMMAR_NOTE_20260611.md`
- `CURRENT_G7_FORMAL_REVIEW_LAUNCH_GRAMMAR_AND_CURRENT_STATE_NOTE_20260612.md`
