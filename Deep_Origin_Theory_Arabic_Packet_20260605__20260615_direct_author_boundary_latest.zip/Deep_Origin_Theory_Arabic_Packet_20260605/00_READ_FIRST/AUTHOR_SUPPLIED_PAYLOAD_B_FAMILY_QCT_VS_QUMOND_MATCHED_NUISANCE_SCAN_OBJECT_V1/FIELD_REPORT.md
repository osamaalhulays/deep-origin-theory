# Author-Supplied Family `QCT` vs `QUMOND` Matched-Nuisance Field Report

Date: `2026-06-13`

## Short verdict

This object does **not** ask whether the author-supplied family shows an empirical
`gobs > gbar` gap. That part was already materialized.

It asks a narrower and harder question:

- under the same one-parameter stellar/bulge matched-nuisance grammar
- and under the same `obs-only` likelihood objective
- where, if anywhere, does the current bounded historical `QCT`
  `artifact_emulator` lane actually beat `QUMOND`?

## Family result

- scanned cases: `49` / `49`
- `QCT`-preferred cases: `18`
- `QUMOND`-preferred cases: `31`
- numerical ties: `0`
- decisive `QCT` cases (`ΔAIC <= -10`): `11`
- decisive `QUMOND` cases (`ΔAIC >= +10`): `20`

## Strongest `QCT` side

- `NGC3198`: `Δloglike = 76.840298`, `ΔAIC = -153.680596`, `rank = None`
- `CVIDWA`: `Δloglike = 73.238824`, `ΔAIC = -146.477648`, `rank = None`
- `NGC2541`: `Δloglike = 63.259770`, `ΔAIC = -126.519540`, `rank = 2`
- `NGC2403`: `Δloglike = 61.553345`, `ΔAIC = -123.106691`, `rank = None`
- `IC2574`: `Δloglike = 49.649391`, `ΔAIC = -99.298783`, `rank = None`

## Strongest `QUMOND` side

- `DDO154`: `Δloglike = -688.153002`, `ΔAIC = 1376.306003`, `rank = None`
- `NGC4736`: `Δloglike = -546.371671`, `ΔAIC = 1092.743342`, `rank = None`
- `NGC7793`: `Δloglike = -292.383552`, `ΔAIC = 584.767104`, `rank = 3`
- `WLM`: `Δloglike = -62.318046`, `ΔAIC = 124.636091`, `rank = None`
- `LVHIS078`: `Δloglike = -48.729661`, `ΔAIC = 97.459322`, `rank = None`

## Clean-first head translation

- top-11 clean-first cases scanned: `11`
- `QCT`-preferred inside top-11: `1`
- all-positive empirical cases scanned: `40`
- `QCT`-preferred inside all-positive empirical cases: `14`

## Scope ceiling

- `QCT` here remains explicitly the bounded historical `artifact_emulator` lane
- no `G4` / `Form A/B/C/D` promotion
- no theory-side authoring claim
- no family-wide public superiority claim beyond this bounded historical-lane field map
