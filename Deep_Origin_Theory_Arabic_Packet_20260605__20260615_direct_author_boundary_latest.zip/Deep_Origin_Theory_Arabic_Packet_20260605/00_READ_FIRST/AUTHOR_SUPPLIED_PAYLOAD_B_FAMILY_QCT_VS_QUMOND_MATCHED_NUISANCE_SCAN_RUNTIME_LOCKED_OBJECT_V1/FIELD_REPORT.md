# Author-Supplied Family `QCT` vs `QUMOND` Matched-Nuisance Field Report

Date: `2026-06-13`

## Short verdict

This object does **not** ask whether the author-supplied family shows an empirical
`gobs > gbar` gap. That part was already materialized.

It asks a narrower and harder question:

- under the same one-parameter stellar/bulge matched-nuisance grammar
- and under the same `obs-only` likelihood objective
- where, if anywhere, does the current bounded historical `QCT`
  `artifact_emulator` lane actually beat `QUMOND`?

## Family result

- scanned cases: `49` / `49`
- `QCT`-preferred cases: `7`
- `QUMOND`-preferred cases: `42`
- numerical ties: `0`
- decisive `QCT` cases (`ΔAIC <= -10`): `4`
- decisive `QUMOND` cases (`ΔAIC >= +10`): `37`

## Strongest `QCT` side

- `NGC3992`: `Δloglike = 28.278080`, `ΔAIC = -56.556160`, `rank = 4`
- `LVHIS077`: `Δloglike = 23.731041`, `ΔAIC = -47.462082`, `rank = 5`
- `LVHIS072`: `Δloglike = 14.007754`, `ΔAIC = -28.015508`, `rank = 6`
- `NGC4725`: `Δloglike = 7.980997`, `ΔAIC = -15.961994`, `rank = None`
- `DDO210`: `Δloglike = 0.670719`, `ΔAIC = -1.341437`, `rank = None`

## Strongest `QUMOND` side

- `NGC2841`: `Δloglike = -1832.988409`, `ΔAIC = 3665.976818`, `rank = None`
- `IC2574`: `Δloglike = -948.668916`, `ΔAIC = 1897.337833`, `rank = None`
- `NGC5055`: `Δloglike = -855.640038`, `ΔAIC = 1711.280076`, `rank = None`
- `NGC2541`: `Δloglike = -523.503156`, `ΔAIC = 1047.006313`, `rank = 2`
- `DDO154`: `Δloglike = -390.884468`, `ΔAIC = 781.768935`, `rank = None`

## Clean-first head translation

- top-11 clean-first cases scanned: `11`
- `QCT`-preferred inside top-11: `3`
- all-positive empirical cases scanned: `40`
- `QCT`-preferred inside all-positive empirical cases: `7`

## Scope ceiling

- `QCT` here remains explicitly the bounded historical `artifact_emulator` lane
- no `G4` / `Form A/B/C/D` promotion
- no theory-side authoring claim
- no family-wide public superiority claim beyond this bounded historical-lane field map
