# G4 `NGC4214` First Non-Toy `Form D` Run Reviewer Object

Date: `2026-06-12`

This note exists for one bounded reason:

if the packet says that the first lawful non-toy `NGC4214` run is the event
that retires `G4`, retires `D3`, and wakes `D4`, this is the reviewer-facing
object that now carries that statement operationally rather than narratively.

Read:

- `G4_NGC4214_FIRST_NONTOY_FORMD_RUN_V1/01_BACKBONE/MANUSCRIPT.md`
- `G4_NGC4214_FIRST_NONTOY_FORMD_RUN_V1/04_OUTPUTS/G4_FIRST_NONTOY_FORMD_RUN_REPORT.md`
- `G4_NGC4214_FIRST_NONTOY_FORMD_RUN_V1/04_OUTPUTS/G4_CROSSING_ADJUDICATION.json`

What is bundled here:

- one frozen production input triple,
- one frozen observed-row file,
- one packet-local replay engine,
- one packet-local reproduction runner,
- one canonical `Form A` table,
- one canonical `QCT` prediction-row table,
- one canonical comparison stack,
- and one canonical likelihood summary.

What is **not** claimed here:

- no `H0`,
- no `BAO/CMB`,
- no absolute-scale authority,
- and no cosmology completion.

This is one bounded first-comparison-stack object only.
