# Clean-First Empirical Reserve Capsule — author-supplied `PAYLOAD_B`

Date: `2026-06-13`

Status: `bounded outward-facing capsule`

Purpose:

This capsule answers one narrow reviewer question directly:

Is `NGC1313` only one isolated named case, or does the landed author-supplied `PAYLOAD_B` family
`PAYLOAD_B` family already carry one structured reserve behind it?

Short answer:

- `yes, one structured reserve already exists in bounded form`

## What is frozen here

The bounded reserve claim frozen here is:

- behind the first named case `NGC1313`, the landed author-supplied `PAYLOAD_B` family
  already contains one reviewer-visible clean-first reserve of `11` galaxies
  and `184` observed rows at empirical `gobs/gbar` scope
- the top `3` reserve cases are `NGC1313`, `NGC2541`, and `NGC7793`
- those top `3` cases alone already carry `100` observed rows

This is **not** yet:

- one theory-side reserve
- one `QCT` prediction reserve
- one matched-nuisance reserve comparison
- or one differential superiority claim

## Why this reserve is real

The reserve is not assembled rhetorically.

It is inherited exactly from the already frozen clean-first rule and preserves
the same local discipline:

- all `11` reserve galaxies remain rowwise comparison-ready
- all `11` keep zero duplicate-radius blocks
- all `11` keep zero negative-`VH2` rows
- all `11` keep zero zero-fill stellar and bulge sentinels
- theory-side authoring eligibility remains `0`

So the reserve is not a post hoc showcase.

It is the already frozen clean-first subfamily made reviewer-visible in one
compact object.

## Present reserve localization

The current reserve stack now reads:

- sample-wide empirical family = `49` galaxies, `1082` rows
- strict clean-first subfamily = `11` galaxies, `184` rows
- first named focused case = `NGC1313`
- second named focused case = `NGC2541`
- third named focused case = `NGC7793`
- structured top-3 reserve = `NGC1313`, `NGC2541`, `NGC7793`, totaling `100`
  rows

## Why this still remains bounded

This reserve is real, but it remains **strictly bounded**.

The packet does **not** yet publish for this reserve:

- one theory-side source profile family
- one `QCT` prediction-row family
- one matched-nuisance fairness execution
- or one named competitor verdict

So the honest reading is not:

- “the reserve already closes the theory-side lane”

The honest reading is:

- the packet now has one focused first empirical case and one structured
  reserve behind it
- and that reserve already carries one second named focused case
- and that reserve now has its full top-`3` named trio materialized
- both are reviewer-visible
- and both remain empirical-only

## Short outward-safe wording

One outward-safe summary sentence is:

> The landed author-supplied `PAYLOAD_B` lane is no longer only one sample-wide
> admissibility family plus one isolated named case: behind `NGC1313`, the
> packet now carries one reviewer-visible clean-first reserve of `11` galaxies
> and `184` observed rows, with `NGC1313`, `NGC2541`, and `NGC7793` forming a
> top-3 reserve of `100` rows at present empirical `gobs/gbar` scope.

## Use rule

Use this capsule to answer:

- “Is the first named author-supplied case isolated, or does it already sit inside a
  structured reserve?”

Do **not** use it to claim:

- one theory-side closure
- one fairness-grade comparator result
- or one whole-program victory
