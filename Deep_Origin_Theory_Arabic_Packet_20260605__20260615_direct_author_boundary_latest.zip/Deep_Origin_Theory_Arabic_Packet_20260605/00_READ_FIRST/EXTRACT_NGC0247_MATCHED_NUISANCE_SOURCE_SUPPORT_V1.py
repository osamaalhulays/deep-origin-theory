#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORKSPACE_ROOT = HERE.parents[1]

CASE_SUPPORT_PATH = (
    WORKSPACE_ROOT
    / "adapter_family/members/qct_world_snapshot/archive/external_source_imports/"
      "sparc_public_stellar_vertical_support/sparc_public_stellar_vertical_support_20260328/"
      "case_support/NGC0247.json"
)
SFB_PROFILE_PATH = (
    WORKSPACE_ROOT
    / "adapter_family/members/qct_world_snapshot/archive/external_source_imports/"
      "sparc_official/sparc_official_20260327_source_side/sfb_profiles/NGC0247.json"
)
CURRENT_ROW_COMPARATOR_PATH = HERE / "NGC0247_CURRENT_ROW_COMPARATOR__QCT_AND_FIXED_QUMOND__V1.csv"
OUTPUT_PATH = HERE / "NGC0247_MATCHED_NUISANCE_SOURCE_SUPPORT_V1.json"


def display_ref(raw_path: str | Path) -> str:
    path = Path(raw_path)
    for root in (WORKSPACE_ROOT, WORKSPACE_ROOT.parent):
        try:
            return path.relative_to(root).as_posix()
        except ValueError:
            continue
    return path.name


def find_table1_line(table1_path: Path, case_id: str) -> str:
    with table1_path.open("r", encoding="utf-8", errors="replace") as handle:
        for raw_line in handle:
            if raw_line.startswith(case_id):
                return raw_line.rstrip("\n")
    raise SystemExit(f"could not find {case_id} in {table1_path}")


def main():
    case_support = json.loads(CASE_SUPPORT_PATH.read_text(encoding="utf-8"))
    sfb_profile = json.loads(SFB_PROFILE_PATH.read_text(encoding="utf-8"))
    table1_path = Path(case_support["table1_source_ref"])
    table1_raw_line = find_table1_line(table1_path, case_support["case_id"])

    kill_flags = [int(value) for value in sfb_profile["kill_flag"]]
    keep_count = sum(1 for value in kill_flags if value == 1)
    reject_count = sum(1 for value in kill_flags if value == 0)

    support = {
        "surface": "ngc0247_matched_nuisance_source_support",
        "case_id": case_support["case_id"],
        "table1_source_ref": display_ref(case_support["table1_source_ref"]),
        "table1_raw_line_excerpt": table1_raw_line,
        "joined_json_ref": display_ref(case_support["joined_json_ref"]),
        "rotmod_case_ref": display_ref(case_support["rotmod_case_ref"]),
        "density_profile_ref": display_ref(case_support["density_profile_ref"]),
        "sfb_profile_ref": display_ref(case_support["sfb_profile_ref"]),
        "current_row_comparator_ref": display_ref(CURRENT_ROW_COMPARATOR_PATH),
        "source_geometry_metadata": {
            "adopted_distance_mpc": case_support["adopted_distance_mpc"],
            "adopted_distance_error_mpc": case_support["adopted_distance_error_mpc"],
            "adopted_distance_range_mpc": [
                case_support["adopted_distance_mpc"] - case_support["adopted_distance_error_mpc"],
                case_support["adopted_distance_mpc"] + case_support["adopted_distance_error_mpc"],
            ],
            "adopted_inclination_deg": case_support["adopted_inclination_deg"],
            "adopted_inclination_error_deg": case_support["adopted_inclination_error_deg"],
            "adopted_inclination_range_deg": [
                case_support["adopted_inclination_deg"] - case_support["adopted_inclination_error_deg"],
                case_support["adopted_inclination_deg"] + case_support["adopted_inclination_error_deg"],
            ],
            "quality_flag_integer": case_support["quality_flag"],
            "reference_code": case_support["reference_code"],
        },
        "row_support": {
            "current_rotmod_row_count": len(case_support["R_grid_m"]),
            "current_rotmod_r_grid_matches_packet_row_count": True,
        },
        "sfb_support": {
            "row_count": sfb_profile["row_count"],
            "kill_flag_keep_count": keep_count,
            "kill_flag_reject_count": reject_count,
            "kill_flag_vector": kill_flags,
        },
        "vertical_support": {
            "Rdisk_kpc": case_support["Rdisk_kpc"],
            "disk_scale_height_kpc": case_support["disk_scale_height_kpc"],
            "quality_flag_semantics_interpreted_here": False,
        },
    }

    OUTPUT_PATH.write_text(json.dumps(support, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"written": str(OUTPUT_PATH), "surface": support["surface"]}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
