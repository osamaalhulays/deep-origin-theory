# Clean-First Isolated Puncture Topology Capsule

Date: `2026-06-13`

## Capsule

Inside the current `11`-galaxy clean-first shortlist, the fair present reading
is not one uninterrupted positive block and not one general post-rank-`7`
collapse.

It is:

- one contiguous all-positive head through rank `7`
- one isolated puncture at rank `8` on `LVHIS055`
- one positive tail that still survives on ranks `9..11`

## Exact numbers

- clean-first galaxies: `11`
- all-positive clean-first galaxies: `10`
- contiguous all-positive head: `7` galaxies / `159` rows
- isolated puncture: `LVHIS055` with `1` nonpositive row
- positive tail after the puncture: `3` galaxies / `18` rows

## Ceiling

This capsule is empirical `gobs/gbar` topology only.
