# Current `G1` Triad Noncollapse And Conditional-Crossing Demotion

Date: `2026-06-11`

Purpose:

This note protects one exact distinction:

- the above-tooth triad remains exact,
- but it no longer survives as one flat coequal daily burden under present
  materials.

## Short verdict

The fair current reading is:

- the exact triad still remains:
  same-route authority crossing,
  real reviewer-visible `Form D`,
  or genuinely fired typed `U2`
- but after current-route witness rejection,
  current-route `Form D` rejection,
  typed-`U2` not-yet-fired adjudication,
  event-layer exhaustion,
  and fail-fast freshness gating,
  same-route crossing is no longer one coequal first-order daily head on
  present materials
- it now survives only as one conditional wake class:
  it becomes first-order again only if one genuinely fresh witness-grade
  candidate appears and survives both freshness routing and the crossing gate
- the direct forward-routing classes above the tooth are therefore:
  fresh `Form D`,
  or fired typed `U2`

## What this does and does not mean

This note does **not** delete crossing from the route grammar.

It means something narrower:

- crossing remains a lawful future class,
- but it is no longer one free-standing daily replay front on the same
  scanned local materials.

So the mature reading is:

- exact triad preserved,
- current burden asymmetric,
- crossing conditional,
- and `Form D` / fired `U2` remain the two direct forward classes above the
  tooth.

## Read with

- `CURRENT_POST_CAGE_EVENT_LAYER_INTAKE_GATED_EXHAUSTION_AND_WATCH_ONLY_STATE_NOTE_20260611.md`
- `CURRENT_POST_CAGE_FRESH_EVENT_REOPENER_INTAKE_GATE_NOTE_20260611.md`
- `POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_WITNESS_DECISION_GATE_REVIEWER_OBJECT_NOTE_20260611.md`
- `POST_CAGE_BRANCH_U1_FORMD_ENGINE_DECISION_GATE_REVIEWER_OBJECT_NOTE_20260611.md`
- `POST_CAGE_BRANCH_U1_TYPED_U2_TRIGGER_ADJUDICATION_REVIEWER_OBJECT_NOTE_20260610.md`
