# Author-Supplied `PAYLOAD_B` `LVHIS072` Sixth Clean Empirical Rowcase Report

Date: `2026-06-13`

## Short verdict

`LVHIS072` is now materialized as the sixth focused clean empirical case above
the landed author-supplied `PAYLOAD_B` family.

## Exact present shape

- target galaxy: `LVHIS072`
- clean-first shortlist rank: `6`
- observed rows: `12`
- radius range: `0.32` to `7.45` kpc
- exact interpolation rows: `1`
- linear interpolation rows: `11`
- all rows stay comparison-ready: `true`
- all rows keep clean-first status: `true`
- all rows keep positive `log10(gobs) - log10(gbar)`: `true`
- `delta` range: `0.21278765723040038` to `1.265443438278682`
- `delta` median: `0.8897723011054728`
- `gbar` peak radius: `0.97` kpc
- `gbar` is nonincreasing after its peak: `true`

## Exact current ceiling

This object gives one focused empirical rowcase only.

It does not yet give:

- one theory-side promotion
- one matched-nuisance comparison
- one competitor verdict
