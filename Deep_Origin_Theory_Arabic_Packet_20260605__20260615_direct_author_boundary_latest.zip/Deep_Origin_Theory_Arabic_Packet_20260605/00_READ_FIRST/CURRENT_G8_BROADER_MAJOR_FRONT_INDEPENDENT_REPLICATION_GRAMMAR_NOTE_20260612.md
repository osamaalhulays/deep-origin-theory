# Current `G8` Broader Major-Front Independent Replication Grammar

Date: `2026-06-12`

Purpose:

Freeze the exact current reading of what already counts under `G8`, and what
still does not.

## Short verdict

The fair current reading is:

- one bounded outside packet-reproduction pass is already real
- that lower rung is already banked
- but no materially independent broader replication wave has yet landed on
  the major live fronts

So `G8` remains open.

## What already landed at the bounded lower rung

The current bounded outside rerun already established that:

- `327` packet file `SHA` values matched
- bundled scripts reran cleanly
- declared numbers reproduced to `<= 2e-6`
- `MACS1206` external-`FITS` absence was handled as documented skip-safe mode

This is real.

But it is still only:

- bounded packet reproduction,
  not broader major-front independent replication

## Exact remaining wound

What still remains is:

- one materially independent replication effort
- broader than the current bounded packet surface
- and real on the major live scientific fronts

## What does not close `G8`

The following do **not** close `G8`:

- outside technical agreement alone
- one bounded packet rerun alone
- internal author reruns
- skip-safe reproduction alone

## Read with

- `CURRENT_D9_BROADER_OUTSIDE_UPTAKE_NON_CLOSURE_NOTE_20260612.md`

