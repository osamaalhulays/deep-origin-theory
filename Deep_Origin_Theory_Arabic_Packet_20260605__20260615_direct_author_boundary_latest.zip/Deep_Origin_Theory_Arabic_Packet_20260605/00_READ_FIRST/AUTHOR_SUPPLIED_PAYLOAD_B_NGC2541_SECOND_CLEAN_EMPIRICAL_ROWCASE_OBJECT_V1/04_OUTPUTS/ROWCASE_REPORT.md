# Author-Supplied `PAYLOAD_B` `NGC2541` Second Clean Empirical Rowcase Report

Date: `2026-06-13`

## Short verdict

`NGC2541` is now materialized as the second focused clean empirical case above
the landed author-supplied `PAYLOAD_B` family.

## Exact present shape

- target galaxy: `NGC2541`
- clean-first shortlist rank: `2`
- observed rows: `31`
- radius range: `0.36` to `21.76` kpc
- exact interpolation rows: `2`
- linear interpolation rows: `29`
- all rows stay comparison-ready: `true`
- all rows keep clean-first status: `true`
- all rows keep positive `log10(gobs) - log10(gbar)`: `true`
- `delta` range: `0.207124258777581` to `0.6422199997508269`
- `delta` median: `0.5466898458483325`
- `gbar` peak radius: `1.07` kpc
- `gbar` is nonincreasing after its peak: `true`

## Exact current ceiling

This object gives one focused empirical rowcase only.

It does not yet give:

- one theory-side promotion
- one matched-nuisance comparison
- one competitor verdict
