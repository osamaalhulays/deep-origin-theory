# Focus Selection Rationale

Date: `2026-06-13`

`NGC2541` is not selected rhetorically.

It is selected because the already frozen clean-first shortlist places it at
rank `2` under the packet-local rule:

- `rows_desc_then_gbar_span_desc_then_name`

## What this means exactly

The packet is not inventing a second showcase by taste.

It is simply extracting the next lawful focused case from the already frozen
reserve behind `NGC1313`.

## Why this is useful

This gives one narrower current gain:

- the reserve is no longer visible only through one first case and one abstract
  reserve ledger
- it now already carries one second named focused case as well

## What this still does not mean

This still does **not** mean:

- one theory-side promotion has begun
- one fairness-grade differential lane has begun
- or one full named-case chain has already closed
