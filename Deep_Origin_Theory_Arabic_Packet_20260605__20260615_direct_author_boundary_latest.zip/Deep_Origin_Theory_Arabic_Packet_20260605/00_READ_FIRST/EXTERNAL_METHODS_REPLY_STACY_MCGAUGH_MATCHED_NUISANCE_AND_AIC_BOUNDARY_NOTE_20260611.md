# External Methods Reply — Stacy McGaugh — Matched-Nuisance And AIC Boundary

Date: `2026-06-11`

Status: `outside methods-side clarification digested with direct fairness follow-up confirmation`

## Purpose

Digest the external methods-side reply into exact packet-useful consequences
without laundering it into endorsement.

This note does **not** claim:

- endorsement of `QCT`,
- endorsement of the current packet as a journal paper,
- or resolution of the larger `MOND` versus dark-matter model-comparison
  problem.

It claims something narrower and useful:

- one outside methods-side human clarification has now landed on nuisance
  symmetry,
  independent-prior handling,
  and the limits of `AIC/BIC`-style superiority language.

## Short digest

The reply gives five useful points:

1. nuisance parameters should be treated the same on both sides,
2. independently measured quantities like distance and inclination naturally
   support Gaussian prior treatment using their quoted measurement
   uncertainty,
3. stellar mass-to-light ratio remains judgment-bearing and model-dependent,
4. `AIC/BIC`-style penalties are not felt as satisfactory for cross-family
   comparisons where extra parameters open enormously unequal effective
   parameter-space volumes,
5. superiority remains one judgment-bearing question that current statistics
   do not fully settle.

## 1. What this strengthens in the current packet

This reply strengthens the current packet in three exact ways:

1. it supports the existing matched-nuisance boundary that what must match is
   the fitting procedure rather than forced equality of fitted nuisance
   values,
2. it supports a later stronger route in which independently measured
   nuisance quantities can be introduced symmetrically through explicit
   priors,
3. it strengthens the current ban on laundering case-level differential
   `AIC/BIC` into unconditional physical-superiority language.

## 2. What this does **not** damage

This reply does **not** damage the current packet's narrow allowed
differential sentence.

The current packet is not claiming:

- Bayesian evidence,
- whole-family `MOND/QUMOND` total defeat,
- or cross-family dark-matter-halo superiority.

It is claiming something narrower:

- one procedural `QCT` versus `QUMOND` differential sentence under symmetric
  matched-nuisance treatment at the current packet ceiling.

The reply is compatible with that narrower sentence.

## 3. What this newly blocks

This reply newly blocks three tempting drifts:

1. treating `AIC/BIC` as if it were one final superiority oracle across
   physically unequal model families,
2. pretending that one mass-to-light prior is neutral or model-free,
3. pretending that "same nuisance treatment" means identical nuisance values
   rather than symmetric treatment law.

## 4. Exact operational consequence

The outward-safe packet grammar should now remain:

- procedural matched-nuisance preference language for the current
  `QCT`/`QUMOND` differential shell,
- explicit caution on `Upsilon`,
- and no transfer from current differential `AIC/BIC` to unconditional
  physical-superiority language.

The later stronger methods path remains:

- explicit symmetric nuisance priors where independently measured quantities
  exist,
- and if desired later,
  one fuller evidence framework rather than `AIC/BIC` alone.

## Bottom line

This is a good external methods-side reply.

It does not hand us a victory slogan.

It does something better:

- it validates the symmetry instinct,
- sharpens the nuisance grammar,
- and narrows the exact place where overclaim would begin.

## Follow-up tightening now confirmed

One later follow-up narrowing was sent back in plain language.

The only returned sentence was:

> "Yes, that sounds fair."

This still does **not** mean:

- endorsement of `QCT` as a whole,
- endorsement of the packet as a journal paper,
- or endorsement of unconditional superiority language.

But it **does** mean something useful and exact:

- the narrowed procedural sentence we are carrying on matched nuisance,
- the caution on `AIC/BIC`,
- and the refusal to launder the result into absolute physical superiority
  language

were not rejected as unfair by the same outside methods-side reader after the
restatement was tightened.

## Operational consequence after the follow-up

The current outward-safe sentence is now better grounded as:

- one procedural differential preference sentence under symmetric matched-
  nuisance treatment,
- with explicit caution that this is not Bayesian evidence,
- not unconditional family-wide superiority,
- and not a final solution to cross-family model-comparison philosophy.

This is stronger than having only our own internal wording.

It is still weaker than formal peer review, and should be used exactly at that
strength and no higher.
