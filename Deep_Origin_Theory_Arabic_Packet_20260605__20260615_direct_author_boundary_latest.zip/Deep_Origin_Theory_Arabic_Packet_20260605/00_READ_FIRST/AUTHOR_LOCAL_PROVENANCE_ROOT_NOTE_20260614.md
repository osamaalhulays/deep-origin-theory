# Author-Local Provenance Root Note

Date: `2026-06-14`

Some packet-visible provenance fields use the token:

- `AUTHOR_LOCAL_PROVENANCE_ROOT/`

This token marks author-side local provenance only.

It does **not** mean that a cold reviewer needs that local tree in order to:

- verify packet-root integrity
- run the reviewer audit bundle
- replay the bundled public packet surfaces

Its role is limited to preserving bounded source/provenance memory for
author-side historical paths without shipping live workstation home-directory
paths inside the public packet body.

If a later author-side replay really needs one of those local historical
artifacts, the token may be rebound privately on the author machine. That
rebinding is outside the public cold-review contract.
