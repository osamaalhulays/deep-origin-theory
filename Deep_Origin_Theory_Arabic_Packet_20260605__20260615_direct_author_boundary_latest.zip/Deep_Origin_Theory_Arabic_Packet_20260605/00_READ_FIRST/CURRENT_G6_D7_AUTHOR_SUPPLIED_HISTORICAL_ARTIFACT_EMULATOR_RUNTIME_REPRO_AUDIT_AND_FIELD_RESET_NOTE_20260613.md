# Current `G6/D7` author-supplied Historical `artifact_emulator` Runtime-Repro Audit And Field Reset Note

Date: `2026-06-13`

Purpose:

State the exact current packet reading after the stored historical
`artifact_emulator` matched-nuisance outputs were rerun under one explicit
runtime lock.

## Short verdict

The old packet-side positive spear:

- `NGC2541`

does **not** survive runtime-locked replay.

So it is retired as one current truthful positive spear.

But the historical lane does not collapse into nothing.

The full runtime-locked family rerun is now explicit, and it yields one new
clean-front positive triad:

- `NGC3992`
- `LVHIS077`
- `LVHIS072`

So the first truthful spear below the stronger later court is now:

- `NGC3992`

That localization is no longer merely preparatory.
The same clean-front triad has now already been consumed into three landed
bounded `Grade 2` stronger-court spears:

- `NGC3992`
- `LVHIS077`
- `LVHIS072`

## Runtime-locked map

Under the explicit runtime lock now used for replay:

- `7` cases favor the bounded historical `QCT` lane
- `42` cases favor `QUMOND`
- `4` are decisive for `QCT`
- `37` are decisive for `QUMOND`

Among the clean-first top-`11`:

- `3` now favor `QCT`
- and they are exactly `NGC3992`, `LVHIS077`, and `LVHIS072`

## What this changes

The packet must no longer read the old historical lane as:

- `NGC2541` positive reserve spear

It must now read it as:

- stale positive spear retired by runtime replay
- runtime-locked family map governs
- `NGC3992` is the first current truthful spear localized by that map
- and that localized triad is now already landed through the stronger court

## What this does not change

This note does **not** reopen:

- raw `PAYLOAD_B` arrival,
- `G4` promotion,
- theory-side authoring,
- or whole-family `QCT > QUMOND`

It corrects one downstream historical comparison layer only.

## Read with

- `CURRENT_G6_D7_AUTHOR_SUPPLIED_FAMILY_MATCHED_NUISANCE_FIELD_MAP_NOTE_20260613.md`
- `CURRENT_G6_D7_PAYLOAD_B_CURRENT_LOCAL_PACKET_EXHAUSTION_AND_WATCH_ONLY_NOTE_20260613.md`
- `CURRENT_MOND_QUMOND_COURT_METHOD_ASCENT_NOTE_20260613.md`
- `AUTHOR_SUPPLIED_PAYLOAD_B_FAMILY_QCT_VS_QUMOND_MATCHED_NUISANCE_SCAN_RUNTIME_LOCKED_OBJECT_V1`
