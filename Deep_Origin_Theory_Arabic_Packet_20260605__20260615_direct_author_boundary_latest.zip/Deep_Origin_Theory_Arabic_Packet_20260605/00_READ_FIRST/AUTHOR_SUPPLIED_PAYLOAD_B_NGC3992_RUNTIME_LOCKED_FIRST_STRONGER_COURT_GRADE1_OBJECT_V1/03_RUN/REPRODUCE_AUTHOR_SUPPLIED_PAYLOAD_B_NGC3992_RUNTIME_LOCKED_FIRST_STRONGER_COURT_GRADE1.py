#!/usr/bin/env python3
from __future__ import annotations

import argparse
import bisect
import csv
import hashlib
import json
import math
import zipfile
from pathlib import Path

import numpy as np
import torch


OBSERVED_SUFFIX = "_vcirc.dat"
BARYON_SUFFIX = "_vbaryons.dat"
OBSERVED_HEADER = "rad_kpc vcirc_km/s e_vcirc"
BARYON_HEADER = (
    "rad_kpc VHI VH2 Vstars eVstars_low eVstars_high Vbulge eVbulge_low eVbulge_high"
)
CASE_ID = "NGC3992"
KPC_IN_M = 3.085677581491367e19
A0_MS2 = 1.2e-10
DELTA_MIN = -0.999
DELTA_MAX = 10.0
SIGMA_FLOOR = 0.01
SCAN_LO = 0.05
SCAN_HI = 1.8
COARSE_STEPS = 3201
REFINEMENT_WINDOWS = ((0.05, 4001), (0.005, 4001), (0.0005, 4001))
TOL = 2.0e-6
EPS = 1.0e-12


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def nonblank_lines(text: str) -> list[str]:
    return [line.strip() for line in text.splitlines() if line.strip()]


def normalize_header(header: str) -> str:
    cleaned = header.strip()
    if cleaned.startswith("#"):
        cleaned = cleaned[1:].strip()
    return " ".join(cleaned.split())


def read_zip_records(zip_path: Path, suffix: str) -> dict[str, dict]:
    records: dict[str, dict] = {}
    with zipfile.ZipFile(zip_path) as archive:
        for member_name in sorted(archive.namelist()):
            if member_name.endswith("/") or not member_name.endswith(suffix):
                continue
            text = archive.read(member_name).decode("utf-8")
            lines = nonblank_lines(text)
            if not lines:
                raise ValueError(f"empty member: {member_name}")
            header = normalize_header(lines[0])
            rows = [line.split() for line in lines[1:]]
            case_id = Path(member_name).name[: -len(suffix)]
            records[case_id] = {
                "member_name": member_name,
                "header": header,
                "rows": rows,
            }
    return records


def signed_square(value: float) -> float:
    return abs(value) * value


def normalize_optional_component(
    row: list[str],
    idx: dict[str, int],
    *,
    value_key: str,
    err_low_key: str,
    err_high_key: str,
    radius: float,
) -> tuple[float, bool]:
    raw = row[idx[value_key]]
    if raw.lower() != "nan":
        return float(raw), False
    low = float(row[idx[err_low_key]])
    high = float(row[idx[err_high_key]])
    if low == 0.0 and high == 0.0:
        return 0.0, True
    raise ValueError(
        f"{CASE_ID}: unexpected {value_key}=nan with nonzero uncertainties at r={radius:.6g}"
    )


def compress_baryonic_record(record: dict) -> tuple[list[dict], dict]:
    header = record["header"].split()
    idx = {name: i for i, name in enumerate(header)}
    if " ".join(header) != BARYON_HEADER:
        raise ValueError(f"{CASE_ID}: unexpected baryonic header")

    duplicate_groups: dict[float, list[dict]] = {}
    negative_vhi_rows = 0
    negative_vh2_rows = 0
    zero_fill_vstars_rows = 0
    zero_fill_vbulge_rows = 0

    for raw_index, row in enumerate(record["rows"]):
        radius = float(row[idx["rad_kpc"]])
        vhi = float(row[idx["VHI"]])
        vh2 = float(row[idx["VH2"]])
        vstars, stars_zero_filled = normalize_optional_component(
            row,
            idx,
            value_key="Vstars",
            err_low_key="eVstars_low",
            err_high_key="eVstars_high",
            radius=radius,
        )
        vbulge, bulge_zero_filled = normalize_optional_component(
            row,
            idx,
            value_key="Vbulge",
            err_low_key="eVbulge_low",
            err_high_key="eVbulge_high",
            radius=radius,
        )
        negative_vhi_rows += int(vhi < 0.0)
        negative_vh2_rows += int(vh2 < 0.0)
        zero_fill_vstars_rows += int(stars_zero_filled)
        zero_fill_vbulge_rows += int(bulge_zero_filled)
        duplicate_groups.setdefault(radius, []).append(
            {
                "raw_index": raw_index,
                "signed_vhi2_km2_s2": signed_square(vhi),
                "signed_vh2_2_km2_s2": signed_square(vh2),
                "vstars2_km2_s2": vstars * vstars,
                "vbulge2_km2_s2": vbulge * vbulge,
            }
        )

    compressed_rows = []
    duplicate_radius_block_count = 0
    for radius in sorted(duplicate_groups):
        items = duplicate_groups[radius]
        duplicate_radius_block_count += int(len(items) > 1)
        compressed_rows.append(
            {
                "r_kpc": radius,
                "source_row_count": len(items),
                "signed_vhi2_km2_s2": sum(item["signed_vhi2_km2_s2"] for item in items)
                / len(items),
                "signed_vh2_2_km2_s2": sum(item["signed_vh2_2_km2_s2"] for item in items)
                / len(items),
                "vstars2_km2_s2": sum(item["vstars2_km2_s2"] for item in items) / len(items),
                "vbulge2_km2_s2": sum(item["vbulge2_km2_s2"] for item in items) / len(items),
            }
        )

    return compressed_rows, {
        "compressed_row_count": len(compressed_rows),
        "duplicate_radius_block_count": duplicate_radius_block_count,
        "negative_vhi_rows": negative_vhi_rows,
        "negative_vh2_rows": negative_vh2_rows,
        "zero_fill_vstars_rows": zero_fill_vstars_rows,
        "zero_fill_vbulge_rows": zero_fill_vbulge_rows,
    }


def interpolate_component(
    radius_grid: list[float],
    values: list[float],
    target_radius: float,
) -> tuple[float, float, float, str]:
    if target_radius < radius_grid[0] or target_radius > radius_grid[-1]:
        raise ValueError(
            f"{CASE_ID}: observed radius {target_radius:.6g} lies outside baryonic grid "
            f"[{radius_grid[0]:.6g}, {radius_grid[-1]:.6g}]"
        )
    index = bisect.bisect_left(radius_grid, target_radius)
    if index < len(radius_grid) and radius_grid[index] == target_radius:
        return values[index], target_radius, target_radius, "exact"
    left_index = index - 1
    right_index = index
    left_radius = radius_grid[left_index]
    right_radius = radius_grid[right_index]
    left_value = values[left_index]
    right_value = values[right_index]
    weight = (target_radius - left_radius) / (right_radius - left_radius)
    value = left_value + weight * (right_value - left_value)
    return value, left_radius, right_radius, "linear"


def gaussian_loglike_grid(residuals_km_s: np.ndarray, sigma_v_km_s: np.ndarray) -> np.ndarray:
    sigma2 = sigma_v_km_s * sigma_v_km_s
    log_const = np.log(2.0 * math.pi * sigma2)
    return -0.5 * np.sum((residuals_km_s * residuals_km_s) / sigma2 + log_const, axis=1)


class Net(torch.nn.Module):
    def __init__(self, in_dim: int = 6, hidden: int = 64):
        super().__init__()
        self.shared = torch.nn.Sequential(
            torch.nn.Linear(in_dim, hidden),
            torch.nn.GELU(),
            torch.nn.Linear(hidden, hidden),
            torch.nn.GELU(),
        )
        self.delta_head = torch.nn.Linear(hidden, 1)
        self.sigma_head = torch.nn.Linear(hidden, 1)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        h = self.shared(x)
        delta = DELTA_MAX * torch.tanh(self.delta_head(h) / DELTA_MAX)
        delta = torch.clamp(delta, min=DELTA_MIN, max=DELTA_MAX)
        sigma = torch.nn.functional.softplus(self.sigma_head(h)) + SIGMA_FLOOR
        return delta, sigma


def build_case_arrays(observed_record: dict, baryonic_record: dict) -> tuple[dict, dict]:
    if observed_record["header"] != OBSERVED_HEADER:
        raise ValueError(f"{CASE_ID}: unexpected observed header")

    baryonic_rows, audit = compress_baryonic_record(baryonic_record)
    radius_grid = [row["r_kpc"] for row in baryonic_rows]
    signed_vhi2 = [row["signed_vhi2_km2_s2"] for row in baryonic_rows]
    signed_vh2_2 = [row["signed_vh2_2_km2_s2"] for row in baryonic_rows]
    vstars2 = [row["vstars2_km2_s2"] for row in baryonic_rows]
    vbulge2 = [row["vbulge2_km2_s2"] for row in baryonic_rows]

    io = {name: i for i, name in enumerate(observed_record["header"].split())}
    component_rows = []
    observed_rows = []
    for row_index, row in enumerate(observed_record["rows"]):
        r_kpc = float(row[io["rad_kpc"]])
        vobs_km_s = float(row[io["vcirc_km/s"]])
        sigma_v_km_s = float(row[io["e_vcirc"]])
        radius_m = r_kpc * KPC_IN_M
        vhi2_val, left_radius, right_radius, interp_mode = interpolate_component(
            radius_grid, signed_vhi2, r_kpc
        )
        vh22_val, _, _, _ = interpolate_component(radius_grid, signed_vh2_2, r_kpc)
        vstars2_val, _, _, _ = interpolate_component(radius_grid, vstars2, r_kpc)
        vbulge2_val, _, _, _ = interpolate_component(radius_grid, vbulge2, r_kpc)
        observed_rows.append(
            {
                "row_index": row_index,
                "r_kpc": r_kpc,
                "r_m": radius_m,
                "vobs_km_s": vobs_km_s,
                "sigma_v_km_s": sigma_v_km_s,
                "gobs_m_s2": (vobs_km_s * vobs_km_s) * 1_000_000.0 / radius_m,
            }
        )
        component_rows.append(
            {
                "row_index": row_index,
                "r_kpc": r_kpc,
                "left_baryonic_r_kpc": left_radius,
                "right_baryonic_r_kpc": right_radius,
                "interpolation_mode": interp_mode,
                "signed_vhi2_km2_s2": vhi2_val,
                "signed_vh2_2_km2_s2": vh22_val,
                "vstars2_km2_s2": vstars2_val,
                "vbulge2_km2_s2": vbulge2_val,
                "gas_signed_vbar2_km2_s2": vhi2_val + vh22_val,
                "stellar_bulge_vbar2_km2_s2": vstars2_val + vbulge2_val,
            }
        )

    return {
        "observed_rows": observed_rows,
        "component_rows": component_rows,
        "gas_power": np.asarray(
            [row["gas_signed_vbar2_km2_s2"] for row in component_rows], dtype=np.float64
        ),
        "stellar_bulge_power": np.asarray(
            [row["stellar_bulge_vbar2_km2_s2"] for row in component_rows], dtype=np.float64
        ),
        "radii_m": np.asarray([row["r_m"] for row in observed_rows], dtype=np.float64),
        "vobs_km_s": np.asarray([row["vobs_km_s"] for row in observed_rows], dtype=np.float64),
        "sigma_v_km_s": np.asarray(
            [row["sigma_v_km_s"] for row in observed_rows], dtype=np.float64
        ),
        "gobs_m_s2": np.asarray([row["gobs_m_s2"] for row in observed_rows], dtype=np.float64),
    }, audit


def lower_scale_gate(gas_power: np.ndarray, stellar_bulge_power: np.ndarray) -> float | None:
    required = SCAN_LO
    for gas_term, stellar_term in zip(gas_power, stellar_bulge_power):
        if gas_term > 0.0:
            continue
        if stellar_term <= 0.0:
            return None
        needed = math.sqrt(max((-gas_term + EPS) / stellar_term, 0.0))
        required = max(required, needed)
    required *= 1.000000001
    if required > SCAN_HI:
        return None
    return required


def evaluate_qumond_grid(
    scales: np.ndarray,
    gas_power: np.ndarray,
    stellar_bulge_power: np.ndarray,
    radii_m: np.ndarray,
    vobs_km_s: np.ndarray,
    sigma_v_km_s: np.ndarray,
) -> np.ndarray:
    total_vbar2 = gas_power[None, :] + np.square(scales)[:, None] * stellar_bulge_power[None, :]
    valid = np.all(total_vbar2 > 0.0, axis=1)
    loglikes = np.full(scales.shape, -np.inf, dtype=np.float64)
    if not np.any(valid):
        return loglikes
    total_valid = total_vbar2[valid]
    gbar = total_valid * 1_000_000.0 / radii_m[None, :]
    y = gbar / A0_MS2
    nu = 0.5 + np.sqrt(0.25 + 1.0 / y)
    vpred_km_s = np.sqrt(total_valid) * np.sqrt(nu)
    residuals = vobs_km_s[None, :] - vpred_km_s
    loglikes[valid] = gaussian_loglike_grid(residuals, sigma_v_km_s)
    return loglikes


@torch.no_grad()
def evaluate_qct_grid(
    scales: np.ndarray,
    gas_power: np.ndarray,
    stellar_bulge_power: np.ndarray,
    radii_m: np.ndarray,
    vobs_km_s: np.ndarray,
    sigma_v_km_s: np.ndarray,
    model: Net,
    mean: np.ndarray,
    std: np.ndarray,
    gamma: float,
    m_eV: float,
    batch_size: int,
) -> np.ndarray:
    total_vbar2 = gas_power[None, :] + np.square(scales)[:, None] * stellar_bulge_power[None, :]
    valid = np.all(total_vbar2 > 0.0, axis=1)
    loglikes = np.full(scales.shape, -np.inf, dtype=np.float64)
    if not np.any(valid):
        return loglikes

    valid_indices = np.flatnonzero(valid)
    total_valid = total_vbar2[valid]
    vbar_ms = np.sqrt(total_valid) * 1000.0
    rmax_m = float(np.max(radii_m))
    vbarmax_ms = np.max(vbar_ms, axis=1)
    rfrac = np.clip(radii_m / rmax_m, 0.0, 2.0).astype(np.float32)
    vdrop = np.clip(vbar_ms / vbarmax_ms[:, None], 0.0, 10.0)

    features = np.empty((len(valid_indices), radii_m.size, 6), dtype=np.float32)
    features[:, :, 0] = gamma
    features[:, :, 1] = math.log10(m_eV)
    features[:, :, 2] = math.log10(rmax_m)
    features[:, :, 3] = np.log10(vbarmax_ms)[:, None]
    features[:, :, 4] = rfrac[None, :]
    features[:, :, 5] = vdrop.astype(np.float32)
    flat_features = (features.reshape(-1, 6) - mean) / std

    flat_delta = np.empty((flat_features.shape[0],), dtype=np.float64)
    flat_sigma = np.empty((flat_features.shape[0],), dtype=np.float64)
    for start in range(0, flat_features.shape[0], batch_size):
        end = min(start + batch_size, flat_features.shape[0])
        batch = torch.from_numpy(flat_features[start:end]).to(dtype=torch.float32)
        delta_t, sigma_t = model(batch)
        flat_delta[start:end] = delta_t.squeeze(1).cpu().numpy().astype(np.float64)
        flat_sigma[start:end] = sigma_t.squeeze(1).cpu().numpy().astype(np.float64)

    delta = flat_delta.reshape(len(valid_indices), radii_m.size)
    sigma = flat_sigma.reshape(len(valid_indices), radii_m.size)
    physical = np.all(delta > -1.0, axis=1)
    if not np.any(physical):
        return loglikes

    physical_indices = valid_indices[physical]
    delta_physical = delta[physical]
    vbar_ms_physical = vbar_ms[physical]
    v_model_km_s = (vbar_ms_physical * np.sqrt(1.0 + delta_physical)) / 1000.0
    residuals = vobs_km_s[None, :] - v_model_km_s
    loglikes[physical_indices] = gaussian_loglike_grid(residuals, sigma_v_km_s)
    return loglikes


def maximize_model(evaluator, low: float, high: float) -> tuple[float | None, float | None]:
    if low > high:
        return None, None
    best_scale: float | None = None
    best_ll: float | None = None
    coarse = np.linspace(low, high, COARSE_STEPS)
    coarse_ll = evaluator(coarse)
    if not np.isfinite(coarse_ll).any():
        return None, None
    best_index = int(np.nanargmax(coarse_ll))
    best_scale = float(coarse[best_index])
    best_ll = float(coarse_ll[best_index])

    for half_window, steps in REFINEMENT_WINDOWS:
        lo = max(low, best_scale - half_window)
        hi = min(high, best_scale + half_window)
        grid = np.linspace(lo, hi, steps)
        ll_values = evaluator(grid)
        finite = np.isfinite(ll_values)
        if not np.any(finite):
            continue
        best_index = int(np.nanargmax(ll_values))
        best_scale = float(grid[best_index])
        best_ll = float(ll_values[best_index])
    return best_scale, best_ll


def evaluate_qumond_single(
    scale: float,
    gas_power: np.ndarray,
    stellar_bulge_power: np.ndarray,
    radii_m: np.ndarray,
    vobs_km_s: np.ndarray,
    sigma_v_km_s: np.ndarray,
) -> dict:
    total_vbar2 = gas_power + (scale * scale) * stellar_bulge_power
    if np.any(total_vbar2 <= 0.0):
        raise ValueError(f"{CASE_ID}: non-positive total baryonic power encountered")
    gbar_m_s2 = total_vbar2 * 1_000_000.0 / radii_m
    y = gbar_m_s2 / A0_MS2
    nu = 0.5 + np.sqrt(0.25 + 1.0 / y)
    vbar_km_s = np.sqrt(total_vbar2)
    vpred_km_s = vbar_km_s * np.sqrt(nu)
    residual_km_s = vobs_km_s - vpred_km_s
    chi2_terms = (residual_km_s / sigma_v_km_s) ** 2
    return {
        "scale": scale,
        "gbar_m_s2": gbar_m_s2,
        "log10_gbar_m_s2": np.log10(gbar_m_s2),
        "nu": nu,
        "vbar_km_s": vbar_km_s,
        "vpred_km_s": vpred_km_s,
        "residual_km_s": residual_km_s,
        "chi2_terms": chi2_terms,
        "chi2_total": float(np.sum(chi2_terms)),
        "ll_obs_only": float(gaussian_loglike_grid(residual_km_s[None, :], sigma_v_km_s)[0]),
    }


@torch.no_grad()
def evaluate_qct_single(
    scale: float,
    gas_power: np.ndarray,
    stellar_bulge_power: np.ndarray,
    radii_m: np.ndarray,
    vobs_km_s: np.ndarray,
    sigma_v_km_s: np.ndarray,
    model: Net,
    mean: np.ndarray,
    std: np.ndarray,
    gamma: float,
    m_eV: float,
) -> dict:
    total_vbar2 = gas_power + (scale * scale) * stellar_bulge_power
    if np.any(total_vbar2 <= 0.0):
        raise ValueError(f"{CASE_ID}: non-positive total baryonic power encountered")
    vbar_ms = np.sqrt(total_vbar2) * 1000.0
    rmax_m = float(np.max(radii_m))
    vbarmax_ms = float(np.max(vbar_ms))
    rfrac = np.clip(radii_m / rmax_m, 0.0, 2.0).astype(np.float32)
    vdrop = np.clip(vbar_ms / vbarmax_ms, 0.0, 10.0).astype(np.float32)
    features = np.column_stack(
        [
            np.full_like(rfrac, gamma, dtype=np.float32),
            np.full_like(rfrac, math.log10(m_eV), dtype=np.float32),
            np.full_like(rfrac, math.log10(rmax_m), dtype=np.float32),
            np.full_like(rfrac, math.log10(vbarmax_ms), dtype=np.float32),
            rfrac,
            vdrop,
        ]
    )
    features_n = (features - mean) / std
    features_t = torch.tensor(features_n, dtype=torch.float32)
    delta_t, sigma_delta_t = model(features_t)
    delta_1d = delta_t.squeeze(1).numpy().astype(np.float64)
    sigma_delta_1d = sigma_delta_t.squeeze(1).numpy().astype(np.float64)
    if np.any(delta_1d <= -1.0):
        raise ValueError(f"{CASE_ID}: historical artifact emulator left the physical domain")
    v_model_ms = vbar_ms * np.sqrt(1.0 + delta_1d)
    sigma_model_ms = vbar_ms * (0.5 * sigma_delta_1d / np.sqrt(1.0 + delta_1d))
    residual_km_s = vobs_km_s - (v_model_ms / 1000.0)
    chi2_terms_obs_only = (residual_km_s / sigma_v_km_s) ** 2
    gbar_m_s2 = total_vbar2 * 1_000_000.0 / radii_m
    return {
        "scale": scale,
        "gbar_m_s2": gbar_m_s2,
        "log10_gbar_m_s2": np.log10(gbar_m_s2),
        "vbar_km_s": vbar_ms / 1000.0,
        "vdrop": vdrop.astype(np.float64),
        "delta_1d": delta_1d,
        "sigma_delta_1d": sigma_delta_1d,
        "v_model_km_s": v_model_ms / 1000.0,
        "sigma_model_km_s": sigma_model_ms / 1000.0,
        "residual_km_s": residual_km_s,
        "chi2_terms_obs_only": chi2_terms_obs_only,
        "chi2_total_obs_only": float(np.sum(chi2_terms_obs_only)),
        "ll_obs_only": float(gaussian_loglike_grid(residual_km_s[None, :], sigma_v_km_s)[0]),
    }


def residual_shape_metrics(residuals: np.ndarray, sigma_v_km_s: np.ndarray) -> dict:
    signs = []
    positive_count = 0
    negative_count = 0
    zero_count = 0
    for value in residuals:
        if value > EPS:
            signs.append(1)
            positive_count += 1
        elif value < -EPS:
            signs.append(-1)
            negative_count += 1
        else:
            zero_count += 1
    sign_change_count = sum(signs[i + 1] != signs[i] for i in range(len(signs) - 1))
    if positive_count and not negative_count:
        sign_class = "all_positive_residual"
    elif negative_count and not positive_count:
        sign_class = "all_negative_residual"
    elif positive_count and negative_count:
        sign_class = "mixed_sign_residual"
    else:
        sign_class = "all_zero_residual"
    return {
        "positive_count": positive_count,
        "negative_count": negative_count,
        "zero_count": zero_count,
        "sign_change_count": sign_change_count,
        "sign_class": sign_class,
        "max_abs_residual_km_s": float(np.max(np.abs(residuals))),
        "mean_abs_residual_km_s": float(np.mean(np.abs(residuals))),
        "rms_sigma_units": float(np.sqrt(np.mean((residuals / sigma_v_km_s) ** 2))),
    }


def near_equal(left: float, right: float, tol: float = TOL) -> bool:
    return abs(left - right) <= tol


def build_report(
    qct_summary: dict,
    qumond_summary: dict,
    differential: dict,
    reproduction_checks: dict,
) -> str:
    if differential["grade1_materialized"]:
        short_verdict = """`NGC3992` now lands as one truthful stronger-court positive
consumer under the runtime-locked field.

It now carries one explicit first stronger-court single-case reading at:

- same case: `NGC3992`
- same one-parameter stellar/bulge nuisance grammar on both sides
- same `obs-only` likelihood objective on both sides
- same runtime-locked bounded historical `QCT` `artifact_emulator` lane"""
        consequence = """This is enough for one current-case `Grade 1` materialization:

- same nuisance floor is satisfied
- same objective is satisfied
- both best scales remain interior
- and `QCT` is decisively preferred in the declared lane"""
        mismatch_block = ""
    else:
        short_verdict = """`NGC3992` does **not** currently land as one stronger-court positive
consumer under the runtime-locked declared historical lane.

The same-case reproduction body is real and useful, but it lands negatively:

- same case: `NGC3992`
- same one-parameter stellar/bulge nuisance grammar on both sides
- same `obs-only` likelihood objective on both sides
- same runtime-locked bounded historical `QCT` `artifact_emulator` lane"""
        consequence = """This is **not** enough for `Grade 1` materialization:

- the same nuisance floor is satisfied
- the same objective is satisfied
- both best scales remain interior
- but `QCT` is **not** preferred in the declared lane"""
        mismatch_block = f"""
## Reproduction-lock result

- stored family lock reproduced exactly on `QUMOND` = `{str(reproduction_checks["qumond_ll_best_obs_only_match"]).lower()}`
- stored family lock reproduced exactly on `QCT` = `{str(reproduction_checks["qct_ll_best_obs_only_match"]).lower()}`
- full lock replay passed = `{str(reproduction_checks["all_checks_pass"]).lower()}`

So this object currently functions as one honest correction surface as much as
one comparison surface: the stored family lock does not replay cleanly for the
historical `QCT` lane under the present explicit runtime."""

    return f"""# Author-Supplied `NGC3992` Runtime-Locked First Stronger-Court `Grade 1` Report

Date: `2026-06-13`

## Short verdict

{short_verdict}

## Same-nuisance floor

- `QUMOND` best scale = `{qumond_summary["best_scale"]:.12f}`
- `QCT` best scale = `{qct_summary["best_scale"]:.12f}`
- `QUMOND` lower-bound hit = `{str(qumond_summary["best_scale_at_lower_bound"]).lower()}`
- `QCT` lower-bound hit = `{str(qct_summary["best_scale_at_lower_bound"]).lower()}`
- `QUMOND` upper-bound hit = `{str(qumond_summary["best_scale_at_upper_bound"]).lower()}`
- `QCT` upper-bound hit = `{str(qct_summary["best_scale_at_upper_bound"]).lower()}`

Both best scales remain interior inside the current legal nuisance window.

## Differential result

- `QCT` best `obs-only` loglike = `{differential["qct_ll_best_obs_only"]:.12f}`
- `QUMOND` best `obs-only` loglike = `{differential["qumond_ll_best_obs_only"]:.12f}`
- `Δloglike(QCT-QUMOND)` = `{differential["delta_loglike_qct_minus_qumond_obs_only"]:.12f}`
- `ΔAIC(QCT-QUMOND)` = `{differential["delta_aic_qct_minus_qumond_obs_only"]:.12f}`
- `ΔBIC(QCT-QUMOND)` = `{differential["delta_bic_qct_minus_qumond_obs_only"]:.12f}`

So under the same nuisance floor and the same objective, the current runtime-locked bounded
historical `QCT` lane is {("decisively preferred" if differential["qct_preferred_under_matched_nuisance_obs_only"] else "not preferred")} on `NGC3992`.

## Residual-shape read

- `QUMOND` residual class = `{differential["qumond_residual_shape"]["sign_class"]}`
- `QUMOND` residual sign changes = `{differential["qumond_residual_shape"]["sign_change_count"]}`
- `QUMOND` residual RMS in sigma units = `{differential["qumond_residual_shape"]["rms_sigma_units"]:.12f}`
- `QCT` residual class = `{differential["qct_residual_shape"]["sign_class"]}`
- `QCT` residual sign changes = `{differential["qct_residual_shape"]["sign_change_count"]}`
- `QCT` residual RMS in sigma units = `{differential["qct_residual_shape"]["rms_sigma_units"]:.12f}`

## Court consequence

{consequence}
{mismatch_block}

## Exact ceiling

This still does **not** claim:

- `Grade 2`
- `Grade 3`
- best-dressed lawful family execution
- theory-side promotion
- whole-family `MOND/QUMOND` defeat
"""


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--observed-zip", type=Path, required=True)
    parser.add_argument("--baryons-zip", type=Path, required=True)
    parser.add_argument("--manifest-lock-json", type=Path, required=True)
    parser.add_argument("--family-case-lock-json", type=Path, required=True)
    parser.add_argument("--model-pt", type=Path, required=True)
    parser.add_argument("--norm-json", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    observed_records = read_zip_records(args.observed_zip.resolve(), OBSERVED_SUFFIX)
    baryonic_records = read_zip_records(args.baryons_zip.resolve(), BARYON_SUFFIX)
    if CASE_ID not in observed_records or CASE_ID not in baryonic_records:
        raise ValueError(f"{CASE_ID}: missing from one of the author-supplied zip files")

    manifest_lock = json.loads(args.manifest_lock_json.resolve().read_text(encoding="utf-8"))
    family_lock = json.loads(args.family_case_lock_json.resolve().read_text(encoding="utf-8"))
    gamma = float(manifest_lock["priors"]["gamma"])
    m_eV = float(manifest_lock["priors"]["m_eV"])

    norm = json.loads(args.norm_json.resolve().read_text(encoding="utf-8"))
    mean = np.asarray(norm["mean"], dtype=np.float32)
    std = np.asarray(norm["std"], dtype=np.float32)
    if mean.shape != (6,) or std.shape != (6,):
        raise ValueError("unexpected norm shape for historical 6-feature artifact emulator")

    model = Net()
    model.load_state_dict(torch.load(args.model_pt.resolve(), map_location="cpu"))
    model.eval()

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    arrays, audit = build_case_arrays(observed_records[CASE_ID], baryonic_records[CASE_ID])
    gas_power = arrays["gas_power"]
    stellar_bulge_power = arrays["stellar_bulge_power"]
    radii_m = arrays["radii_m"]
    vobs_km_s = arrays["vobs_km_s"]
    sigma_v_km_s = arrays["sigma_v_km_s"]
    observed_rows = arrays["observed_rows"]
    component_rows = arrays["component_rows"]

    legal_low = lower_scale_gate(gas_power, stellar_bulge_power)
    if legal_low is None:
        raise ValueError(f"{CASE_ID}: no legal positive-total-vbar2 scale window found")

    qumond_eval = lambda scales: evaluate_qumond_grid(
        scales, gas_power, stellar_bulge_power, radii_m, vobs_km_s, sigma_v_km_s
    )
    qct_eval = lambda scales: evaluate_qct_grid(
        scales,
        gas_power,
        stellar_bulge_power,
        radii_m,
        vobs_km_s,
        sigma_v_km_s,
        model,
        mean,
        std,
        gamma,
        m_eV,
        batch_size=65536,
    )

    qumond_best_scale, qumond_best_ll = maximize_model(qumond_eval, legal_low, SCAN_HI)
    qct_best_scale, qct_best_ll = maximize_model(qct_eval, legal_low, SCAN_HI)
    if qumond_best_scale is None or qct_best_scale is None:
        raise ValueError(f"{CASE_ID}: failed to materialize one finite matched-nuisance maximum")

    qumond_fixed = evaluate_qumond_single(
        1.0, gas_power, stellar_bulge_power, radii_m, vobs_km_s, sigma_v_km_s
    )
    qumond_best = evaluate_qumond_single(
        qumond_best_scale, gas_power, stellar_bulge_power, radii_m, vobs_km_s, sigma_v_km_s
    )
    qct_fixed = evaluate_qct_single(
        1.0, gas_power, stellar_bulge_power, radii_m, vobs_km_s, sigma_v_km_s, model, mean, std, gamma, m_eV
    )
    qct_best = evaluate_qct_single(
        qct_best_scale, gas_power, stellar_bulge_power, radii_m, vobs_km_s, sigma_v_km_s, model, mean, std, gamma, m_eV
    )

    delta_loglike = float(qct_best["ll_obs_only"] - qumond_best["ll_obs_only"])
    delta_aic = float((-2.0 * qct_best["ll_obs_only"] + 2.0) - (-2.0 * qumond_best["ll_obs_only"] + 2.0))
    delta_bic = float(
        (-2.0 * qct_best["ll_obs_only"] + math.log(len(observed_rows)))
        - (-2.0 * qumond_best["ll_obs_only"] + math.log(len(observed_rows)))
    )

    reproduction_checks = {
        "case_id": CASE_ID,
        "family_lock_ref": str(args.family_case_lock_json.resolve()),
        "qumond_best_scale_match": near_equal(qumond_best_scale, float(family_lock["qumond_best_scale"])),
        "qct_best_scale_match": near_equal(qct_best_scale, float(family_lock["qct_best_scale"])),
        "qumond_ll_best_obs_only_match": near_equal(
            qumond_best["ll_obs_only"], float(family_lock["qumond_ll_best_obs_only"])
        ),
        "qct_ll_best_obs_only_match": near_equal(
            qct_best["ll_obs_only"], float(family_lock["qct_ll_best_obs_only"])
        ),
        "delta_loglike_match": near_equal(
            delta_loglike, float(family_lock["delta_loglike_qct_minus_qumond_obs_only"])
        ),
        "delta_aic_match": near_equal(
            delta_aic, float(family_lock["delta_aic_qct_minus_qumond_obs_only"])
        ),
        "delta_bic_match": near_equal(
            delta_bic, float(family_lock["delta_bic_qct_minus_qumond_obs_only"])
        ),
        "observed_row_count_match": len(observed_rows) == int(family_lock["observed_row_count"]),
        "compressed_baryonic_row_count_match": audit["compressed_row_count"] == int(family_lock["compressed_baryonic_row_count"]),
    }
    reproduction_checks["all_checks_pass"] = all(reproduction_checks.values())

    qct_summary = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_RUNTIME_LOCKED_QCT_ARTIFACT_EMULATOR_MATCHED_NUISANCE_OBJECT_V1",
        "date": "2026-06-13",
        "case_id": CASE_ID,
        "delta_source": "artifact_emulator",
        "historical_lane_only": True,
        "g4_promotion_claimed": False,
        "observed_row_count": len(observed_rows),
        "compressed_baryonic_row_count": audit["compressed_row_count"],
        "duplicate_radius_block_count": audit["duplicate_radius_block_count"],
        "negative_vhi_rows": audit["negative_vhi_rows"],
        "negative_vh2_rows": audit["negative_vh2_rows"],
        "zero_fill_vstars_rows": audit["zero_fill_vstars_rows"],
        "zero_fill_vbulge_rows": audit["zero_fill_vbulge_rows"],
        "fixed_scale": 1.0,
        "best_scale": qct_best_scale,
        "best_scale_at_lower_bound": near_equal(qct_best_scale, legal_low),
        "best_scale_at_upper_bound": near_equal(qct_best_scale, SCAN_HI),
        "ll_fixed_obs_only": qct_fixed["ll_obs_only"],
        "ll_best_obs_only": qct_best["ll_obs_only"],
        "chi2_fixed_obs_only": qct_fixed["chi2_total_obs_only"],
        "chi2_best_obs_only": qct_best["chi2_total_obs_only"],
        "delta_loglike_best_minus_fixed_obs_only": qct_best["ll_obs_only"] - qct_fixed["ll_obs_only"],
        "delta_aic_best_minus_fixed_obs_only": (2.0 - 2.0 * qct_best["ll_obs_only"]) - (2.0 - 2.0 * qct_fixed["ll_obs_only"]),
        "delta_bic_best_minus_fixed_obs_only": (math.log(len(observed_rows)) - 2.0 * qct_best["ll_obs_only"]) - (math.log(len(observed_rows)) - 2.0 * qct_fixed["ll_obs_only"]),
        "training_manifest_hash": manifest_lock["config_hash"],
        "historical_model_pt_ref": str(args.model_pt.resolve()),
        "historical_model_pt_sha256": sha256(args.model_pt.resolve()),
        "historical_norm_json_ref": str(args.norm_json.resolve()),
        "historical_norm_json_sha256": sha256(args.norm_json.resolve()),
        "raw_observed_zip_ref": str(args.observed_zip.resolve()),
        "raw_baryons_zip_ref": str(args.baryons_zip.resolve()),
        "raw_observed_zip_sha256": sha256(args.observed_zip.resolve()),
        "raw_baryons_zip_sha256": sha256(args.baryons_zip.resolve()),
        "qct_side_prediction_materialized": True,
        "comparison_ready_against_existing_qumond_anchor": True,
        "cosmic_closure_claim": False
    }

    qumond_summary = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_RUNTIME_LOCKED_QUMOND_MATCHED_NUISANCE_ANCHOR_OBJECT_V1",
        "date": "2026-06-13",
        "case_id": CASE_ID,
        "observed_row_count": len(observed_rows),
        "compressed_baryonic_row_count": audit["compressed_row_count"],
        "duplicate_radius_block_count": audit["duplicate_radius_block_count"],
        "negative_vhi_rows": audit["negative_vhi_rows"],
        "negative_vh2_rows": audit["negative_vh2_rows"],
        "zero_fill_vstars_rows": audit["zero_fill_vstars_rows"],
        "zero_fill_vbulge_rows": audit["zero_fill_vbulge_rows"],
        "fixed_scale": 1.0,
        "best_scale": qumond_best_scale,
        "best_scale_at_lower_bound": near_equal(qumond_best_scale, legal_low),
        "best_scale_at_upper_bound": near_equal(qumond_best_scale, SCAN_HI),
        "ll_fixed_obs_only": qumond_fixed["ll_obs_only"],
        "ll_best_obs_only": qumond_best["ll_obs_only"],
        "chi2_fixed": qumond_fixed["chi2_total"],
        "chi2_best": qumond_best["chi2_total"],
        "delta_loglike_best_minus_fixed": qumond_best["ll_obs_only"] - qumond_fixed["ll_obs_only"],
        "delta_aic_best_minus_fixed": (2.0 - 2.0 * qumond_best["ll_obs_only"]) - (2.0 - 2.0 * qumond_fixed["ll_obs_only"]),
        "delta_bic_best_minus_fixed": (math.log(len(observed_rows)) - 2.0 * qumond_best["ll_obs_only"]) - (math.log(len(observed_rows)) - 2.0 * qumond_fixed["ll_obs_only"]),
        "competitor_side_anchor_materialized": True,
        "qct_side_prediction_materialized": False,
        "cosmic_closure_claim": False
    }

    qct_residual_shape = residual_shape_metrics(qct_best["residual_km_s"], sigma_v_km_s)
    qumond_residual_shape = residual_shape_metrics(qumond_best["residual_km_s"], sigma_v_km_s)
    grade1_materialized = (
        delta_loglike > 0.0
        and delta_aic <= -10.0
        and not qct_summary["best_scale_at_lower_bound"]
        and not qct_summary["best_scale_at_upper_bound"]
        and not qumond_summary["best_scale_at_lower_bound"]
        and not qumond_summary["best_scale_at_upper_bound"]
    )

    differential = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_RUNTIME_LOCKED_FIRST_STRONGER_COURT_GRADE1_DIFFERENTIAL_SUMMARY_20260613",
        "date": "2026-06-13",
        "case_id": CASE_ID,
        "scope": "same_case_same_single_nuisance_obs_only_differential__grade1_only",
        "qct_delta_source": "artifact_emulator",
        "same_nuisance_floor": True,
        "same_obs_only_objective": True,
        "best_scales_interior": (
            not qct_summary["best_scale_at_lower_bound"]
            and not qct_summary["best_scale_at_upper_bound"]
            and not qumond_summary["best_scale_at_lower_bound"]
            and not qumond_summary["best_scale_at_upper_bound"]
        ),
        "qct_best_scale": qct_best_scale,
        "qumond_best_scale": qumond_best_scale,
        "qct_ll_best_obs_only": qct_best["ll_obs_only"],
        "qumond_ll_best_obs_only": qumond_best["ll_obs_only"],
        "delta_loglike_qct_minus_qumond_obs_only": delta_loglike,
        "delta_aic_qct_minus_qumond_obs_only": delta_aic,
        "delta_bic_qct_minus_qumond_obs_only": delta_bic,
        "qct_preferred_under_matched_nuisance_obs_only": delta_loglike > 0.0,
        "strength_band": "decisive_qct" if delta_aic <= -10.0 else "nondecisive_or_negative",
        "qumond_residual_shape": qumond_residual_shape,
        "qct_residual_shape": qct_residual_shape,
        "grade1_materialized": grade1_materialized,
        "verdict": (
            "GRADE1_MATCHED_NUISANCE_NON_RESCUE_MATERIALIZED_FOR_NGC3992_IN_CURRENT_RUNTIME_LOCKED_DECLARED_HISTORICAL_LANE"
            if grade1_materialized
            else "GRADE1_NOT_MATERIALIZED_FOR_NGC3992_IN_CURRENT_RUNTIME_LOCKED_DECLARED_HISTORICAL_LANE"
        ),
        "no_grade2_claim": True,
        "no_grade3_claim": True,
        "no_theory_side_promotion": True,
        "cosmic_closure_claim": False
    }

    fixed_qumond_rows = []
    best_qumond_rows = []
    fixed_qct_rows = []
    best_qct_rows = []
    for obs, comp, fq_gbar, fq_loggbar, fq_nu, fq_vbar, fq_vpred, fq_resid, fq_chi2, bq_gbar, bq_loggbar, bq_nu, bq_vbar, bq_vpred, bq_resid, bq_chi2, fdelta, fsigma, fgbar, flogbar, fvbar, fvdrop, fvmodel, fsigmav, fresid, fchi2, bdelta, bsigma, bgbar, blogbar, bvbar, bvdrop, bvmodel, bsigmav, bresid, bchi2 in zip(
        observed_rows,
        component_rows,
        qumond_fixed["gbar_m_s2"],
        qumond_fixed["log10_gbar_m_s2"],
        qumond_fixed["nu"],
        qumond_fixed["vbar_km_s"],
        qumond_fixed["vpred_km_s"],
        qumond_fixed["residual_km_s"],
        qumond_fixed["chi2_terms"],
        qumond_best["gbar_m_s2"],
        qumond_best["log10_gbar_m_s2"],
        qumond_best["nu"],
        qumond_best["vbar_km_s"],
        qumond_best["vpred_km_s"],
        qumond_best["residual_km_s"],
        qumond_best["chi2_terms"],
        qct_fixed["delta_1d"],
        qct_fixed["sigma_delta_1d"],
        qct_fixed["gbar_m_s2"],
        qct_fixed["log10_gbar_m_s2"],
        qct_fixed["vbar_km_s"],
        qct_fixed["vdrop"],
        qct_fixed["v_model_km_s"],
        qct_fixed["sigma_model_km_s"],
        qct_fixed["residual_km_s"],
        qct_fixed["chi2_terms_obs_only"],
        qct_best["delta_1d"],
        qct_best["sigma_delta_1d"],
        qct_best["gbar_m_s2"],
        qct_best["log10_gbar_m_s2"],
        qct_best["vbar_km_s"],
        qct_best["vdrop"],
        qct_best["v_model_km_s"],
        qct_best["sigma_model_km_s"],
        qct_best["residual_km_s"],
        qct_best["chi2_terms_obs_only"],
    ):
        fixed_qumond_rows.append(
            {
                "row_index": obs["row_index"],
                "r_kpc": obs["r_kpc"],
                "vobs_km_s": obs["vobs_km_s"],
                "sigma_v_km_s": obs["sigma_v_km_s"],
                "scale_s": 1.0,
                "gbar_m_s2": fq_gbar,
                "log10_gbar_m_s2": fq_loggbar,
                "nu": fq_nu,
                "vbar_km_s": fq_vbar,
                "v_qumond_km_s": fq_vpred,
                "residual_km_s": fq_resid,
                "chi2_term": fq_chi2,
            }
        )
        best_qumond_rows.append(
            {
                "row_index": obs["row_index"],
                "r_kpc": obs["r_kpc"],
                "vobs_km_s": obs["vobs_km_s"],
                "sigma_v_km_s": obs["sigma_v_km_s"],
                "scale_s": qumond_best_scale,
                "gbar_m_s2": bq_gbar,
                "log10_gbar_m_s2": bq_loggbar,
                "nu": bq_nu,
                "vbar_km_s": bq_vbar,
                "v_qumond_km_s": bq_vpred,
                "residual_km_s": bq_resid,
                "chi2_term": bq_chi2,
            }
        )
        fixed_qct_rows.append(
            {
                "row_index": obs["row_index"],
                "r_kpc": obs["r_kpc"],
                "vobs_km_s": obs["vobs_km_s"],
                "sigma_v_km_s": obs["sigma_v_km_s"],
                "scale_s": 1.0,
                "gbar_m_s2": fgbar,
                "log10_gbar_m_s2": flogbar,
                "vbar_km_s": fvbar,
                "vdrop": fvdrop,
                "delta_qct": fdelta,
                "sigma_delta_qct": fsigma,
                "v_qct_km_s": fvmodel,
                "sigma_model_km_s": fsigmav,
                "residual_km_s": fresid,
                "chi2_term_obs_only": fchi2,
            }
        )
        best_qct_rows.append(
            {
                "row_index": obs["row_index"],
                "r_kpc": obs["r_kpc"],
                "vobs_km_s": obs["vobs_km_s"],
                "sigma_v_km_s": obs["sigma_v_km_s"],
                "scale_s": qct_best_scale,
                "gbar_m_s2": bgbar,
                "log10_gbar_m_s2": blogbar,
                "vbar_km_s": bvbar,
                "vdrop": bvdrop,
                "delta_qct": bdelta,
                "sigma_delta_qct": bsigma,
                "v_qct_km_s": bvmodel,
                "sigma_model_km_s": bsigmav,
                "residual_km_s": bresid,
                "chi2_term_obs_only": bchi2,
            }
        )

    write_csv(
        output_dir / "NGC3992_OBSERVED_KINEMATIC_ROWS.csv",
        ["row_index", "r_kpc", "r_m", "vobs_km_s", "sigma_v_km_s", "gobs_m_s2"],
        observed_rows,
    )
    write_csv(
        output_dir / "NGC3992_COMPONENT_ROWS_AT_OBSERVED_RADII.csv",
        [
            "row_index",
            "r_kpc",
            "left_baryonic_r_kpc",
            "right_baryonic_r_kpc",
            "interpolation_mode",
            "signed_vhi2_km2_s2",
            "signed_vh2_2_km2_s2",
            "vstars2_km2_s2",
            "vbulge2_km2_s2",
            "gas_signed_vbar2_km2_s2",
            "stellar_bulge_vbar2_km2_s2",
        ],
        component_rows,
    )
    write_csv(
        output_dir / "NGC3992_QUMOND_FIXED_SCALE_COMPARATOR.csv",
        [
            "row_index",
            "r_kpc",
            "vobs_km_s",
            "sigma_v_km_s",
            "scale_s",
            "gbar_m_s2",
            "log10_gbar_m_s2",
            "nu",
            "vbar_km_s",
            "v_qumond_km_s",
            "residual_km_s",
            "chi2_term",
        ],
        fixed_qumond_rows,
    )
    write_csv(
        output_dir / "NGC3992_QUMOND_MATCHED_NUISANCE_COMPARATOR.csv",
        [
            "row_index",
            "r_kpc",
            "vobs_km_s",
            "sigma_v_km_s",
            "scale_s",
            "gbar_m_s2",
            "log10_gbar_m_s2",
            "nu",
            "vbar_km_s",
            "v_qumond_km_s",
            "residual_km_s",
            "chi2_term",
        ],
        best_qumond_rows,
    )
    write_csv(
        output_dir / "NGC3992_QCT_ARTIFACT_EMULATOR_FIXED_SCALE_COMPARATOR.csv",
        [
            "row_index",
            "r_kpc",
            "vobs_km_s",
            "sigma_v_km_s",
            "scale_s",
            "gbar_m_s2",
            "log10_gbar_m_s2",
            "vbar_km_s",
            "vdrop",
            "delta_qct",
            "sigma_delta_qct",
            "v_qct_km_s",
            "sigma_model_km_s",
            "residual_km_s",
            "chi2_term_obs_only",
        ],
        fixed_qct_rows,
    )
    write_csv(
        output_dir / "NGC3992_QCT_ARTIFACT_EMULATOR_MATCHED_NUISANCE_COMPARATOR.csv",
        [
            "row_index",
            "r_kpc",
            "vobs_km_s",
            "sigma_v_km_s",
            "scale_s",
            "gbar_m_s2",
            "log10_gbar_m_s2",
            "vbar_km_s",
            "vdrop",
            "delta_qct",
            "sigma_delta_qct",
            "v_qct_km_s",
            "sigma_model_km_s",
            "residual_km_s",
            "chi2_term_obs_only",
        ],
        best_qct_rows,
    )
    write_json(output_dir / "NGC3992_QUMOND_MATCHED_NUISANCE_SUMMARY.json", qumond_summary)
    write_json(output_dir / "NGC3992_QCT_MATCHED_NUISANCE_SUMMARY.json", qct_summary)
    write_json(output_dir / "NGC3992_GRADE1_DIFFERENTIAL_SUMMARY.json", differential)
    write_json(output_dir / "REPRODUCTION_CHECKS.json", reproduction_checks)
    write_json(
        output_dir / "VERDICT.json",
        {
            "case_id": CASE_ID,
            "verdict": differential["verdict"],
            "grade1_materialized": differential["grade1_materialized"],
            "all_reproduction_checks_pass": reproduction_checks["all_checks_pass"],
        },
    )
    (output_dir / "NGC3992_GRADE1_REPORT.md").write_text(
        build_report(qct_summary, qumond_summary, differential, reproduction_checks),
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "qct_summary": qct_summary,
                "qumond_summary": qumond_summary,
                "differential": differential,
                "reproduction_checks": reproduction_checks,
            },
            indent=2,
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
