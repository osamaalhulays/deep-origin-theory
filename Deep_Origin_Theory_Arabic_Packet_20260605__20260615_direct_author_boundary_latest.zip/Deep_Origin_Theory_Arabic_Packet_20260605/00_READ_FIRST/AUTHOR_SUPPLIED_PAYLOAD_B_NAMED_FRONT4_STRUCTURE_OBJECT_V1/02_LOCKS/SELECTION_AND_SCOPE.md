# Selection And Scope

Date: `2026-06-13`

This object does not invent a new front by taste.

It reuses the already frozen clean-first shortlist exactly as it stands and
selects only its first four ranks:

- `NGC1313`
- `NGC2541`
- `NGC7793`
- `NGC3992`

## Source rule

The front is defined only by:

- `CLEAN_FIRST_PRIORITY_SHORTLIST.csv`
- `OBSERVED_ROW_EMPIRICAL_COMPARISON_READY.csv`
- `GALAXY_COMPARISON_ADMISSIBILITY_LEDGER.csv`

No new scientific rule is introduced here.

## Present bounded role

The present role is narrow:

- show that the visible named head already covers a majority share of
  clean-first rows
- show who the current first four named cases are
- show how much reserve remains behind them

It does **not** promote the front into:

- theory-side authoring
- one `QCT` prediction family
- one fairness-grade comparator family
- or one superiority verdict
