# Author-Supplied `PAYLOAD_B` Named Front-`4` Structure Object

Date: `2026-06-13`

Purpose:

Freeze one reviewer-visible named front above the already materialized
clean-first reserve so the visible empirical head no longer stops at a trio.

This object exists to show the exact named front formed by the first four
clean-first cases and to quantify how much of the clean-first reserve is now
covered by named focused cases.

## What this object carries

- one packet-local reproduce script driven only by the already frozen shortlist
  and rowwise comparison outputs
- one reviewer-visible front-`4` ledger
- one front-versus-tail split summary
- one front summary surface

## What this object closes

This object closes one narrow but useful wound:

- the visible named empirical head is no longer three cases deep
- one named front of `4` focused cases now exists
- and that front can be replayed exactly from packet-local outputs

## What this object does not close

This object does **not**:

- claim one theory-side promotion
- claim one `QCT` prediction family
- claim one matched-nuisance fairness execution
- claim one named competitor verdict
- or change the current open-bank topology

## Exact current reading

The fair current reading is:

- the named visible head now contains `4` clean-first cases
- that head carries `120` of `184` clean-first rows
- the remaining tail still exists and remains bounded
- and the whole front remains empirical `gobs/gbar` only
