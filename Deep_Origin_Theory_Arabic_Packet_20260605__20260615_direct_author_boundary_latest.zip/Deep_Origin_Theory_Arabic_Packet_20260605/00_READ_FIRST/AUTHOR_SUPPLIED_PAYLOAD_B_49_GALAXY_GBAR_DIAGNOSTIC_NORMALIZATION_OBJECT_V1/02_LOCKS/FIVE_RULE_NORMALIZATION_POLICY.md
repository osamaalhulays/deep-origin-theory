# Five-Rule Normalization Policy

Date: `2026-06-13`

This object freezes one explicit five-rule policy for one narrow lane only:

- observed-row `gbar` diagnostics from the landed author-supplied `PAYLOAD_B` files

## Rule 1. Duplicate rounded radii

Rule:

- if one baryonic file contains repeated rounded `rad_kpc` entries,
  group the rows by identical rounded radius,
  convert every component to its diagnostic power representation first,
  then take the arithmetic mean inside that radius block,
  then keep one compressed row for interpolation

Current visible scope:

- this rule is exercised only on `DDO210`

## Rule 2. Negative gas-component rows

Rule:

- `VHI` and `VH2` are interpreted by one sign-preserving square:
  `signed_v2 = sign(V) * V^2`

Reason:

- the sign is already carried by the landed component curve and must not be
  silently erased by absolute squaring

## Rule 3. Optional `nan` stellar/bulge rows

Rule:

- if one stellar or bulge component value is `nan`
  and its associated low/high uncertainty fields are both `0.00`,
  replace that component by `0.0` inside this diagnostic lane

Current visible scope:

- the present payload shows this only as one bounded inner-anchor sentinel
  pattern

## Rule 4. Component-curve to source-density boundary

Rule:

- no `rho_b(r)` authoring is claimed here
- this lane materializes `gbar` only at observed radii
- one silent conversion from component curves into theory-side
  source-density authoring remains forbidden

## Rule 5. Theory-side promotion boundary

Rule:

- this object remains empirical
- no direct promotion into `G4`
- no direct promotion into `Form A/B/C/D`

## Exact consequence

The `49` galaxies are now lawful for one explicit diagnostic use:

- observed-row `gbar` / `gobs` diagnostics with frozen normalization choices

They are not yet promoted to:

- `rho_b(r)` source authoring
- theory-side transport or screening authoring
