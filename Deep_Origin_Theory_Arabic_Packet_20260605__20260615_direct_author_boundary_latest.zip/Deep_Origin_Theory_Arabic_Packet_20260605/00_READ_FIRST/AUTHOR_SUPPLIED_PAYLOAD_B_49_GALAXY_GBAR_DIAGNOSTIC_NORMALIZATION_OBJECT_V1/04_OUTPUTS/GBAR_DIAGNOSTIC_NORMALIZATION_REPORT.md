# Author-Supplied `PAYLOAD_B` 49-Galaxy `gbar` Diagnostic Normalization Report

Date: `2026-06-13`

## Short verdict

The `49` landed galaxies are now materialized as one explicit downstream
diagnostic lane:

- `gbar` at observed radii only

The lane is closed by one exact five-rule lock.

## Frozen choices

1. duplicate rounded radii:
   signed-power mean compression
2. negative gas components:
   sign-preserving square
3. `nan` stellar / bulge sentinels with zero uncertainties:
   zero-fill to `0.0`
4. component-curve to source-density promotion:
   not chosen;
   `rho_b(r)` authoring remains out of scope
5. theory-side promotion:
   not chosen;
   payload remains empirical `PAYLOAD_B`

## Exact counts

- matched galaxies: `49`
- observed rows materialized: `1082`
- baryonic raw rows scanned: `4850`
- duplicate-radius galaxies: `1`
- duplicate-radius blocks: `5`
- negative `VHI` rows: `557`
- negative `VH2` rows: `50`
- zero-filled stellar `nan` rows: `25`
- zero-filled bulge `nan` rows: `25`
- all observed rows landed inside the baryonic interpolation range:
  `true`
- all signed total baryonic powers stayed positive at observed radii:
  `true`

## Exact present ceiling

This object gives one real empirical gain.

It does not yet give:

- one `rho_b(r)` authoring object
- one `Form C`
- one `Form D`
- one theory-side promotion into `G4`
