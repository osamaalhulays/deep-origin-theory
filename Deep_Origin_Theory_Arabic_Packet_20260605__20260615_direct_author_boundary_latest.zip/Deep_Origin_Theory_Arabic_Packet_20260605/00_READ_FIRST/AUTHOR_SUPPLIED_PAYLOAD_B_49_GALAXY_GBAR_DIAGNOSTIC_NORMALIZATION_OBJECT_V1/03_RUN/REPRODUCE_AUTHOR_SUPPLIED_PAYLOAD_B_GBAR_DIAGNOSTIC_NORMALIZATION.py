#!/usr/bin/env python3

from __future__ import annotations

import argparse
import bisect
import csv
import hashlib
import json
import math
import zipfile
from collections import defaultdict
from pathlib import Path


OBSERVED_SUFFIX = "_vcirc.dat"
BARYON_SUFFIX = "_vbaryons.dat"
OBSERVED_HEADER = "rad_kpc vcirc_km/s e_vcirc"
BARYON_HEADER = (
    "rad_kpc VHI VH2 Vstars eVstars_low eVstars_high Vbulge eVbulge_low eVbulge_high"
)
KPC_IN_M = 3.085677581491367e19


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def nonblank_lines(text: str) -> list[str]:
    return [line.strip() for line in text.splitlines() if line.strip()]


def normalize_header(header: str) -> str:
    cleaned = header.strip()
    if cleaned.startswith("#"):
        cleaned = cleaned[1:].strip()
    return " ".join(cleaned.split())


def galaxy_name_from_member(member_name: str, suffix: str) -> str:
    if not member_name.endswith(suffix):
        raise ValueError(f"unexpected member name: {member_name}")
    return Path(member_name).name[: -len(suffix)]


def read_zip_records(zip_path: Path, suffix: str) -> dict[str, dict]:
    records: dict[str, dict] = {}
    with zipfile.ZipFile(zip_path) as archive:
        for member_name in sorted(archive.namelist()):
            if member_name.endswith("/") or not member_name.endswith(suffix):
                continue
            text = archive.read(member_name).decode("utf-8")
            lines = nonblank_lines(text)
            if not lines:
                raise ValueError(f"empty member: {member_name}")
            header = normalize_header(lines[0])
            rows = [line.split() for line in lines[1:]]
            galaxy = galaxy_name_from_member(member_name, suffix)
            records[galaxy] = {
                "member_name": member_name,
                "header": header,
                "rows": rows,
            }
    return records


def signed_square(value: float) -> float:
    return abs(value) * value


def parse_float(value: str) -> float:
    return float(value)


def normalize_optional_component(
    row: list[str],
    idx: dict[str, int],
    *,
    value_key: str,
    err_low_key: str,
    err_high_key: str,
    galaxy: str,
    radius: float,
) -> tuple[float, bool]:
    raw = row[idx[value_key]]
    if raw.lower() != "nan":
        return float(raw), False
    low = float(row[idx[err_low_key]])
    high = float(row[idx[err_high_key]])
    if low == 0.0 and high == 0.0:
        return 0.0, True
    raise ValueError(
        f"{galaxy}: unexpected {value_key}=nan with nonzero uncertainties at r={radius:.6g}"
    )


def compress_baryonic_record(galaxy: str, record: dict) -> tuple[list[dict], dict]:
    header = record["header"].split()
    idx = {name: i for i, name in enumerate(header)}
    if " ".join(header) != BARYON_HEADER:
        raise ValueError(f"{galaxy}: unexpected baryonic header")

    raw_rows = []
    duplicate_groups = defaultdict(list)
    negative_vhi_rows = 0
    negative_vh2_rows = 0
    zero_fill_vstars_rows = 0
    zero_fill_vbulge_rows = 0

    for raw_index, row in enumerate(record["rows"]):
        radius = parse_float(row[idx["rad_kpc"]])
        vhi = parse_float(row[idx["VHI"]])
        vh2 = parse_float(row[idx["VH2"]])
        vstars, stars_zero_filled = normalize_optional_component(
            row,
            idx,
            value_key="Vstars",
            err_low_key="eVstars_low",
            err_high_key="eVstars_high",
            galaxy=galaxy,
            radius=radius,
        )
        vbulge, bulge_zero_filled = normalize_optional_component(
            row,
            idx,
            value_key="Vbulge",
            err_low_key="eVbulge_low",
            err_high_key="eVbulge_high",
            galaxy=galaxy,
            radius=radius,
        )

        negative_vhi_rows += int(vhi < 0.0)
        negative_vh2_rows += int(vh2 < 0.0)
        zero_fill_vstars_rows += int(stars_zero_filled)
        zero_fill_vbulge_rows += int(bulge_zero_filled)

        normalized = {
            "raw_index": raw_index,
            "r_kpc": radius,
            "signed_vhi2_km2_s2": signed_square(vhi),
            "signed_vh2_2_km2_s2": signed_square(vh2),
            "vstars2_km2_s2": vstars * vstars,
            "vbulge2_km2_s2": vbulge * vbulge,
            "zero_filled_vstars": stars_zero_filled,
            "zero_filled_vbulge": bulge_zero_filled,
        }
        raw_rows.append(normalized)
        duplicate_groups[radius].append(normalized)

    compressed_rows = []
    duplicate_radius_blocks = []
    duplicate_radius_source_rows_absorbed = 0

    for radius in sorted(duplicate_groups):
        items = duplicate_groups[radius]
        count = len(items)
        if count > 1:
            duplicate_radius_blocks.append(
                {
                    "r_kpc": radius,
                    "source_row_count": count,
                    "source_indices": [item["raw_index"] for item in items],
                    "raw_signed_vhi2_km2_s2": [item["signed_vhi2_km2_s2"] for item in items],
                    "raw_signed_vh2_2_km2_s2": [item["signed_vh2_2_km2_s2"] for item in items],
                    "raw_vstars2_km2_s2": [item["vstars2_km2_s2"] for item in items],
                    "raw_vbulge2_km2_s2": [item["vbulge2_km2_s2"] for item in items],
                }
            )
            duplicate_radius_source_rows_absorbed += count
        compressed_rows.append(
            {
                "r_kpc": radius,
                "source_row_count": count,
                "signed_vhi2_km2_s2": sum(item["signed_vhi2_km2_s2"] for item in items) / count,
                "signed_vh2_2_km2_s2": sum(item["signed_vh2_2_km2_s2"] for item in items) / count,
                "vstars2_km2_s2": sum(item["vstars2_km2_s2"] for item in items) / count,
                "vbulge2_km2_s2": sum(item["vbulge2_km2_s2"] for item in items) / count,
            }
        )

    return compressed_rows, {
        "raw_row_count": len(raw_rows),
        "unique_radius_count": len(compressed_rows),
        "duplicate_radius_block_count": len(duplicate_radius_blocks),
        "duplicate_radius_source_rows_absorbed": duplicate_radius_source_rows_absorbed,
        "duplicate_radius_blocks": duplicate_radius_blocks,
        "negative_vhi_rows": negative_vhi_rows,
        "negative_vh2_rows": negative_vh2_rows,
        "zero_fill_vstars_rows": zero_fill_vstars_rows,
        "zero_fill_vbulge_rows": zero_fill_vbulge_rows,
    }


def interpolate_component(
    radius_grid: list[float],
    values: list[float],
    target_radius: float,
) -> tuple[float, float, float, str]:
    if target_radius < radius_grid[0] or target_radius > radius_grid[-1]:
        raise ValueError(
            f"observed radius {target_radius:.6g} lies outside baryonic grid "
            f"[{radius_grid[0]:.6g}, {radius_grid[-1]:.6g}]"
        )
    index = bisect.bisect_left(radius_grid, target_radius)
    if index < len(radius_grid) and radius_grid[index] == target_radius:
        return values[index], target_radius, target_radius, "exact"
    left_index = index - 1
    right_index = index
    left_radius = radius_grid[left_index]
    right_radius = radius_grid[right_index]
    left_value = values[left_index]
    right_value = values[right_index]
    weight = (target_radius - left_radius) / (right_radius - left_radius)
    value = left_value + weight * (right_value - left_value)
    return value, left_radius, right_radius, "linear"


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def build_policy_lock() -> dict:
    return {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_GBAR_DIAGNOSTIC_NORMALIZATION_POLICY_LOCK_20260613",
        "diagnostic_lane": "observed_row_gbar_only",
        "all_five_choices_frozen": True,
        "choices": {
            "duplicate_radius_rule": {
                "status": "chosen",
                "value": "duplicate_radius_signed_power_mean_compression",
            },
            "negative_gas_rule": {
                "status": "chosen",
                "value": "sign_preserving_square_for_VHI_and_VH2",
            },
            "optional_nan_component_rule": {
                "status": "chosen",
                "value": "zero_fill_nan_stellar_or_bulge_component_when_associated_uncertainties_are_zero",
            },
            "component_to_density_rule": {
                "status": "chosen",
                "value": "no_rho_b_authoring__materialize_gbar_only_at_observed_radii",
            },
            "theory_side_promotion_rule": {
                "status": "chosen",
                "value": "no_theory_side_authoring_promotion__payload_remains_empirical_PAYLOAD_B",
            },
        },
        "operational_details": {
            "baryonic_to_observed_grid_rule": "linear_interpolation_on_compressed_component_power_curves",
            "gas_sign_encoding_preserved": True,
            "output_scope": "diagnostic_only",
        },
        "verdict": (
            "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_GBAR_DIAGNOSTIC_NORMALIZATION_POLICY_LOCK_CLOSED__ALL_FIVE_LOCAL_CHOICES_ARE_NOW_EXPLICIT_FOR_ONE_GBAR_ONLY_LANE"
        ),
    }


def build_report(summary: dict) -> str:
    return f"""# Author-Supplied `PAYLOAD_B` 49-Galaxy `gbar` Diagnostic Normalization Report

Date: `2026-06-13`

## Short verdict

The `49` landed galaxies are now materialized as one explicit downstream
diagnostic lane:

- `gbar` at observed radii only

The lane is closed by one exact five-rule lock.

## Frozen choices

1. duplicate rounded radii:
   signed-power mean compression
2. negative gas components:
   sign-preserving square
3. `nan` stellar / bulge sentinels with zero uncertainties:
   zero-fill to `0.0`
4. component-curve to source-density promotion:
   not chosen;
   `rho_b(r)` authoring remains out of scope
5. theory-side promotion:
   not chosen;
   payload remains empirical `PAYLOAD_B`

## Exact counts

- matched galaxies: `{summary["matched_galaxy_count"]}`
- observed rows materialized: `{summary["observed_row_count"]}`
- baryonic raw rows scanned: `{summary["baryonic_row_count"]}`
- duplicate-radius galaxies: `{summary["duplicate_radius_galaxy_count"]}`
- duplicate-radius blocks: `{summary["duplicate_radius_block_count"]}`
- negative `VHI` rows: `{summary["negative_vhi_row_count"]}`
- negative `VH2` rows: `{summary["negative_vh2_row_count"]}`
- zero-filled stellar `nan` rows: `{summary["zero_fill_vstars_row_count"]}`
- zero-filled bulge `nan` rows: `{summary["zero_fill_vbulge_row_count"]}`
- all observed rows landed inside the baryonic interpolation range:
  `{str(summary["all_observed_rows_within_baryonic_range"]).lower()}`
- all signed total baryonic powers stayed positive at observed radii:
  `{str(summary["all_signed_total_baryonic_powers_positive"]).lower()}`

## Exact present ceiling

This object gives one real empirical gain.

It does not yet give:

- one `rho_b(r)` authoring object
- one `Form C`
- one `Form D`
- one theory-side promotion into `G4`
"""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--observed-zip", required=True)
    parser.add_argument("--baryons-zip", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    observed_zip = Path(args.observed_zip).resolve()
    baryons_zip = Path(args.baryons_zip).resolve()
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    observed_records = read_zip_records(observed_zip, OBSERVED_SUFFIX)
    baryonic_records = read_zip_records(baryons_zip, BARYON_SUFFIX)

    if set(observed_records) != set(baryonic_records):
        raise ValueError("observed/baryonic galaxy sets do not match")

    if any(record["header"] != OBSERVED_HEADER for record in observed_records.values()):
        raise ValueError("unexpected observed header detected")

    policy_lock = build_policy_lock()
    row_rows = []
    galaxy_rows = []
    duplicate_audit = {}

    negative_vhi_row_count = 0
    negative_vh2_row_count = 0
    zero_fill_vstars_row_count = 0
    zero_fill_vbulge_row_count = 0
    duplicate_radius_galaxy_count = 0
    duplicate_radius_block_count = 0
    baryonic_row_count = 0
    observed_row_count = 0
    all_observed_rows_within_baryonic_range = True
    all_signed_total_baryonic_powers_positive = True

    for galaxy in sorted(observed_records):
        observed = observed_records[galaxy]
        baryonic = baryonic_records[galaxy]
        io = {name: i for i, name in enumerate(observed["header"].split())}

        compressed_rows, baryonic_audit = compress_baryonic_record(galaxy, baryonic)
        duplicate_radius_galaxy_count += int(baryonic_audit["duplicate_radius_block_count"] > 0)
        duplicate_radius_block_count += baryonic_audit["duplicate_radius_block_count"]
        negative_vhi_row_count += baryonic_audit["negative_vhi_rows"]
        negative_vh2_row_count += baryonic_audit["negative_vh2_rows"]
        zero_fill_vstars_row_count += baryonic_audit["zero_fill_vstars_rows"]
        zero_fill_vbulge_row_count += baryonic_audit["zero_fill_vbulge_rows"]
        baryonic_row_count += baryonic_audit["raw_row_count"]
        duplicate_audit[galaxy] = baryonic_audit["duplicate_radius_blocks"]

        radius_grid = [row["r_kpc"] for row in compressed_rows]
        signed_vhi2 = [row["signed_vhi2_km2_s2"] for row in compressed_rows]
        signed_vh2_2 = [row["signed_vh2_2_km2_s2"] for row in compressed_rows]
        vstars2 = [row["vstars2_km2_s2"] for row in compressed_rows]
        vbulge2 = [row["vbulge2_km2_s2"] for row in compressed_rows]

        min_gbar = None
        max_gbar = None

        observed_rows = observed["rows"]
        observed_row_count += len(observed_rows)
        for observed_index, row in enumerate(observed_rows):
            radius_kpc = float(row[io["rad_kpc"]])
            vobs_km_s = float(row[io["vcirc_km/s"]])
            e_vobs_km_s = float(row[io["e_vcirc"]])

            signed_vhi2_value, left_radius, right_radius, interp_mode = interpolate_component(
                radius_grid, signed_vhi2, radius_kpc
            )
            signed_vh2_2_value, _, _, _ = interpolate_component(radius_grid, signed_vh2_2, radius_kpc)
            vstars2_value, _, _, _ = interpolate_component(radius_grid, vstars2, radius_kpc)
            vbulge2_value, _, _, _ = interpolate_component(radius_grid, vbulge2, radius_kpc)

            signed_total_baryonic_power = (
                signed_vhi2_value + signed_vh2_2_value + vstars2_value + vbulge2_value
            )
            if signed_total_baryonic_power <= 0.0:
                all_signed_total_baryonic_powers_positive = False

            radius_m = radius_kpc * KPC_IN_M
            gbar_m_s2 = signed_total_baryonic_power * 1_000_000.0 / radius_m
            gobs_m_s2 = (vobs_km_s * vobs_km_s) * 1_000_000.0 / radius_m
            min_gbar = gbar_m_s2 if min_gbar is None else min(min_gbar, gbar_m_s2)
            max_gbar = gbar_m_s2 if max_gbar is None else max(max_gbar, gbar_m_s2)

            row_rows.append(
                {
                    "galaxy": galaxy,
                    "observed_row_index": observed_index,
                    "r_kpc_observed": radius_kpc,
                    "vobs_km_s": vobs_km_s,
                    "e_vobs_km_s": e_vobs_km_s,
                    "left_baryonic_r_kpc": left_radius,
                    "right_baryonic_r_kpc": right_radius,
                    "interpolation_mode": interp_mode,
                    "signed_vhi2_km2_s2": signed_vhi2_value,
                    "signed_vh2_2_km2_s2": signed_vh2_2_value,
                    "vstars2_km2_s2": vstars2_value,
                    "vbulge2_km2_s2": vbulge2_value,
                    "vbar2_signed_km2_s2": signed_total_baryonic_power,
                    "gbar_m_s2": gbar_m_s2,
                    "log10_gbar_m_s2": math.log10(gbar_m_s2),
                    "gobs_m_s2": gobs_m_s2,
                    "log10_gobs_m_s2": math.log10(gobs_m_s2),
                    "delta_log10_gobs_minus_gbar": math.log10(gobs_m_s2) - math.log10(gbar_m_s2),
                }
            )

        galaxy_rows.append(
            {
                "galaxy": galaxy,
                "observed_rows": len(observed_rows),
                "baryonic_rows_raw": baryonic_audit["raw_row_count"],
                "baryonic_unique_radii_after_compression": baryonic_audit["unique_radius_count"],
                "duplicate_radius_block_count": baryonic_audit["duplicate_radius_block_count"],
                "negative_vhi_rows": baryonic_audit["negative_vhi_rows"],
                "negative_vh2_rows": baryonic_audit["negative_vh2_rows"],
                "zero_fill_vstars_rows": baryonic_audit["zero_fill_vstars_rows"],
                "zero_fill_vbulge_rows": baryonic_audit["zero_fill_vbulge_rows"],
                "min_observed_r_kpc": min(float(item[io["rad_kpc"]]) for item in observed_rows),
                "max_observed_r_kpc": max(float(item[io["rad_kpc"]]) for item in observed_rows),
                "min_gbar_m_s2": min_gbar,
                "max_gbar_m_s2": max_gbar,
                "materialized_diagnostic_rows": len(observed_rows),
                "status": "diagnostic_gbar_materialized",
            }
        )

    summary = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_GBAR_DIAGNOSTIC_NORMALIZATION_SUMMARY_20260613",
        "diagnostic_lane": "observed_row_gbar_only",
        "matched_galaxy_count": len(observed_records),
        "observed_row_count": observed_row_count,
        "baryonic_row_count": baryonic_row_count,
        "materialized_diagnostic_row_count": len(row_rows),
        "duplicate_radius_galaxy_count": duplicate_radius_galaxy_count,
        "duplicate_radius_block_count": duplicate_radius_block_count,
        "negative_vhi_row_count": negative_vhi_row_count,
        "negative_vh2_row_count": negative_vh2_row_count,
        "zero_fill_vstars_row_count": zero_fill_vstars_row_count,
        "zero_fill_vbulge_row_count": zero_fill_vbulge_row_count,
        "all_observed_rows_within_baryonic_range": all_observed_rows_within_baryonic_range,
        "all_signed_total_baryonic_powers_positive": all_signed_total_baryonic_powers_positive,
        "rho_b_authoring_materialized": False,
        "theory_side_authoring_promotion": False,
        "all_five_choices_frozen": True,
        "verdict": (
            "AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_GBAR_DIAGNOSTIC_NORMALIZATION_MATERIALIZED__THE_49_GALAXIES_ARE_NOW_LAWFUL_FOR_EXPLICIT_GBAR_ONLY_DIAGNOSTIC_USE"
        ),
    }

    normalization_audit = {
        "surface": "author_supplied_payload_b_49_galaxy_gbar_diagnostic_normalization_audit",
        "policy_lock_verdict": policy_lock["verdict"],
        "summary_verdict": summary["verdict"],
        "raw_zip_fingerprints": {
            "observed_zip": {
                "filename": observed_zip.name,
                "sha256": sha256(observed_zip),
                "bytes": observed_zip.stat().st_size,
            },
            "baryons_zip": {
                "filename": baryons_zip.name,
                "sha256": sha256(baryons_zip),
                "bytes": baryons_zip.stat().st_size,
            },
        },
        "duplicate_radius_blocks": duplicate_audit,
    }

    write_csv(
        output_dir / "OBSERVED_ROW_GBAR_DIAGNOSTIC.csv",
        [
            "galaxy",
            "observed_row_index",
            "r_kpc_observed",
            "vobs_km_s",
            "e_vobs_km_s",
            "left_baryonic_r_kpc",
            "right_baryonic_r_kpc",
            "interpolation_mode",
            "signed_vhi2_km2_s2",
            "signed_vh2_2_km2_s2",
            "vstars2_km2_s2",
            "vbulge2_km2_s2",
            "vbar2_signed_km2_s2",
            "gbar_m_s2",
            "log10_gbar_m_s2",
            "gobs_m_s2",
            "log10_gobs_m_s2",
            "delta_log10_gobs_minus_gbar",
        ],
        row_rows,
    )
    write_csv(
        output_dir / "GALAXY_DIAGNOSTIC_STATUS.csv",
        [
            "galaxy",
            "observed_rows",
            "baryonic_rows_raw",
            "baryonic_unique_radii_after_compression",
            "duplicate_radius_block_count",
            "negative_vhi_rows",
            "negative_vh2_rows",
            "zero_fill_vstars_rows",
            "zero_fill_vbulge_rows",
            "min_observed_r_kpc",
            "max_observed_r_kpc",
            "min_gbar_m_s2",
            "max_gbar_m_s2",
            "materialized_diagnostic_rows",
            "status",
        ],
        galaxy_rows,
    )
    (output_dir / "NORMALIZATION_POLICY_LOCK.json").write_text(
        json.dumps(policy_lock, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (output_dir / "NORMALIZATION_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (output_dir / "NORMALIZATION_AUDIT.json").write_text(
        json.dumps(normalization_audit, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (output_dir / "GBAR_DIAGNOSTIC_NORMALIZATION_REPORT.md").write_text(
        build_report(summary),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
