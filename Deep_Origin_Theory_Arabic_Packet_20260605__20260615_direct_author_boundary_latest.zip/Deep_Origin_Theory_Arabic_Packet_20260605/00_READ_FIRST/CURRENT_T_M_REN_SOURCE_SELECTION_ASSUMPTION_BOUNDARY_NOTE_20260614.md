# Current `T_m^ren` Source-Selection Assumption Boundary Note

Date: `2026-06-14`

Purpose:

Answer one exact reviewer-facing question cleanly:

- why this exact `T_m^ren` source selection now?

## Short verdict

The current packet does **not** claim:

- one final necessity theorem proving that this source selection is uniquely
  forced

It does claim something narrower:

- one explicit current-scope working-source boundary

## What is fixed at current scope

The current packet already fixes:

- one declared common parent-source route
- one compact public representative `O_phi = T_m^ren`
- one longer canonical representative carrying the normalization factor
- one no-surplus discipline
- one no-parameter-split discipline
- and one later-theorem ceiling kept visible above the present route

## Why this is lawful now

At current packet scope, the source-selection burden is not:

- prove the final external uniqueness theorem immediately

It is narrower:

- make the working source explicit
- keep its normalization class explicit
- and keep the later theorem above it explicit

That is already what the packet now does.

## What this note does not claim

This note does **not** claim:

- one final necessity theorem
- one all-regime closure theorem
- one finished same-parent uniqueness theorem
- or one completed `G1` landing

## Fair present reading

The fair present reading is no longer:

- the packet silently chooses one exact source without saying so

It is:

- the packet openly uses one bounded current-scope source-selection boundary,
  while the stronger theorem remains later

## Read with

- `PARENT_SOURCE_NORMALIZATION_CLASS_NOTE_20260606.md`
- `CURRENT_SCOPE_DERIVATION_PERMISSION_AND_LATER_THEOREM_TRANSFER_NOTE_20260607.md`
- `FIVE_CENTRAL_OBJECTIONS_AND_CURRENT_SCOPE_NARROWING_NOTE_20260607.md`
