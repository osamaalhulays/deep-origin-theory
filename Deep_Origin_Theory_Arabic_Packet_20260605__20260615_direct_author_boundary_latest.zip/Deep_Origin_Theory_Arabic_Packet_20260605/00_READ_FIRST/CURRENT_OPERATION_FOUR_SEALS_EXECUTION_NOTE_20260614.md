# Current Operation Four Seals Execution Note

Date: `2026-06-14`

Purpose:

Expose the present execution order after the final sovereign reread.

## The four seals

- `G1` = theory-sovereignty seal
- `G5` = `MACS1206` authority-arrival seal
- `G7` = formal-review dispatch seal
- `G8` = broader independent-replication seal

## Order

The current order is:

1. `G7` first
2. `G5` preparation second
3. `G1` time-boxed
4. `G8` after first real `G7` dispatch

## What is not the current live order

It is no longer honest to behave as if:

- `G4` is still the live spend target
- `G6/D7` are still the live arrival target
- or the landed bounded `MOND/QUMOND` triad is still one live bank head
