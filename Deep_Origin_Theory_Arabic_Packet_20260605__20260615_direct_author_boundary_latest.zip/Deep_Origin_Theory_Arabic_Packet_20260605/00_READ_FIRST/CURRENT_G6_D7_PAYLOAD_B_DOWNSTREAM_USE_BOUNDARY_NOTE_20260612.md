# Current `G6` / `D7` `PAYLOAD_B` Downstream-Use Boundary Note

Date: `2026-06-12`

Purpose:

Freeze the exact bounded downstream-use grammar for the first real author-supplied
direct-author `PAYLOAD_B` landing so the empirical payload is not silently
misread as theory-side authoring or as one already normalized baryonic source
profile.

## Short verdict

The fair current reading is:

- the payload really closes `G6`
- and really closes `D7` at `PAYLOAD_B_admit`
- but it does **not** by itself authorize silent conversion into one theory-
  side source profile
- and it does **not** by itself fix one unique later rematerialization rule
  for every downstream use

## Exact landed shape

- `49` observed files
- `49` baryonic component files
- `49 / 49` matched galaxy pairs
- total observed rows = `1082`
- total baryonic rows = `4850`
- all baryonic files are oversampled relative to the observed rows

## What this payload is

This payload is:

- one lawful direct-author empirical `L2` payload
- one machine-readable observed-plus-components landing
- one bounded diagnostic-grade empirical input family

## What this payload is not

This payload is **not**:

- one direct `rho_b(r)` source-density profile pack
- one theory-side `Form A/B/C/D` authoring object
- one automatic `G4` crossing authorization
- one proof of `NGC4214` because that target is not in the landed set
- one blanket public republication permission for row-level or near-rowwise
  derivative tables built from the source payload

## Exact downstream hygiene constraints

Any later downstream use must keep the following explicit:

1. `gbar` may be rematerialized from component curves only through one openly
   declared component rule
2. no silent conversion from circular-speed components to `rho_b(r)` may be
   claimed
3. negative gas-component rows must not be silently absolute-squared
4. duplicate radii must be normalized by one declared rule before strict-grid
   interpolation
5. optional bulge `nan` rows must be handled only by one declared bounded
   rule

## Exact visible flags in the landed payload

- negative `VHI` rows are visible
- negative `VH2` rows are visible
- `DDO210_vbaryons.dat` contains duplicate rounded radii
- some optional bulge rows appear as `nan`

These flags do **not** damage `G6` / `D7` closure.

They only constrain later rematerialization discipline.

They also constrain outward-public exposure:

- landed intake does **not** by itself authorize outward republication of
  row-level or near-rowwise derivative tables built from the same direct-author
  payload
- the current public packet therefore keeps receipt, lock, summary, ledger,
  and bounded report surfaces visible while withholding those derivative tables
  from outward publication

## Safe present conclusion

The safe present conclusion is:

- `G6` / `D7` are closed at `PAYLOAD_B` grade
- later empirical use is lawful
  only if its normalization choices stay explicit
- and theory-side authoring remains distinct from this payload lane

One such explicit later lane is now materialized separately:

- `CURRENT_G6_D7_PAYLOAD_B_49_GALAXY_GBAR_DIAGNOSTIC_LANE_NOTE_20260613.md`
- `AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_GBAR_DIAGNOSTIC_NORMALIZATION_OBJECT_V1`

One stricter empirical comparison-admissibility layer above that normalized
lane is now also materialized separately at public summary / ledger grade:

- `CURRENT_G6_D7_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_NOTE_20260613.md`
- `AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_OBJECT_V1`

The exact current outward-public boundary for that whole family is frozen
separately here:

- `CURRENT_DIRECT_AUTHOR_PUBLIC_DERIVATIVE_BOUNDARY_NOTE_20260615.md`

## Read with

- `CURRENT_G6_L2_DIRECT_AUTHOR_PAYLOAD_ARRIVED_AND_CLASSIFIED_AS_PAYLOAD_B_NOTE_20260612.md`
- `CURRENT_D7_L2_PAYLOAD_B_ADMIT_BOUNDED_VERDICT_NOTE_20260612.md`
- `AUTHOR_SUPPLIED_PAYLOAD_B_RECEIPT_AUDIT_OBJECT_V1`
- `CURRENT_DIRECT_AUTHOR_PUBLIC_DERIVATIVE_BOUNDARY_NOTE_20260615.md`
- `CURRENT_G6_D7_PAYLOAD_B_49_GALAXY_GBAR_DIAGNOSTIC_LANE_NOTE_20260613.md`
- `AUTHOR_SUPPLIED_PAYLOAD_B_49_GALAXY_GBAR_DIAGNOSTIC_NORMALIZATION_OBJECT_V1`
