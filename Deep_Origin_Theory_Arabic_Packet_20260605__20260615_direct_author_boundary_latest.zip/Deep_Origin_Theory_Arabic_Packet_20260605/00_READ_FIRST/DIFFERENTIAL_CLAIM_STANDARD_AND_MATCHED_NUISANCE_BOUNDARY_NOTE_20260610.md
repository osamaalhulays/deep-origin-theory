# Differential Claim Standard And Matched-Nuisance Boundary Note

Date: `2026-06-10`

Status: `reviewer-facing differential-claim grammar`

Purpose:

Freeze the minimum public standard for outward `QCT` versus `QUMOND`
differential language at the current packet ceiling.

This note compresses one later outside methods-side clarification into
packet-safe grammar.

## Short verdict

There is no single minimum standard for every comparator sentence.

The minimum standard depends on the kind of claim being made.

For the current packet:

- the live `NGC0247` differential headline is one matched-nuisance result
- the allowed reading is one procedural preference under symmetric `MLE`
  nuisance treatment
- and the result must not be relabeled as Bayesian evidence or unconditional
  physical superiority

The later outside methods-side clarification also sharpens two boundaries:

- independently measured nuisance quantities can later be handled
  symmetrically by explicit priors without changing the current packet claim,
- and present `AIC/BIC` arithmetic must not be inflated into one final
  superiority oracle.

## 1. Differential claim standard

If the public claim is:

- `QCT` is preferred to `QUMOND`

then the minimum standard is:

- matched nuisance on both sides
- same visible comparator basis
- same procedural optimization law
- same parameter-counting rule

The fitted nuisance values themselves do **not** need to be identical.

What must match is the procedure,
not the numerical value of the fitted nuisance.

If later independently measured nuisance quantities such as distance or
inclination are opened,
the natural stronger route is one symmetric prior treatment on both sides.

So the allowed sentence is:

- under symmetric matched-nuisance `MLE` treatment,
  `QCT` is procedurally preferred to `QUMOND`

## 2. Fixed-anchor constrained claim standard

If the public claim is narrower:

- `QUMOND` fails here under one fixed anchor

then one externally justified fixed nuisance anchor is sufficient,
but the scope must remain explicit:

- under this fixed anchor only

That supports one constrained failure sentence only.

It does **not** support unconditional superiority language.

## 3. Later Bayesian standard

The cleaner stronger later standard is:

- one independent photometric prior on `Upsilon`
- where independently measured nuisance quantities exist,
  one explicit symmetric prior treatment for them as well
- full nuisance marginalization
- one resulting Bayes factor

That is not the current packet claim.

It is one later stronger methods front.

## 4. What the current packet already satisfies

The current packet already makes the outward differential shell explicit:

- `equal_free_obs_only` uses `obs-only` on both sides
- one nuisance count is fitted on the `QCT` side
- one nuisance count is fitted on the `QUMOND` side
- the fitted values remain separately visible as
  `upsilon_qct_obs_only` and `upsilon_qumond_obs_only`
- the historical mixed shell remains preserved as fenced history only
- the same-convention replay shell is therefore one explicit parity/control
  lane rather than one hidden mixed shell
- the present pro-`QCT` support shell is separately audited in the executed
  parity witness scoring stack
- and that support-bearing executed stack is the one carrying
  `Delta AIC = -15.398764714420167`
  under the current faithful matched-nuisance live lane

So the packet already satisfies the procedural minimum for one differential
matched-nuisance sentence without laundering the control shell into the
support-bearing shell.

## 5. What this blocks

This note blocks three common drifts:

- calling the current `Delta AIC` result Bayesian evidence
- laundering one fixed-anchor result into unconditional differential
  superiority
- pretending nuisance parity means identical fitted `Upsilon` values rather
  than identical fitting procedure
- treating present `AIC/BIC` arithmetic as if it were one settled absolute
  superiority measure even when parameter families are not equally
  permissive

## Best outward-safe reading

One mature outward-safe sentence is:

> At the current packet ceiling, the `NGC0247` matched-nuisance result
> authorizes one procedural differential sentence only: the packet makes the
> same-convention control shell explicit, but the present pro-`QCT`
> differential support comes from the separately audited executed parity
> witness scoring shell, under symmetric matched-nuisance `MLE` treatment.
> It does not yet authorize Bayesian-evidence language,
> unconditional physical-superiority language,
> or one final superiority reading from `AIC/BIC` alone.
