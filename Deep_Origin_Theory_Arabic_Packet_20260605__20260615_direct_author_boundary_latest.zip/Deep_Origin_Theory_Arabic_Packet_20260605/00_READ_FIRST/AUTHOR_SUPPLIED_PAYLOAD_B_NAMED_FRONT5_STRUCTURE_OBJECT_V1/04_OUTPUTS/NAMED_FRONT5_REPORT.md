# Author-Supplied `PAYLOAD_B` Named Front-`5` Structure Report

Date: `2026-06-13`

## Short verdict

The visible named empirical head is no longer only a top-`3` trio.

It now extends to a named front of `5` clean-first cases.

## Exact present shape

- named front galaxy count: `5`
- named front observed-row count: `135`
- clean-first total galaxy count: `11`
- clean-first total observed-row count: `184`
- remaining tail galaxy count: `6`
- remaining tail observed-row count: `49`
- named front share of clean-first rows: `0.7336956521739131`
- total exact interpolation rows in front: `13`
- total linear interpolation rows in front: `122`
- all front rows stay comparison-ready: `true`
- all front rows stay clean-first: `true`
- all front rows keep positive empirical gaps: `true`

## Named front

- rank 1: `NGC1313` with `40` rows, `delta_median = 0.6133288585909309`, and `gbar_peak_radius_kpc = 0.99`
- rank 2: `NGC2541` with `31` rows, `delta_median = 0.5466898458483325`, and `gbar_peak_radius_kpc = 1.07`
- rank 3: `NGC7793` with `29` rows, `delta_median = 0.44378271651489243`, and `gbar_peak_radius_kpc = 1.11`
- rank 4: `NGC3992` with `20` rows, `delta_median = 0.25739265614996754`, and `gbar_peak_radius_kpc = 6.1`
- rank 5: `LVHIS077` with `15` rows, `delta_median = 0.8916244858112812`, and `gbar_peak_radius_kpc = 1.83`

## Exact current ceiling

This object gives one named-front structure only.

It does not yet give:

- one theory-side promotion
- one `QCT` prediction family
- one matched-nuisance fairness comparison
- one named competitor verdict
