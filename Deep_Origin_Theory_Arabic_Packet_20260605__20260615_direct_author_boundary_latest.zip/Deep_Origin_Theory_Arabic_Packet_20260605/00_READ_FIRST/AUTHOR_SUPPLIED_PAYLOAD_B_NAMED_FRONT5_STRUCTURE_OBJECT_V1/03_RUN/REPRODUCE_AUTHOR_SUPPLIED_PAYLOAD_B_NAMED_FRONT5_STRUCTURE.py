#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import json
import statistics
from pathlib import Path


FRONT_RANKS = {1, 2, 3, 4, 5}


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def build_report(summary: dict, front_rows: list[dict[str, object]]) -> str:
    front_lines = "\n".join(
        [
            f"- rank {row['rank']}: `{row['galaxy']}` with `{row['observed_rows']}` rows, `delta_median = {row['delta_median']}`, and `gbar_peak_radius_kpc = {row['gbar_peak_radius_kpc']}`"
            for row in front_rows
        ]
    )
    return f"""# Author-Supplied `PAYLOAD_B` Named Front-`5` Structure Report

Date: `2026-06-13`

## Short verdict

The visible named empirical head is no longer only a top-`3` trio.

It now extends to a named front of `5` clean-first cases.

## Exact present shape

- named front galaxy count: `{summary["named_front_galaxy_count"]}`
- named front observed-row count: `{summary["named_front_row_count"]}`
- clean-first total galaxy count: `{summary["clean_first_total_galaxy_count"]}`
- clean-first total observed-row count: `{summary["clean_first_total_row_count"]}`
- remaining tail galaxy count: `{summary["remaining_tail_galaxy_count"]}`
- remaining tail observed-row count: `{summary["remaining_tail_row_count"]}`
- named front share of clean-first rows: `{summary["named_front_row_share_of_clean_first"]}`
- total exact interpolation rows in front: `{summary["front_exact_interpolation_row_count"]}`
- total linear interpolation rows in front: `{summary["front_linear_interpolation_row_count"]}`
- all front rows stay comparison-ready: `{str(summary["all_front_rows_comparison_ready"]).lower()}`
- all front rows stay clean-first: `{str(summary["all_front_rows_clean_first"]).lower()}`
- all front rows keep positive empirical gaps: `{str(summary["all_front_rows_delta_positive"]).lower()}`

## Named front

{front_lines}

## Exact current ceiling

This object gives one named-front structure only.

It does not yet give:

- one theory-side promotion
- one `QCT` prediction family
- one matched-nuisance fairness comparison
- one named competitor verdict
"""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rowwise-csv", required=True)
    parser.add_argument("--ledger-csv", required=True)
    parser.add_argument("--shortlist-csv", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    rowwise_rows = load_csv(Path(args.rowwise_csv).resolve())
    ledger_rows = load_csv(Path(args.ledger_csv).resolve())
    shortlist_rows = load_csv(Path(args.shortlist_csv).resolve())
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    ledger_by_galaxy = {row["galaxy"]: row for row in ledger_rows}

    clean_first_total_galaxy_count = len(shortlist_rows)
    clean_first_total_row_count = sum(int(row["observed_rows"]) for row in shortlist_rows)

    front_shortlist = [row for row in shortlist_rows if int(row["rank"]) in FRONT_RANKS]
    front_shortlist.sort(key=lambda row: int(row["rank"]))
    front_galaxies = [row["galaxy"] for row in front_shortlist]

    front_rows: list[dict[str, object]] = []
    exact_total = 0
    linear_total = 0
    all_positive = True
    all_ready = True
    all_clean = True

    for shortlist in front_shortlist:
        galaxy = shortlist["galaxy"]
        rank = int(shortlist["rank"])
        ledger = ledger_by_galaxy.get(galaxy)
        if ledger is None:
            raise ValueError(f"{galaxy}: missing admissibility ledger row")

        case_rows = [row for row in rowwise_rows if row["galaxy"] == galaxy]
        if not case_rows:
            raise ValueError(f"{galaxy}: missing rowwise case rows")

        radii = [float(row["r_kpc_observed"]) for row in case_rows]
        gbar = [float(row["gbar_m_s2"]) for row in case_rows]
        deltas = [float(row["delta_log10_gobs_minus_gbar"]) for row in case_rows]
        exact_count = sum(row["interpolation_mode"] == "exact" for row in case_rows)
        linear_count = sum(row["interpolation_mode"] == "linear" for row in case_rows)
        peak_index = max(range(len(gbar)), key=gbar.__getitem__)

        exact_total += exact_count
        linear_total += linear_count
        all_positive = all_positive and all(delta > 0.0 for delta in deltas)
        all_ready = all_ready and all(
            row["rowwise_empirical_comparison_ready"] == "true" for row in case_rows
        )
        all_clean = all_clean and all(row["clean_first_gate_pass"] == "true" for row in case_rows)

        front_rows.append(
            {
                "rank": rank,
                "galaxy": galaxy,
                "observed_rows": len(case_rows),
                "gbar_span_dex": float(shortlist["gbar_span_dex"]),
                "exact_interpolation_row_count": exact_count,
                "linear_interpolation_row_count": linear_count,
                "delta_min": min(deltas),
                "delta_max": max(deltas),
                "delta_median": statistics.median(deltas),
                "gbar_peak_radius_kpc": radii[peak_index],
                "all_delta_positive": all(delta > 0.0 for delta in deltas),
                "duplicate_radius_block_count": int(ledger["duplicate_radius_block_count"]),
                "negative_vh2_rows": int(ledger["negative_vh2_rows"]),
                "zero_fill_vstars_rows": int(ledger["zero_fill_vstars_rows"]),
                "zero_fill_vbulge_rows": int(ledger["zero_fill_vbulge_rows"]),
            }
        )

    named_front_row_count = sum(int(row["observed_rows"]) for row in front_rows)
    remaining_tail_galaxy_count = clean_first_total_galaxy_count - len(front_rows)
    remaining_tail_row_count = clean_first_total_row_count - named_front_row_count

    summary = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_NAMED_FRONT5_STRUCTURE_SUMMARY_20260613",
        "comparison_scope": "empirical_gobs_gbar_only",
        "named_front_galaxy_count": len(front_rows),
        "named_front_row_count": named_front_row_count,
        "clean_first_total_galaxy_count": clean_first_total_galaxy_count,
        "clean_first_total_row_count": clean_first_total_row_count,
        "remaining_tail_galaxy_count": remaining_tail_galaxy_count,
        "remaining_tail_row_count": remaining_tail_row_count,
        "named_front_row_share_of_clean_first": named_front_row_count / clean_first_total_row_count,
        "front_exact_interpolation_row_count": exact_total,
        "front_linear_interpolation_row_count": linear_total,
        "named_front_galaxies": front_galaxies,
        "all_front_rows_comparison_ready": all_ready,
        "all_front_rows_clean_first": all_clean,
        "all_front_rows_delta_positive": all_positive,
        "verdict": (
            "AUTHOR_SUPPLIED_PAYLOAD_B_NAMED_FRONT5_STRUCTURE_MATERIALIZED__THE_VISIBLE_HEAD_NOW_COVERS_5_GALAXIES_AND_135_OF_184_CLEAN_FIRST_ROWS"
        ),
    }

    fieldnames = [
        "rank",
        "galaxy",
        "observed_rows",
        "gbar_span_dex",
        "exact_interpolation_row_count",
        "linear_interpolation_row_count",
        "delta_min",
        "delta_max",
        "delta_median",
        "gbar_peak_radius_kpc",
        "all_delta_positive",
        "duplicate_radius_block_count",
        "negative_vh2_rows",
        "zero_fill_vstars_rows",
        "zero_fill_vbulge_rows",
    ]
    write_csv(output_dir / "NAMED_FRONT5_LEDGER.csv", fieldnames, front_rows)
    (output_dir / "NAMED_FRONT5_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (output_dir / "NAMED_FRONT5_REPORT.md").write_text(
        build_report(summary, front_rows),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
