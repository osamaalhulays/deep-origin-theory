# Author-Supplied `NGC1313` `QUMOND` Matched-Nuisance Anchor Report

Date: `2026-06-13`

## Short verdict

`NGC1313` is no longer only one clean empirical `gobs > gbar` witness.

It now also carries one real local competitor-side anchor:

- one reproducible `QUMOND` lane at fixed scale `s = 1.0`
- and one reproducible one-parameter matched-nuisance `QUMOND` lane

This is still **not** a `QCT` victory object.
It is one honest local anchor that prepares the later fair differential
comparison.

## Frozen scope

- case: `NGC1313`
- observed rows: `40`
- compressed baryonic radii: `200`
- duplicate-radius blocks: `0`
- negative `VHI` rows: `1`
- negative `VH2` rows: `0`

## Matched-nuisance result

- best stellar/bulge speed scale `s_best` = `1.276032750000`
- fixed lane `s_fixed` = `1.000000000000`
- `ll_fixed_obs_only` = `-336.319423904387`
- `ll_best_obs_only` = `-199.428203954239`
- `chi2_fixed` = `456.871445785845`
- `chi2_best` = `183.089005885549`
- `Δloglike(best-fixed)` = `136.891219950148`
- `ΔAIC(best-fixed)` = `-271.782439900297`
- `ΔBIC(best-fixed)` = `-270.093560446183`

## What this object now gives

- one packet-local reproducible competitor-side anchor for `NGC1313`
- one exact observed-row freeze derived from the landed author-supplied files
- one exact stellar/bulge nuisance grammar for later fair comparison

## What this object does not give

- no `QCT` prediction yet
- no matched-nuisance `QCT` vs `QUMOND` verdict yet
- no theory-side `rho_b(r)` authoring claim
- no cosmology completion
