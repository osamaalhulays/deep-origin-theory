from __future__ import annotations

import json
import re
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path


SCRIPT_PATH = Path(__file__).resolve()
OBJECT_ROOT = SCRIPT_PATH.parents[1]
ROOT = SCRIPT_PATH.parents[4]
OUTPUTS = OBJECT_ROOT / "04_OUTPUTS"

IGNORE_FRAGMENTS = (
    "/node_modules/",
    "/tmp_",
    "/L2_FORM_C_CURRENT_REPO_NO_GO_V1/",
    "/g4_external_intake/",
    "/G4_FORM_C_SOURCE_GOVERNED_L2_EVALUATOR_V1/",
)

CODE_SUFFIXES = {".py", ".ts", ".js", ".mjs", ".cjs", ".jl", ".m", ".r", ".R", ".sh"}
TARGET_NAMES = ("Delta_QCT_L2", "Xi_QCT_L2", "delta_qct_l2", "xi_qct_l2")
REQUIRED_BUNDLE_NAMES = {
    "QCT_EVALUATOR_FUNCTION.py",
    "observed_rows.csv",
    "prediction_rows.csv",
    "likelihood.py",
    "fit_report.json",
    "H0_SCALE_POLICY.md",
    "L0_BOUNDARY_CLAIM_CARD.md",
}

CALLABLE_LINE_PATTERNS = [
    ("python_def", re.compile(r"\bdef\s+(Delta_QCT_L2|Xi_QCT_L2|delta_qct_l2|xi_qct_l2)\s*\(")),
    ("python_lambda", re.compile(r"\b(Delta_QCT_L2|Xi_QCT_L2|delta_qct_l2|xi_qct_l2)\s*=\s*lambda\b")),
    ("js_function", re.compile(r"\bfunction\s+(Delta_QCT_L2|Xi_QCT_L2|delta_qct_l2|xi_qct_l2)\s*\(")),
    ("js_assignment", re.compile(r"\b(const|let|var)\s+(Delta_QCT_L2|Xi_QCT_L2|delta_qct_l2|xi_qct_l2)\s*=")),
]

NOTE_CHECKS = [
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_O4_O5_KREIB_CROSS_REPO_REFINEMENT_AFTER_RULE_AND_OPERATOR_SUPPLY_20260608.md",
        "fragments": [
            "bounded geometric evaluator probe at `C0_NO_CLAIM_EXPORT`: present",
            "true-closure-grade numeric Delta / Xi authority: absent",
        ],
        "meaning": "rule/operator/probe are present while true-closure-grade numeric authority remains absent",
    },
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_EVALUATOR_CONTENT_TARGET_AFTER_RULE_AND_OPERATOR_SUPPLY_20260608.md",
        "fragments": [
            "one bounded geometric evaluator probe at `C0_NO_CLAIM_EXPORT` also exists",
            "one promotable source-governed `Delta_QCT_L2(x_i)` or",
            "authority still does not",
        ],
        "meaning": "the route itself still records the missing evaluator/value authority step",
    },
    {
        "path": ROOT
        / "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/POST_CAGE_BRANCH_U1_BOUNDED_PROBE_VERSUS_PROMOTABLE_AUTHORITY_NOTE_20260608.md",
        "fragments": [
            "one bounded nontrivial geometric response evaluator probe now also exists",
            "but the surviving wound is still the missing jump from bounded probe",
        ],
        "meaning": "bounded probe and promotable authority are explicitly separated",
    },
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_KREIB_Q_PREFILL_AND_U1_SEED_CLASS_NOTE_20260608.md",
        "fragments": [
            "treating third-generation `C0_NO_CLAIM_EXPORT` probes as promotable",
            "These are the main false-rescue traps.",
        ],
        "meaning": "bounded no-claim probes may not be promoted into authority by inflation",
    },
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/02_LOCKS/ALLOWED_AUTHORING_FORMS.md",
        "fragments": [
            "3. `Form C`",
            "source-governed evaluator function for `Delta_QCT_L2(x)` or",
        ],
        "meaning": "Form C is frozen as a callable evaluator form, not as mere naming",
    },
]


def relative(path: Path) -> str:
    return str(path.relative_to(ROOT))


def include(path: Path) -> bool:
    path_str = str(path)
    if not path.is_file():
        return False
    if any(fragment in path_str for fragment in IGNORE_FRAGMENTS):
        return False
    if path.parent.name == "03_RUN" and path.name.startswith("REPRODUCE_"):
        return False
    return True


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def collect_code_symbol_hits() -> list[dict]:
    hits: list[dict] = []
    for path in sorted(ROOT.rglob("*")):
        if not include(path) or path.suffix not in CODE_SUFFIXES:
            continue
        matched_lines = []
        for index, line in enumerate(read_text(path).splitlines(), start=1):
            if any(name in line for name in TARGET_NAMES):
                matched_lines.append({"line": index, "text": line.strip()})
        if matched_lines:
            hits.append(
                {
                    "path": relative(path),
                    "matches": matched_lines,
                }
            )
    return hits


def collect_callable_hits() -> list[dict]:
    hits: list[dict] = []
    for path in sorted(ROOT.rglob("*")):
        if not include(path) or path.suffix not in CODE_SUFFIXES:
            continue
        matched_lines = []
        for index, line in enumerate(read_text(path).splitlines(), start=1):
            kinds = [
                kind for kind, pattern in CALLABLE_LINE_PATTERNS if pattern.search(line)
            ]
            if kinds:
                matched_lines.append(
                    {
                        "line": index,
                        "kinds": kinds,
                        "text": line.strip(),
                    }
                )
        if matched_lines:
            hits.append(
                {
                    "path": relative(path),
                    "matches": matched_lines,
                }
            )
    return hits


def collect_bundle_hits() -> list[dict]:
    grouped: dict[Path, set[str]] = defaultdict(set)
    for path in sorted(ROOT.rglob("*")):
        if not include(path):
            continue
        if path.name in REQUIRED_BUNDLE_NAMES:
            grouped[path.parent].add(path.name)
    hits = []
    for directory in sorted(grouped):
        names = sorted(grouped[directory])
        hits.append(
            {
                "directory": relative(directory),
                "present_names": names,
                "is_candidate": (
                    "QCT_EVALUATOR_FUNCTION.py" in names
                    or "likelihood.py" in names
                    or len(names) >= 3
                ),
            }
        )
    return hits


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {
            fragment: (fragment in text) for fragment in item["fragments"]
        }
        results.append(
            {
                "path": relative(item["path"]),
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def build_report(status: dict, note_checks: list[dict], bundle_hits: list[dict]) -> str:
    lines = [
        "# Form C Current-Repo No-Go Report",
        "",
        f"Generated at: `{status['generated_at_utc']}`",
        "",
        f"Verdict: `{status['verdict']}`",
        "",
        "## Summary",
        "",
        f"- code-facing symbol hits found: `{status['code_symbol_hit_count']}`",
        f"- callable evaluator candidates found: `{status['callable_candidate_count']}`",
        f"- evaluator-grade bundle directories found: `{status['candidate_bundle_directory_count']}`",
        f"- note checks passed: `{str(status['all_note_checks_pass']).lower()}`",
        f"- later external Form C intake governed separately: `{str(status['later_external_form_c_governed_separately']).lower()}`",
        "",
        "## Bundle directories",
        "",
    ]
    if not bundle_hits:
        lines.append("- none")
    else:
        for hit in bundle_hits:
            lines.append(
                f"- `{hit['directory']}` -> `{', '.join(hit['present_names'])}`"
            )
    lines.extend(
        [
            "",
            "## Note checks",
            "",
        ]
    )
    for check in note_checks:
        lines.append(f"- `{check['path']}` -> `{str(check['passed']).lower()}`")
    lines.extend(
        [
            "",
            "## Reading",
            "",
            "- the current frozen route already carries rule/operator/probe grammar,",
            "- this audit intentionally excludes the later fresh external Form C intake lane that is governed separately,",
            "- within this narrowed pre-external-intake route the code-bearing surfaces still do not carry one callable `Form C` evaluator family,",
            "- and no evaluator-grade bundle directory is presently visible above that same narrowed route,",
            "- so current lawful Form C materialization remains absent on that narrowed route only.",
            "",
            "## Next exact move",
            "",
            "- keep hidden local `Form C` hunting closed on the same narrowed frozen route",
            "- route live work above the separately admitted external Form C package toward frozen source profile + frozen `m_inv` + frozen benchmark bins + explicit branch/fiber rule only if needed",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    OUTPUTS.mkdir(parents=True, exist_ok=True)

    code_symbol_hits = collect_code_symbol_hits()
    callable_hits = collect_callable_hits()
    bundle_hits = collect_bundle_hits()
    note_checks = collect_note_checks()
    candidate_bundle_hits = [hit for hit in bundle_hits if hit["is_candidate"]]

    status = {
        "object_kind": "form_c_current_repo_no_go_status",
        "generated_at_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "scope": "current_repo_visible_frozen_route_pre_external_intake_only",
        "code_symbol_hit_count": len(code_symbol_hits),
        "callable_candidate_count": len(callable_hits),
        "candidate_bundle_directory_count": len(candidate_bundle_hits),
        "all_note_checks_pass": all(check["passed"] for check in note_checks),
        "callable_form_c_present": len(callable_hits) > 0,
        "evaluator_grade_bundle_present": len(candidate_bundle_hits) > 0,
        "later_external_form_c_governed_separately": True,
        "verdict": "FORM_C_CURRENT_REPO_VISIBLE_ROUTE_NO_GO_MATERIALIZED",
    }

    verdict = {
        "verdict": status["verdict"],
        "scope": status["scope"],
        "why": [
            "rule/operator/probe ladder is present below the target",
            "the route still records the missing jump from bounded probe to promotable authority",
            "the repo-wide code-bearing scan for this narrowed audit excludes the later fresh external Form C intake lane",
            "within that narrowed route no callable Delta_QCT_L2/Xi_QCT_L2 evaluator surface is presently visible",
            "no evaluator-grade bundle directory is presently visible on that narrowed route",
        ],
        "next_exact_move": "POST_EXTERNAL_FORMC_EXECUTION_ON_FROZEN_INPUTS_OR_STRONGER_FRESH_FORMABD_ARRIVAL",
        "reopen_if": [
            "a callable source-governed Form C evaluator surface becomes visible",
            "an evaluator-owned emitted value or prediction surface becomes visible above that callable family",
            "a real Form D operator engine producing those outputs lawfully becomes visible",
        ],
        "ceiling": [
            "not a permanent impossibility theorem",
            "not a rejection of Form D in principle",
            "not a full-program failure verdict",
        ],
    }

    report = build_report(status, note_checks, bundle_hits)

    (OUTPUTS / "code_symbol_hits.json").write_text(
        json.dumps(code_symbol_hits, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "callable_surface_hits.json").write_text(
        json.dumps(callable_hits, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "bundle_surface_hits.json").write_text(
        json.dumps(bundle_hits, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "note_checks.json").write_text(
        json.dumps(note_checks, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "status_summary.json").write_text(
        json.dumps(status, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "verdict.json").write_text(
        json.dumps(verdict, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "FORM_C_CURRENT_REPO_NO_GO_REPORT.md").write_text(
        report,
        encoding="utf-8",
    )

    if code_symbol_hits:
        raise SystemExit("unexpected code-facing symbol hit found")
    if callable_hits:
        raise SystemExit("unexpected callable evaluator candidate found")
    if candidate_bundle_hits:
        raise SystemExit("unexpected evaluator-grade bundle directory found")
    if not all(check["passed"] for check in note_checks):
        raise SystemExit("required note evidence check failed")


if __name__ == "__main__":
    main()
