# Current `G2` Standalone-Head Retirement And `U1` South Absorption Note

Date: `2026-06-11`

Purpose:

This note records one later clean reread of the south front.

The claim is not:

- final south physical completion is already finished.

The claim is narrower:

- the older standalone `G2` head no longer survives as one separate live
  owner head.

## Short verdict

The fair current reading is:

- strict same-cage south completion is no longer a viable owner route,
- `Branch P` south work remains alive only as one discrimination gate,
- and the constructive south owner already lives inside `U1`.

More exactly:

- one real independent carrier `Q` is now the forced minimal widening,
- south stays inside the preferred bounded-regime-first discipline of `U1`,
- and distinct south carrierhood (`U2`) is still not yet forced.

## Why the standalone `G2` head retires

Three later gains align:

1. strict same-cage closure already fails on
   `Bianchi / total stress-energy transport closure`
2. the `Branch P` south side is now exact but discrimination-only:
   generator-route-token neck,
   missing generator/object freeze,
   missing basis freeze,
   and no lawful south time law yet
3. `U1` already carries the constructive south grammar:
   one same-carrier bounded south projection,
   one first exact bounded south readout family `BS1`,
   one first live singleton freeze,
   and one explicit single-carrier south ownership test

So the remaining south work is no longer best read as:

- one separate sovereign south head

It is now better read as:

- one absorbed same-carrier south burden inside `G1 -> U1`

## What this does not say

This note does **not** say:

- south physicalization is fully solved
- transport closure is already complete
- `U1` is already solved
- `U2` is impossible

It says something narrower and more useful:

- the older standalone `G2` head is retired
- and the surviving south battlefield is already owned inside `U1`

## Read with

- `POST_CAGE_TRANSPORT_ACTION_THEOREM_REVIEWER_OBJECT_NOTE_20260610.md`
- `POST_CAGE_O5_SOUTH_SUBSTRATE_GATE_LOCALIZES_TO_GENERATOR_ROUTE_TOKEN_NECK_NOTE_20260608.md`
- `POST_CAGE_BRANCH_U1_FIRST_NARROWING_NO_MANDATORY_BQ_AND_PASSIVE_SOUTH_PROJECTION_NOTE_20260608.md`
- `POST_CAGE_BRANCH_U1_BS1_BOUNDED_SOUTH_READOUT_FAMILY_NOTE_20260608.md`
- `POST_CAGE_BRANCH_U1_RR0_BS1_IR1_STEP1_SOUTH_SINGLETON_FREEZE_NOTE_20260608.md`
- `POST_CAGE_BRANCH_U1_SINGLE_CARRIER_OWNERSHIP_TEST_NOTE_20260608.md`
