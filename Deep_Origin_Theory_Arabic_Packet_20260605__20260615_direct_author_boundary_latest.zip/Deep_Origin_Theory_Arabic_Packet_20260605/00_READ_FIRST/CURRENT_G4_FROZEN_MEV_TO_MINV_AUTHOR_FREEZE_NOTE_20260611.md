# Current `G4` Frozen `m_eV` To `m_inv` Author Freeze Note

Date: `2026-06-11`

## Short verdict

The local `G4` route no longer lacks a lawful production `m_inv`.

The value now frozen for the first `NGC4214` run is:

```text
m_inv_m1 = 5.067730717679395941e-19
```

## Exact read

This is not one new fitted parameter.

It is the same already visible frozen prior:

- `m_eV = 1e-25`

translated through the already visible production-solver rule:

```text
m_inv_m = m_eV / HBAR_C
```

with:

- `HBAR_C = 1.973269804e-7 eV*m`

## Bottom line

The frozen `NGC4214` triple now exists locally:

- source profile
- benchmark-bin roster
- production `m_inv`

So the next honest motion is the first lawful non-toy `Form D` run on that
triple.
