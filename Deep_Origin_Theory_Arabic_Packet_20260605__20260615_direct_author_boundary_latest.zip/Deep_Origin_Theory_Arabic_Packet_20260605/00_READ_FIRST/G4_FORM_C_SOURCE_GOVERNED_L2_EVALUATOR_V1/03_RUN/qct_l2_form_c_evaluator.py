#!/usr/bin/env python3
"""
QCT L2 Form C source-governed evaluator, V1.

Purpose
-------
Implements the minimal callable evaluator obtained by composing:
  SPEC-205 phenomenological closure PDE
  + same-source/boundary contract
  + phi -> Delta -> V_model extraction lock.

This is not a fit routine. It does not read observed g_obs or residuals.
It emits Delta_QCT_L2 from a supplied baryonic source profile.

Scope
-----
V1 implements the spherically embedded / radial source class. It is the
smallest cold-callable Form C evaluator object. General axisymmetric 2D is a
Form D/operator-engine extension, not silently claimed here.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional
import argparse
import csv
import json
import math

import numpy as np
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import spsolve

G_SI = 6.67430e-11
C_SI = 299792458.0
KAPPA_SI = 8.0 * math.pi * G_SI / (C_SI ** 2)


@dataclass(frozen=True)
class QCTL2EvaluatorConfig:
    """Frozen evaluator configuration.

    m_inv_m1 is the inverse length entering SPEC-205 through m_eff^2.
    beta and beta_alpha are fixed conventions, defaulting to one.
    """

    m_inv_m1: float
    beta: float = 1.0
    beta_alpha: float = 1.0
    kappa: float = KAPPA_SI
    outer_boundary: str = "phi_outer_zero"
    inner_boundary: str = "regular_center_flux_zero"
    delta_rule: str = "Delta(r) := -phi(r)"

    def validate(self) -> None:
        if self.m_inv_m1 < 0:
            raise ValueError("m_inv_m1 must be non-negative")
        if self.beta != 1.0 or self.beta_alpha != 1.0:
            raise ValueError("V1 forbids beta/beta_alpha variation; both must equal 1.0")
        if self.kappa <= 0:
            raise ValueError("kappa must be positive")


@dataclass(frozen=True)
class RadialSourceProfile:
    """Radial baryonic source profile for the V1 spherical-pullback class."""

    r_m: np.ndarray
    rho_b_kg_m3: np.ndarray
    gbar_m_s2: Optional[np.ndarray] = None

    def validate(self) -> None:
        r = np.asarray(self.r_m, dtype=float)
        rho = np.asarray(self.rho_b_kg_m3, dtype=float)
        if r.ndim != 1 or rho.ndim != 1:
            raise ValueError("r_m and rho_b_kg_m3 must be one-dimensional")
        if len(r) != len(rho):
            raise ValueError("r_m and rho_b_kg_m3 must have the same length")
        if len(r) < 4:
            raise ValueError("at least four radial nodes are required")
        if np.any(r <= 0):
            raise ValueError("all radial nodes must be positive")
        if np.any(np.diff(r) <= 0):
            raise ValueError("radial nodes must be strictly increasing")
        if np.any(rho < 0):
            raise ValueError("rho_b_kg_m3 must be non-negative")
        if self.gbar_m_s2 is not None:
            gbar = np.asarray(self.gbar_m_s2, dtype=float)
            if gbar.shape != r.shape:
                raise ValueError("gbar_m_s2 must have the same shape as r_m")
            if np.any(gbar <= 0):
                raise ValueError("gbar_m_s2 must be positive where supplied")


def _cell_faces(r: np.ndarray) -> np.ndarray:
    faces = np.empty(len(r) + 1, dtype=float)
    faces[1:-1] = 0.5 * (r[:-1] + r[1:])
    faces[0] = 0.0
    # finite outer shell face by midpoint extrapolation
    faces[-1] = r[-1] + 0.5 * (r[-1] - r[-2])
    return faces


def solve_phi_radial(profile: RadialSourceProfile, config: QCTL2EvaluatorConfig) -> np.ndarray:
    """Solve the radial SPEC-205 closure in finite-volume form.

    Equation:
      (1/r^2) d/dr (r^2 dphi/dr) - m_eff^2(r) phi = beta*kappa*rho_b(r)
      m_eff^2 = m_inv^2 + beta_alpha*kappa*rho_b

    Boundary conditions:
      inner: regular flux through r=0 is zero
      outer: phi(r_outer)=0
    """
    config.validate()
    profile.validate()

    r = np.asarray(profile.r_m, dtype=float)
    rho = np.asarray(profile.rho_b_kg_m3, dtype=float)
    n = len(r)
    faces = _cell_faces(r)
    m_eff2 = config.m_inv_m1 ** 2 + config.beta_alpha * config.kappa * rho

    A = lil_matrix((n, n), dtype=float)
    b = np.zeros(n, dtype=float)

    # Unknowns are cell-center phi values. Last node is pinned to zero.
    for i in range(n - 1):
        rlo, rhi = faces[i], faces[i + 1]
        vol_over_4pi = (rhi ** 3 - rlo ** 3) / 3.0
        if vol_over_4pi <= 0:
            raise ValueError("invalid finite-volume shell volume")

        # outward face contribution
        dr_up = r[i + 1] - r[i]
        cup = (rhi ** 2) / (vol_over_4pi * dr_up)
        A[i, i] -= cup
        A[i, i + 1] += cup

        # inward face contribution; for i=0, rlo=0 so regular flux is zero.
        if i > 0:
            dr_dn = r[i] - r[i - 1]
            cdn = (rlo ** 2) / (vol_over_4pi * dr_dn)
            A[i, i] -= cdn
            A[i, i - 1] += cdn

        A[i, i] -= m_eff2[i]
        b[i] = config.beta * config.kappa * rho[i]

    # outer Dirichlet phi=0
    A[n - 1, n - 1] = 1.0
    b[n - 1] = 0.0

    phi = spsolve(csr_matrix(A), b)
    return np.asarray(phi, dtype=float)


def evaluate_delta_radial(profile: RadialSourceProfile, config: QCTL2EvaluatorConfig) -> dict:
    phi = solve_phi_radial(profile, config)
    delta = -phi
    return {
        "r_m": np.asarray(profile.r_m, dtype=float),
        "rho_b_kg_m3": np.asarray(profile.rho_b_kg_m3, dtype=float),
        "phi": phi,
        "delta_qct_l2_of_r": delta,
        "gbar_m_s2": None if profile.gbar_m_s2 is None else np.asarray(profile.gbar_m_s2, dtype=float),
        "source_governance": {
            "closure": "SPEC-205 phenomenological closure, beta=beta_alpha=1",
            "boundary": "regular center plus phi outer decay/zero boundary",
            "extraction": "Delta(r) := -phi(R=r,z=0)",
            "forbidden_inputs": [
                "observed g_obs residuals",
                "QUMOND residuals",
                "halo tuning",
                "mass-to-light backsolving",
                "likelihood-optimized Delta values",
            ],
        },
    }


def delta_at_x_bins(
    profile: RadialSourceProfile,
    config: QCTL2EvaluatorConfig,
    x_bins: Iterable[float],
    *,
    branch_rule: str = "monotone_source_branch_required",
) -> list[dict]:
    """Project Delta(r) onto requested x=log10(gbar) bins.

    V1 is intentionally conservative: it only emits single-valued Delta(x_i)
    if x(r) is monotone over the supplied source window. If not monotone, the
    evaluator refuses to silently choose a branch or aggregate fiber. A later
    author-supplied branch/fiber rule would be an explicit new convention.
    """
    if profile.gbar_m_s2 is None:
        raise ValueError("gbar_m_s2 is required to evaluate Delta at x bins")
    if branch_rule != "monotone_source_branch_required":
        raise ValueError("V1 allows only monotone_source_branch_required")

    out = evaluate_delta_radial(profile, config)
    gbar = np.asarray(profile.gbar_m_s2, dtype=float)
    x = np.log10(gbar)
    delta = out["delta_qct_l2_of_r"]
    dx = np.diff(x)
    monotone_inc = np.all(dx > 0)
    monotone_dec = np.all(dx < 0)
    if not (monotone_inc or monotone_dec):
        raise ValueError(
            "x(r)=log10(gbar) is not monotone; V1 refuses silent branch/fiber fusion"
        )
    if monotone_dec:
        xp, fp = x[::-1], delta[::-1]
    else:
        xp, fp = x, delta

    rows = []
    for j, xb in enumerate(x_bins):
        xb = float(xb)
        if xb < xp[0] or xb > xp[-1]:
            value = None
            status = "outside_source_x_range"
        else:
            value = float(np.interp(xb, xp, fp))
            status = "emitted_from_source_governed_evaluator"
        rows.append({
            "benchmark_bin_id": f"bin_{j:03d}",
            "x_i": xb,
            "delta_qct_l2": value,
            "status": status,
            "branch_rule": branch_rule,
        })
    return rows


def load_profile_csv(path: Path) -> RadialSourceProfile:
    rows = list(csv.DictReader(path.open()))
    r = np.array([float(row["r_m"]) for row in rows], dtype=float)
    rho = np.array([float(row["rho_b_kg_m3"]) for row in rows], dtype=float)
    if "gbar_m_s2" in rows[0] and rows[0]["gbar_m_s2"] != "":
        gbar = np.array([float(row["gbar_m_s2"]) for row in rows], dtype=float)
    else:
        gbar = None
    return RadialSourceProfile(r, rho, gbar)


def write_delta_csv(rows: list[dict], path: Path) -> None:
    fieldnames = [
        "benchmark_bin_id", "x_i", "delta_qct_l2", "status", "branch_rule",
        "operator_authority_ref", "source_to_total_rule_ref", "no_borrowing_declaration",
    ]
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            row = dict(row)
            row["operator_authority_ref"] = "SPEC-205 radial closure evaluator V1"
            row["source_to_total_rule_ref"] = "Delta(r)=-phi(r); optional monotone x-pushforward"
            row["no_borrowing_declaration"] = "no observed residuals, no QUMOND residuals, no fitting"
            w.writerow(row)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", required=True, type=Path)
    ap.add_argument("--m-inv-m1", required=True, type=float)
    ap.add_argument("--x-bins", type=Path)
    ap.add_argument("--output-json", type=Path)
    ap.add_argument("--output-delta-csv", type=Path)
    args = ap.parse_args()

    profile = load_profile_csv(args.profile)
    cfg = QCTL2EvaluatorConfig(m_inv_m1=args.m_inv_m1)
    out = evaluate_delta_radial(profile, cfg)

    payload = {
        "object_class": "FORM_C_PACKAGE",
        "evaluator": "QCT_L2_SPEC205_RADIAL_DELTA_EVALUATOR_V1",
        "row_count": int(len(out["r_m"])),
        "m_inv_m1": args.m_inv_m1,
        "delta_min": float(np.min(out["delta_qct_l2_of_r"])),
        "delta_max": float(np.max(out["delta_qct_l2_of_r"])),
        "phi_min": float(np.min(out["phi"])),
        "phi_max": float(np.max(out["phi"])),
        "source_governance": out["source_governance"],
        "ceiling": "Form C evaluator only; not Form A values unless source profile, bins, and monotone x projection are supplied",
    }

    if args.x_bins is not None:
        x_rows = [float(line.strip()) for line in args.x_bins.read_text().splitlines() if line.strip() and not line.startswith("#")]
        delta_rows = delta_at_x_bins(profile, cfg, x_rows)
        payload["x_bin_rows"] = delta_rows
        if args.output_delta_csv is not None:
            write_delta_csv(delta_rows, args.output_delta_csv)

    if args.output_json is not None:
        args.output_json.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    else:
        print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
