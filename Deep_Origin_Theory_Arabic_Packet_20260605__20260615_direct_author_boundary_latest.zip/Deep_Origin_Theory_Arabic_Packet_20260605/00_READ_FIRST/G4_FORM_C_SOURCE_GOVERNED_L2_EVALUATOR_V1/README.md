# G4 Form C Source-Governed L2 Evaluator V1

This is the smallest fresh internal object I can honestly materialize without fabricating Form A values.

It is a callable `Form C` evaluator based on the existing SPEC-205 closure plus the locked `phi -> Delta -> V_model` extraction route.

Run toy self-test:

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt

python3 03_RUN/qct_l2_form_c_evaluator.py \
  --profile 04_INPUT_TEMPLATES/source_profile_TEMPLATE.csv \
  --m-inv-m1 1e-21 \
  --x-bins 04_INPUT_TEMPLATES/frozen_x_bins_TEMPLATE.txt \
  --output-json 05_OUTPUTS/toy_selftest_output.json \
  --output-delta-csv 05_OUTPUTS/toy_delta_table.csv
```

The toy source is not a scientific Form A table. It only proves that the evaluator is callable and refuses no-cheat constraints.

Runtime note:

- `requirements.txt` is now shipped with the package.
- the toy self-test was re-verified on `2026-06-11` in a clean Python `3.14`
  virtual environment with `numpy 2.4.6` and `scipy 1.17.1`.

To make this a live `G4` flip object, replace the toy profile and bins with the frozen benchmark source/bins and freeze the QCT parameter input by author authority.
