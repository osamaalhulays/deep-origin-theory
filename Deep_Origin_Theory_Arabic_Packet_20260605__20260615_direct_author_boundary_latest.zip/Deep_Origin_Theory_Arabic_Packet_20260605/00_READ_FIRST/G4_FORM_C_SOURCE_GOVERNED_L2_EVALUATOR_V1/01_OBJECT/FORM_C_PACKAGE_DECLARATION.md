# G4 Form C Source-Governed L2 Evaluator Package V1

Date: 2026-06-11

Status: fresh internal authoring object candidate

## Primary class

`FORM_C_PACKAGE`

## Object name

`QCT_L2_SPEC205_RADIAL_DELTA_EVALUATOR_V1`

## Claim

This package materializes one bounded callable evaluator for `Delta_QCT_L2`
from the already declared public chain:

1. SPEC-205 phenomenological closure,
2. same-source / asymptotic boundary convention,
3. equatorial radial extraction lock,
4. non-parameterized `phi -> Delta -> V_model` mapping.

It is not a `Form A` populated table. It is a source-governed evaluator which can emit a `Form A`-shaped table only after receiving:

- a lawful baryonic source profile,
- a frozen `m_inv` value or already-approved QCT parameter draw,
- frozen benchmark bins,
- and a monotone `x = log10(gbar)` source branch.

## Exact mathematical object

Given a radial/spherical-pullback baryonic source profile

`S = (r_j, rho_b(r_j), gbar(r_j))`,

and the fixed SPEC-205 conventions

`beta = 1`, `beta_alpha = 1`, `kappa = 8*pi*G/c^2`,

solve

```text
(1/r^2) d/dr (r^2 dphi/dr) - m_eff^2(r) phi = kappa rho_b(r)
m_eff^2(r) = m_inv^2 + kappa rho_b(r)
```

with

```text
regular center flux
outer/asymptotic decay represented by phi(r_outer)=0
```

then emit

```text
Delta_QCT_L2(r) = -phi(r)
```

and, only when `x(r)=log10(gbar(r))` is monotone over the supplied window,

```text
Delta_QCT_L2(x_i) = linear_interpolate[Delta(r) along x(r)] at x_i.
```

If `x(r)` is not monotone, V1 refuses to emit a single-valued `Delta(x_i)` table. A branch/fiber selection rule would be a separate explicit authorial convention and is not silently introduced here.

## Why this is not a cheat

- No observed `gobs` appears in the evaluator.
- No QUMOND residual appears in the evaluator.
- No halo profile appears in the evaluator.
- No mass-to-light backsolve appears in the evaluator.
- No likelihood optimization appears in the evaluator.
- `beta` and `beta_alpha` are fixed to one.
- `m_inv` is consumed as a QCT parameter/input, not split or tuned inside the evaluator.
- The output is generated from a baryonic source through the closure equation, not from a fitted target residual.

## Ceiling

This package does not claim:

- observed-row crossing,
- likelihood or fit,
- `H0` authority,
- full cosmology closure,
- `MOND/QUMOND` family closure,
- or completion of `G4` by itself.

It only changes the immediate G4 bottleneck from:

`no visible Form C evaluator`

to:

`one bounded fresh Form C evaluator object exists for the spherical/radial source class, pending author freeze/adoption and execution on the true frozen bins.`
