# Hard Ceiling Compliance Card

## No silent new operator

The evaluator uses the SPEC-205 closure operator. The new object is a callable numerical realization of the already-declared closure, not a new physical operator.

## No parameter split

`beta = 1` and `beta_alpha = 1`. `m_inv` is one input parameter from the existing QCT closure family; it is not split by radius, component, source, galaxy, or bin.

## No kernel promotion

The package does not claim that older bounded probes were already authority-bearing. It supplies a fresh explicit evaluator object.

## No symbol fusion

`Delta_QCT_L2` is emitted from `phi` through the locked extraction `Delta=-phi`. No `Xi` object is fused into `Delta`.

## No truth-claim inflation

The package is Form C only. It does not claim Form A numeric closure until source rows and bins are actually run.

## No empirical payload reclassification

The evaluator requires a source profile as input, but it does not treat empirical direct-author payload arrival as theory-side authoring.

## No fit-derived reverse engineering

No observed residual, QUMOND residual, mass-to-light residual, likelihood residual, or fitted halo surface is permitted as input to define `Delta`.
