# Input / Output Schema

## Required input CSV

`source_profile.csv`

Columns:

```text
r_m,rho_b_kg_m3,gbar_m_s2
```

- `r_m`: strictly increasing radial grid in meters.
- `rho_b_kg_m3`: nonnegative baryonic mass density.
- `gbar_m_s2`: positive baryonic acceleration, required only for x-bin projection.

## Required parameter

```text
m_inv_m1
```

This is the inverse length already belonging to the QCT closure/parameter family. V1 does not split it, fit it, or tune it.

## Optional x-bin file

One number per line:

```text
x_i = log10(gbar_i)
```

## Core output

```text
r_m
phi(r)
Delta_QCT_L2(r) = -phi(r)
```

## Optional Form-A-shaped output

Only if `x(r)` is monotone:

```text
benchmark_bin_id,x_i,delta_qct_l2,status,branch_rule,operator_authority_ref,source_to_total_rule_ref,no_borrowing_declaration
```

## Refusal condition

If `x(r)` is nonmonotone, the evaluator refuses single-valued `Delta(x_i)` emission. It will not silently choose an inner/outer branch or average multiple fibers.
