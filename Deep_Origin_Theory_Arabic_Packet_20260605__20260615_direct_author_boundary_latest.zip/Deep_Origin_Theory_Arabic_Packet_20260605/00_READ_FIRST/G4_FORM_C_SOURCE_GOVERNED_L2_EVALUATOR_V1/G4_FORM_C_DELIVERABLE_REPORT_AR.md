# تقرير تسليم G4 — Form C Source-Governed L2 Evaluator V1

## 1. Primary verdict

`FORM_C_PACKAGE_MATERIALIZED_BOUNDED`

لم أستطع إنتاج `Form A` عددي حقيقي من دون إدخال مصدر/معلمات/بنات frozen فعلية. إنتاج أرقام `Delta_QCT_L2(x_i)` من الفراغ سيكون reverse engineering أو naming inflation.

ما أمكن بناؤه قانونيًا هو جسم `Form C`: دالة تقييم source-governed قابلة للتشغيل، مبنية من سلسلة SPEC-205 + boundary/extraction locks، وتصدر `Delta_QCT_L2` من مصدر باريوني.

## 2. Chosen deliverable class

`Form C evaluator function`

اسم الجسم:

`QCT_L2_SPEC205_RADIAL_DELTA_EVALUATOR_V1`

## 3. Exact theorem / construction / no-go statement

### Construction statement

إذا أُعطي evaluator مصدرًا باريونيًا شعاعيًا:

`S = (r_j, rho_b(r_j), gbar(r_j))`

ومعاملًا مجمدًا:

`m_inv`

فإنه يحل معادلة SPEC-205 الشعاعية:

```text
(1/r^2) d/dr (r^2 dphi/dr) - m_eff^2(r) phi = kappa rho_b(r)
m_eff^2(r) = m_inv^2 + kappa rho_b(r)
```

مع:

```text
beta = 1
beta_alpha = 1
kappa = 8*pi*G/c^2
regular center flux
outer decay represented by phi(r_outer)=0
```

ثم يصدر:

```text
Delta_QCT_L2(r) = -phi(r)
```

وإذا كان:

```text
x(r) = log10(gbar(r))
```

monotone على النافذة المعطاة، يصدر أيضًا:

```text
Delta_QCT_L2(x_i)
```

بالاستيفاء الخطي على الفرع نفسه.

إذا لم يكن `x(r)` monotone، يرفض V1 إصدار جدول `Delta(x_i)` أحادي القيمة، ولا يختار فرعًا أو fiber-average بصمت.

## 4. Exact assumptions

1. `SPEC-205` مقبول كـ phenomenological closure حاضر في السلسلة.
2. `beta = beta_alpha = 1` ولا يوجد fitting لهما.
3. `m_inv` مدخل QCT مجمد من خارج evaluator، وليس parameter split داخلي.
4. المصدر الباريوني يُعطى كملف source profile، وليس كـ residual أو fit product.
5. `Delta(r) = -phi(r)` هو extraction rule.
6. `Delta(x_i)` لا يصدر إلا إذا كانت `x(r)` monotone؛ وإلا فالمطلوب rule إضافي صريح.
7. لا يتم استخدام `g_obs`, QUMOND residuals, halo fits, mass-to-light backsolving, likelihood-optimized targets.

## 5. Exact typed objects used

```text
InputSourceProfile:
  type: CSV[r_m, rho_b_kg_m3, optional gbar_m_s2]

FrozenQCTParameter:
  type: m_inv_m1 >= 0

ClosureOperator:
  type: SPEC-205 radial finite-volume closure

BoundaryContract:
  type: regular_center_flux_zero + phi_outer_zero

ExtractionRule:
  type: Delta(r) := -phi(r)

OptionalXProjection:
  type: monotone x(r)=log10(gbar(r)) interpolation only

OutputCore:
  type: Delta_QCT_L2(r)

OutputOptional:
  type: Delta_QCT_L2(x_i)
```

## 6. Derivation or construction skeleton

1. اقرأ `r`, `rho_b`, و optionally `gbar` من source profile.
2. تحقق من أن `r` موجب ومتزايد، وأن `rho_b >= 0`.
3. ثبّت `kappa = 8*pi*G/c^2`.
4. ثبّت `beta = beta_alpha = 1`.
5. ابنِ `m_eff^2(r) = m_inv^2 + kappa*rho_b(r)`.
6. حل finite-volume radial closure.
7. استخرج `Delta(r) = -phi(r)`.
8. إذا أُعطيت `x_i` و `gbar`, احسب `x(r)=log10(gbar)`.
9. إذا كان `x(r)` monotone, أصدر `Delta(x_i)`.
10. إذا لم يكن monotone, ارفض إصدار Form-A-shaped table؛ لا silent branch fusion.

## 7. Final formula / schema / pseudocode

```python
profile = RadialSourceProfile(r_m, rho_b_kg_m3, gbar_m_s2)
config = QCTL2EvaluatorConfig(m_inv_m1=m_inv)
phi = solve_phi_radial(profile, config)
delta_r = -phi
rows = delta_at_x_bins(profile, config, x_bins)
```

أمر تشغيل اختباري:

```bash
python3 03_RUN/qct_l2_form_c_evaluator.py \
  --profile 04_INPUT_TEMPLATES/source_profile_TEMPLATE.csv \
  --m-inv-m1 1e-21 \
  --x-bins 04_INPUT_TEMPLATES/frozen_x_bins_TEMPLATE.txt \
  --output-json 05_OUTPUTS/toy_selftest_output.json \
  --output-delta-csv 05_OUTPUTS/toy_delta_table.csv
```

## 8. Earliest blocker

المانع الأول لم يعد: “لا توجد أي طريقة لصياغة evaluator”.

المانع الآن هو:

```text
frozen source rows + frozen m_inv + frozen benchmark bins are not yet supplied as authoritative G4 execution inputs.
```

وبالنسبة لـ `Delta(x_i)` تحديدًا، يوجد مانع إضافي إذا كانت `x(r)` غير monotone:

```text
no lawful branch/fiber projection rule is frozen yet.
```

## 9. Smallest extra freedom that would flip remaining no-go

أصغر حرية متبقية، إذا أردتم تحويل هذا إلى `Form A`, هي واحدة من اثنتين:

### الحالة السهلة

إذا كانت `x(r)` monotone في المصدر الفعلي:

```text
author-freeze source profile + m_inv + benchmark bins
```

ثم السكربت يخرج `Delta_QCT_L2(x_i)` مباشرة.

### الحالة غير monotone

إذا لم تكن `x(r)` monotone:

```text
one explicit branch/fiber projection convention
```

مثل:

```text
outer-branch only
```

أو:

```text
source-measure fiber average
```

لكن هذا يجب أن يعلن كحرية authorial جديدة، لا أن يدخل بصمت.

## 10. Why this respects the hard ceilings

- لا operator جديد: هو realization لـ SPEC-205 closure.
- لا parameter split: `beta` و `beta_alpha` ثابتان، و`m_inv` لا يُقسّم.
- لا kernel promotion: الجسم جديد ومعلن، وليس rebranding لبروب قديم.
- لا symbol fusion: لا يستخدم Xi ولا يخلطه مع Delta.
- لا truth inflation: هذا Form C فقط، وليس L0 crossing.
- لا closure inflation: لا يدعي fit, likelihood, H0, CMB, أو cosmology closure.
- لا empirical payload reclassification: المصدر الباريوني input، وليس authoring payload بديل.
- لا reverse engineering: لا يستخدم observed residuals أو QUMOND residuals أو likelihood targets.

## 11. Blunt bottom line

لم أصنع `Form A` أرقامًا؛ ذلك سيكون غير قانوني دون source/bin/parameter freeze.

الذي صنعته هو أقوى جسم داخلي يمكن إنشاؤه الآن بلا غش:

```text
fresh bounded Form C evaluator object
```

هذا لا يغلق `G4` وحده، لكنه يغير موضع العائق من:

```text
لا توجد دالة تقييم L2 source-governed
```

إلى:

```text
الدالة موجودة؛ نحتاج تشغيلها على source rows + frozen bins + frozen parameter authority، أو نحتاج branch/fiber rule إذا كان x(r) غير monotone.
```
