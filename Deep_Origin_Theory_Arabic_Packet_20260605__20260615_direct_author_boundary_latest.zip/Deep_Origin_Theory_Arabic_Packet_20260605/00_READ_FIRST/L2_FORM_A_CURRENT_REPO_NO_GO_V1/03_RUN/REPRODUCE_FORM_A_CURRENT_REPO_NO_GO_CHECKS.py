from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


SCRIPT_PATH = Path(__file__).resolve()
OBJECT_ROOT = SCRIPT_PATH.parents[1]
ROOT = SCRIPT_PATH.parents[4]
OUTPUTS = OBJECT_ROOT / "04_OUTPUTS"

IGNORE_FRAGMENTS = (
    "/node_modules/",
    "/tmp_",
    "/L2_FORM_A_CURRENT_REPO_NO_GO_V1/",
)
DATA_SUFFIXES = {".csv", ".json", ".ndjson"}

DATA_TOKENS = (
    "Delta_QCT_L2",
    "Xi_QCT_L2",
    "delta_qct_l2",
    "benchmark_bin_id",
)

NOTE_CHECKS = [
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_O4_O5_KREIB_CROSS_REPO_REFINEMENT_AFTER_RULE_AND_OPERATOR_SUPPLY_20260608.md",
        "fragments": [
            "bounded geometric evaluator probe at `C0_NO_CLAIM_EXPORT`: present",
            "`missing_numeric_Delta_QCT_L2_response_values_at_SPARC_bins`",
        ],
        "meaning": "rule/operator/probe present while direct numeric authority remains absent",
    },
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_EVALUATOR_CONTENT_TARGET_AFTER_RULE_AND_OPERATOR_SUPPLY_20260608.md",
        "fragments": [
            "one promotable source-governed `Delta_QCT_L2(x_i)` or",
            "authority still does not",
        ],
        "meaning": "the route itself still records the missing promotable Delta/Xi authority",
    },
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_KREIB_Q_PREFILL_AND_U1_SEED_CLASS_NOTE_20260608.md",
        "fragments": [
            "treating third-generation `C0_NO_CLAIM_EXPORT` probes as promotable",
            "These are the main false-rescue traps.",
        ],
        "meaning": "bounded no-claim probes may not be promoted into authority by inflation",
    },
]


def relative(path: Path) -> str:
    return str(path.relative_to(ROOT))


def include(path: Path) -> bool:
    path_str = str(path)
    return path.is_file() and not any(fragment in path_str for fragment in IGNORE_FRAGMENTS)


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def classify_data_hit(path: Path, text: str) -> tuple[str, int]:
    if path.name == "FORM_A_DELTA_TABLE_TEMPLATE.csv":
        row_count = max(0, len([line for line in text.splitlines() if line.strip()]) - 1)
        return "template_only", row_count
    if (
        path.name == "status_summary.json"
        and "log10_gobs_QCT(x) = x + Delta_QCT_L2(x)" in text
    ):
        return "formula_only", 0
    return "candidate_numeric_surface", 0


def collect_data_hits() -> list[dict]:
    hits: list[dict] = []
    for path in sorted(ROOT.rglob("*")):
        if not include(path) or path.suffix.lower() not in DATA_SUFFIXES:
            continue
        text = read_text(path)
        matched_lines = []
        for index, line in enumerate(text.splitlines(), start=1):
            if any(token in line for token in DATA_TOKENS):
                matched_lines.append({"line": index, "text": line.strip()})
        if not matched_lines:
            continue
        classification, row_count = classify_data_hit(path, text)
        hits.append(
            {
                "path": relative(path),
                "classification": classification,
                "row_count": row_count,
                "matches": matched_lines,
            }
        )
    return hits


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {
            fragment: (fragment in text) for fragment in item["fragments"]
        }
        results.append(
            {
                "path": relative(item["path"]),
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def build_report(status: dict, note_checks: list[dict], hits: list[dict]) -> str:
    lines = [
        "# Form A Current-Repo No-Go Report",
        "",
        f"Generated at: `{status['generated_at_utc']}`",
        "",
        f"Verdict: `{status['verdict']}`",
        "",
        "## Summary",
        "",
        f"- direct populated numeric candidate surfaces found: `{status['candidate_numeric_surface_count']}`",
        f"- formula-only placeholders found: `{status['formula_only_count']}`",
        f"- template-only surfaces found: `{status['template_only_count']}`",
        f"- populated benchmark rows found: `{status['populated_template_row_count_total']}`",
        f"- bounded-probe promotion fence confirmed: `{str(status['bounded_probe_promotion_fence_confirmed']).lower()}`",
        "",
        "## Data-bearing hits",
        "",
    ]
    if not hits:
        lines.append("- none")
    else:
        for hit in hits:
            lines.append(
                f"- `{hit['classification']}`: `{hit['path']}`"
            )
    lines.extend(
        [
            "",
            "## Note checks",
            "",
        ]
    )
    for check in note_checks:
        lines.append(
            f"- `{check['path']}` -> `{str(check['passed']).lower()}`"
        )
    lines.extend(
        [
            "",
            "## Reading",
            "",
            "- the current route already carries rule/operator/probe grammar,",
            "- but the repo-visible data-bearing surfaces still do not carry one populated `Form A` authority pack,",
            "- so current lawful `Form A` materialization is absent.",
            "",
            "## Next exact move",
            "",
            "- stop hidden-`Form A` hunting on the same frozen route",
            "- escalate to one `Form C` evaluator-content attack, or else a stronger same-route failure verdict",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    OUTPUTS.mkdir(parents=True, exist_ok=True)

    hits = collect_data_hits()
    note_checks = collect_note_checks()

    candidate_hits = [
        hit for hit in hits if hit["classification"] == "candidate_numeric_surface"
    ]
    formula_hits = [hit for hit in hits if hit["classification"] == "formula_only"]
    template_hits = [hit for hit in hits if hit["classification"] == "template_only"]

    status = {
        "object_kind": "form_a_current_repo_no_go_status",
        "generated_at_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "scope": "current_repo_visible_frozen_route_only",
        "candidate_numeric_surface_count": len(candidate_hits),
        "formula_only_count": len(formula_hits),
        "template_only_count": len(template_hits),
        "populated_template_row_count_total": sum(hit["row_count"] for hit in template_hits),
        "all_note_checks_pass": all(check["passed"] for check in note_checks),
        "bounded_probe_promotion_fence_confirmed": any(
            "promotable" in fragment and present
            for check in note_checks
            for fragment, present in check["fragments"].items()
        ),
        "direct_form_a_value_pack_present": len(candidate_hits) > 0,
        "benchmark_roster_materialized": any(hit["row_count"] > 0 for hit in template_hits),
        "verdict": "FORM_A_CURRENT_REPO_VISIBLE_ROUTE_NO_GO_MATERIALIZED",
    }

    verdict = {
        "verdict": status["verdict"],
        "scope": status["scope"],
        "why": [
            "rule/operator/probe ladder is present",
            "bounded probes are already fenced below promotable authority",
            "data-bearing surfaces expose only formula placeholders and header-only templates",
            "no populated direct Delta/Xi authority pack is currently visible",
        ],
        "next_exact_move": "FORM_C_EVALUATOR_CONTENT_ATTACK_OR_STRONGER_SAME_ROUTE_FAILURE_VERDICT",
        "ceiling": [
            "not a permanent impossibility theorem",
            "not a rejection of Form B/C/D in principle",
            "not a full-program failure verdict",
        ],
    }

    report = build_report(status, note_checks, hits)

    (OUTPUTS / "data_surface_hits.json").write_text(
        json.dumps(hits, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "note_checks.json").write_text(
        json.dumps(note_checks, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "status_summary.json").write_text(
        json.dumps(status, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "verdict.json").write_text(
        json.dumps(verdict, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "FORM_A_CURRENT_REPO_NO_GO_REPORT.md").write_text(
        report,
        encoding="utf-8",
    )

    if candidate_hits:
        raise SystemExit("unexpected candidate numeric surface found")
    if any(hit["row_count"] > 0 for hit in template_hits):
        raise SystemExit("unexpected populated template rows found")
    if not all(check["passed"] for check in note_checks):
        raise SystemExit("required note evidence check failed")


if __name__ == "__main__":
    main()
