# Current `G6` / `D7` author-supplied Clean-First Reserve Structure Note

Date: `2026-06-13`

Purpose:

Freeze the exact current reading after the first focused clean-first case from
the landed author-supplied `PAYLOAD_B` family is no longer alone and now sits on one
reviewer-visible reserve.

## Short verdict

The fair current reading is:

- `NGC1313` is no longer only one named first case
- one clean-first reserve now exists behind it
- that reserve currently contains `11` galaxies and `184` observed rows
- the top `3` reserve cases currently carry `100` observed rows
- the reserve remains empirical `gobs/gbar` only
- theory-side promotion is still not claimed

## Exact current gain

This now gives:

- one reviewer-visible clean-first reserve ledger
- one compact top-3 reserve surface
- one procedural reserve behind the first named case rather than one singleton
- one second named focused case now materialized inside that reserve
- one third named focused case now materialized inside that reserve
- one fourth named focused case now materialized inside that reserve
- one fifth named focused case now materialized inside that reserve
- one sixth named focused case now materialized inside that reserve
- one seventh named focused case now materialized inside that reserve
- one named front-7 now materialized above the remaining tail

## Exact current ceiling

This still does **not** give:

- one theory-side authoring move
- one `QCT` prediction family
- one matched-nuisance execution
- one named competitor verdict

## Read with

- `CURRENT_G6_D7_PAYLOAD_B_49_GALAXY_ROWWISE_COMPARISON_ADMISSIBILITY_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_NGC1313_FIRST_CLEAN_EMPIRICAL_ROWCASE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_NGC2541_SECOND_CLEAN_EMPIRICAL_ROWCASE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_NGC7793_THIRD_CLEAN_EMPIRICAL_ROWCASE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_NGC3992_FOURTH_CLEAN_EMPIRICAL_ROWCASE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_LVHIS077_FIFTH_CLEAN_EMPIRICAL_ROWCASE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_LVHIS072_SIXTH_CLEAN_EMPIRICAL_ROWCASE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_LVHIS011_SEVENTH_CLEAN_EMPIRICAL_ROWCASE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_NAMED_FRONT4_STRUCTURE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_NAMED_FRONT5_STRUCTURE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_NAMED_FRONT6_STRUCTURE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_NAMED_FRONT7_STRUCTURE_NOTE_20260613.md`
- `AUTHOR_SUPPLIED_PAYLOAD_B_CLEAN_FIRST_RESERVE_STRUCTURE_OBJECT_V1`
- `CLEAN_FIRST_EMPIRICAL_RESERVE_CAPSULE__AUTHOR_SUPPLIED_PAYLOAD_B__V1.md`
