# Current `G6` / `D7` author-supplied Top-`3` Clean Focused Trio Note

Date: `2026-06-13`

Purpose:

Freeze the exact current reading after the visible top-`3` clean-first reserve
inside the landed author-supplied `PAYLOAD_B` lane is no longer partly abstract.

## Short verdict

The fair current reading is:

- the top-`3` clean-first reserve is now fully materialized as three named
  focused empirical cases
- those three cases are `NGC1313`, `NGC2541`, and `NGC7793`
- together they currently carry `100` observed rows
- all three remain empirical `gobs/gbar` only
- theory-side promotion is still not claimed

## Exact current gain

This now gives:

- one full named focused trio instead of one first case plus one partly tabular
  reserve
- three exact row tables
- three compact key-row tables
- three replayable focused-case summary surfaces

## Exact current ceiling

This still does **not** give:

- one theory-side authoring move
- one `QCT` prediction family
- one matched-nuisance execution
- one named competitor verdict

## Read with

- `CURRENT_G6_D7_AUTHOR_SUPPLIED_NGC1313_FIRST_CLEAN_EMPIRICAL_ROWCASE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_NGC2541_SECOND_CLEAN_EMPIRICAL_ROWCASE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_NGC7793_THIRD_CLEAN_EMPIRICAL_ROWCASE_NOTE_20260613.md`
- `CURRENT_G6_D7_AUTHOR_SUPPLIED_CLEAN_FIRST_RESERVE_STRUCTURE_NOTE_20260613.md`
- `TOP3_CLEAN_EMPIRICAL_TRIO_CAPSULE__AUTHOR_SUPPLIED_PAYLOAD_B__V1.md`
