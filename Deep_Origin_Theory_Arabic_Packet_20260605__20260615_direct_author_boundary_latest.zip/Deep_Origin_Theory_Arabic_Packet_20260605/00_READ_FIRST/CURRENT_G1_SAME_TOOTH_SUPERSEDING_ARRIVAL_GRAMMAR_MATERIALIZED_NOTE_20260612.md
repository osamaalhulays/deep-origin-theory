# Current `G1` Same-Tooth Superseding Arrival Grammar Materialized

Date: `2026-06-12`

Purpose:

Record the exact effect of the new superseding-arrival grammar on the current
`G1` same-tooth battlefield.

## Short verdict

The route no longer carries:

- one vague `supersede` branch.

It now carries:

- one exact typed superseding-arrival grammar with three classes:
  `SUPERSEDE_A_DIRECT_DISCHARGE`,
  `SUPERSEDE_B_ORDER_REREAD`,
  and
  `SUPERSEDE_C_SAME_TOOTH_BREAK`.

The current route result under that grammar is:

- `no_current_repo_visible_same_tooth_superseding_package`

## Exact consequence

This is:

- same-tooth superseding-arrival grammar progress only.

It is **not**:

- a present superseding arrival,
- a landed ordinary freeze witness,
- final pairwise law,
- `T_Q^(0)` closure,
- or exact transport closure.

## Read with

- `POST_CAGE_BRANCH_U1_SAME_TOOTH_SUPERSEDING_ARRIVAL_GRAMMAR_REVIEWER_OBJECT_NOTE_20260612.md`
- `POST_CAGE_BRANCH_U1_SAME_TOOTH_SUPERSEDING_ARRIVAL_GRAMMAR_V1/04_OUTPUTS/SAME_TOOTH_SUPERSEDING_ARRIVAL_GRAMMAR_REPORT.md`
- `CURRENT_G1_SAME_TOOTH_FREEZE_WITNESS_ARRIVAL_GRAMMAR_MATERIALIZED_NOTE_20260612.md`
- `CURRENT_G1_SAME_TOOTH_FREEZE_WITNESS_LOCAL_PACKET_EXHAUSTION_AND_WATCH_ONLY_NOTE_20260612.md`
