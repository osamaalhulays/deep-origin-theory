# Current `G6` `L2` Direct-Author Payload Arrived And Classified As `PAYLOAD_B`

Date: `2026-06-12`

Purpose:

Freeze one exact current-state note for the live `G6` lane after the promised
direct-author source corridor has turned into a real attachment-bearing payload.

## Short verdict

The fair current reading is:

- one lawful direct-author payload has now really arrived
- the arrival is machine-readable
- same-source coherence survives across the paired files
- the packet now carries one bounded receipt audit object for that
  landing
- the payload does not reach `PAYLOAD_A`
- the payload does reach `PAYLOAD_B`
- `G6` is therefore closed

## Exact arrival facts

- one direct-author email supplied the payload to the user on `2026-06-12`
- the arrival channel is one lawful `G6` channel:
  direct-author payload supplied to the user
- the payload arrives as two zip attachments:
  one observed-circular-speed set and one baryonic-component set
- the observed set contains `49` machine-readable `.dat` files
- the baryonic set contains `49` machine-readable `.dat` files
- the galaxy-name sets match exactly across the two zips
- the landed pair therefore contains `49 / 49` exact matched galaxy pairs
- total observed rows = `1082`
- total baryonic rows = `4850`
- all observed files share one uniform header:
  `rad_kpc vcirc_km/s e_vcirc`
- all baryonic files share one uniform header:
  `rad_kpc VHI VH2 Vstars eVstars_low eVstars_high Vbulge eVbulge_low eVbulge_high`
- the baryonic files are oversampled relative to the observed rows in all
  `49/49` galaxy pairs, exactly as documented by the author in the message

## Why this is not `PAYLOAD_A`

`PAYLOAD_A` requires full component curves with component uncertainties.

The landed payload does not reach that class because:

- there is no explicit gas-uncertainty surface for the gas side as such
- the gas side is supplied as split components `VHI` and `VH2`, not as one
  uncertainty-complete generic `Vgas` field
- the stellar and bulge uncertainties are present only on those components and
  in asymmetric low/high form, not as one complete uncertainty surface across
  all components

So the lawful read is:

- `PAYLOAD_A` is not admitted

## Why this does reach `PAYLOAD_B`

`PAYLOAD_B` requires component curves without component uncertainties.

The landed payload does reach that class because:

- `Vobs` and `sigma_Vobs` are supplied directly in the observed files
- baryonic component curves are supplied directly in machine-readable form
- the stellar component is supplied directly as `Vstars`
- the optional bulge component is supplied directly as `Vbulge`
- the gas side is supplied in one stronger split form:
  `VHI` plus `VH2`,
  which is sufficient for the weaker component-curve class even though it is
  not one uncertainty-complete `PAYLOAD_A` gas surface
- no OCR, digitization, proxy fitting, or `Vbar` substitution is needed to
  materialize the arrival

So the lawful class freeze is:

- `PAYLOAD_B`

## Exact closure effect

This note does **not** claim:

- `PAYLOAD_A`
- automatic `C2`
- theory-side `G4` authoring
- full bank closure

It claims something narrower:

- the empirical `L2` payload has now actually arrived through one lawful
  channel
- the arrival has passed the exact current intake reading at `PAYLOAD_B` grade
- and `G6` is therefore no longer one live open arrival wound

## Redistribution boundary

This note records payload arrival and exact intake class only.

It does **not** republish the raw direct-author files inside the public packet.

Instead, the packet now carries one bounded receipt object:

- `AUTHOR_SUPPLIED_PAYLOAD_B_RECEIPT_AUDIT_OBJECT_V1`

## Downstream boundary

This note also does **not** claim that the landed empirical payload already
fixes one unique downstream normalization for:

- signed gas-component rematerialization
- duplicate-radius compression
- optional bulge `nan` handling
- or silent conversion from circular-speed components to `rho_b(r)`

## Read with

- `CURRENT_G6_L2_EMPIRICAL_PAYLOAD_ARRIVAL_GRAMMAR_NOTE_20260611.md`
- `CURRENT_D7_L2_PAYLOAD_B_ADMIT_BOUNDED_VERDICT_NOTE_20260612.md`
- `AUTHOR_SUPPLIED_PAYLOAD_B_RECEIPT_AUDIT_OBJECT_V1`
- `HISTORICAL_G6_AUTHOR_SUPPLIED_PRE_ARRIVAL_MAILBOX_STATUS_NOTE_20260612.md`
- `CURRENT_G6_D7_PAYLOAD_B_DOWNSTREAM_USE_BOUNDARY_NOTE_20260612.md`
