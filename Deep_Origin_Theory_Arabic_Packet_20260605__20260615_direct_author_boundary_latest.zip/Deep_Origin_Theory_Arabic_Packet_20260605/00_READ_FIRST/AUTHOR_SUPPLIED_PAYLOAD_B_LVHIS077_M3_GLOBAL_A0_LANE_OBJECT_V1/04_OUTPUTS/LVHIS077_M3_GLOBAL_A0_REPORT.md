# Author-Supplied `LVHIS077` `M3` Global-`a0` Lane Report

Date: `2026-06-13`

## Short verdict

One case-owned `M3` global-`a0` lane is now materially executed on `LVHIS077`.

The declared global roster was executed without per-galaxy fitting.

The best family-plus-`a0` combo is:

- `standard` @ `a0 = 1.27e-10 m/s^2`

## Scoreboard

- `simple` @ `a0=1.20e-10`: best scale = `1.298523375014`; best `obs-only` loglike = `-106.817959541384`
- `simple` @ `a0=1.22e-10`: best scale = `1.287372375015`; best `obs-only` loglike = `-106.188866467402`
- `simple` @ `a0=1.27e-10`: best scale = `1.260202125015`; best `obs-only` loglike = `-104.656608301007`
- `standard` @ `a0=1.20e-10`: best scale = `1.544153250007`; best `obs-only` loglike = `-106.126862567709`
- `standard` @ `a0=1.22e-10`: best scale = `1.529843750008`; best `obs-only` loglike = `-105.582987154899`
- `standard` @ `a0=1.27e-10`: best scale = `1.495013000009`; best `obs-only` loglike = `-104.267979765360`

## Best-combo differential result

- `QCT` best `obs-only` loglike = `-83.086918498765`
- global-best `QUMOND` loglike = `-104.267979765360`
- `Δloglike(QCT-global_best)` = `21.181061266595`
- `ΔAIC(QCT-global_best)` = `-42.362122533190`
- `ΔBIC(QCT-global_best)` = `-42.362122533190`

## Court consequence

- `M3` execution = `true`
- `M3` non-rescue = `true`
- full-ladder `Grade 2` already materialized = `false`

## Exact ceiling

This object does **not** claim:

- `M4`
- full-ladder `Grade 2`
- `Grade 3`
- per-galaxy `a0` fitting
- whole-family `MOND/QUMOND` defeat
