#!/usr/bin/env python3
from __future__ import annotations

import json
import shutil
import subprocess
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "03_RUN" / "AUDIT_AUTHOR_SUPPLIED_PAYLOAD_B_LVHIS077_M4_LAWFUL_EFE_ADMISSION.py"
OUT_DIR = ROOT / "05_SELFTEST" / "SELFTEST_OUTPUTS" / "lvhis077_m4_lawful_efe_admission_audit"
PYTHON_BIN = Path("AUTHOR_LOCAL_PROVENANCE_ROOT/.venv-ngc2541/bin/python")

OBS_ZIP = Path(
    "AUTHOR_LOCAL_PROVENANCE_ROOT/artifacts/debt_board_20260530/author_supplied_payload_b_raw_20260613/vcirc_obs.zip"
)
BARYONS_ZIP = Path(
    "AUTHOR_LOCAL_PROVENANCE_ROOT/artifacts/debt_board_20260530/author_supplied_payload_b_raw_20260613/vcirc_baryons.zip"
)
COURT_PROTOCOL = Path(
    "AUTHOR_LOCAL_PROVENANCE_ROOT/artifacts/debt_board_20260530/MOND_QUMOND_FAMILY_COURT_V1/02_PROTOCOL/BEST_DRESSED_LAWFUL_FAMILY_LADDER.md"
)


class LVHIS077M4LawfulEFEAdmissionAuditTest(unittest.TestCase):
    maxDiff = None

    def setUp(self) -> None:
        if OUT_DIR.exists():
            shutil.rmtree(OUT_DIR)
        OUT_DIR.mkdir(parents=True, exist_ok=True)

    def test_audits_m4_admission_and_reads_grade2_consequence(self) -> None:
        result = subprocess.run(
            [
                str(PYTHON_BIN),
                str(RUNNER),
                "--observed-zip",
                str(OBS_ZIP),
                "--baryons-zip",
                str(BARYONS_ZIP),
                "--court-protocol",
                str(COURT_PROTOCOL),
                "--output-dir",
                str(OUT_DIR),
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(
            result.returncode,
            0,
            msg=f"runner failed\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}",
        )

        summary_path = OUT_DIR / "LVHIS077_M4_ADMISSION_AUDIT_SUMMARY.json"
        self.assertTrue(summary_path.exists(), msg="summary output is missing")
        summary = json.loads(summary_path.read_text(encoding="utf-8"))

        self.assertEqual(summary["case_id"], "LVHIS077")
        self.assertEqual(summary["object_class"], "M4_LAWFUL_EFE_ADMISSION_AUDIT")
        self.assertTrue(summary["protocol_m4_condition_present"])
        self.assertFalse(summary["case_owned_m4_object_present"])
        self.assertFalse(summary["case_owned_efe_runner_present"])
        self.assertFalse(summary["case_owned_efe_prior_basis_present"])
        self.assertFalse(summary["payload_external_field_column_present"])
        self.assertFalse(summary["m4_admitted_under_current_packet_visible_materials"])
        self.assertTrue(summary["grade2_materialized_by_admitted_lane_exhaustion"])
        joined_hits = "\n".join(summary["case_owned_inventory"]["content_hits"])
        self.assertNotIn("AUTHOR_SUPPLIED_PAYLOAD_B_LVHIS077_M2_INTERPOLATION_FAMILY_LANE_OBJECT_V1", joined_hits)
        self.assertNotIn("AUTHOR_SUPPLIED_PAYLOAD_B_LVHIS077_M3_GLOBAL_A0_LANE_OBJECT_V1", joined_hits)


if __name__ == "__main__":
    unittest.main()
