# Current `G4` / `D3` / `D4` / `D5` Dependent Wake Order

Date: `2026-06-11`

Purpose:

This note fixes the downstream wake order after the first lawful non-toy
`NGC4214` run and the later current-materials `D4` no-ascent reread.

## Short verdict

The fair current reading is:

- `G4` is now retired
- `D3` is now retired
- `D4` is now retired on one bounded current-materials no-ascent result
- `D5` still wakes only after `D4` has already landed lawful absolute-scale
  authority and is therefore now watch-only

So the lane does **not** carry four coequal open fronts,
and it no longer carries one live `G4` owner wound either.

## Exact wake order

### `G4`

`G4` lands only when:

- one lawful observed-row crossing exists above the sealed no-data topology,
- `QCT`-side prediction rows exist,
- and one real comparison stack exists

That condition is now materially satisfied on the first lawful non-toy
`NGC4214` run.

### `D3`

`D3` does not wake before the landed `G4` event above.

When awake, it may only:

- import observed rows,
- run likelihood,
- and establish fit-capable confrontation

That task is now also materially landed on the same `NGC4214` run.

### `D4`

`D4` does not wake before `D3` has already landed fit-capable confrontation.

When awake, it may only:

- move from normalized posture to lawful absolute-scale authority

That wake condition was indeed satisfied immediately after the first non-toy
run.

But the later current-materials reread closes the temporary live state
negatively:

- the galactic confrontation remains normalized-only and harsh
- the separate background / distance absolute-scale branch already executed
  through policy repair and still remained bounded below authority

So under current materials,
`D4` no longer remains one honest live spend.

### `D5`

`D5` does not wake before `D4` has already landed lawful absolute-scale
authority.

When awake, it may only widen through:

- `L4` background expansion
- `L5` structure / growth
- `L6` `CMB`
- `L7` cross-scale synthesis

## Current honest reading

At present:

- `G4` is retired after true-`L0` landing,
- `D3` is retired after first comparison-stack / likelihood opening,
- `D4` is retired after bounded current-materials no-ascent,
- `D5` is watch-only pending one fresh authority-grade ascent event.

Nothing weaker,
and nothing stronger,
counts as the honest current state here.
