# Author-Supplied `LVHIS072` Runtime-Locked First Stronger-Court `Grade 1` Report

Date: `2026-06-13`

## Short verdict

`LVHIS072` now lands as one truthful stronger-court positive
consumer under the runtime-locked field.

It now carries one explicit first stronger-court single-case reading at:

- same case: `LVHIS072`
- same one-parameter stellar/bulge nuisance grammar on both sides
- same `obs-only` likelihood objective on both sides
- same runtime-locked bounded historical `QCT` `artifact_emulator` lane

## Same-nuisance floor

- `QUMOND` best scale = `1.449323875010`
- `QCT` best scale = `0.564425875035`
- `QUMOND` lower-bound hit = `false`
- `QCT` lower-bound hit = `false`
- `QUMOND` upper-bound hit = `false`
- `QCT` upper-bound hit = `false`

Both best scales remain interior inside the current legal nuisance window.

## Differential result

- `QCT` best `obs-only` loglike = `-128.224473129692`
- `QUMOND` best `obs-only` loglike = `-142.232226892576`
- `Δloglike(QCT-QUMOND)` = `14.007753762883`
- `ΔAIC(QCT-QUMOND)` = `-28.015507525767`
- `ΔBIC(QCT-QUMOND)` = `-28.015507525767`

So under the same nuisance floor and the same objective, the current runtime-locked bounded
historical `QCT` lane is decisively preferred on `LVHIS072`.

## Residual-shape read

- `QUMOND` residual class = `mixed_sign_residual`
- `QUMOND` residual sign changes = `1`
- `QUMOND` residual RMS in sigma units = `4.432017310646`
- `QCT` residual class = `mixed_sign_residual`
- `QCT` residual sign changes = `1`
- `QCT` residual RMS in sigma units = `4.160306697195`

## Court consequence

This is enough for one current-case `Grade 1` materialization:

- same nuisance floor is satisfied
- same objective is satisfied
- both best scales remain interior
- and `QCT` is decisively preferred in the declared lane


## Exact ceiling

This still does **not** claim:

- `Grade 2`
- `Grade 3`
- best-dressed lawful family execution
- theory-side promotion
- whole-family `MOND/QUMOND` defeat
