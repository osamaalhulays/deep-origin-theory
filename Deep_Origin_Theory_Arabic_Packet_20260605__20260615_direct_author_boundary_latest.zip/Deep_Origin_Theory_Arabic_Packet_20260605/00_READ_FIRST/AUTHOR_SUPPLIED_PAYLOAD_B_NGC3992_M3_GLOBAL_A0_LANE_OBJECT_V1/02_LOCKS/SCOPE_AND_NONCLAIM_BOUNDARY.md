# Scope And Nonclaim Boundary

Date: `2026-06-13`

This object is one bounded `M3` global-`a0` lane only.

Allowed:

- same-case `NGC3992`
- same one-parameter stellar/bulge nuisance treatment on both sides
- same `obs-only` likelihood objective on both sides
- one declared global interpolation-family roster
- one declared global `a0` roster
- one family-plus-`a0` best-combo selection
- one exact decision on whether `M3` rescues or fails to rescue the case

Not allowed:

- per-galaxy `a0` fitting
- silent insertion of undeclared `a0` candidates
- residual-derived `a0` candidates
- silent reopening of `M4`
- silent promotion from `M3` execution to full-ladder `Grade 2`
- `Grade 3`
- theory-side promotion
- whole-family `MOND/QUMOND` defeat language
- cosmology completion
