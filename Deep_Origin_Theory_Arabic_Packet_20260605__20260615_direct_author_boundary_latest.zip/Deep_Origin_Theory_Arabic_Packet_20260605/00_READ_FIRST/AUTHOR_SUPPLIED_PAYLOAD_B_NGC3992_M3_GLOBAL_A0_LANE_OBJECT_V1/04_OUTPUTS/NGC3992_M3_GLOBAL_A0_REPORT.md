# Author-Supplied `NGC3992` `M3` Global-`a0` Lane Report

Date: `2026-06-13`

## Short verdict

One case-owned `M3` global-`a0` lane is now materially executed on `NGC3992`.

The declared global roster was executed without per-galaxy fitting.

The best family-plus-`a0` combo is:

- `simple` @ `a0 = 1.20e-10 m/s^2`

## Scoreboard

- `simple` @ `a0=1.20e-10`: best scale = `0.820782462387`; best `obs-only` loglike = `-114.275342884785`
- `simple` @ `a0=1.22e-10`: best scale = `0.816174955409`; best `obs-only` loglike = `-115.146049583152`
- `simple` @ `a0=1.27e-10`: best scale = `0.804951495457`; best `obs-only` loglike = `-117.279243901057`
- `standard` @ `a0=1.20e-10`: best scale = `0.970274036718`; best `obs-only` loglike = `-121.336679077693`
- `standard` @ `a0=1.22e-10`: best scale = `0.964010083745`; best `obs-only` loglike = `-122.660279363325`
- `standard` @ `a0=1.27e-10`: best scale = `0.948693366815`; best `obs-only` loglike = `-125.853377520472`

## Best-combo differential result

- `QCT` best `obs-only` loglike = `-85.997262797138`
- global-best `QUMOND` loglike = `-114.275342884785`
- `Δloglike(QCT-global_best)` = `28.278080087647`
- `ΔAIC(QCT-global_best)` = `-56.556160175294`
- `ΔBIC(QCT-global_best)` = `-56.556160175294`

## Court consequence

- `M3` execution = `true`
- `M3` non-rescue = `true`
- full-ladder `Grade 2` already materialized = `false`

## Exact ceiling

This object does **not** claim:

- `M4`
- full-ladder `Grade 2`
- `Grade 3`
- per-galaxy `a0` fitting
- whole-family `MOND/QUMOND` defeat
