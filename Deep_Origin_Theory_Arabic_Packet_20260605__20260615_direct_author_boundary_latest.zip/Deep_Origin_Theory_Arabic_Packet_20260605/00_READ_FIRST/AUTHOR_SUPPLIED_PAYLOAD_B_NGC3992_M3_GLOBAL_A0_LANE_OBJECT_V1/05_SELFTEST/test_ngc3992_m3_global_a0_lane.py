#!/usr/bin/env python3
from __future__ import annotations

import json
import shutil
import subprocess
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "03_RUN" / "REPRODUCE_AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_M3_GLOBAL_A0_LANE.py"
OUT_DIR = ROOT / "05_SELFTEST" / "SELFTEST_OUTPUTS" / "ngc3992_m3_global_a0_lane"
PYTHON_BIN = Path("AUTHOR_LOCAL_PROVENANCE_ROOT/.venv-ngc2541/bin/python")

OBS_ZIP = Path(
    "AUTHOR_LOCAL_PROVENANCE_ROOT/artifacts/debt_board_20260530/author_supplied_payload_b_raw_20260613/vcirc_obs.zip"
)
BARYON_ZIP = Path(
    "AUTHOR_LOCAL_PROVENANCE_ROOT/artifacts/debt_board_20260530/author_supplied_payload_b_raw_20260613/vcirc_baryons.zip"
)
MODEL_PT = Path(
    "AUTHOR_LOCAL_PROVENANCE_ROOT/tmp_migration_bundle_20260226/artifacts/emulator_poc_model.pt"
)
NORM_JSON = Path(
    "AUTHOR_LOCAL_PROVENANCE_ROOT/tmp_migration_bundle_20260226/artifacts/emulator_poc_norm.json"
)


class NGC3992M3GlobalA0LaneTest(unittest.TestCase):
    maxDiff = None

    def setUp(self) -> None:
        if OUT_DIR.exists():
            shutil.rmtree(OUT_DIR)
        OUT_DIR.mkdir(parents=True, exist_ok=True)

    def test_materializes_global_a0_lane_and_selects_best_combo(self) -> None:
        result = subprocess.run(
            [
                str(PYTHON_BIN),
                str(RUNNER),
                "--observed-zip",
                str(OBS_ZIP),
                "--baryons-zip",
                str(BARYON_ZIP),
                "--model-pt",
                str(MODEL_PT),
                "--norm-json",
                str(NORM_JSON),
                "--output-dir",
                str(OUT_DIR),
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(
            result.returncode,
            0,
            msg=f"runner failed\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}",
        )

        summary_path = OUT_DIR / "NGC3992_M3_GLOBAL_A0_DIFFERENTIAL_SUMMARY.json"
        self.assertTrue(summary_path.exists(), msg="summary output is missing")
        summary = json.loads(summary_path.read_text(encoding="utf-8"))

        self.assertEqual(summary["case_id"], "NGC3992")
        self.assertEqual(summary["object_class"], "M3_GLOBAL_A0_LANE")
        self.assertEqual(summary["family_member_count"], 2)
        self.assertEqual(summary["a0_candidate_count"], 3)
        self.assertEqual(summary["tested_combo_count"], 6)
        self.assertIn(summary["best_qumond_family_member"], ["simple", "standard"])
        self.assertIn(
            summary["best_qumond_a0_m_s2"],
            [1.2e-10, 1.22e-10, 1.27e-10],
        )
        self.assertGreaterEqual(
            summary["qumond_global_best_ll_obs_only"],
            summary["qumond_simple_baseline_ll_obs_only"],
        )
        self.assertGreaterEqual(
            summary["delta_aic_qct_minus_qumond_global_best_obs_only"],
            summary["delta_aic_qct_minus_qumond_simple_baseline_obs_only"],
        )


if __name__ == "__main__":
    unittest.main()
