#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
import math
from pathlib import Path

import numpy as np
import torch


CASE_ID = "NGC3992"

HERE = Path(__file__).resolve()
OBJECT_ROOT = HERE.parents[1]
DEBT_ROOT = HERE.parents[2]
M2_SCRIPT = (
    DEBT_ROOT
    / "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_M2_INTERPOLATION_FAMILY_LANE_OBJECT_V1"
    / "03_RUN"
    / "REPRODUCE_AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_M2_INTERPOLATION_FAMILY_LANE.py"
)
DEFAULT_MANIFEST_LOCK = (
    DEBT_ROOT
    / "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_M2_INTERPOLATION_FAMILY_LANE_OBJECT_V1"
    / "02_LOCKS"
    / "RUNTIME_LOCKED_MANIFEST_PRIOR_LOCK.json"
)
DEFAULT_INTERPOLATION_ROSTER = (
    DEBT_ROOT
    / "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_M2_INTERPOLATION_FAMILY_LANE_OBJECT_V1"
    / "02_LOCKS"
    / "INTERPOLATION_FAMILY_ROSTER.json"
)
DEFAULT_A0_ROSTER = OBJECT_ROOT / "02_LOCKS" / "GLOBAL_A0_ROSTER.json"


def load_m2_module():
    spec = importlib.util.spec_from_file_location("ngc3992_m2_lane", M2_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"failed to load M2 helper script from {M2_SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


M2 = load_m2_module()
GRADE1 = M2.GRADE1
FAMILY_MEMBERS = tuple(M2.FAMILY_MEMBERS)
SCAN_HI = M2.SCAN_HI


def evaluate_qumond_grid_family_a0(
    scales: np.ndarray,
    gas_power: np.ndarray,
    stellar_bulge_power: np.ndarray,
    radii_m: np.ndarray,
    vobs_km_s: np.ndarray,
    sigma_v_km_s: np.ndarray,
    family_member: str,
    a0_m_s2: float,
) -> np.ndarray:
    total_vbar2 = gas_power[None, :] + np.square(scales)[:, None] * stellar_bulge_power[None, :]
    valid = np.all(total_vbar2 > 0.0, axis=1)
    loglikes = np.full(scales.shape, -np.inf, dtype=np.float64)
    if not np.any(valid):
        return loglikes
    total_valid = total_vbar2[valid]
    gbar = total_valid * 1_000_000.0 / radii_m[None, :]
    nu = M2.qumond_nu(gbar / a0_m_s2, family_member)
    vpred_km_s = np.sqrt(total_valid) * np.sqrt(nu)
    residuals = vobs_km_s[None, :] - vpred_km_s
    loglikes[valid] = GRADE1.gaussian_loglike_grid(residuals, sigma_v_km_s)
    return loglikes


def evaluate_qumond_single_family_a0(
    scale: float,
    gas_power: np.ndarray,
    stellar_bulge_power: np.ndarray,
    radii_m: np.ndarray,
    vobs_km_s: np.ndarray,
    sigma_v_km_s: np.ndarray,
    family_member: str,
    a0_m_s2: float,
) -> dict:
    total_vbar2 = gas_power + (scale * scale) * stellar_bulge_power
    if np.any(total_vbar2 <= 0.0):
        raise ValueError(f"{CASE_ID}: non-positive total baryonic power encountered")
    gbar_m_s2 = total_vbar2 * 1_000_000.0 / radii_m
    nu = M2.qumond_nu(gbar_m_s2 / a0_m_s2, family_member)
    vbar_km_s = np.sqrt(total_vbar2)
    vpred_km_s = vbar_km_s * np.sqrt(nu)
    residual_km_s = vobs_km_s - vpred_km_s
    chi2_terms = (residual_km_s / sigma_v_km_s) ** 2
    return {
        "family_member": family_member,
        "a0_m_s2": a0_m_s2,
        "scale": scale,
        "gbar_m_s2": gbar_m_s2,
        "log10_gbar_m_s2": np.log10(gbar_m_s2),
        "nu": nu,
        "vbar_km_s": vbar_km_s,
        "vpred_km_s": vpred_km_s,
        "residual_km_s": residual_km_s,
        "chi2_terms": chi2_terms,
        "chi2_total": float(np.sum(chi2_terms)),
        "ll_obs_only": float(GRADE1.gaussian_loglike_grid(residual_km_s[None, :], sigma_v_km_s)[0]),
    }


def build_combo_rows(observed_rows: list[dict], combo_eval: dict) -> list[dict]:
    rows = []
    for obs, gbar, loggbar, nu, vbar, vpred, resid, chi2 in zip(
        observed_rows,
        combo_eval["gbar_m_s2"],
        combo_eval["log10_gbar_m_s2"],
        combo_eval["nu"],
        combo_eval["vbar_km_s"],
        combo_eval["vpred_km_s"],
        combo_eval["residual_km_s"],
        combo_eval["chi2_terms"],
    ):
        rows.append(
            {
                "row_index": obs["row_index"],
                "r_kpc": obs["r_kpc"],
                "vobs_km_s": obs["vobs_km_s"],
                "sigma_v_km_s": obs["sigma_v_km_s"],
                "family_member": combo_eval["family_member"],
                "a0_m_s2": combo_eval["a0_m_s2"],
                "scale_s": combo_eval["scale"],
                "gbar_m_s2": gbar,
                "log10_gbar_m_s2": loggbar,
                "nu": nu,
                "vbar_km_s": vbar,
                "v_qumond_km_s": vpred,
                "residual_km_s": resid,
                "chi2_term": chi2,
            }
        )
    return rows


def build_report(qct_summary: dict, differential: dict, combo_summaries: list[dict]) -> str:
    combo_lines = []
    for item in combo_summaries:
        combo_lines.append(
            f"- `{item['family_member']}` @ `a0={item['a0_m_s2']:.2e}`: "
            f"best scale = `{item['best_scale']:.12f}`; "
            f"best `obs-only` loglike = `{item['ll_best_obs_only']:.12f}`"
        )
    combo_text = "\n".join(combo_lines)
    best_family = differential["best_qumond_family_member"]
    best_a0 = differential["best_qumond_a0_m_s2"]
    return f"""# Author-Supplied `NGC3992` `M3` Global-`a0` Lane Report

Date: `2026-06-13`

## Short verdict

One case-owned `M3` global-`a0` lane is now materially executed on `NGC3992`.

The declared global roster was executed without per-galaxy fitting.

The best family-plus-`a0` combo is:

- `{best_family}` @ `a0 = {best_a0:.2e} m/s^2`

## Scoreboard

{combo_text}

## Best-combo differential result

- `QCT` best `obs-only` loglike = `{differential['qct_best_ll_obs_only']:.12f}`
- global-best `QUMOND` loglike = `{differential['qumond_global_best_ll_obs_only']:.12f}`
- `Δloglike(QCT-global_best)` = `{differential['delta_loglike_qct_minus_qumond_global_best_obs_only']:.12f}`
- `ΔAIC(QCT-global_best)` = `{differential['delta_aic_qct_minus_qumond_global_best_obs_only']:.12f}`
- `ΔBIC(QCT-global_best)` = `{differential['delta_bic_qct_minus_qumond_global_best_obs_only']:.12f}`

## Court consequence

- `M3` execution = `true`
- `M3` non-rescue = `{str(differential['m3_non_rescue_materialized']).lower()}`
- full-ladder `Grade 2` already materialized = `false`

## Exact ceiling

This object does **not** claim:

- `M4`
- full-ladder `Grade 2`
- `Grade 3`
- per-galaxy `a0` fitting
- whole-family `MOND/QUMOND` defeat
"""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--observed-zip", type=Path, required=True)
    parser.add_argument("--baryons-zip", type=Path, required=True)
    parser.add_argument("--model-pt", type=Path, required=True)
    parser.add_argument("--norm-json", type=Path, required=True)
    parser.add_argument("--manifest-lock-json", type=Path, default=DEFAULT_MANIFEST_LOCK)
    parser.add_argument("--interpolation-roster-json", type=Path, default=DEFAULT_INTERPOLATION_ROSTER)
    parser.add_argument("--a0-roster-json", type=Path, default=DEFAULT_A0_ROSTER)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    observed_records = GRADE1.read_zip_records(args.observed_zip.resolve(), GRADE1.OBSERVED_SUFFIX)
    baryonic_records = GRADE1.read_zip_records(args.baryons_zip.resolve(), GRADE1.BARYON_SUFFIX)
    if CASE_ID not in observed_records or CASE_ID not in baryonic_records:
        raise ValueError(f"{CASE_ID}: missing from one of the author-supplied zip files")

    manifest_lock = json.loads(args.manifest_lock_json.resolve().read_text(encoding="utf-8"))
    interpolation_roster = json.loads(args.interpolation_roster_json.resolve().read_text(encoding="utf-8"))
    a0_roster = json.loads(args.a0_roster_json.resolve().read_text(encoding="utf-8"))
    gamma = float(manifest_lock["priors"]["gamma"])
    m_eV = float(manifest_lock["priors"]["m_eV"])

    declared_members = [member["name"] for member in interpolation_roster["members"]]
    if declared_members != list(FAMILY_MEMBERS):
        raise ValueError(
            f"{CASE_ID}: interpolation roster members {declared_members} do not match executable family {list(FAMILY_MEMBERS)}"
        )

    a0_candidates = a0_roster["a0_candidates"]
    if len(a0_candidates) != 3:
        raise ValueError(f"{CASE_ID}: expected exactly 3 global a0 candidates")

    norm = json.loads(args.norm_json.resolve().read_text(encoding="utf-8"))
    mean = np.asarray(norm["mean"], dtype=np.float32)
    std = np.asarray(norm["std"], dtype=np.float32)
    if mean.shape != (6,) or std.shape != (6,):
        raise ValueError("unexpected norm shape for historical 6-feature artifact emulator")

    model = GRADE1.Net()
    model.load_state_dict(torch.load(args.model_pt.resolve(), map_location="cpu"))
    model.eval()

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    arrays, audit = GRADE1.build_case_arrays(observed_records[CASE_ID], baryonic_records[CASE_ID])
    gas_power = arrays["gas_power"]
    stellar_bulge_power = arrays["stellar_bulge_power"]
    radii_m = arrays["radii_m"]
    vobs_km_s = arrays["vobs_km_s"]
    sigma_v_km_s = arrays["sigma_v_km_s"]
    observed_rows = arrays["observed_rows"]
    component_rows = arrays["component_rows"]

    legal_low = GRADE1.lower_scale_gate(gas_power, stellar_bulge_power)
    if legal_low is None:
        raise ValueError(f"{CASE_ID}: no legal positive-total-vbar2 scale window found")

    qct_eval = lambda scales: GRADE1.evaluate_qct_grid(
        scales,
        gas_power,
        stellar_bulge_power,
        radii_m,
        vobs_km_s,
        sigma_v_km_s,
        model,
        mean,
        std,
        gamma,
        m_eV,
        batch_size=65536,
    )
    qct_best_scale, qct_best_ll = GRADE1.maximize_model(qct_eval, legal_low, SCAN_HI)
    if qct_best_scale is None or qct_best_ll is None:
        raise ValueError(f"{CASE_ID}: failed to materialize one finite QCT maximum")
    qct_best = GRADE1.evaluate_qct_single(
        qct_best_scale,
        gas_power,
        stellar_bulge_power,
        radii_m,
        vobs_km_s,
        sigma_v_km_s,
        model,
        mean,
        std,
        gamma,
        m_eV,
    )

    qct_summary = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_RUNTIME_LOCKED_QCT_ARTIFACT_EMULATOR_MATCHED_NUISANCE_OBJECT_V1",
        "date": "2026-06-13",
        "case_id": CASE_ID,
        "best_scale": qct_best_scale,
        "best_scale_at_lower_bound": GRADE1.near_equal(qct_best_scale, legal_low),
        "best_scale_at_upper_bound": GRADE1.near_equal(qct_best_scale, SCAN_HI),
        "ll_best_obs_only": qct_best_ll,
        "training_manifest_hash": manifest_lock["config_hash"],
        "cosmic_closure_claim": False,
    }

    combo_summaries: list[dict] = []
    global_best_summary: dict | None = None
    global_best_eval: dict | None = None
    global_scoreboard_rows = []
    simple_baseline_best_ll = None

    for family_member in FAMILY_MEMBERS:
        for candidate in a0_candidates:
            a0_m_s2 = float(candidate["a0_m_s2"])
            label = str(candidate["label"])
            combo_eval = lambda scales, member=family_member, a0=a0_m_s2: evaluate_qumond_grid_family_a0(
                scales,
                gas_power,
                stellar_bulge_power,
                radii_m,
                vobs_km_s,
                sigma_v_km_s,
                member,
                a0,
            )
            best_scale, best_ll = GRADE1.maximize_model(combo_eval, legal_low, SCAN_HI)
            if best_scale is None or best_ll is None:
                raise ValueError(f"{CASE_ID}: failed to materialize one finite {family_member}@{a0_m_s2:.2e} maximum")
            fixed_eval = evaluate_qumond_single_family_a0(
                1.0,
                gas_power,
                stellar_bulge_power,
                radii_m,
                vobs_km_s,
                sigma_v_km_s,
                family_member,
                a0_m_s2,
            )
            best_eval = evaluate_qumond_single_family_a0(
                best_scale,
                gas_power,
                stellar_bulge_power,
                radii_m,
                vobs_km_s,
                sigma_v_km_s,
                family_member,
                a0_m_s2,
            )
            summary = {
                "object": f"AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_QUMOND_{family_member.upper()}_{label.upper()}_M3_MATCHED_NUISANCE_SUMMARY_20260613",
                "date": "2026-06-13",
                "case_id": CASE_ID,
                "family_member": family_member,
                "a0_label": label,
                "a0_m_s2": a0_m_s2,
                "best_scale": best_scale,
                "best_scale_at_lower_bound": GRADE1.near_equal(best_scale, legal_low),
                "best_scale_at_upper_bound": GRADE1.near_equal(best_scale, SCAN_HI),
                "ll_fixed_obs_only": fixed_eval["ll_obs_only"],
                "ll_best_obs_only": best_ll,
                "chi2_best_obs_only": best_eval["chi2_total"],
                "residual_shape": GRADE1.residual_shape_metrics(best_eval["residual_km_s"], sigma_v_km_s),
                "global_a0_declared": True,
                "per_galaxy_a0_fit": False,
                "cosmic_closure_claim": False,
            }
            combo_summaries.append(summary)
            global_scoreboard_rows.append(
                {
                    "family_member": family_member,
                    "a0_label": label,
                    "a0_m_s2": a0_m_s2,
                    "best_scale": best_scale,
                    "best_scale_at_lower_bound": summary["best_scale_at_lower_bound"],
                    "best_scale_at_upper_bound": summary["best_scale_at_upper_bound"],
                    "ll_fixed_obs_only": fixed_eval["ll_obs_only"],
                    "ll_best_obs_only": best_ll,
                    "delta_loglike_best_minus_fixed_obs_only": best_ll - fixed_eval["ll_obs_only"],
                    "residual_sign_class": summary["residual_shape"]["sign_class"],
                    "residual_sign_change_count": summary["residual_shape"]["sign_change_count"],
                    "residual_rms_sigma_units": summary["residual_shape"]["rms_sigma_units"],
                }
            )
            GRADE1.write_csv(
                output_dir / f"NGC3992_QUMOND_{family_member.upper()}_{label.upper()}_MATCHED_NUISANCE_COMPARATOR.csv",
                [
                    "row_index",
                    "r_kpc",
                    "vobs_km_s",
                    "sigma_v_km_s",
                    "family_member",
                    "a0_m_s2",
                    "scale_s",
                    "gbar_m_s2",
                    "log10_gbar_m_s2",
                    "nu",
                    "vbar_km_s",
                    "v_qumond_km_s",
                    "residual_km_s",
                    "chi2_term",
                ],
                build_combo_rows(observed_rows, best_eval),
            )
            GRADE1.write_json(
                output_dir / f"NGC3992_QUMOND_{family_member.upper()}_{label.upper()}_MATCHED_NUISANCE_SUMMARY.json",
                summary,
            )
            if family_member == "simple" and label == "canonical_fixed_baseline":
                simple_baseline_best_ll = best_ll
            if global_best_summary is None or best_ll > global_best_summary["ll_best_obs_only"]:
                global_best_summary = summary
                global_best_eval = best_eval

    assert global_best_summary is not None
    assert global_best_eval is not None
    assert simple_baseline_best_ll is not None

    delta_loglike_global_best = qct_best_ll - global_best_summary["ll_best_obs_only"]
    delta_aic_global_best = (-2.0 * qct_best_ll + 2.0) - (-2.0 * global_best_summary["ll_best_obs_only"] + 2.0)
    delta_bic_global_best = (-2.0 * qct_best_ll + math.log(len(observed_rows))) - (
        -2.0 * global_best_summary["ll_best_obs_only"] + math.log(len(observed_rows))
    )
    delta_aic_simple_baseline = (-2.0 * qct_best_ll + 2.0) - (-2.0 * simple_baseline_best_ll + 2.0)

    best_scales_interior = (
        not qct_summary["best_scale_at_lower_bound"]
        and not qct_summary["best_scale_at_upper_bound"]
        and not global_best_summary["best_scale_at_lower_bound"]
        and not global_best_summary["best_scale_at_upper_bound"]
    )
    m3_non_rescue_materialized = (
        delta_loglike_global_best > 0.0 and delta_aic_global_best <= -10.0 and best_scales_interior
    )

    differential = {
        "object_class": "M3_GLOBAL_A0_LANE",
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_M3_GLOBAL_A0_DIFFERENTIAL_SUMMARY_20260613",
        "date": "2026-06-13",
        "case_id": CASE_ID,
        "family_member_count": len(FAMILY_MEMBERS),
        "a0_candidate_count": len(a0_candidates),
        "tested_combo_count": len(FAMILY_MEMBERS) * len(a0_candidates),
        "same_nuisance_floor": True,
        "same_obs_only_objective": True,
        "best_scales_interior": best_scales_interior,
        "qct_best_scale": qct_best_scale,
        "qct_best_ll_obs_only": qct_best_ll,
        "qumond_simple_baseline_ll_obs_only": simple_baseline_best_ll,
        "best_qumond_family_member": global_best_summary["family_member"],
        "best_qumond_a0_label": global_best_summary["a0_label"],
        "best_qumond_a0_m_s2": global_best_summary["a0_m_s2"],
        "qumond_global_best_scale": global_best_summary["best_scale"],
        "qumond_global_best_ll_obs_only": global_best_summary["ll_best_obs_only"],
        "delta_loglike_qct_minus_qumond_global_best_obs_only": delta_loglike_global_best,
        "delta_aic_qct_minus_qumond_global_best_obs_only": delta_aic_global_best,
        "delta_bic_qct_minus_qumond_global_best_obs_only": delta_bic_global_best,
        "delta_aic_qct_minus_qumond_simple_baseline_obs_only": delta_aic_simple_baseline,
        "m3_execution_materialized": True,
        "m3_non_rescue_materialized": m3_non_rescue_materialized,
        "grade2_materialized_under_current_full_ladder": False,
        "grade2_blockers_remaining": (["M4"] if m3_non_rescue_materialized else ["M3"]),
        "qumond_global_best_residual_shape": global_best_summary["residual_shape"],
        "qct_residual_shape": GRADE1.residual_shape_metrics(qct_best["residual_km_s"], sigma_v_km_s),
        "verdict": (
            "M3_GLOBAL_A0_NON_RESCUE_MATERIALIZED_ON_NGC3992__FULL_GRADE2_STILL_BLOCKED_BY_M4"
            if m3_non_rescue_materialized
            else "M3_GLOBAL_A0_EXECUTED_BUT_NON_RESCUE_NOT_MATERIALIZED_ON_NGC3992"
        ),
        "cosmic_closure_claim": False,
    }

    GRADE1.write_csv(
        output_dir / "NGC3992_OBSERVED_KINEMATIC_ROWS.csv",
        ["row_index", "r_kpc", "r_m", "vobs_km_s", "sigma_v_km_s", "gobs_m_s2"],
        observed_rows,
    )
    GRADE1.write_csv(
        output_dir / "NGC3992_COMPONENT_ROWS_AT_OBSERVED_RADII.csv",
        [
            "row_index",
            "r_kpc",
            "left_baryonic_r_kpc",
            "right_baryonic_r_kpc",
            "interpolation_mode",
            "signed_vhi2_km2_s2",
            "signed_vh2_2_km2_s2",
            "vstars2_km2_s2",
            "vbulge2_km2_s2",
            "gas_signed_vbar2_km2_s2",
            "stellar_bulge_vbar2_km2_s2",
        ],
        component_rows,
    )
    GRADE1.write_csv(
        output_dir / "NGC3992_QCT_ARTIFACT_EMULATOR_MATCHED_NUISANCE_COMPARATOR.csv",
        [
            "row_index",
            "r_kpc",
            "vobs_km_s",
            "sigma_v_km_s",
            "scale_s",
            "gbar_m_s2",
            "log10_gbar_m_s2",
            "vbar_km_s",
            "vdrop",
            "delta_qct",
            "sigma_delta_qct",
            "v_qct_km_s",
            "sigma_model_km_s",
            "residual_km_s",
            "chi2_term_obs_only",
        ],
        M2.build_qct_rows(observed_rows, qct_best),
    )
    GRADE1.write_csv(
        output_dir / "NGC3992_M3_GLOBAL_A0_SCOREBOARD.csv",
        [
            "family_member",
            "a0_label",
            "a0_m_s2",
            "best_scale",
            "best_scale_at_lower_bound",
            "best_scale_at_upper_bound",
            "ll_fixed_obs_only",
            "ll_best_obs_only",
            "delta_loglike_best_minus_fixed_obs_only",
            "residual_sign_class",
            "residual_sign_change_count",
            "residual_rms_sigma_units",
        ],
        global_scoreboard_rows,
    )
    GRADE1.write_json(output_dir / "NGC3992_QCT_MATCHED_NUISANCE_SUMMARY.json", qct_summary)
    GRADE1.write_json(output_dir / "NGC3992_M3_GLOBAL_A0_DIFFERENTIAL_SUMMARY.json", differential)
    GRADE1.write_json(
        output_dir / "VERDICT.json",
        {
            "case_id": CASE_ID,
            "best_qumond_family_member": differential["best_qumond_family_member"],
            "best_qumond_a0_m_s2": differential["best_qumond_a0_m_s2"],
            "m3_execution_materialized": True,
            "m3_non_rescue_materialized": differential["m3_non_rescue_materialized"],
            "grade2_materialized_under_current_full_ladder": False,
            "verdict": differential["verdict"],
        },
    )
    (output_dir / "NGC3992_M3_GLOBAL_A0_REPORT.md").write_text(
        build_report(qct_summary, differential, combo_summaries),
        encoding="utf-8",
    )

    print(
        json.dumps(
            {
                "qct_summary": qct_summary,
                "combo_summaries": combo_summaries,
                "differential": differential,
            },
            indent=2,
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
