# Author-Supplied `PAYLOAD_B` `NGC3992` Fourth Clean Empirical Rowcase Report

Date: `2026-06-13`

## Short verdict

`NGC3992` is now materialized as the fourth focused clean empirical case above
the landed author-supplied `PAYLOAD_B` family.

## Exact present shape

- target galaxy: `NGC3992`
- clean-first shortlist rank: `4`
- observed rows: `20`
- radius range: `6.1` to `39.2` kpc
- exact interpolation rows: `2`
- linear interpolation rows: `18`
- all rows stay comparison-ready: `true`
- all rows keep clean-first status: `true`
- all rows keep positive `log10(gobs) - log10(gbar)`: `true`
- `delta` range: `0.16450494754325362` to `0.34040678069063723`
- `delta` median: `0.25739265614996754`
- `gbar` peak radius: `6.1` kpc
- `gbar` is nonincreasing after its peak: `true`

## Exact current ceiling

This object gives one focused empirical rowcase only.

It does not yet give:

- one theory-side promotion
- one matched-nuisance comparison
- one competitor verdict
