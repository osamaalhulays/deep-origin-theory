# Current `D7` `L2` Post-Payload Intake And Bounded Verdict Note

Date: `2026-06-11`

Purpose:

This note freezes the exact intake and verdict grammar that runs only after
one lawful `G6` payload arrival.

## Short verdict

The fair current reading is:

- `D7` is already materialized,
- but it is dormant before one lawful `G6` arrival,
- and when it wakes it may only verify,
  classify,
  and issue one bounded verdict.

## Verify-class order

The verify-class pass runs in this order:

1. verify the arrival channel is one lawful `G6` channel
2. verify the payload is machine-readable
3. verify rowwise same-source coherence
4. verify required rowwise fields
5. classify exactly as `PAYLOAD_A`, `PAYLOAD_B`, `hold`, or `reject`

## Admit / hold / reject grammar

Admit the payload if:

- the arrival channel is lawful
- the payload is machine-readable
- same-source coherence survives
- all required fields for `PAYLOAD_A` or `PAYLOAD_B` survive

Hold the payload if:

- the arrival channel is lawful
- the payload is genuinely machine-readable
- but exact class cannot yet be frozen because one bounded clarification is
  still missing

Reject the payload if it is:

- one rejected substitute
- one forbidden workaround
- one non-lawful arrival channel
- one non-machine-readable surface

## Bounded verdicts only

The bounded post-payload verdicts are:

- `PAYLOAD_A_admit`
  -> claim-capable reopen may open subject to `QF0` screen
- `PAYLOAD_B_admit`
  -> diagnostic-only reopen,
  no `C2`
- `payload_hold_pending_exact_source_clarification`
  -> no reopen,
  bounded clarification wait only
- `payload_reject_not_a_G6_gate_object`
  -> no reopen,
  return to `G6` wait-state

## Read with

- `CURRENT_G6_L2_EMPIRICAL_PAYLOAD_ARRIVAL_GRAMMAR_NOTE_20260611.md`
- `L2_PUBLIC_HUNT_COSMIC_CLOSURE_AND_DIRECT_AUTHOR_ADMISSION_GATE_NOTE_20260606.md`
