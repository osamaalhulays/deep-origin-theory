# Fourth Clean Empirical Gap Witness Capsule — NGC3992

Date: `2026-06-13`

Status: `bounded outward-facing capsule`

Purpose:

This capsule answers one narrow reviewer question directly:

Does the visible author-supplied clean-first head now extend to a fourth named,
reviewer-readable empirical case above the landed payload?

Short answer:

- `yes, in bounded form`

## Case

- named case = `NGC3992`
- source lane = direct-author author-supplied `PAYLOAD_B`
- scope = empirical `gobs/gbar` only
- selection role = `rank-4 clean-first case`

## What is frozen here

The bounded witness claim frozen here is:

- `NGC3992` is the current fourth named clean-first empirical gap witness
  inside the landed author-supplied `PAYLOAD_B` family at present `gobs/gbar` scope.

This is **not** yet:

- one theory-side witness
- one `QCT` prediction-case closure
- one `QUMOND` fairness verdict
- or one differential superiority claim

## Witness type

Witness type:

- `rowwise all-positive empirical gobs-vs-gbar gap under clean-first direct-author payload conditions`

The packet-local focused case now shows:

- `20` rows
- all `20` rows are comparison-ready
- all `20` rows preserve clean-first status
- `2` exact interpolation rows
- `18` linear interpolation rows
- `delta = log10(gobs) - log10(gbar)` is positive in all `20` rows
- `delta_min = 0.16450494754325362`
- `delta_max = 0.34040678069063723`
- `delta_median = 0.25739265614996754`
- `gbar` peaks at `r = 6.1 kpc`
- `gbar` is nonincreasing after that peak

## Why this case matters

`NGC3992` is not selected arbitrarily.

The already frozen selection rule makes it rank `4`, so it extends the visible
named head beyond the top-`3` trio and pushes the named head to `120` rows.

## Why this still remains bounded

`NGC3992` is a real fourth focused empirical witness, but it remains
**strictly bounded**.

The packet does **not** yet publish for `NGC3992`:

- one theory-side source profile pack
- one `QCT` prediction row family
- one matched-nuisance fairness comparison
- or one named competitor verdict

So the honest reading is not:

- “`NGC3992` already proves the theory-side lane.”

The honest reading is:

- the packet now has a fourth focused empirical case above the landed author-supplied `PAYLOAD_B` family
  family
- that case is reader-visible row by row
- while still remaining empirical-only

## Short outward-safe wording

One outward-safe summary sentence is:

> `NGC3992` is the current fourth named clean-first empirical gap witness
> inside the landed author-supplied `PAYLOAD_B` family: under the direct-author
> non-`SPARC` rowwise lane, all 20 observed rows remain comparison-ready and
> clean-first, and every row preserves a positive empirical
> `log10(gobs) - log10(gbar)` gap at present `gobs/gbar` scope.

## Use rule

Use this capsule to answer:

- “Do you now have a fourth named focused empirical case above the author-supplied `PAYLOAD_B` family
  landing?”

Do **not** use it to claim:

- one theory-side closure
- one fairness-grade comparator result
- or one whole-program victory
