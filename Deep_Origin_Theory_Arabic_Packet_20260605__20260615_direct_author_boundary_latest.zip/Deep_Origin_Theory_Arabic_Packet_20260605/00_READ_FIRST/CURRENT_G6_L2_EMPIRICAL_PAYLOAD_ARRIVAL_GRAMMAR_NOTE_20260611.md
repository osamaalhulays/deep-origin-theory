# Current `G6` `L2` Empirical Payload Arrival Grammar

Date: `2026-06-11`

Purpose:

This note upgrades the older broad "`L2` is payload-gated" reading into one
exact current arrival grammar.

## Short verdict

The fair current reading is:

- the lawful public hunt is already exhausted,
- the missing wall is not more search effort,
- and the only live `G6` wound is one lawful external payload arrival that
  can be classified exactly as `PAYLOAD_A` or `PAYLOAD_B`.

## Lawful arrival channels only

The lawful arrival channels are:

- explicit machine-readable same-corridor release
- explicit machine-readable `CDS` or `VizieR` release
- explicit `DOI`-bound machine-readable supplementary dataset
- direct-author payload supplied to the user

Nothing outside these channels counts as `G6` arrival.

## `PAYLOAD_A` vs `PAYLOAD_B`

`PAYLOAD_A` is:

- full component curves with component uncertainties

Minimum required rowwise fields:

- `galaxy_id`
- `radius`
- `radius_unit`
- `Vobs`
- `sigma_Vobs`
- `Vgas`
- `sigma_Vgas`
- `Vdisk`
- `sigma_Vdisk`
- optional `Vbulge`
- optional `sigma_Vbulge`
- `source_reference`

`PAYLOAD_B` is:

- component curves without component uncertainties

Minimum required rowwise fields:

- `galaxy_id`
- `radius`
- `radius_unit`
- `Vobs`
- `sigma_Vobs`
- `Vgas`
- `Vdisk`
- optional `Vbulge`
- `source_reference`

## Current governed verdict

The current honest read is:

- the public hunt is cosmically closed
- one direct-author corridor is now explicitly pending with the near
  promised window ending `2026-06-12` and fallback window ending
  `2026-06-22`
- the selected next target is therefore no longer one vague public wait;
  it is wait-first on that exact direct-author corridor or one equally lawful
  machine-readable release
- no intake verification has yet run on one newly supplied payload
- no `PAYLOAD_A` or `PAYLOAD_B` classification has yet been executed on one
  newly supplied file
- no hidden local payload may be treated as already arrived through OCR,
  digitization,
  proxy fitting,
  or `Vbar` substitution

So the remaining wound is:

- one real external payload arrival,
  not one hidden local assembly move

## Rejected substitutes

The following do **not** count as `G6` arrival:

- PDF-only massmodel plots
- component semantics visible only as plotted lines
- global or integrated masses without rowwise component curves
- `H I` cubes or maps without released component rows
- `Vobs`-only or `Vc`-only rows without baryonic component curves
- `Vbar`-only rows for the source-geometry claim path
- prose claims that the dataset is public without the files

## Exact arrival event

`G6` flips from open to arrived only when:

- one payload reaches the user through one lawful arrival channel
- and the payload passes intake verification
- and the payload is classified exactly as `PAYLOAD_A` or `PAYLOAD_B`

Until then:

- `G6` remains open

## Read with

- `AUTHORITY_GATED_FRONTS_NOTE__MACS1206_AND_L2_20260606.md`
- `L2_PUBLIC_HUNT_COSMIC_CLOSURE_AND_DIRECT_AUTHOR_ADMISSION_GATE_NOTE_20260606.md`
- `CURRENT_G6_DIRECT_AUTHOR_PENDING_PAYLOAD_CORRIDOR_NOTE_20260611.md`
