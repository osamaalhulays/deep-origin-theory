#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import math
from pathlib import Path

import numpy as np
import torch


CASE_ID = "NGC3992"
FAMILY_MEMBERS = ("simple", "standard")
SCAN_HI = 1.8

HERE = Path(__file__).resolve()
OBJECT_ROOT = HERE.parents[1]
DEBT_ROOT = HERE.parents[2]
GRADE1_SCRIPT = (
    DEBT_ROOT
    / "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_RUNTIME_LOCKED_FIRST_STRONGER_COURT_GRADE1_OBJECT_V1"
    / "03_RUN"
    / "REPRODUCE_AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_RUNTIME_LOCKED_FIRST_STRONGER_COURT_GRADE1.py"
)
DEFAULT_MANIFEST_LOCK = OBJECT_ROOT / "02_LOCKS" / "RUNTIME_LOCKED_MANIFEST_PRIOR_LOCK.json"
DEFAULT_FAMILY_ROSTER = OBJECT_ROOT / "02_LOCKS" / "INTERPOLATION_FAMILY_ROSTER.json"


def load_grade1_module():
    spec = importlib.util.spec_from_file_location("ngc3992_grade1_runtime_locked", GRADE1_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"failed to load grade1 helper script from {GRADE1_SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


GRADE1 = load_grade1_module()


def qumond_nu(y: np.ndarray, family_member: str) -> np.ndarray:
    if family_member == "simple":
        return 0.5 + np.sqrt(0.25 + 1.0 / y)
    if family_member == "standard":
        # Derived by inverting y = x * mu(x) with mu(x) = x / sqrt(1 + x^2).
        return np.sqrt(0.5 * (1.0 + np.sqrt(1.0 + 4.0 / np.square(y))))
    raise ValueError(f"unsupported family member: {family_member}")


def evaluate_qumond_grid_family(
    scales: np.ndarray,
    gas_power: np.ndarray,
    stellar_bulge_power: np.ndarray,
    radii_m: np.ndarray,
    vobs_km_s: np.ndarray,
    sigma_v_km_s: np.ndarray,
    family_member: str,
) -> np.ndarray:
    total_vbar2 = gas_power[None, :] + np.square(scales)[:, None] * stellar_bulge_power[None, :]
    valid = np.all(total_vbar2 > 0.0, axis=1)
    loglikes = np.full(scales.shape, -np.inf, dtype=np.float64)
    if not np.any(valid):
        return loglikes
    total_valid = total_vbar2[valid]
    gbar = total_valid * 1_000_000.0 / radii_m[None, :]
    nu = qumond_nu(gbar / GRADE1.A0_MS2, family_member)
    vpred_km_s = np.sqrt(total_valid) * np.sqrt(nu)
    residuals = vobs_km_s[None, :] - vpred_km_s
    loglikes[valid] = GRADE1.gaussian_loglike_grid(residuals, sigma_v_km_s)
    return loglikes


def evaluate_qumond_single_family(
    scale: float,
    gas_power: np.ndarray,
    stellar_bulge_power: np.ndarray,
    radii_m: np.ndarray,
    vobs_km_s: np.ndarray,
    sigma_v_km_s: np.ndarray,
    family_member: str,
) -> dict:
    total_vbar2 = gas_power + (scale * scale) * stellar_bulge_power
    if np.any(total_vbar2 <= 0.0):
        raise ValueError(f"{CASE_ID}: non-positive total baryonic power encountered")
    gbar_m_s2 = total_vbar2 * 1_000_000.0 / radii_m
    nu = qumond_nu(gbar_m_s2 / GRADE1.A0_MS2, family_member)
    vbar_km_s = np.sqrt(total_vbar2)
    vpred_km_s = vbar_km_s * np.sqrt(nu)
    residual_km_s = vobs_km_s - vpred_km_s
    chi2_terms = (residual_km_s / sigma_v_km_s) ** 2
    return {
        "family_member": family_member,
        "scale": scale,
        "gbar_m_s2": gbar_m_s2,
        "log10_gbar_m_s2": np.log10(gbar_m_s2),
        "nu": nu,
        "vbar_km_s": vbar_km_s,
        "vpred_km_s": vpred_km_s,
        "residual_km_s": residual_km_s,
        "chi2_terms": chi2_terms,
        "chi2_total": float(np.sum(chi2_terms)),
        "ll_obs_only": float(GRADE1.gaussian_loglike_grid(residual_km_s[None, :], sigma_v_km_s)[0]),
    }


def build_family_rows(
    observed_rows: list[dict],
    family_eval: dict,
) -> list[dict]:
    rows = []
    for obs, gbar, loggbar, nu, vbar, vpred, resid, chi2 in zip(
        observed_rows,
        family_eval["gbar_m_s2"],
        family_eval["log10_gbar_m_s2"],
        family_eval["nu"],
        family_eval["vbar_km_s"],
        family_eval["vpred_km_s"],
        family_eval["residual_km_s"],
        family_eval["chi2_terms"],
    ):
        rows.append(
            {
                "row_index": obs["row_index"],
                "r_kpc": obs["r_kpc"],
                "vobs_km_s": obs["vobs_km_s"],
                "sigma_v_km_s": obs["sigma_v_km_s"],
                "family_member": family_eval["family_member"],
                "scale_s": family_eval["scale"],
                "gbar_m_s2": gbar,
                "log10_gbar_m_s2": loggbar,
                "nu": nu,
                "vbar_km_s": vbar,
                "v_qumond_km_s": vpred,
                "residual_km_s": resid,
                "chi2_term": chi2,
            }
        )
    return rows


def build_qct_rows(observed_rows: list[dict], qct_eval: dict) -> list[dict]:
    rows = []
    for obs, delta, sigma, gbar, loggbar, vbar, vdrop, vmodel, sigmav, resid, chi2 in zip(
        observed_rows,
        qct_eval["delta_1d"],
        qct_eval["sigma_delta_1d"],
        qct_eval["gbar_m_s2"],
        qct_eval["log10_gbar_m_s2"],
        qct_eval["vbar_km_s"],
        qct_eval["vdrop"],
        qct_eval["v_model_km_s"],
        qct_eval["sigma_model_km_s"],
        qct_eval["residual_km_s"],
        qct_eval["chi2_terms_obs_only"],
    ):
        rows.append(
            {
                "row_index": obs["row_index"],
                "r_kpc": obs["r_kpc"],
                "vobs_km_s": obs["vobs_km_s"],
                "sigma_v_km_s": obs["sigma_v_km_s"],
                "scale_s": qct_eval["scale"],
                "gbar_m_s2": gbar,
                "log10_gbar_m_s2": loggbar,
                "vbar_km_s": vbar,
                "vdrop": vdrop,
                "delta_qct": delta,
                "sigma_delta_qct": sigma,
                "v_qct_km_s": vmodel,
                "sigma_model_km_s": sigmav,
                "residual_km_s": resid,
                "chi2_term_obs_only": chi2,
            }
        )
    return rows


def build_report(qct_summary: dict, differential: dict, family_summaries: list[dict]) -> str:
    lines = []
    for item in family_summaries:
        lines.append(
            f"- `{item['family_member']}` best scale = `{item['best_scale']:.12f}`; "
            f"best `obs-only` loglike = `{item['ll_best_obs_only']:.12f}`"
        )
    family_lines = "\n".join(lines)
    best_family = differential["best_qumond_family_member"]
    best_family_text = "still not enough to absorb the case" if differential["m2_non_rescue_materialized"] else "stronger than the locked simple lane"
    return f"""# Author-Supplied `NGC3992` `M2` Interpolation-Family Lane Report

Date: `2026-06-13`

## Short verdict

One case-owned `M2` lawful interpolation-family lane is now materially executed
on `NGC3992`.

The family was run under:

- the same one-parameter stellar/bulge nuisance grammar
- the same `obs-only` likelihood objective
- the same runtime-locked bounded historical `QCT` lane
- one declared global interpolation roster with no galaxy-specific retuning

The family-best `QUMOND` member is:

- `{best_family}`

and that family-best lane is `{best_family_text}`.

## Family scoreboard

{family_lines}

## Family-best differential result

- `QCT` best `obs-only` loglike = `{differential["qct_best_ll_obs_only"]:.12f}`
- family-best `QUMOND` loglike = `{differential["qumond_family_best_ll_obs_only"]:.12f}`
- `Δloglike(QCT-family_best)` = `{differential["delta_loglike_qct_minus_qumond_family_best_obs_only"]:.12f}`
- `ΔAIC(QCT-family_best)` = `{differential["delta_aic_qct_minus_qumond_family_best_obs_only"]:.12f}`
- `ΔBIC(QCT-family_best)` = `{differential["delta_bic_qct_minus_qumond_family_best_obs_only"]:.12f}`

## Court consequence

- `M2` execution = `true`
- `M2` non-rescue = `{str(differential["m2_non_rescue_materialized"]).lower()}`
- full-ladder `Grade 2` already materialized = `false`

So this object closes one narrower tooth honestly:

- one declared global interpolation-family lane is no longer hypothetical
- the stronger court now has one case-owned `M2` execution surface
- but `M3/M4` remain outside this object and therefore full-ladder `Grade 2`
  is not silently claimed

## Exact ceiling

This object does **not** claim:

- full-ladder `Grade 2`
- `Grade 3`
- galaxy-specific interpolation retuning
- theory-side promotion
- whole-family `MOND/QUMOND` defeat
"""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--observed-zip", type=Path, required=True)
    parser.add_argument("--baryons-zip", type=Path, required=True)
    parser.add_argument("--model-pt", type=Path, required=True)
    parser.add_argument("--norm-json", type=Path, required=True)
    parser.add_argument("--manifest-lock-json", type=Path, default=DEFAULT_MANIFEST_LOCK)
    parser.add_argument("--family-roster-json", type=Path, default=DEFAULT_FAMILY_ROSTER)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    observed_records = GRADE1.read_zip_records(args.observed_zip.resolve(), GRADE1.OBSERVED_SUFFIX)
    baryonic_records = GRADE1.read_zip_records(args.baryons_zip.resolve(), GRADE1.BARYON_SUFFIX)
    if CASE_ID not in observed_records or CASE_ID not in baryonic_records:
        raise ValueError(f"{CASE_ID}: missing from one of the author-supplied zip files")

    manifest_lock = json.loads(args.manifest_lock_json.resolve().read_text(encoding="utf-8"))
    family_roster = json.loads(args.family_roster_json.resolve().read_text(encoding="utf-8"))
    gamma = float(manifest_lock["priors"]["gamma"])
    m_eV = float(manifest_lock["priors"]["m_eV"])

    norm = json.loads(args.norm_json.resolve().read_text(encoding="utf-8"))
    mean = np.asarray(norm["mean"], dtype=np.float32)
    std = np.asarray(norm["std"], dtype=np.float32)
    if mean.shape != (6,) or std.shape != (6,):
        raise ValueError("unexpected norm shape for historical 6-feature artifact emulator")

    model = GRADE1.Net()
    model.load_state_dict(torch.load(args.model_pt.resolve(), map_location="cpu"))
    model.eval()

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    arrays, audit = GRADE1.build_case_arrays(observed_records[CASE_ID], baryonic_records[CASE_ID])
    gas_power = arrays["gas_power"]
    stellar_bulge_power = arrays["stellar_bulge_power"]
    radii_m = arrays["radii_m"]
    vobs_km_s = arrays["vobs_km_s"]
    sigma_v_km_s = arrays["sigma_v_km_s"]
    observed_rows = arrays["observed_rows"]
    component_rows = arrays["component_rows"]

    legal_low = GRADE1.lower_scale_gate(gas_power, stellar_bulge_power)
    if legal_low is None:
        raise ValueError(f"{CASE_ID}: no legal positive-total-vbar2 scale window found")

    qct_eval = lambda scales: GRADE1.evaluate_qct_grid(
        scales,
        gas_power,
        stellar_bulge_power,
        radii_m,
        vobs_km_s,
        sigma_v_km_s,
        model,
        mean,
        std,
        gamma,
        m_eV,
        batch_size=65536,
    )
    qct_best_scale, qct_best_ll = GRADE1.maximize_model(qct_eval, legal_low, SCAN_HI)
    if qct_best_scale is None:
        raise ValueError(f"{CASE_ID}: failed to materialize one finite QCT maximum")
    qct_best = GRADE1.evaluate_qct_single(
        qct_best_scale,
        gas_power,
        stellar_bulge_power,
        radii_m,
        vobs_km_s,
        sigma_v_km_s,
        model,
        mean,
        std,
        gamma,
        m_eV,
    )
    qct_summary = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_RUNTIME_LOCKED_QCT_ARTIFACT_EMULATOR_MATCHED_NUISANCE_OBJECT_V1",
        "date": "2026-06-13",
        "case_id": CASE_ID,
        "delta_source": "artifact_emulator",
        "historical_lane_only": True,
        "observed_row_count": len(observed_rows),
        "compressed_baryonic_row_count": audit["compressed_row_count"],
        "best_scale": qct_best_scale,
        "best_scale_at_lower_bound": GRADE1.near_equal(qct_best_scale, legal_low),
        "best_scale_at_upper_bound": GRADE1.near_equal(qct_best_scale, SCAN_HI),
        "ll_best_obs_only": qct_best_ll,
        "training_manifest_hash": manifest_lock["config_hash"],
        "historical_model_pt_ref": str(args.model_pt.resolve()),
        "historical_model_pt_sha256": GRADE1.sha256(args.model_pt.resolve()),
        "historical_norm_json_ref": str(args.norm_json.resolve()),
        "historical_norm_json_sha256": GRADE1.sha256(args.norm_json.resolve()),
        "raw_observed_zip_ref": str(args.observed_zip.resolve()),
        "raw_baryons_zip_ref": str(args.baryons_zip.resolve()),
        "raw_observed_zip_sha256": GRADE1.sha256(args.observed_zip.resolve()),
        "raw_baryons_zip_sha256": GRADE1.sha256(args.baryons_zip.resolve()),
        "cosmic_closure_claim": False,
    }

    family_member_summaries: list[dict] = []
    family_best_eval: dict | None = None
    family_best_summary: dict | None = None
    simple_summary: dict | None = None
    family_scoreboard_rows = []

    declared_members = [member["name"] for member in family_roster["members"]]
    if declared_members != list(FAMILY_MEMBERS):
        raise ValueError(
            f"{CASE_ID}: roster members {declared_members} do not match the executable family {list(FAMILY_MEMBERS)}"
        )

    for family_member in FAMILY_MEMBERS:
        family_eval = lambda scales, member=family_member: evaluate_qumond_grid_family(
            scales,
            gas_power,
            stellar_bulge_power,
            radii_m,
            vobs_km_s,
            sigma_v_km_s,
            member,
        )
        best_scale, best_ll = GRADE1.maximize_model(family_eval, legal_low, SCAN_HI)
        if best_scale is None or best_ll is None:
            raise ValueError(f"{CASE_ID}: failed to materialize one finite {family_member} maximum")
        fixed_eval = evaluate_qumond_single_family(
            1.0,
            gas_power,
            stellar_bulge_power,
            radii_m,
            vobs_km_s,
            sigma_v_km_s,
            family_member,
        )
        best_eval = evaluate_qumond_single_family(
            best_scale,
            gas_power,
            stellar_bulge_power,
            radii_m,
            vobs_km_s,
            sigma_v_km_s,
            family_member,
        )
        summary = {
            "object": f"AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_QUMOND_{family_member.upper()}_M2_MATCHED_NUISANCE_SUMMARY_20260613",
            "date": "2026-06-13",
            "case_id": CASE_ID,
            "family_member": family_member,
            "observed_row_count": len(observed_rows),
            "compressed_baryonic_row_count": audit["compressed_row_count"],
            "fixed_scale": 1.0,
            "best_scale": best_scale,
            "best_scale_at_lower_bound": GRADE1.near_equal(best_scale, legal_low),
            "best_scale_at_upper_bound": GRADE1.near_equal(best_scale, SCAN_HI),
            "ll_fixed_obs_only": fixed_eval["ll_obs_only"],
            "ll_best_obs_only": best_ll,
            "chi2_fixed_obs_only": fixed_eval["chi2_total"],
            "chi2_best_obs_only": best_eval["chi2_total"],
            "delta_loglike_best_minus_fixed_obs_only": best_ll - fixed_eval["ll_obs_only"],
            "residual_shape": GRADE1.residual_shape_metrics(best_eval["residual_km_s"], sigma_v_km_s),
            "global_member_declared_in_roster": True,
            "galaxy_specific_retuning": False,
            "cosmic_closure_claim": False,
        }
        family_member_summaries.append(summary)
        family_scoreboard_rows.append(
            {
                "family_member": family_member,
                "best_scale": best_scale,
                "best_scale_at_lower_bound": summary["best_scale_at_lower_bound"],
                "best_scale_at_upper_bound": summary["best_scale_at_upper_bound"],
                "ll_fixed_obs_only": fixed_eval["ll_obs_only"],
                "ll_best_obs_only": best_ll,
                "delta_loglike_best_minus_fixed_obs_only": best_ll - fixed_eval["ll_obs_only"],
                "residual_sign_class": summary["residual_shape"]["sign_class"],
                "residual_sign_change_count": summary["residual_shape"]["sign_change_count"],
                "residual_rms_sigma_units": summary["residual_shape"]["rms_sigma_units"],
            }
        )

        GRADE1.write_csv(
            output_dir / f"NGC3992_QUMOND_{family_member.upper()}_MATCHED_NUISANCE_COMPARATOR.csv",
            [
                "row_index",
                "r_kpc",
                "vobs_km_s",
                "sigma_v_km_s",
                "family_member",
                "scale_s",
                "gbar_m_s2",
                "log10_gbar_m_s2",
                "nu",
                "vbar_km_s",
                "v_qumond_km_s",
                "residual_km_s",
                "chi2_term",
            ],
            build_family_rows(observed_rows, best_eval),
        )
        GRADE1.write_json(
            output_dir / f"NGC3992_QUMOND_{family_member.upper()}_MATCHED_NUISANCE_SUMMARY.json",
            summary,
        )

        if family_member == "simple":
            simple_summary = summary
        if family_best_summary is None or best_ll > family_best_summary["ll_best_obs_only"]:
            family_best_summary = summary
            family_best_eval = best_eval

    assert family_best_summary is not None
    assert family_best_eval is not None
    assert simple_summary is not None

    delta_loglike_family_best = qct_best_ll - family_best_summary["ll_best_obs_only"]
    delta_aic_family_best = (-2.0 * qct_best_ll + 2.0) - (
        -2.0 * family_best_summary["ll_best_obs_only"] + 2.0
    )
    delta_bic_family_best = (-2.0 * qct_best_ll + math.log(len(observed_rows))) - (
        -2.0 * family_best_summary["ll_best_obs_only"] + math.log(len(observed_rows))
    )
    delta_aic_simple = (-2.0 * qct_best_ll + 2.0) - (-2.0 * simple_summary["ll_best_obs_only"] + 2.0)

    best_scales_interior = (
        not qct_summary["best_scale_at_lower_bound"]
        and not qct_summary["best_scale_at_upper_bound"]
        and not family_best_summary["best_scale_at_lower_bound"]
        and not family_best_summary["best_scale_at_upper_bound"]
    )
    m2_non_rescue_materialized = (
        delta_loglike_family_best > 0.0 and delta_aic_family_best <= -10.0 and best_scales_interior
    )

    differential = {
        "object_class": "M2_INTERPOLATION_FAMILY_LANE",
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_NGC3992_M2_INTERPOLATION_FAMILY_LANE_DIFFERENTIAL_SUMMARY_20260613",
        "date": "2026-06-13",
        "case_id": CASE_ID,
        "family_member_count": len(FAMILY_MEMBERS),
        "family_members_tested": list(FAMILY_MEMBERS),
        "global_family_declared": True,
        "same_nuisance_floor": True,
        "same_obs_only_objective": True,
        "best_scales_interior": best_scales_interior,
        "qct_best_scale": qct_best_scale,
        "qct_best_ll_obs_only": qct_best_ll,
        "qumond_simple_best_ll_obs_only": simple_summary["ll_best_obs_only"],
        "best_qumond_family_member": family_best_summary["family_member"],
        "qumond_family_best_scale": family_best_summary["best_scale"],
        "qumond_family_best_ll_obs_only": family_best_summary["ll_best_obs_only"],
        "delta_loglike_qct_minus_qumond_family_best_obs_only": delta_loglike_family_best,
        "delta_aic_qct_minus_qumond_family_best_obs_only": delta_aic_family_best,
        "delta_bic_qct_minus_qumond_family_best_obs_only": delta_bic_family_best,
        "delta_aic_qct_minus_qumond_simple_best_obs_only": delta_aic_simple,
        "m2_execution_materialized": True,
        "m2_non_rescue_materialized": m2_non_rescue_materialized,
        "grade2_materialized_under_current_full_ladder": False,
        "grade2_blockers_remaining": ["M3", "M4"],
        "qumond_family_best_residual_shape": family_best_summary["residual_shape"],
        "qct_residual_shape": GRADE1.residual_shape_metrics(qct_best["residual_km_s"], sigma_v_km_s),
        "verdict": (
            "M2_INTERPOLATION_FAMILY_NON_RESCUE_MATERIALIZED_ON_NGC3992__FULL_GRADE2_STILL_BLOCKED_BY_M3_M4"
            if m2_non_rescue_materialized
            else "M2_INTERPOLATION_FAMILY_EXECUTED_BUT_NON_RESCUE_NOT_MATERIALIZED_ON_NGC3992"
        ),
        "cosmic_closure_claim": False,
    }

    GRADE1.write_csv(
        output_dir / "NGC3992_OBSERVED_KINEMATIC_ROWS.csv",
        ["row_index", "r_kpc", "r_m", "vobs_km_s", "sigma_v_km_s", "gobs_m_s2"],
        observed_rows,
    )
    GRADE1.write_csv(
        output_dir / "NGC3992_COMPONENT_ROWS_AT_OBSERVED_RADII.csv",
        [
            "row_index",
            "r_kpc",
            "left_baryonic_r_kpc",
            "right_baryonic_r_kpc",
            "interpolation_mode",
            "signed_vhi2_km2_s2",
            "signed_vh2_2_km2_s2",
            "vstars2_km2_s2",
            "vbulge2_km2_s2",
            "gas_signed_vbar2_km2_s2",
            "stellar_bulge_vbar2_km2_s2",
        ],
        component_rows,
    )
    GRADE1.write_csv(
        output_dir / "NGC3992_QCT_ARTIFACT_EMULATOR_MATCHED_NUISANCE_COMPARATOR.csv",
        [
            "row_index",
            "r_kpc",
            "vobs_km_s",
            "sigma_v_km_s",
            "scale_s",
            "gbar_m_s2",
            "log10_gbar_m_s2",
            "vbar_km_s",
            "vdrop",
            "delta_qct",
            "sigma_delta_qct",
            "v_qct_km_s",
            "sigma_model_km_s",
            "residual_km_s",
            "chi2_term_obs_only",
        ],
        build_qct_rows(observed_rows, qct_best),
    )
    GRADE1.write_csv(
        output_dir / "NGC3992_M2_INTERPOLATION_FAMILY_SCOREBOARD.csv",
        [
            "family_member",
            "best_scale",
            "best_scale_at_lower_bound",
            "best_scale_at_upper_bound",
            "ll_fixed_obs_only",
            "ll_best_obs_only",
            "delta_loglike_best_minus_fixed_obs_only",
            "residual_sign_class",
            "residual_sign_change_count",
            "residual_rms_sigma_units",
        ],
        family_scoreboard_rows,
    )
    GRADE1.write_json(output_dir / "NGC3992_QCT_MATCHED_NUISANCE_SUMMARY.json", qct_summary)
    GRADE1.write_json(output_dir / "NGC3992_M2_INTERPOLATION_FAMILY_DIFFERENTIAL_SUMMARY.json", differential)
    GRADE1.write_json(
        output_dir / "VERDICT.json",
        {
            "case_id": CASE_ID,
            "best_qumond_family_member": differential["best_qumond_family_member"],
            "m2_execution_materialized": True,
            "m2_non_rescue_materialized": differential["m2_non_rescue_materialized"],
            "grade2_materialized_under_current_full_ladder": False,
            "verdict": differential["verdict"],
        },
    )
    (output_dir / "NGC3992_M2_INTERPOLATION_FAMILY_REPORT.md").write_text(
        build_report(qct_summary, differential, family_member_summaries),
        encoding="utf-8",
    )

    print(
        json.dumps(
            {
                "qct_summary": qct_summary,
                "family_member_summaries": family_member_summaries,
                "differential": differential,
            },
            indent=2,
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
