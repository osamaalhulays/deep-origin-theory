# Current `G4` Monotone Public Source-Profile Candidate Note

Date: `2026-06-11`

Status: `bounded local gain above admitted Form D`

## Short verdict

The local packet universe still does **not** contain one fully authoritative
production input triple for the admitted external `Form D` engine.

But it no longer deserves the older blanket reading:

- `source profile = template only`
- `benchmark bins = template only`

because two exact public-source candidate pairs are now materially visible:

- `NGC1705`
- `NGC4214`

Each pair now contains:

- one candidate source profile,
- one candidate case-native `x_i = log10(gbar)` roster,
- one public-lineage manifest,
- and one clean pre-observed toy-engine diagnostic pass.

## Exact gain

For the two surviving monotone-ready bulgeless cases,
the candidate source profile is now built from already visible public inputs:

- public SPARC stellar vertical support,
- public HI surface-density support,
- the visible published fixed gas-vertical rule,
- and the public SPARC `v_bar(R)` rotmod rows.

This matches the current extraction lock:

```text
Delta(r) := -phi(R=r,z=0)
```

so no silent branch/fiber fusion is used here.

## Branch/fiber result

Among the seven published gas-vertical cases scanned under this route:

- `NGC1705` is monotone-ready
- `NGC4214` is monotone-ready
- the other five remain blocked at non-monotone `x(r)`

So the conditional branch/fiber wake gate is now discharged for the two
materialized cases above.

## Engine diagnostic result

Using the admitted external `Form D` engine with the shipped toy `m_inv`
lock only for bounded diagnostics,
both monotone-ready cases now pass to:

```text
FORM_A_AND_QCT_PREDICTION_ROWS_MATERIALIZED
```

This does **not** claim production authority,
observed-row crossing,
or `G4` closure.

## Exact remaining blocker

One later direct-author execution-priority choice has now already frozen the
first production-case source-profile / benchmark-bin pair on:

- `NGC4214`

This is not promoted here into one formal superiority theorem over
`NGC1705`.

`NGC1705` remains one monotone-ready reserve case.

What still remains is:

- one author-frozen production `m_inv` lock

## Bottom line

`G4` is not closed.

But the wound is now materially tighter:

- from total local source/bin absence beyond templates
- to two already-materialized monotone-ready candidate pairs,
  with branch/fiber discharged,
  with `NGC4214` now frozen as the first production case,
  and the remaining blocker compressed mainly to production `m_inv`
  authority.
