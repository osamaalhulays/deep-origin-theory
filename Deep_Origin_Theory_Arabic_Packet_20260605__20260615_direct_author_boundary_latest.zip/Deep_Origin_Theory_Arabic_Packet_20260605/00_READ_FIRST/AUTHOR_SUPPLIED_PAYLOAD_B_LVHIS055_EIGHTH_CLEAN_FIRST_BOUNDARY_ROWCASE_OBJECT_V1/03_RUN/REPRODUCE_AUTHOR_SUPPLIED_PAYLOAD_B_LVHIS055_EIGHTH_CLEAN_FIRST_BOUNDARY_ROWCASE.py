#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import json
import statistics
from pathlib import Path


TARGET_GALAXY = "LVHIS055"
EXPECTED_RANK = 8


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def build_report(summary: dict) -> str:
    return f"""# Author-Supplied `PAYLOAD_B` `LVHIS055` Eighth Clean-First Boundary Rowcase Report

Date: `2026-06-13`

## Short verdict

`LVHIS055` is now materialized as the current eighth clean-first case, and it
is the first present clean-first case that breaks the packet-local all-positive
empirical gap condition.

## Exact present shape

- target galaxy: `{summary["galaxy"]}`
- clean-first shortlist rank: `{summary["clean_first_priority_rank"]}`
- observed rows: `{summary["observed_row_count"]}`
- radius range: `{summary["min_r_kpc"]}` to `{summary["max_r_kpc"]}` kpc
- exact interpolation rows: `{summary["exact_interpolation_row_count"]}`
- linear interpolation rows: `{summary["linear_interpolation_row_count"]}`
- all rows stay comparison-ready: `{str(summary["all_rows_comparison_ready"]).lower()}`
- all rows keep clean-first status: `{str(summary["all_rows_clean_first"]).lower()}`
- all rows keep positive `log10(gobs) - log10(gbar)`: `{str(summary["all_delta_positive"]).lower()}`
- nonpositive row count: `{summary["nonpositive_row_count"]}`
- first nonpositive row index: `{summary["first_nonpositive_row_index"]}`
- first nonpositive row radius: `{summary["first_nonpositive_radius_kpc"]}` kpc
- first nonpositive `delta`: `{summary["first_nonpositive_delta"]}`
- `delta` range: `{summary["delta_min"]}` to `{summary["delta_max"]}`
- `delta` median: `{summary["delta_median"]}`
- `gbar` peak radius: `{summary["gbar_peak_radius_kpc"]}` kpc
- `gbar` is nonincreasing after its peak: `{str(summary["gbar_nonincreasing_after_peak"]).lower()}`

## Exact current ceiling

This object gives one boundary rowcase only.

It does not yet give:

- one theory-side promotion
- one matched-nuisance comparison
- one competitor verdict
- one claim that the current negative witness is physically interpreted
"""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rowwise-csv", required=True)
    parser.add_argument("--ledger-csv", required=True)
    parser.add_argument("--shortlist-csv", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    rowwise_rows = load_csv(Path(args.rowwise_csv).resolve())
    ledger_rows = load_csv(Path(args.ledger_csv).resolve())
    shortlist_rows = load_csv(Path(args.shortlist_csv).resolve())
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    ledger = next((row for row in ledger_rows if row["galaxy"] == TARGET_GALAXY), None)
    if ledger is None:
        raise ValueError(f"{TARGET_GALAXY}: missing galaxy ledger row")

    shortlist = next((row for row in shortlist_rows if row["galaxy"] == TARGET_GALAXY), None)
    if shortlist is None:
        raise ValueError(f"{TARGET_GALAXY}: missing shortlist row")
    if int(shortlist["rank"]) != EXPECTED_RANK:
        raise ValueError(f"{TARGET_GALAXY}: is not rank-{EXPECTED_RANK} in the clean-first shortlist")

    case_rows = [row for row in rowwise_rows if row["galaxy"] == TARGET_GALAXY]
    if not case_rows:
        raise ValueError(f"{TARGET_GALAXY}: missing rowwise case rows")

    observed_rows = len(case_rows)
    radii = [float(row["r_kpc_observed"]) for row in case_rows]
    gbar = [float(row["gbar_m_s2"]) for row in case_rows]
    deltas = [float(row["delta_log10_gobs_minus_gbar"]) for row in case_rows]

    all_rows_comparison_ready = all(
        row["rowwise_empirical_comparison_ready"] == "true" for row in case_rows
    )
    all_rows_clean_first = all(row["clean_first_gate_pass"] == "true" for row in case_rows)
    all_delta_positive = all(delta > 0.0 for delta in deltas)
    nonpositive_indices = [index for index, delta in enumerate(deltas) if delta <= 0.0]
    first_nonpositive_index = nonpositive_indices[0] if nonpositive_indices else None
    exact_interpolation_row_count = sum(row["interpolation_mode"] == "exact" for row in case_rows)
    linear_interpolation_row_count = sum(row["interpolation_mode"] == "linear" for row in case_rows)
    radius_strictly_increasing = all(radii[i + 1] > radii[i] for i in range(len(radii) - 1))
    gbar_peak_index = max(range(len(gbar)), key=gbar.__getitem__)
    gbar_peak_radius_kpc = radii[gbar_peak_index]
    gbar_nonincreasing_after_peak = all(
        gbar[i + 1] <= gbar[i] for i in range(gbar_peak_index, len(gbar) - 1)
    )

    summary = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_LVHIS055_EIGHTH_CLEAN_FIRST_BOUNDARY_ROWCASE_SUMMARY_20260613",
        "galaxy": TARGET_GALAXY,
        "comparison_scope": "empirical_gobs_gbar_only",
        "clean_first_priority_rank": int(shortlist["rank"]),
        "observed_row_count": observed_rows,
        "min_r_kpc": min(radii),
        "max_r_kpc": max(radii),
        "radius_strictly_increasing": radius_strictly_increasing,
        "exact_interpolation_row_count": exact_interpolation_row_count,
        "linear_interpolation_row_count": linear_interpolation_row_count,
        "all_rows_comparison_ready": all_rows_comparison_ready,
        "all_rows_clean_first": all_rows_clean_first,
        "all_delta_positive": all_delta_positive,
        "nonpositive_row_count": len(nonpositive_indices),
        "first_nonpositive_row_index": first_nonpositive_index,
        "first_nonpositive_radius_kpc": (
            radii[first_nonpositive_index] if first_nonpositive_index is not None else None
        ),
        "first_nonpositive_delta": (
            deltas[first_nonpositive_index] if first_nonpositive_index is not None else None
        ),
        "delta_min": min(deltas),
        "delta_max": max(deltas),
        "delta_median": statistics.median(deltas),
        "gbar_peak_row_index": gbar_peak_index,
        "gbar_peak_radius_kpc": gbar_peak_radius_kpc,
        "gbar_nonincreasing_after_peak": gbar_nonincreasing_after_peak,
        "theory_side_authoring_eligible": False,
        "boundary_role": "first_current_clean_first_nonpositive_break",
        "verdict": (
            "AUTHOR_SUPPLIED_PAYLOAD_B_LVHIS055_EIGHTH_CLEAN_FIRST_BOUNDARY_ROWCASE_MATERIALIZED__THE_RANK8_CASE_IS_THE_FIRST_CURRENT_CLEAN_FIRST_BOUNDARY_BREAK_AT_GOBS_GBAR_SCOPE"
        ),
    }

    key_rows = []
    key_specs = [
        ("first_nonpositive_row", first_nonpositive_index if first_nonpositive_index is not None else 0),
        ("gbar_peak_row", gbar_peak_index),
        ("last_row", len(case_rows) - 1),
    ]
    for role, index in key_specs:
        row = case_rows[index]
        key_rows.append(
            {
                "key_role": role,
                "observed_row_index": row["observed_row_index"],
                "r_kpc_observed": row["r_kpc_observed"],
                "log10_gbar_m_s2": row["log10_gbar_m_s2"],
                "log10_gobs_m_s2": row["log10_gobs_m_s2"],
                "delta_log10_gobs_minus_gbar": row["delta_log10_gobs_minus_gbar"],
                "interpolation_mode": row["interpolation_mode"],
            }
        )

    write_csv(
        output_dir / "LVHIS055_BOUNDARY_ROWCASE.csv",
        [
            "galaxy",
            "observed_row_index",
            "r_kpc_observed",
            "vobs_km_s",
            "e_vobs_km_s",
            "interpolation_mode",
            "vbar2_signed_km2_s2",
            "gbar_m_s2",
            "log10_gbar_m_s2",
            "gobs_m_s2",
            "log10_gobs_m_s2",
            "delta_log10_gobs_minus_gbar",
            "rowwise_empirical_comparison_ready",
            "current_scope_class",
            "clean_first_gate_pass",
            "clean_first_priority_rank",
            "theory_side_authoring_eligible",
            "comparison_scope",
        ],
        case_rows,
    )
    write_csv(
        output_dir / "LVHIS055_BOUNDARY_KEY_ROWS.csv",
        [
            "key_role",
            "observed_row_index",
            "r_kpc_observed",
            "log10_gbar_m_s2",
            "log10_gobs_m_s2",
            "delta_log10_gobs_minus_gbar",
            "interpolation_mode",
        ],
        key_rows,
    )
    (output_dir / "ROWCASE_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (output_dir / "ROWCASE_REPORT.md").write_text(
        build_report(summary),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
