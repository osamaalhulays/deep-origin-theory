# Front-`7` Maximal All-Positive Boundary Capsule — author-supplied `PAYLOAD_B`

Date: `2026-06-13`

Status: `bounded outward-facing capsule`

Purpose:

This capsule answers one narrow reviewer question directly:

Do you now show not only front-`7`, but also that front-`7` is the current
maximal all-positive clean-first head?

Short answer:

- `yes, in bounded form`

## What is frozen here

The bounded boundary claim frozen here is:

- the current all-positive clean-first head inside the landed author-supplied `PAYLOAD_B` family
  `PAYLOAD_B` lane is front-`7`
- that head currently carries `159` of `184` clean-first rows
- the first present break appears immediately at rank `8` on `LVHIS055`

This is **not** yet:

- one theory-side front
- one `QCT` prediction front
- one matched-nuisance front comparison
- or one differential superiority claim

## Exact boundary shape

The current maximal head is:

- `NGC1313` = rank-`1`, `40` rows
- `NGC2541` = rank-`2`, `31` rows
- `NGC7793` = rank-`3`, `29` rows
- `NGC3992` = rank-`4`, `20` rows
- `LVHIS077` = rank-`5`, `15` rows
- `LVHIS072` = rank-`6`, `12` rows
- `LVHIS011` = rank-`7`, `12` rows

Together this gives:

- `7` named focused cases
- `159` observed rows
- all head rows comparison-ready
- all head rows clean-first
- all head rows with positive empirical `log10(gobs) - log10(gbar)`

The first present break is:

- `LVHIS055` = rank-`8`, `7` rows
- one nonpositive row appears there
- first nonpositive row index = `0`
- first nonpositive row radius = `0.29 kpc`
- first nonpositive `delta = -9.191637233385563e-05`

## Why this matters

The stopping point is not rhetorical.

It is exactly the first place where the already frozen clean-first order stops
supporting an all-positive head under the packet-local empirical rowwise lane.

## Why this still remains bounded

This boundary is real, but it remains **strictly bounded**.

The packet does **not** yet publish for this head or its first break:

- one theory-side source profile family
- one `QCT` prediction-row family
- one matched-nuisance fairness execution
- or one named competitor verdict

So the honest reading is not:

- “the current head already proves the theory-side lane”

The honest reading is:

- the packet now has one maximal current all-positive head above the landed
  author-supplied family
- the packet also shows exactly where that head stops
- and both surfaces remain empirical-only

## Short outward-safe wording

One outward-safe summary sentence is:

> The landed author-supplied `PAYLOAD_B` lane now carries one maximal current
> all-positive clean-first head of seven focused empirical cases totaling
> `159` of `184` clean-first rows, and the packet openly shows that the first
> lawful extension beyond that head breaks at rank `8` on `LVHIS055` within
> present empirical `gobs/gbar` scope.

## Use rule

Use this capsule to answer:

- “Do you now show where the current all-positive head honestly stops?”

Do **not** use it to claim:

- one theory-side closure
- one fairness-grade comparator result
- or one whole-program victory
