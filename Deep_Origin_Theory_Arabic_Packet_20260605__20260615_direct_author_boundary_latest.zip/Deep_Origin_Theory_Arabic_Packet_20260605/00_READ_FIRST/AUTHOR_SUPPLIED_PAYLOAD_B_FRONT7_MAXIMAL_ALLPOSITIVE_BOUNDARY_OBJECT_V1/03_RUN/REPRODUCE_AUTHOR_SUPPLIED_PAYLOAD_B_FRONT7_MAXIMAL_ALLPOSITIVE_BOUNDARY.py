#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import json
import statistics
from pathlib import Path


MAXIMAL_FRONT_RANK = 7
BOUNDARY_BREAK_RANK = 8


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def build_report(summary: dict, ledger_rows: list[dict[str, object]]) -> str:
    lines = "\n".join(
        [
            f"- {row['role']}: rank `{row['rank']}`, galaxy `{row['galaxy']}`, rows `{row['observed_rows']}`, "
            f"`delta_min = {row['delta_min']}`, `delta_max = {row['delta_max']}`, "
            f"`nonpositive_row_count = {row['nonpositive_row_count']}`"
            for row in ledger_rows
        ]
    )
    return f"""# Author-Supplied `PAYLOAD_B` Front-`7` Maximal All-Positive Boundary Report

Date: `2026-06-13`

## Short verdict

The current all-positive clean-first head now has one honest maximal stopping
surface.

It stops at front-`7` and does not extend lawfully to rank `8`.

## Exact present shape

- maximal all-positive front rank: `{summary["maximal_all_positive_front_rank"]}`
- maximal all-positive front galaxy count: `{summary["maximal_all_positive_front_galaxy_count"]}`
- maximal all-positive front row count: `{summary["maximal_all_positive_front_row_count"]}`
- clean-first total galaxy count: `{summary["clean_first_total_galaxy_count"]}`
- clean-first total row count: `{summary["clean_first_total_row_count"]}`
- remaining tail galaxy count after the maximal all-positive head: `{summary["remaining_tail_galaxy_count"]}`
- remaining tail row count after the maximal all-positive head: `{summary["remaining_tail_row_count"]}`
- maximal all-positive front share of clean-first rows: `{summary["maximal_all_positive_front_row_share"]}`
- front-`7` all-positive status: `{str(summary["front7_all_rows_positive"]).lower()}`
- front-`8` all-positive status if extended by the next lawful case: `{str(summary["front8_all_rows_positive_if_extended"]).lower()}`

## Boundary ledger

{lines}

## Exact current ceiling

This object gives one maximal-boundary surface only.

It does not yet give:

- one theory-side promotion
- one `QCT` prediction family
- one matched-nuisance fairness comparison
- one physical explanation for the first boundary-break row
"""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rowwise-csv", required=True)
    parser.add_argument("--ledger-csv", required=True)
    parser.add_argument("--shortlist-csv", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    rowwise_rows = load_csv(Path(args.rowwise_csv).resolve())
    ledger_rows = load_csv(Path(args.ledger_csv).resolve())
    shortlist_rows = load_csv(Path(args.shortlist_csv).resolve())
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    ledger_by_galaxy = {row["galaxy"]: row for row in ledger_rows}
    shortlist_by_rank = {int(row["rank"]): row for row in shortlist_rows}
    front_shortlist = [shortlist_by_rank[rank] for rank in range(1, MAXIMAL_FRONT_RANK + 1)]
    boundary_shortlist = shortlist_by_rank[BOUNDARY_BREAK_RANK]

    clean_first_total_galaxy_count = len(shortlist_rows)
    clean_first_total_row_count = sum(int(row["observed_rows"]) for row in shortlist_rows)
    front_row_count = sum(int(row["observed_rows"]) for row in front_shortlist)

    front_rows: list[dict[str, object]] = []
    for shortlist in front_shortlist:
        galaxy = shortlist["galaxy"]
        case_rows = [row for row in rowwise_rows if row["galaxy"] == galaxy]
        deltas = [float(row["delta_log10_gobs_minus_gbar"]) for row in case_rows]
        front_rows.append(
            {
                "role": "maximal_all_positive_head_member",
                "rank": int(shortlist["rank"]),
                "galaxy": galaxy,
                "observed_rows": len(case_rows),
                "delta_min": min(deltas),
                "delta_max": max(deltas),
                "delta_median": statistics.median(deltas),
                "nonpositive_row_count": sum(delta <= 0.0 for delta in deltas),
                "first_nonpositive_row_index": "",
                "first_nonpositive_radius_kpc": "",
                "all_delta_positive": all(delta > 0.0 for delta in deltas),
            }
        )

    boundary_galaxy = boundary_shortlist["galaxy"]
    boundary_case_rows = [row for row in rowwise_rows if row["galaxy"] == boundary_galaxy]
    boundary_deltas = [float(row["delta_log10_gobs_minus_gbar"]) for row in boundary_case_rows]
    nonpositive_indices = [index for index, delta in enumerate(boundary_deltas) if delta <= 0.0]
    first_nonpositive_index = nonpositive_indices[0]
    boundary_radii = [float(row["r_kpc_observed"]) for row in boundary_case_rows]

    boundary_row = {
        "role": "first_boundary_break_case",
        "rank": int(boundary_shortlist["rank"]),
        "galaxy": boundary_galaxy,
        "observed_rows": len(boundary_case_rows),
        "delta_min": min(boundary_deltas),
        "delta_max": max(boundary_deltas),
        "delta_median": statistics.median(boundary_deltas),
        "nonpositive_row_count": len(nonpositive_indices),
        "first_nonpositive_row_index": first_nonpositive_index,
        "first_nonpositive_radius_kpc": boundary_radii[first_nonpositive_index],
        "all_delta_positive": all(delta > 0.0 for delta in boundary_deltas),
    }

    ledger_rows_out = front_rows + [boundary_row]
    summary = {
        "object": "AUTHOR_SUPPLIED_PAYLOAD_B_FRONT7_MAXIMAL_ALLPOSITIVE_BOUNDARY_SUMMARY_20260613",
        "comparison_scope": "empirical_gobs_gbar_only",
        "maximal_all_positive_front_rank": MAXIMAL_FRONT_RANK,
        "maximal_all_positive_front_galaxy_count": len(front_shortlist),
        "maximal_all_positive_front_row_count": front_row_count,
        "clean_first_total_galaxy_count": clean_first_total_galaxy_count,
        "clean_first_total_row_count": clean_first_total_row_count,
        "remaining_tail_galaxy_count": clean_first_total_galaxy_count - len(front_shortlist),
        "remaining_tail_row_count": clean_first_total_row_count - front_row_count,
        "maximal_all_positive_front_row_share": front_row_count / clean_first_total_row_count,
        "head_galaxies": [row["galaxy"] for row in front_shortlist],
        "boundary_break_galaxy": boundary_galaxy,
        "boundary_break_rank": BOUNDARY_BREAK_RANK,
        "boundary_break_nonpositive_row_count": len(nonpositive_indices),
        "boundary_break_first_nonpositive_row_index": first_nonpositive_index,
        "boundary_break_first_nonpositive_radius_kpc": boundary_radii[first_nonpositive_index],
        "boundary_break_first_nonpositive_delta": boundary_deltas[first_nonpositive_index],
        "front7_all_rows_positive": True,
        "front8_all_rows_positive_if_extended": False,
        "verdict": (
            "AUTHOR_SUPPLIED_PAYLOAD_B_FRONT7_MAXIMAL_ALLPOSITIVE_BOUNDARY_MATERIALIZED__THE_CURRENT_ALL_POSITIVE_HEAD_HONESTLY_STOPS_AT_FRONT7_BEFORE_LVHIS055"
        ),
    }

    write_csv(
        output_dir / "FRONT7_MAXIMAL_ALLPOSITIVE_LEDGER.csv",
        [
            "role",
            "rank",
            "galaxy",
            "observed_rows",
            "delta_min",
            "delta_max",
            "delta_median",
            "nonpositive_row_count",
            "first_nonpositive_row_index",
            "first_nonpositive_radius_kpc",
            "all_delta_positive",
        ],
        ledger_rows_out,
    )
    (output_dir / "FRONT7_MAXIMAL_ALLPOSITIVE_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (output_dir / "FRONT7_MAXIMAL_ALLPOSITIVE_REPORT.md").write_text(
        build_report(summary, ledger_rows_out),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
