# Selection And Scope

Date: `2026-06-13`

This object does not invent a stopping point by taste.

It reuses the already frozen clean-first shortlist exactly as it stands and
binds:

- ranks `1..7` as the current all-positive head
- rank `8` as the first present break candidate

## Source rule

The boundary is defined only by:

- `CLEAN_FIRST_PRIORITY_SHORTLIST.csv`
- `OBSERVED_ROW_EMPIRICAL_COMPARISON_READY.csv`
- `GALAXY_COMPARISON_ADMISSIBILITY_LEDGER.csv`

No new scientific rule is introduced here.

## Present bounded role

The present role is narrow:

- show that the visible all-positive head currently stops at rank `7`
- show who the head cases are
- show which exact lawful next case breaks the condition

It does **not** promote the boundary into:

- theory-side authoring
- one `QCT` prediction family
- one fairness-grade comparator family
- or one superiority verdict
