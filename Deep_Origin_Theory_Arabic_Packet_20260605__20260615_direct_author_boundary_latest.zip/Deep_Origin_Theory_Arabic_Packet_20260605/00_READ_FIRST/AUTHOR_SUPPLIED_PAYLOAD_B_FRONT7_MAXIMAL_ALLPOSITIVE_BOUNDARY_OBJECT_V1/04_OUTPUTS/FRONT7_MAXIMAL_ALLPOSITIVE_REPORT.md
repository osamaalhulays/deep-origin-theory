# Author-Supplied `PAYLOAD_B` Front-`7` Maximal All-Positive Boundary Report

Date: `2026-06-13`

## Short verdict

The current all-positive clean-first head now has one honest maximal stopping
surface.

It stops at front-`7` and does not extend lawfully to rank `8`.

## Exact present shape

- maximal all-positive front rank: `7`
- maximal all-positive front galaxy count: `7`
- maximal all-positive front row count: `159`
- clean-first total galaxy count: `11`
- clean-first total row count: `184`
- remaining tail galaxy count after the maximal all-positive head: `4`
- remaining tail row count after the maximal all-positive head: `25`
- maximal all-positive front share of clean-first rows: `0.8641304347826086`
- front-`7` all-positive status: `true`
- front-`8` all-positive status if extended by the next lawful case: `false`

## Boundary ledger

- maximal_all_positive_head_member: rank `1`, galaxy `NGC1313`, rows `40`, `delta_min = 0.19955408170893918`, `delta_max = 1.0441321624537672`, `nonpositive_row_count = 0`
- maximal_all_positive_head_member: rank `2`, galaxy `NGC2541`, rows `31`, `delta_min = 0.207124258777581`, `delta_max = 0.6422199997508269`, `nonpositive_row_count = 0`
- maximal_all_positive_head_member: rank `3`, galaxy `NGC7793`, rows `29`, `delta_min = 0.21689352579817012`, `delta_max = 0.6562431351338152`, `nonpositive_row_count = 0`
- maximal_all_positive_head_member: rank `4`, galaxy `NGC3992`, rows `20`, `delta_min = 0.16450494754325362`, `delta_max = 0.34040678069063723`, `nonpositive_row_count = 0`
- maximal_all_positive_head_member: rank `5`, galaxy `LVHIS077`, rows `15`, `delta_min = 0.3588836196376004`, `delta_max = 1.0570897006015691`, `nonpositive_row_count = 0`
- maximal_all_positive_head_member: rank `6`, galaxy `LVHIS072`, rows `12`, `delta_min = 0.21278765723040038`, `delta_max = 1.265443438278682`, `nonpositive_row_count = 0`
- maximal_all_positive_head_member: rank `7`, galaxy `LVHIS011`, rows `12`, `delta_min = 0.41271075539437163`, `delta_max = 1.1280128010002795`, `nonpositive_row_count = 0`
- first_boundary_break_case: rank `8`, galaxy `LVHIS055`, rows `7`, `delta_min = -9.191637233385563e-05`, `delta_max = 0.9747702495473565`, `nonpositive_row_count = 1`

## Exact current ceiling

This object gives one maximal-boundary surface only.

It does not yet give:

- one theory-side promotion
- one `QCT` prediction family
- one matched-nuisance fairness comparison
- one physical explanation for the first boundary-break row
