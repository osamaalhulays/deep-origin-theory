# Current `G5` `MACS1206` Terminal Carrier Arrival Grammar

Date: `2026-06-11`

Purpose:

This note upgrades the older broad "`MACS1206` is authority-gated" reading
into one exact current gate grammar.

## Short verdict

The fair current reading is:

- the same-target bounded ceiling is already materialized,
- the same-target numeric route is already closed,
- and the only live `G5` wound is one missing terminal carrier class:
  one target-specific joint baryonic covariance carrier,
  or one lawful equivalent.

## What counts as one authority-grade terminal carrier

An incoming object counts as one authority-grade `G5` carrier only if it is:

- target-specific to `MACS1206`
- machine-readable rather than figure-only or prose-only
- source-side,
  source-certified,
  or source-acknowledged for the published/current-version branch
- jointly baryonic rather than one isolated component hint
- covariance-carrying,
  or explicit enough in uncertainty semantics to support lawful covariance-
  carrying cluster-scale adjudication
- same-target coherent with the already frozen `MACS1206` stack
- usable without OCR,
  figure reading,
  or component fitting by us

The strongest form is:

- one target-specific joint baryonic covariance carrier

## What counts as one lawful equivalent

An incoming object counts as one lawful equivalent only if it is:

- one machine-readable baryonic input file set for the same target
- source-touched strongly enough to stand in for the missing carrier
- explicit in gas / galaxy radial baryonic semantics
- explicit in uncertainty or covariance semantics
- usable for the same adjudication role without reconstructing hidden rows by
  us

The allowed equivalent forms are bounded to:

- one equivalent machine-readable carrier used for the published run
- or one target-specific machine-readable gas and galaxy radial mass input set
  with uncertainty columns that lawfully closes the same carrier role

## Current governed wait-state

The current honest read is:

- highest present bounded ceiling = materialized
- prediction-complete standby scaffold = materialized
- prediction-complete standby entered = `no`
- same-target numeric duty = closed
- same-target local next move = `none`
- public refarming route = exhausted
- measurement-class bridge reopening = forbidden
- exact terminal gap class = still missing

So the remaining wound is not:

- same-target local immaturity

It is:

- exact carrier-arrival absence

## What does not count as landing

The following do **not** land `G5`:

- one paper pointer only
- one generic code reference only
- one broad permission statement without carrier files
- one figure-level baryonic surface without machine-readable semantics
- one current-version authority rumor without one target-specific carrier class
- more local same-target farming

## Exact landing event

`G5` flips from open to landed only when:

- one incoming object is received,
- verified as target-specific to `MACS1206`,
- verified as one authority-grade terminal carrier or one lawful equivalent,
- and verified as sufficient for lawful covariance-carrying cluster-scale
  adjudication above the current frozen same-target stack

Until that event occurs:

- `G5` remains open

## Read with

- `AUTHORITY_GATED_FRONTS_NOTE__MACS1206_AND_L2_20260606.md`
- `MACS1206_STAGE2_COMPLETE_AND_SAME_TARGET_AUTHORITY_ONLY_GATE_NOTE_20260606.md`
- `MACS1206_TERMINAL_AUTHORITY_CAPTURE_PLAN_AND_TRAP_NOTE_20260606.md`
