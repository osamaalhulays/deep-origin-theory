# Author-Supplied `PAYLOAD_B` `NGC7793` Third Clean Empirical Rowcase Report

Date: `2026-06-13`

## Short verdict

`NGC7793` is now materialized as the third focused clean empirical case above
the landed author-supplied `PAYLOAD_B` family.

## Exact present shape

- target galaxy: `NGC7793`
- clean-first shortlist rank: `3`
- observed rows: `29`
- radius range: `0.5` to `6.13` kpc
- exact interpolation rows: `2`
- linear interpolation rows: `27`
- all rows stay comparison-ready: `true`
- all rows keep clean-first status: `true`
- all rows keep positive `log10(gobs) - log10(gbar)`: `true`
- `delta` range: `0.21689352579817012` to `0.6562431351338152`
- `delta` median: `0.44378271651489243`
- `gbar` peak radius: `1.11` kpc
- `gbar` is nonincreasing after its peak: `true`

## Exact current ceiling

This object gives one focused empirical rowcase only.

It does not yet give:

- one theory-side promotion
- one matched-nuisance comparison
- one competitor verdict
