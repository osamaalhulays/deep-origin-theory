# Focus Selection Rationale

Date: `2026-06-13`

`NGC7793` is not selected rhetorically.

It is selected because the already frozen clean-first shortlist places it at
rank `3` under the packet-local rule:

- `rows_desc_then_gbar_span_desc_then_name`

## What this means exactly

The packet is not inventing a third showcase by taste.

It is simply extracting the next lawful focused case from the already frozen
top-`3` reserve behind `NGC1313` and `NGC2541`.

## Why this is useful

This gives one narrower current gain:

- the top-`3` reserve is no longer partly tabular
- it is now fully reader-visible as three named focused cases

## What this still does not mean

This still does **not** mean:

- one theory-side promotion has begun
- one fairness-grade differential lane has begun
- or one full named-case chain has already closed
