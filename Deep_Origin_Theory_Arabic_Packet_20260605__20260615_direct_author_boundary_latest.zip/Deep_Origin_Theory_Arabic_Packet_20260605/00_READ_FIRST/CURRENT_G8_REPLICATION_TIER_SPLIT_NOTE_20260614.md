# Current `G8` Replication Tier Split Note

Date: `2026-06-14`

Purpose:

Freeze one exact replication-tier grammar so the packet does not overclaim
what cold reruns do and do not establish.

## Short verdict

The current replication ladder should now be read in tiers:

- `Tier 1`: cold-audit accessibility / usability rerun
- `Tier 2`: technical reproducibility rerun
- `Tier 3`: bounded scientific replication read
- `Tier 4`: formal review / broader outside scientific uptake

## Exact current value of each tier

### Tier 1

What counts:

- unzip packet
- run one declared audit command
- report `all_checks_pass`, platform, and output folder or log

What it proves:

- packet accessibility
- portability
- non-brittle execution

What it does **not** prove:

- scientific fairness
- lawful comparator choice
- physical interpretation

### Tier 2

What counts:

- technical rerun by one independent technical reader
- hash checks
- script reruns
- output equality or bounded numeric agreement

What it proves:

- technical reproducibility

### Tier 3

What counts:

- one scientifically literate bounded read on a narrow question such as
  same-nuisance fairness, claim boundary, or comparator lawfulness

What it begins:

- scientific replication at bounded scope

### Tier 4

What counts:

- formal review cycle
- materially broader outside uptake

## Exact current packet reading

Many friends running one cold audit can be genuinely useful.

That wave should be named:

- `cold-audit accessibility wave`

It should **not** be named:

- `scientific independent replication`

## Governing consequence

`Tier 1` and `Tier 2` strengthen the packet and can be banked honestly.

But `G8` itself remains open until one materially independent broader wave
 above those lower rungs actually lands.
