# Focus Selection Rationale

Date: `2026-06-13`

`LVHIS011` is not selected rhetorically.

It is selected because the already frozen clean-first shortlist places it at
rank `7` under the packet-local rule:

- `rows_desc_then_gbar_span_desc_then_name`

## What this means exactly

The packet is not inventing a seventh showcase by taste.

It is simply extracting the next lawful focused case after the already
materialized named front-`6`.

## Why this is useful

This gives one narrower current gain:

- the visible named head is no longer only six cases deep
- it now reaches a seventh named case
- it pushes the named head to `159` of `184` clean-first rows

## What this still does not mean

This still does **not** mean:

- one theory-side promotion has begun
- one fairness-grade differential lane has begun
- or one full named-case chain has already closed
