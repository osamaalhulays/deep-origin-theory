# External Provenance Reply — Liliya L.R. Williams — `A370` System-31 And Supplementary Authority

Date: `2026-06-14`

Status: `outside provenance-side clarification digested with bounded packet consequence`

## Purpose

Digest one outside provenance-side author reply into exact packet-useful
consequences without laundering it into one new scientific result, one new
data product, or one endorsement.

This note does **not** claim:

- one new `A370` north closure,
- one new strong-lensing reconstruction,
- one new packet-owned public numeric surface,
- or endorsement of `QCT`.

It claims something narrower and useful:

- one outside author-side clarification now sharply constrains what the
  Williams/Ghosh `A370` public surface is,
- and what it is not.

## Short digest

The mailbox reply gives five usable points:

1. they did **not** use anything called `system 31` in their `A370` work,
2. they used no unpublished data there,
3. the material used came from cited papers,
4. the supplementary material is the relevant public image-system surface for
   that work,
5. the thread included the attachment `BUFFALO_A370_SLimages 2.txt`,
6. that attachment is now mirrored locally at
   `00_READ_FIRST/EXTERNAL_SOURCE_MIRRORS/LILIYA_WILLIAMS_A370_20260419/BUFFALO_A370_SLimages 2.txt`,
7. the mirrored table itself visibly carries `29.*` and `30.*` rows but no
   `31.*` row.

## What this strengthens

This clarification strengthens the packet in three exact ways:

1. it blocks treating `system 31` as one Williams/Ghosh authority label for
   `A370`,
2. it sharpens the packet's provenance grammar for the `A370` lensing lane,
3. it reduces one real public-source ambiguity without inventing one new
   packet-native data product.

## What this does **not** do

This clarification does **not** do any of the following:

- prove one new lensing result,
- create one new north-side closure,
- turn the mail reply into one public theorem,
- or silently convert the thread attachment into one packet-native mirrored
  asset.

## Exact operational consequence

When the packet refers to the Williams/Ghosh `A370` lane, the outward-safe
reading should now remain:

- cited papers plus supplementary material = the lawful public surface for
  that line,
- `system 31` = not one Williams/Ghosh system label on that line,
- anything stronger requires some other public artifact or one later lawful
  local mirror.

## Local mirror status

The mailbox thread included `BUFFALO_A370_SLimages 2.txt`.

That attachment is now mirrored explicitly inside this packet tree at:

- `00_READ_FIRST/EXTERNAL_SOURCE_MIRRORS/LILIYA_WILLIAMS_A370_20260419/BUFFALO_A370_SLimages 2.txt`

So the present packet now carries both:

- the bounded prose consequence of the reply,
- and one explicit local mirror of the attached supplementary table.

The mirror should still be read as one provenance/support surface, not as one
new packet-owned scientific result.

## Routing

Primary support:

- `A370` provenance clarification lane,
- external engagement calibration,
- lineage / attribution discipline.

Secondary support:

- cold-reader source discipline,
- under-attribution prevention,
- and prevention of false authority-token reuse around `system 31`.

## Bottom line

This is one real outside provenance clarification win.

It does **not** create one new scientific closure.

It does remove one real `A370` source-identity ambiguity, and it now carries
both the author-side clarification and the attached supplementary table as
explicit mirrored support surfaces.
