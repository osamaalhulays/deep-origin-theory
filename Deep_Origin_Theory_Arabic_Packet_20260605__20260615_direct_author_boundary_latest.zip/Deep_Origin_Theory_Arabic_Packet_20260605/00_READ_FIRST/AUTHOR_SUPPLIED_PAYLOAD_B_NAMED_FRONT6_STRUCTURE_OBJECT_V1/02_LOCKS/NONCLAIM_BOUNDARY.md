# Nonclaim Boundary

Date: `2026-06-13`

This object is a named-front structure object only.

It is lawful to say:

- one named front of `6` clean-first cases now exists
- that front currently carries `147` of `184` clean-first rows
- the remaining clean-first tail still contains `5` galaxies and `37` rows

It is **not** lawful to say from this object alone:

- one theory-side lane is now solved
- one `QCT` prediction family has landed for the front
- one `QUMOND` fairness comparison has been executed for the front
- one differential superiority verdict has been earned
- or one whole-bank closure has been achieved
