# Current `G4` External `Form D` First-Crossing Engine Note

Date: `2026-06-11`

Purpose:

Record the exact effect of the newly supplied `G4` first-crossing engine
without inflating it into true observed crossing or downstream closure that it
has not yet earned.

## Short verdict

The route now has:

- one real fresh external `Form D` engine in hand,
- above the already-admitted external `Form C` path.

This is a real gain.

The earlier package-runtime defect is now closed in the mirrored intake:

- `requirements.txt` is shipped,
- the install path is explicit,
- and the toy self-test passes in a clean Python `3.14` environment after
  dependency install.

So the clean current read is now:

- real `Form D` engine present,
- clean `Form D` admission flipped.

## What this does and does not change

It does change the route from:

- no stronger fresh `Form D` object in hand

to:

- one concrete stronger clean-admitted `Form D` engine now exists.

It does **not** yet count as:

- same-route crossing,
- true `D3` opening,
- `D4`,
- `D5`,
- fired typed `U2`,
- or `G6` payload arrival.

## Exact next move

Two lawful choices now exist:

- run the admitted engine on one authoritative non-toy execution-input
  triple,
- or continue on the already-admitted `Form C` path as the lower bounded
  route if the same triple is supplied there first.

## Sovereign execution read

The admitted `Form D` engine should now be read under one sharper
execution discipline:

- no more local replay hunting for hidden `Form A/B/C/D`,
- no template-only escalation into crossing language,
- no soft widening by naming alone,
- and no tuning loop after outputs are seen.

The daily route is now simply:

`freeze -> run -> adjudicate`

with the production triple:

- one authoritative source profile,
- one author-frozen `m_inv`,
- one frozen benchmark-bin roster.

## What this still does not create

One later external freeze / run / adjudicate harness may sit above this
engine as one cleaner execution shell.

But that combined stack still does **not** create one third live `G4`
scientific candidate.

The live locally materialized monotone-ready candidate pairs remain only:

- `NGC1705`
- `NGC4214`

Any future non-monotone branch/fiber route remains reserved only and is not
live in the current `V1` execution state.

## Bottom line

The route has climbed.

What is missing now is no longer engine imagination or package hardening.

It is completion of authoritative production input freeze.

More sharply on the current local route:

- the source-profile / benchmark-bin pair is now already author-frozen on
  `NGC4214`,
- and the remaining local production tooth is one author-frozen `m_inv`.
