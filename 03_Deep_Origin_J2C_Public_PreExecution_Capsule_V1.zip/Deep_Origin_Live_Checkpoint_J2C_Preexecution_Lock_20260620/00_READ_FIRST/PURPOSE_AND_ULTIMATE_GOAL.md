# Purpose And Ultimate Goal

The ultimate goal is not to win a single galaxy case or to publish a larger
packet. The goal is to complete Deep Origin Theory as one source-governed,
variational, cosmologically closed theory of spacetime and dark matter.

Target chain:

```text
spacetime and matter
-> galactic gravity and lensing
-> clusters
-> H(z), growth, BAO, CMB
-> strong field and the GR limit
```

The theory must survive without per-system patching, post-hoc fitting, or
fit-derived rescue parameters.

Hard rules:

```text
source-governed
materially non-null
declared before data
no fit-derived rescue
no direct observable handle
publish failure as honestly as success
```

`QCT` is a route inside the wider Deep Origin program, not a separate end in
itself.

This checkpoint freezes the next lawful theory-side question before execution:

```text
Can a same-action cosmological scalar background change the physical
mass/radius scaling of the total Jordan-frame acceleration, or does it only
change amplitudes, effective couplings, and transition scales?
```
