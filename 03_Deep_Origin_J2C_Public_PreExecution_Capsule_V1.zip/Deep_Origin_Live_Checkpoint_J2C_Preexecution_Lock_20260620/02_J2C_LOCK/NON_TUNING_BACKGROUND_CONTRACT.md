# Non-Tuning Background Contract

Contract status:

```text
J2C_EXECUTION_CONTRACT_LOCKED__NO_BACKGROUND_AS_M_INV
```

The following quantities are not admissible fit parameters:

```text
H(t)
phi_bar(t)
dot(phi_bar)(t)
X_bar(t)
```

They must be derived from the declared `J2` structural action class and frozen
before any local source or galaxy is evaluated. An exact finite `K_can(X),
G3(X)` representative must be frozen before any predictive branch verdict.

Reject the branch if any of them is:

- selected per galaxy,
- selected from rotation residuals,
- selected after seeing a target failure,
- allowed to vary like hidden `m_inv`,
- replaced by an arbitrary local scale,
- widened into free `G3(phi, X)` or free `K(X)` without a separate gate.

This contract is a pre-execution judge. It does not claim `J2C` success or
failure.
