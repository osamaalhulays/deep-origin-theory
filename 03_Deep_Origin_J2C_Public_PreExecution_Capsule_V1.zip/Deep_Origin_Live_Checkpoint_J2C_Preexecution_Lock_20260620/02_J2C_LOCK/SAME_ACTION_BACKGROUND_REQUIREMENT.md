# Structural Action-Class Background Requirement

Before any local source calculation, derive and freeze:

- structural-action-class Friedmann equations,
- structural-action-class scalar background equation,
- exact finite action representative before predictive branch verdict,
- branch selector before local-source evaluation if several branches are lawful,
- `H(t)`,
- `phi_bar(t)`,
- `dot(phi_bar)(t)`,
- `X_bar(t)`,
- effective Planck mass,
- scalar kinetic/stability coefficients,
- cosmological branch or freeze rule.

Forbidden:

- `phi_dot` selected per galaxy,
- `X_bar` selected after seeing a failed target,
- background fitted to rotation residuals,
- background branch changed between targets without a cosmological rule,
- background used as a hidden `m_inv`.

If this requirement is not met, the allowed verdict is:

```text
J2C_PHYSICAL_METRIC_COMPLETION_INCOMPLETE
__NO_BRANCH_VERDICT
```

If the exact finite action representative is not frozen before solving, the
allowed verdict is:

```text
J2C_ACTION_REPRESENTATIVE_NOT_FROZEN
__NO_PREDICTIVE_ADMISSION
```

If several lawful background branches remain without a theory-side selector,
the allowed verdict is:

```text
J2C_BACKGROUND_BRANCH_UNDERDETERMINED
__NO_PREDICTIVE_ADMISSION
```

If the background must be data-tuned, the allowed verdict is:

```text
J2C_REQUIRES_DATA_TUNED_BACKGROUND
__REJECT
```
