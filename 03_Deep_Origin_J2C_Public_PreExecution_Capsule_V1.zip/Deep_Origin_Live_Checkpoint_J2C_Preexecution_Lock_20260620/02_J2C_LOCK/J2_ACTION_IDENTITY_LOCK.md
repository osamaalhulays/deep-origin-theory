# J2 Structural Action-Class Identity Lock

The locked parent corridor is the luminal kinetic-braiding scalar-metric
structural action class:

```text
S_J2 =
int d^4x sqrt(-g) [
  (M_P^2 / 2) F(phi) R
  + K_can(X)
  - G3(X) Box(phi)
  - M_P^2 Lambda_J
] + S_m[g, psi]

F(phi) = exp(-2 beta phi)
K_can(X) = canonical normalization still requiring exact representative freeze
G4_X = 0
G5 = 0
```

This capsule does not claim that a unique exact finite `K_can(X), G3(X)`
representative has already been frozen. Before any predictive `J2C` branch
verdict, a later execution must freeze:

- explicit `K_can(X)` normalization,
- exact finite `G3(X)` representative or finite family,
- coefficient domains, units, and field normalization,
- branch-selection rule,
- stable hash of the action representative.

If that representative is not frozen before solving, the lawful verdict is:

```text
J2C_ACTION_REPRESENTATIVE_NOT_FROZEN__NO_PREDICTIVE_ADMISSION
```

This checkpoint does not open:

- arbitrary `G3(phi, X)`,
- free `K(X)` co-design,
- vector completion,
- disformal matter metric,
- galaxy-specific branch selection,
- residual-derived scale selection.

The purpose is to test whether a class-consistent cosmological background,
after exact representative freezing, can change the isolated exterior
deep-acceleration asymptotic scaling of total physical acceleration.
