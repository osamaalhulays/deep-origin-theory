# Physical-Metric Completion Contract

`J2C` cannot be judged from scalar-gradient scaling alone.

The local system must derive the Jordan-frame potentials after scalar-metric
diagonalization:

```text
Psi_J
Phi_J
Phi_lens = (Psi_J + Phi_J) / 2
g_total_Jordan = -partial_r Psi_J
```

The following channels must be separated:

```text
direct_conformal_channel
braiding_induced_metric_channel
scalar_stress_channel
total_jordan_frame_acceleration
lensing_potential
```

No assumption of:

```text
g_extra proportional to pi_prime
```

is allowed before diagonalization.

The deep target for the total extra physical acceleration is:

```text
g_extra proportional to sqrt(M_b) / r
```
