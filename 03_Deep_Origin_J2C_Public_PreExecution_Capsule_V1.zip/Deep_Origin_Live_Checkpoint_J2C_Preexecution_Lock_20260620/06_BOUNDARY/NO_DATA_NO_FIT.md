# No Data, No Fit

This checkpoint ingests no galaxy rows and uses no fit during `J2C` execution.
The branch design is development-informed by prior public results such as the
`NGC1003` negative result and response-activity atlas; that is not the same as
using galaxy rows inside the `J2C` execution.

Forbidden in this pre-execution lock:

- `NGC1003` tuning,
- SPARC fit,
- kill-suite fit,
- residual-derived background,
- target-specific `phi_dot`,
- target-specific `X_bar`,
- free post-failure function choice.

The future `J2C` derivation must be evaluated by the locked verdict grammar,
not by a post-hoc fit improvement.
