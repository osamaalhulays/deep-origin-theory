# Publication Commitment

The future `J2C` result must be published regardless of outcome.

If the first execution contains a bug, the result must not be silently edited.
The correct handling is:

```text
invalidated or superseded run declared
bug ledger published
corrected run released with a new hash
```

The result release must include:

- pre-lock hash,
- result hash,
- exact verdict,
- derivation outputs,
- diff against this pre-execution lock,
- bug ledger if needed.
