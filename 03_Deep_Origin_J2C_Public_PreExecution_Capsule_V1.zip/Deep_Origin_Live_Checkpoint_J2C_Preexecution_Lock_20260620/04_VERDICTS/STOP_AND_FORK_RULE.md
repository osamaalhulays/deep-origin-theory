# Stop And Fork Rule

After `J2C`, no silent middle branch is allowed.

```text
J2C scaling succeeds + lensing + stability pass
-> freeze exact finite family before kill suite

J2C scaling succeeds but lensing fails
-> disformal/vector decision

J2C scaling fails only
-> J2B nonlinear-K/braiding finite-family decision

J2C stability or cosmology fails
-> retire J2 local branch

J2C physical metric incomplete
-> no branch verdict, not success
```

Forbidden before the public `J2C` verdict:

- `J2B`,
- vector completion,
- disformal completion,
- kill-suite fit,
- SPARC fit,
- MOND/QUMOND live challenge,
- new free function,
- galaxy-specific background rescue.
