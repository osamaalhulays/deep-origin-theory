# Allowed Verdicts

The verdict grammar is frozen before execution.

Primary scaling verdicts:

```text
J2C_BACKGROUND_ASSISTED_TOTAL_SCALING_ADMITTED
__LENSING_STABILITY_GATE_NEXT

J2C_BACKGROUND_COEFFICIENTS_ONLY
__TOTAL_PHYSICAL_ACCELERATION_SCALING_NO_GO

J2C_REQUIRES_DATA_TUNED_BACKGROUND
__REJECT

J2C_ACTION_REPRESENTATIVE_NOT_FROZEN
__NO_PREDICTIVE_ADMISSION

J2C_BACKGROUND_BRANCH_UNDERDETERMINED
__NO_PREDICTIVE_ADMISSION

J2C_PHYSICAL_METRIC_COMPLETION_INCOMPLETE
__NO_BRANCH_VERDICT
```

Verdict precedence:

1. data-tuned background reject,
2. exact action representative not frozen,
3. underdetermined background branch,
4. incomplete physical-metric derivation,
5. stability or hyperbolicity failure,
6. scaling verdict,
7. lensing verdict.

Secondary route verdicts:

```text
J2C_COSMOLOGICAL_GRADIENT_SCALE_NO_GO

J2C_REQUIRES_SINGULAR_G3_BACKGROUND_JET
__REJECT

J2C_DYNAMICS_WITHOUT_LENSING_NO_GO
__DISFORMAL_OR_VECTOR_DECISION_NEXT

J2C_STABILITY_NO_GO

J2C_COSMOLOGY_LOCAL_BRANCH_INCOMPATIBLE
```

No new success definition may be added after execution begins.
