# J2C Exponent-Adjudication Rules

The target

```text
g_extra proportional to sqrt(M_b) / r
```

is an isolated, exterior, deep-acceleration asymptotic benchmark. It is not a
claim about every finite radius inside a disk galaxy.

Rules:

1. Extract exponents only after full Jordan-frame physical-metric completion.
2. Use the dominant term in the declared deep exterior asymptotic regime.
3. Record logarithmic factors separately; do not silently turn them into power
   exponents.
4. If competing terms remain tied and no branch selector is frozen, use
   `J2C_BACKGROUND_BRANCH_UNDERDETERMINED__NO_PREDICTIVE_ADMISSION`.
5. If the MOND-like pair appears only in a crossover shell, do not call it an
   asymptotic admission.
6. Require symbolic equality of the powers unless a tolerance contract is
   frozen before execution.

