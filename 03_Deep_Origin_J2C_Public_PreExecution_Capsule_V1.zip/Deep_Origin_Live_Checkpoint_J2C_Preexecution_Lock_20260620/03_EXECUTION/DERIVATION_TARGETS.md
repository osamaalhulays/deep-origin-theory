# Derivation Targets

The `J2C` execution must materialize:

1. Structural-action-class cosmological background equations.
2. Exact finite action representative before predictive branch verdict.
3. Frozen background branch or freeze rule.
4. Local perturbation system around:

```text
phi(t, r) = phi_bar(t) + pi(t, r)
X = X_bar + delta X
```

5. Full physical-metric diagonalization.
6. Separate acceleration-channel expressions.
7. Dominant radial-current balance:

```text
sum_p c_p(t) y^p = C(t) M_b / r^3
```

8. Exponent table for every required channel.
9. Isolated exterior deep-acceleration asymptotic adjudication against:

```text
g_extra proportional to sqrt(M_b) / r
```

10. Lensing identity check from the same Jordan metric.
11. Stability, hyperbolicity, `c_T = 1`, high-acceleration, and strong-coupling
   checks.

No galaxy data, no `NGC1003` tuning, and no kill-suite fit are allowed before
these analytic targets are materialized.
