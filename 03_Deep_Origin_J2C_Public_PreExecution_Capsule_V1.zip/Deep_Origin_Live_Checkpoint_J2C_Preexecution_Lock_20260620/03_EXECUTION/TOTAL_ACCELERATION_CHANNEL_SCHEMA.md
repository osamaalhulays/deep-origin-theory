# Total Acceleration Channel Schema

For each channel, record:

```text
channel
dominant_radial_current_power_p
output_power_q_a
explicit_radius_power_s_a
mass_exponent_q_over_p
radius_exponent_s_minus_3q_over_p
mond_mass_match
mond_radius_match
simultaneous_mond_pair_match
allowed_verdict_if_failed
```

Required channels:

```text
direct_conformal_channel
braiding_induced_metric_channel
scalar_stress_channel
total_jordan_frame_acceleration
lensing_potential
```

If:

```text
sum_p c_p(t) y^p = C(t) M_b / r^3
g_a proportional to r^(s_a) y^(q_a)
```

then dominant power `p` gives:

```text
mass exponent   = q_a / p
radius exponent = s_a - 3 q_a / p
```

The MOND-like deep target is:

```text
mass exponent = 1/2
radius exponent = -1
```

If the same-action background changes only `c_p(t)`, `C(t)`, `G_eff(t)`, or
transition scales while preserving radial operator powers, it cannot change
these exponents.
