# Reproduction Environment

This capsule is a pre-execution lock. It does not require a solver or external
data.

Minimum checks:

```text
shasum -c 05_INTEGRITY/SHA256SUMS.txt
python3 -m json.tool 05_INTEGRITY/PREEXECUTION_STATUS.json
```

Expected state:

```text
PUBLIC_PREEXECUTION_LOCK
j2c_result_known = false
galaxy_data_used = false
fit_used = false
result_will_be_published_regardless_of_outcome = true
```

The future `J2C_RESULT_RELEASE_V1` must cite the hash of this checkpoint and
publish the result whether it is success, failure, or no-branch-verdict.
