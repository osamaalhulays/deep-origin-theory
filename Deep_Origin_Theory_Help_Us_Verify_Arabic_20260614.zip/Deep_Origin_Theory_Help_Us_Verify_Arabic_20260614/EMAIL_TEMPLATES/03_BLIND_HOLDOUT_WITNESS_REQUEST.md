Subject: طلب شاهد timestamp للـ blind holdout

Dear [Name],

We are preparing a blind-holdout test. I am not asking you to evaluate the
theory.

I only need an independent witness that certain files existed before
unblinding:

- `TARGET_LOCK.json`
- `PREDICTION_LOCK.json`
- `COMPARATOR_PROTOCOL_LOCKED.json`

If you are willing, I will send you the lock files and hashes. Please keep
them or timestamp them. After unblinding, I may ask you to confirm that the
same locked objects were used.

This is only a pre-registration integrity check, not an endorsement.

Thank you very much,
Osama
