Subject: طلب نصيحة خاصة حول تصنيف arXiv / endorsement

Dear [Name],

I am preparing an arXiv submission and would value private advice on category
fit.

If you are already qualified and independently comfortable under arXiv's own
endorsement system, I would also appreciate guidance on whether endorsement
would be appropriate. There is no expectation, no pressure, and no quid pro
quo. Please do not endorse unless you are confident the submission is suitable
for the category.

A short reply is completely fine.

Thank you very much,
Osama
