---
name: تقرير audit بارد
about: أبلغ عن تشغيل REVIEWER_AUDIT_BUNDLE_V1/RUN_AUDIT_ALL.sh
labels: cold-audit, reproducibility
---

## الحزمة

- Packet filename:
- Packet SHA256, if known:

## البيئة

- OS:
- Python version:
- Shell:

## الأمر

```bash
bash REVIEWER_AUDIT_BUNDLE_V1/RUN_AUDIT_ALL.sh
```

## النتيجة

- Completed? yes/no
- Final `all_checks_pass`:
- Runtime:

## المرفقات

يرجى إرفاق log الطرفية أو مجلد المخرجات إن أمكن.
