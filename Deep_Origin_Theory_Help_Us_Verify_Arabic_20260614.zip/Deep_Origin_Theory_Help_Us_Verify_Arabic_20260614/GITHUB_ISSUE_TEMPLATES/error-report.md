---
name: بلاغ خطأ
about: أبلغ عن مشكلة واحدة محددة
labels: bug
---

## الملف / الجسم

## الأمر المستخدم

```bash

```

## المتوقع

## المشاهد

## log / screenshot

## هل يمكن إعادة إنتاجه؟

- [ ] yes
- [ ] no
- [ ] not sure
*** Delete File: /Users/imac/Desktop/الادابتور/Deep_Origin_Theory_Help_Us_Verify_Arabic_20260614/README_AR.md
