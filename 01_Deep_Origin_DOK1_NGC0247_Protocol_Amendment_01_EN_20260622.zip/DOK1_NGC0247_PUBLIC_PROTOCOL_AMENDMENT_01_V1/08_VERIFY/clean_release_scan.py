#!/usr/bin/env python3
import pathlib
import sys

root = pathlib.Path(__file__).resolve().parents[1]
bad = []
LOCAL_PATH_MARKERS = [b"/" + b"Users/", b"file" + b"://", b"C:" + b"\\Users\\"]
for p in root.rglob("*"):
    if p.is_file():
        rel = p.relative_to(root).as_posix()
        data = p.read_bytes()
        if any(x in rel for x in ["__MACOSX", ".DS_Store", "__pycache__"]) or rel.endswith(".pyc"):
            bad.append(rel)
        if any(marker in data for marker in LOCAL_PATH_MARKERS):
            bad.append(rel)
if bad:
    print("FAILED")
    print("\n".join(sorted(set(bad))))
    sys.exit(1)
print("CLEAN_RELEASE_SCAN_PASS")
