#!/usr/bin/env python3
import csv
import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]

REQUIRED = [
    "00_READ_FIRST/READ_FIRST_EN.md",
    "00_READ_FIRST/READ_FIRST_AR.md",
    "01_LINEAGE/ORIGINAL_ZENODO_RECORD.json",
    "01_LINEAGE/ORIGINAL_GIT_COMMIT_TAG.json",
    "01_LINEAGE/AMENDMENT_REASON.md",
    "01_LINEAGE/ORIGINAL_TO_AMENDMENT_DIFF.md",
    "02_MODEL_ROSTER/COMPARATOR_ROSTER_LOCK.json",
    "02_MODEL_ROSTER/SAME_MU_AQUAL_CONTRACT.md",
    "02_MODEL_ROSTER/SAME_MU_QUMOND_CONTRACT.md",
    "02_MODEL_ROSTER/FIXED_QUMOND_REFERENCE_BOUNDARY.md",
    "02_MODEL_ROSTER/NEWTONIAN_CONTROL_CONTRACT.md",
    "03_GLOBAL_POLICIES/I0_QBAR_POLICY_LOCK.json",
    "03_GLOBAL_POLICIES/EFE_POLICY_LOCK.json",
    "03_GLOBAL_POLICIES/NUISANCE_ROSTER_LOCK.csv",
    "03_GLOBAL_POLICIES/TARGET_RADIUS_ROSTER_LOCK.csv",
    "03_GLOBAL_POLICIES/G1_FIREWALL.md",
    "04_OBSERVABLES/OBSERVABLE_OBJECT_TAXONOMY.md",
    "04_OBSERVABLES/EXACT_OBSERVABLE_FORMULAS.json",
    "04_OBSERVABLES/SIGN_CLASSIFICATION_POLICY.json",
    "05_ADJUDICATION/PRIMARY_LEXICOGRAPHIC_TOPOLOGY_ENDPOINT.md",
    "05_ADJUDICATION/SECONDARY_NUMERICAL_ENDPOINTS.md",
    "05_ADJUDICATION/FINAL_VERDICT_GRAMMAR.json",
    "05_ADJUDICATION/VERDICT_PRECEDENCE.md",
    "06_NONCLAIMS/DEVELOPMENT_EXPOSURE_DISCLOSURE.md",
    "06_NONCLAIMS/MOND_FAMILY_NONCLAIM.md",
    "06_NONCLAIMS/NO_RESULT_KNOWN_RECEIPT.json",
    "06_NONCLAIMS/NO_SOLVER_NO_PREDICTIONS_RECEIPT.json",
    "07_PUBLICATION_PREP/ZENODO_METADATA_DRAFT.json",
    "07_PUBLICATION_PREP/GITHUB_RELEASE_NOTES_DRAFT.md",
    "07_PUBLICATION_PREP/PUBLICATION_COMMITMENT.md",
]

FORMULAS = {
    "DELTA_TRUE": "DELTA_TRUE_i = log10(g_obs_i) - log10(g_bar_G0_i)",
    "DELTA_MODEL": "DELTA_MODEL_i(model) = log10(g_model_i) - log10(g_bar_G0_i)",
    "R_OM": "R_OM_i(model) = DELTA_TRUE_i - DELTA_MODEL_i(model)",
    "R_MO": "R_MO_i(model) = DELTA_MODEL_i(model) - DELTA_TRUE_i",
    "SIGN_SEQUENCE": "SIGN_SEQUENCE(DELTA)_i = sign_layer(DELTA_i, sigma_i, layer)",
    "TRANSITION_SET": "TRANSITION_SET = {R_i to R_{i+1}: SIGN_SEQUENCE_i != SIGN_SEQUENCE_{i+1} and neither state is indeterminate}",
    "CONTIGUOUS_SIGN_RUNS": "CONTIGUOUS_SIGN_RUNS = maximal contiguous index intervals with identical non-indeterminate sign state",
    "NUMERICAL_FIT_RESIDUALS": "FIT_RESIDUAL_i(model) = V_obs_i - V_model_i, secondary-only, never governing topology",
}

def load_json(rel):
    with open(ROOT / rel, "r", encoding="utf-8") as f:
        return json.load(f)

def fail(msg):
    print(json.dumps({"all_checks_pass": False, "error": msg}, indent=2))
    sys.exit(1)

for rel in REQUIRED:
    if not (ROOT / rel).exists():
        fail(f"missing required file: {rel}")

roster = load_json("02_MODEL_ROSTER/COMPARATOR_ROSTER_LOCK.json")
lanes = {lane["lane_id"]: lane for lane in roster["lanes"]}
if set(lanes) != {"C0", "C1", "C2", "C3", "C4"}:
    fail("comparator roster must contain exactly C0-C4")
if lanes["C4"]["status"] != "SENSITIVITY_ONLY_NOT_GOVERNING":
    fail("EFE lane must be sensitivity-only unless independent authority is frozen")

i0 = load_json("03_GLOBAL_POLICIES/I0_QBAR_POLICY_LOCK.json")
if i0["both_modes_selectable"] is not False:
    fail("more than one I0 mode is selectable")
if i0["selected_mode"] != "PREDECLARED_COSMOLOGY_ONLY_DOMAIN_WITH_WHOLE_DOMAIN_ROBUST_ADJUDICATION":
    fail("unexpected I0 mode")
if i0["galaxy_data_used_to_select_I0"] or i0["I0_is_rowwise"] or i0["I0_is_galaxy_specific"]:
    fail("I0 policy is not globally frozen")

efe = load_json("03_GLOBAL_POLICIES/EFE_POLICY_LOCK.json")
if efe["governing_EFE_lane_admitted"]:
    fail("governing EFE lane cannot be admitted without independent authority")

with open(ROOT / "03_GLOBAL_POLICIES/NUISANCE_ROSTER_LOCK.csv", newline="", encoding="utf-8") as f:
    nuisance_rows = list(csv.DictReader(f))
if len(nuisance_rows) != 1:
    fail("nuisance roster must be one exact finite governing baseline here")
if nuisance_rows[0]["governing_or_sensitivity"] != "governing":
    fail("baseline nuisance roster must be governing")

with open(ROOT / "03_GLOBAL_POLICIES/TARGET_RADIUS_ROSTER_LOCK.csv", newline="", encoding="utf-8") as f:
    radius_rows = list(csv.DictReader(f))
if len(radius_rows) != 26:
    fail("target-radius roster must contain the 26 frozen source-side radii")

formula_doc = load_json("04_OBSERVABLES/EXACT_OBSERVABLE_FORMULAS.json")
seen = {}
for row in formula_doc["formulas"]:
    seen[row["id"]] = row
for key, value in FORMULAS.items():
    if key not in seen:
        fail(f"missing formula {key}")
    if seen[key]["formula"] != value:
        fail(f"formula text mismatch for {key}")
    if hashlib.sha256(value.encode()).hexdigest() != seen[key]["sha256"]:
        fail(f"formula hash mismatch for {key}")

sign = load_json("04_OBSERVABLES/SIGN_CLASSIFICATION_POLICY.json")
if [x["layer"] for x in sign["layers"]] != ["S0", "S1", "S2"]:
    fail("sign layers must be S0/S1/S2")

verdicts = load_json("05_ADJUDICATION/FINAL_VERDICT_GRAMMAR.json")
if verdicts["no_result_known"] is not True:
    fail("result must remain unknown")

receipt = load_json("06_NONCLAIMS/NO_SOLVER_NO_PREDICTIONS_RECEIPT.json")
for key in ["DO_K1_solver_executed", "AQUAL_solver_executed", "QUMOND_solver_executed", "prediction_rows_emitted", "observed_rows_embedded", "fit_executed"]:
    if receipt[key] is not False:
        fail(f"forbidden execution flag set: {key}")

LOCAL_PATH_MARKERS = [b"/" + b"Users/", b"file" + b"://", b"C:" + b"\\Users\\"]

for p in ROOT.rglob("*"):
    if p.is_file():
        rel = p.relative_to(ROOT).as_posix()
        if "__MACOSX" in rel or ".DS_Store" in rel or "__pycache__" in rel or rel.endswith(".pyc"):
            fail(f"system artifact leaked: {rel}")
        text = p.read_bytes()
        if any(marker in text for marker in LOCAL_PATH_MARKERS):
            fail(f"local path leaked: {rel}")
        lowered = rel.lower()
        if "prediction_row" in lowered or "solver_output" in lowered:
            fail(f"prediction or solver output file leaked: {rel}")

print(json.dumps({
    "all_checks_pass": True,
    "verdict": "DOK1_NGC0247_PUBLIC_PROTOCOL_AMENDMENT_READY__COMPARATOR_AND_ADJUDICATION_LOCK_COMPLETE__NO_SOLVER_RUN__NO_PREDICTION_ROWS__NO_RESULT_KNOWN",
    "comparator_lanes": sorted(lanes),
    "i0_policy": i0["selected_mode"],
    "efe_policy": efe["EFE_status"],
    "nuisance_rows": len(nuisance_rows),
    "target_radius_rows": len(radius_rows),
    "stop_line": "READY_FOR_MANUAL_PUBLIC_PROTOCOL_AMENDMENT_BEFORE_PREDICTION_GENERATION"
}, indent=2))
