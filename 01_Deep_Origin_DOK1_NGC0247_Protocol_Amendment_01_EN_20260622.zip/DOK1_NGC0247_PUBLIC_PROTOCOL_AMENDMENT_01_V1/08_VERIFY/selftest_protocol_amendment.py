#!/usr/bin/env python3
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
cmd = [sys.executable, str(root / "08_VERIFY" / "verify_protocol_amendment.py")]
raise SystemExit(subprocess.call(cmd))

