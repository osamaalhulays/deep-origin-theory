# Amendment Reason

The previous milestone correctly stopped with:

```text
DOK1_NGC0247_COMPARATOR_PROTOCOL_INCOMPLETE
__PUBLIC_AMENDMENT_REQUIRED
```

The stop was not a scientific result. The missing item was a public,
pre-prediction comparator and adjudication lock.

This amendment completes the comparator roster, `I0/Qbar` handling, EFE policy,
symmetric nuisance roster, observable taxonomy, topology endpoint, secondary
receipts, verdict precedence, and public development-exposure disclosure.

No solver is run here. No prediction rows are emitted here. No observed-side
rows are opened here.

