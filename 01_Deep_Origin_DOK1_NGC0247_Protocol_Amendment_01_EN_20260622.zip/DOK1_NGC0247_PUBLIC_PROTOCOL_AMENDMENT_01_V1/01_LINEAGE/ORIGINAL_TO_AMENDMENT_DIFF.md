# Original To Amendment Diff

The original public pre-execution lock froze the `DO-K1` local engine and its
global boundary policy before any galaxy execution.

This amendment adds the missing public court layer:

- governing comparator hierarchy `C0/C1/C2/C3/C4`
- exact `I0/Qbar` mode: cosmology-only domain with full-domain robust
  adjudication
- EFE policy: sensitivity-only unless independent authority is frozen before
  prediction generation
- one symmetric nuisance roster
- exact observable definitions and formula hashes
- sign classification layers `S0/S1/S2`
- lexicographic primary topology endpoint
- secondary numerical receipts
- final verdict precedence and forbidden language
- development-exposure disclosure

It does not change the theory, source geometry, public chronology, or challenge
target.

