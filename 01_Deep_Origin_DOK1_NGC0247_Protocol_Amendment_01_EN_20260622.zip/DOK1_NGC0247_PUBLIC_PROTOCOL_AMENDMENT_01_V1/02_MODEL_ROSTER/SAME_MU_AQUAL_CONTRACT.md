# Same-Mu AQUAL Contract

The same-mu AQUAL lane uses exactly:

```text
mu_DO(x) = x / (1 + x^3)^(1/3)
```

It must use the same admitted `G0` baryonic source, same target-radius roster,
same nuisance roster, same numerical accuracy policy, and same lawful boundary
domain as `DO-K1` where mathematically applicable.

Its purpose is to decide whether any future `DO-K1` topology result is really
specific to the `K(Q)/Helmholtz/cosmological-boundary` term, or merely the
ordinary same-mu AQUAL nonlinear geometry.

