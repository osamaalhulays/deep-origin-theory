# Same-Mu QUMOND Contract

The common-source QUMOND lane is constructed from the same `mu_DO` relation:

```text
y = x * mu_DO(x)
nu_DO(y) = x(y) / y
```

The inverse `x(y)` must be deterministic and frozen before prediction rows are
generated. It may not be adjusted from residuals, sign topology, or previous
model performance.

This lane is the governing fair QUMOND geometry control if numerically
admitted. The historical fixed-QUMOND current stack remains a reference lane,
not the governing fair comparator if its source construction differs from `G0`.

