# Newtonian G0 Control Contract

`C0` is the Newtonian baryon-only control using the identical admitted `G0`
source. It exists to verify units, signs, source construction, radius handling,
and boundary conventions.

It is not a `MOND` competitor and must not be used as evidence for or against
`MOND/QUMOND` family status.

