# Fixed QUMOND Reference Boundary

The historical fixed-QUMOND current stack is preserved as:

```text
HISTORICAL_FIXED_QUMOND_CURRENT_STACK_REFERENCE
```

It may support bounded lineage statements, including the previously exposed
fixed-QUMOND pressure witness. It is not the governing fair comparator for the
new `G0` source-only challenge unless its source construction is identical to
the admitted `G0` source.

It may not be used to claim whole-family `MOND/QUMOND` defeat.

