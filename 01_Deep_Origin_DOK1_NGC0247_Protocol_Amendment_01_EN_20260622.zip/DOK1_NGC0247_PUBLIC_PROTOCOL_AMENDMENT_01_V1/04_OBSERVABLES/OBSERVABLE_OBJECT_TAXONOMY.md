# Observable Object Taxonomy

The following objects are distinct and must not be conflated:

- `DELTA_TRUE`: observed baryonic response, defined only after observed-side
  opening.
- `DELTA_MODEL`: model-predicted baryonic response from a frozen source-only
  model prediction.
- `R_OM`: observed-minus-model response residual.
- `R_MO`: model-minus-observed response residual.
- `SIGN_SEQUENCE(DELTA)`: ordered signs of a response object under a declared
  sign layer.
- `TRANSITION_SET`: radial transitions in the sign sequence.
- `CONTIGUOUS_SIGN_RUNS`: maximal same-sign radial runs.
- `NUMERICAL_FIT_RESIDUALS`: secondary numerical residuals only.

The previous fixed-QUMOND residual stack and `sigma_delta_1d_current` diagnostics
are preserved as historical exposed context. They are not the governing
observable objects of this new source-only court.

