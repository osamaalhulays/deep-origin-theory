# DO-K1 / NGC0247 Protocol Amendment 01

This release candidate freezes the comparator roster, `I0/Qbar` policy, EFE
policy, nuisance roster, observable taxonomy, topology endpoint, and verdict
grammar before source-only predictions are generated.

No solver has been run. No prediction rows exist. No current challenge result
is known.

Suggested tag:

```text
dok1-ngc0247-protocol-amendment-01-20260622
```

