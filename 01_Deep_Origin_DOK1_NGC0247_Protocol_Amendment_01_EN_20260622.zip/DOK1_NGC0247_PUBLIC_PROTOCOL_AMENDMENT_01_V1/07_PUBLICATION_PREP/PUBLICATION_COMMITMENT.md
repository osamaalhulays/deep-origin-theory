# Publication Commitment

If this amendment is published manually before prediction generation, the later
source-only prediction lock and exposed-result release must preserve this
protocol and report the result whether it supports `DO-K1`, supports AQUAL,
supports QUMOND, is non-robust, or fails all admitted lanes.

This amendment itself must not be edited after prediction rows are generated.

