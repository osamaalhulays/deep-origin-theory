# Secondary Numerical Endpoints

Secondary endpoints are receipts only:

- chi-square
- log-likelihood
- weighted RMSE
- maximum standardized residual
- radial-band contributions
- covariance-aware likelihood where covariance exists
- leave-one-row-out sensitivity

`AIC/BIC` may be reported as receipts. They do not govern the topology verdict.

