# Primary Lexicographic Topology Endpoint

The primary endpoint is deterministic and lexicographic. No weighted score may
be invented after observed-side opening.

For every model and every frozen `I0/nuisance` point, compare in this order:

1. Maximize rowwise signed-topology agreement count.
2. Minimize signed-transition-count discrepancy.
3. Minimize transition-location discrepancy using the frozen target-radius
   metric.
4. Minimize longest contiguous mismatch run.
5. Minimize total contiguous mismatch count.

Report separately:

- exact sequence match
- positive / negative / indeterminate counts
- inner / middle / outer topology
- transition radii
- topology robustness over `I0`
- topology robustness over nuisances

A model strictly dominates another only if it is better at the first tier where
they differ, the difference exceeds numerical classification uncertainty, and
the domination is robust over the governing `I0/nuisance` policy.

