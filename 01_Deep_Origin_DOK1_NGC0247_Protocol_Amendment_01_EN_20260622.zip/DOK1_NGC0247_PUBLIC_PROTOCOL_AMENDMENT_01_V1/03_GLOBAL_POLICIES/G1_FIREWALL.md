# G1 Firewall

The current primary challenge is `G0` only.

`G1` remains:

```text
NOT_PART_OF_CURRENT_PRIMARY_CHALLENGE
```

No lopsided, multiscale, feathered, or high-resolution morphology sensitivity
lane may become governing in this challenge without a separate pre-prediction
public amendment.

