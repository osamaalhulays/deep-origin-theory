# Deep Origin Research Program Reader Edition v1.0.0

Status: `PREPRINT__NOT_PEER_REVIEWED`

This package is a standalone reader-facing synthesis of the current public
state. It is not a claim of final cosmic closure, not a claim of MOND/QUMOND
family defeat, and not peer-reviewed certification.

Legacy project/repository name: `Deep Origin Theory`.

## Cold Reader Orientation

- A `harvest track` means a route whose validated lessons, negative results,
  tools, and comparator discipline are preserved for reuse, without claiming
  that the route is the current completed theory.
- QCT is a mature major research track under constrained internal
  redevelopment. DO-K1 is a distinct candidate-engine lane inside the broader
  Deep Origin Research Program, not QCT itself and not proof that QCT has been
  discarded.
- J1/J2/J2B/J2C are route-pruning lanes, Keystone is structural-bridge work,
  and dual-time is related mathematics.

## Start Here

1. `01_DEEP_ORIGIN_CURRENT_STATUS_SYNTHESIS_EN.pdf`
2. `02_DEEP_ORIGIN_CURRENT_STATUS_SYNTHESIS_AR.pdf`
3. `05_PUBLIC_QUANTITATIVE_RESULTS_AT_A_GLANCE.md`
4. `03_PUBLIC_CLAIM_EVIDENCE_MATRIX.csv`
5. `04_PUBLIC_RESULTS_AND_NOGO_ATLAS.csv`
6. `06_REPRODUCIBILITY_INDEX.md`
7. `10_READER_DOCUMENTATION.zip` for PDF build-source provenance only.

## What This Package Claims

- Deep Origin is currently a governed research program, not a completed
  predictive theory.
- No unified predictively admitted action is claimed in this reader edition.
- The public DO-K1 vs NGC247 challenge terminated before prediction generation.
- No NGC247 observed-side empirical match was run for DO-K1.
- The J2R representative route reached a bounded coefficient-only scaling
  no-go.

## What This Package Does Not Claim

- No final cosmic closure.
- No full MOND/QUMOND family defeat.
- No peer-review certification.
- No complete cold-replay package for every historical internal result.
- No observational rejection of DO-K1 on NGC247.
- No completed successor action.

## Package Integrity

From this directory:

```bash
shasum -a 256 -c SHA256SUMS.txt
```

Expected result:

```text
all listed files OK
```

## Why Some Results Are Deferred

Some genuine local gains are preserved in:

`11_DEFERRED_LOCAL_RESULTS_LEDGER_NOT_HEADLINE.csv`

They are not used as headline claims because they still need compact public
capsules with exact public locators, fields, checksums, assumptions, and claim
ceilings.
