# Changelog

## reader-edition-v1.0.0

- Converted RC5 into final standalone reader edition wording.
- Removed publication-hold and release-candidate text from reader-facing PDFs.
- Removed headline use of deferred results without compact public locators.
- Regenerated PDFs, manifest, SHA ledger, reader documentation supplement, and outer zip.
