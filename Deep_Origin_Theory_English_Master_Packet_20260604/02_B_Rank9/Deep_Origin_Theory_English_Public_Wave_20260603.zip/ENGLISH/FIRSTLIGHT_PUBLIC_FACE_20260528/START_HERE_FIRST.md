# Firstlight Public Face / Start Here First

This package is the outward cosmology-facing public face of **Deep Origin
Theory**.

It is not the place where cosmology is claimed complete.

## What this package is trying to show

This package is trying to show:

- how the `Firstlight` line is named publicly,
- how it can be surfaced responsibly,
- and how outward visibility is kept separate from unfinished proof and later
  unpublished technical work.

## What is actually claimed here

The public claim here is one of disciplined outward identity:

- the cosmology-facing line is named,
- its visible sequence is stated,
- and its present-tense boundaries are made explicit.

This package is meant to be read as a **public-face package**, not as a final
observational closure package.

## What is explicitly not claimed here

This package does **not** claim:

- completed cosmology,
- final observational closure,
- completed outward scientific legitimacy,
- or a finished `Firstlight III` scientific result.

## Public reading order

Recommended first reading path:

1. `README.md`
2. `PUBLIC_POSITION.md`
3. `CLAIM_BOUNDARY_CARD.md`
4. `FACE_SEQUENCE.md`
5. `TIMESTAMP_GUARD.md`
6. `DEFERRED_WORK_NOTE.md`
7. `SOURCE_LAYER.md`

## What has been intentionally left out of the public package

This public package is meant to foreground the outward face itself.

It is not meant to foreground:

- package-audit records,
- status ledgers,
- or approval-facing mechanics.
