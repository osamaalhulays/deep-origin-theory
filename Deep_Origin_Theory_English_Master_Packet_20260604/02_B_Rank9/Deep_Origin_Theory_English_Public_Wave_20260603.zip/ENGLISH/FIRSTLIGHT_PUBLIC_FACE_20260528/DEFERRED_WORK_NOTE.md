# Firstlight Deferred Work Note

## Work held outside this package

The following are explicitly excluded from this public-face package:

- later transport-bridge development
- unresolved transport-legitimacy work
- unfinished cosmology-facing technical extensions beyond the outward face

## Why this separation is lawful

The current public reading already distinguishes:

- a publishable public face: `Firstlight` as a timestamped outward line
- later unpublished work: transport-facing technical development not yet closed

This package follows that distinction strictly.
