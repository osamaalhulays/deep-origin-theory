# Firstlight Public Face Package

This package is the cosmology-facing public face of the theory, not the place where cosmology is claimed complete.

If you are new to this package, start with:

- `START_HERE_FIRST.md`

## What this package is

It holds the outward public line of **Firstlight** inside **Deep Origin Theory**:

- how the cosmology-facing line is named,
- how it can be spoken about responsibly,
- and how outward visibility is kept separate from final proof.

## What this package is not

It is not a completed cosmology package.

It should be read as a **public-face and timestamped-identity package**, not as the final observational closure.

Source visibility:

- `SOURCE_LAYER.md`
