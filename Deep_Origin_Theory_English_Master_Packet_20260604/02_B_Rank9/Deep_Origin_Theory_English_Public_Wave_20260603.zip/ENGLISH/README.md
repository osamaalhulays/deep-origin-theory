# Deep Origin Theory / English Final Bundles

This wing contains the approved outward-facing English publication bundles for **Deep Origin Theory**.

If you are new to the project, start here first:

- `START_HERE_FIRST.md`

Included bundles:

- `Keystone_I_The_First_Bearing_20260429`
- `Keystone_II_Source_Governed_Framework_20260520`
- `DEEP_ORIGIN_PUBLIC_CORE_20260528`
- `FIRSTLIGHT_PUBLIC_FACE_20260528`
- `AUTHOR_AND_THEORY_FRONTMATTER_20260527`

Source visibility and package-governance map:

- `SOURCE_LAYER_INDEX.md`

Recommended reading order:

1. `START_HERE_FIRST.md`
2. `Keystone_I_The_First_Bearing_20260429`
3. `Keystone_II_Source_Governed_Framework_20260520`
4. `DEEP_ORIGIN_PUBLIC_CORE_20260528`
5. `FIRSTLIGHT_PUBLIC_FACE_20260528`
6. `AUTHOR_AND_THEORY_FRONTMATTER_20260527`
7. `SOURCE_LAYER_INDEX.md`
