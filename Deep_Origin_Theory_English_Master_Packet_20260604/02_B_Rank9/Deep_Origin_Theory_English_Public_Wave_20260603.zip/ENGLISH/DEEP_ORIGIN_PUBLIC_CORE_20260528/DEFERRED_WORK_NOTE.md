# Deep Origin Deferred Work Note

## Work held outside this package

The following are explicitly excluded from this public-core package:

- `Deep Origin IV: The Hidden Mass`
- hidden-mass results still under active theorem work
- downstream finite `T_ren` development
- any unresolved deeper layers beyond `Deep Origin III`

## Why this separation is lawful

The current public reading already distinguishes:

- a publishable core: `Deep Origin I / II / III`
- later unpublished work: `Deep Origin IV` and beyond

This package follows that distinction strictly.
