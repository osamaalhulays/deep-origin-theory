# Deep Origin Public Core / Start Here First

This package is a public lineage package inside **Deep Origin Theory**.

It is not the first scientific entry point. Read it after `Keystone I` and
`Keystone II`.

## What this package is trying to show

This package is trying to show the bounded public core of the deeper
`Deep Origin` line:

- the named inner line that the theory is built on,
- the structural core that is already safe to surface publicly,
- and the clean separation between the public core and later unpublished work.

## What is actually claimed here

The public claim here is structural rather than observational:

- a bounded public core exists,
- its internal sequence is named openly,
- and its later unpublished extension is not being smuggled into publication form.

This package is meant to be read as a **lineage and boundary package**, not as
a standalone scientific proof package.

## What is explicitly not claimed here

This package does **not** claim:

- completion of the deeper unpublished line,
- cosmology completion by depth transfer,
- or a hidden import of unfinished active chambers.

## Public reading order

Recommended first reading path:

1. `README.md`
2. `PUBLIC_POSITION.md`
3. `CLAIM_BOUNDARY_CARD.md`
4. `CORE_SEQUENCE.md`
5. `DEFERRED_WORK_NOTE.md`
6. `SOURCE_LAYER.md`

## What has been intentionally left out of the public package

This public package is meant to foreground the public core itself.

It is not meant to foreground:

- package-audit records,
- status ledgers,
- or approval-facing mechanics.
