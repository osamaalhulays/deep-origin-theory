# Deep Origin Public Core Package

This package is not the first scientific entry point. Read it after `Keystone I` and `Keystone II`.

If you are new to this package, start with:

- `START_HERE_FIRST.md`

## What this package is

It presents the bounded public core of the deeper `Deep Origin` lineage inside **Deep Origin Theory**.

Its role is to show:

- the inner line that the public theory name is built on,
- the staged structural core that is already publishable,
- and the separation between the bounded public core and later unpublished work.

## What this package is not

It does not claim completion of the deeper unpublished line.

It is a **lineage package**, not a standalone scientific proof package.

Included files:

- `START_HERE_FIRST.md`
- `PUBLIC_POSITION.md`
- `CLAIM_BOUNDARY_CARD.md`
- `CORE_SEQUENCE.md`
- `DEFERRED_WORK_NOTE.md`
- `SOURCE_LAYER.md`
