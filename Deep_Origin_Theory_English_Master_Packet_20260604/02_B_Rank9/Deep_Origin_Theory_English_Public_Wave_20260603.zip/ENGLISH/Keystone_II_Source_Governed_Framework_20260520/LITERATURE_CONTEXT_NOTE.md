# Keystone II / External Literature Context

This note exists to make the outward literature posture of `Keystone II`
explicit without pretending that the package is already a full journal-style
bibliography-bearing law paper.

## 1. Immediate outward context

`Keystone II` should be read as standing:

- downstream of the response-language already surfaced publicly in
  `Keystone I`,
- adjacent to scalar-tensor and matter-trace coupling traditions,
- and upstream of any later observational cosmology paper.

## 2. Response-language context already surfaced publicly

The response-facing language that prepared the public shelf did not begin from
an empty vocabulary. In `Keystone I`, the outward bridge language was already
placed next to published response-theory sources such as:

- Koichi Hattori and Kazunori Itakura, *In-medium polarization tensor in
  strong magnetic fields: part I*, Annals of Physics 446, 169114 (2022),
  `arXiv:2205.04312`
- Koichi Hattori and Kazunori Itakura, *In-medium polarization tensor in
  strong magnetic fields: part II*, Annals of Physics 446, 169115 (2022),
  `arXiv:2205.04313`
- Nirmalya Brahma and Katelin Schutz, *Photon conversion to axions and
  scalars in background fields*, `arXiv:2401.05453`

These papers are not claimed as direct authorities for the full Keystone II
law chain. They matter because they keep the public response language attached
to standard retarded-response and field-conversion traditions rather than to
an isolated private vocabulary.

## 3. Scalar-tensor / matter-trace context

The explicit parent-source statement

`O_phi = -(alpha_star/M_P) T_m^ren`

places the public formulation next to familiar scalar-tensor and matter-trace
coupling families rather than outside known theoretical language.

The point is not that `Keystone II` reproduces any one standard model
unchanged. The point is narrower:

- the package is written in a space adjacent to scalar-mediated matter-trace
  coupling,
- it is not asking the reader to accept two unrelated formal backgrounds,
- and it should therefore be read next to scalar-tensor traditions such as
  Brans-Dicke and Damour-Esposito-Farese rather than as a source-free slogan.

## 4. Broader mathematical context that is not direct source authority here

The broader dual-time mathematical arm associated with Mohamed Haj Yousef may
still be acknowledged outward as related context:

- Mohamed Haj Yousef, *Dual-Time Topological Geometry and the Emergence of
  Temporal Asymmetry in Non-Equilibrium Dynamics*, Mathematics 14(5):853
  (2026), DOI `10.3390/math14050853`

But this line is not the direct source authority for the present Keystone II
law-bearing chain. In the public shelf it is treated as:

- supportive mathematical context,
- not the direct source of the governing action,
- not the direct source of the frozen closure relation,
- and not the direct source of the response-to-observable chain surfaced here.

## 5. What this note does and does not do

This note does:

- make the outward literature posture explicit,
- show that Keystone II is not being presented as source-free,
- and distinguish direct source authority from broader related context.

This note does not:

- pretend that Keystone II is already a full bibliography-bearing journal
  paper,
- replace the local theory documents that still carry the core three-layer
  chain,
- or inflate the package into completed observational cosmology.
