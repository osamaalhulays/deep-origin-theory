# Deep Origin Theory / Keystone II English Bundle

This folder presents the strongest current public **law-bearing framework** layer in the English shelf.

If you are new to this package, start with:

- `START_HERE_FIRST.md`

## What this package is

**Keystone II** presents Deep Origin Theory as:

- a source-governed framework,
- a locked physical kernel,
- and a lawful route from curvature response to cosmological-dynamics language.

## What this package is not

It is not presented as:

- completed cosmology,
- final observational closure,
- a learned emulator,
- or a post-hoc fitting patch.

## Why it matters

If `Keystone I` is the bounded bridge result, `Keystone II` is the package that tries to show the **law-bearing spine** behind the broader program.

Public position:

- `Deep Origin Theory / Keystone II: a source-governed framework for curvature response and cosmological dynamics.`

Recommended reading order inside this folder:

1. `START_HERE_FIRST.md`
2. `MAIN_SCIENTIFIC_PAPER_EN.md`
3. `LITERATURE_CONTEXT_NOTE.md`
4. `SOURCE_LAYER.md`

Source visibility:

- `SOURCE_LAYER.md`
