# Keystone II / Start Here First

This package is the public law-bearing entry point for **Keystone II** inside
**Deep Origin Theory**.

If you are opening this package for the first time, read this file before the
main paper.

## What this package is trying to show

`Keystone II` is trying to make the deeper line of the theory readable as a
law-bearing framework rather than as a loose philosophical slogan.

Its public task is narrower than finished cosmology:

- to present one governed source line,
- one controlled closure relation,
- and one lawful route from curvature response to observable language.

## What is actually claimed here

The present outward claim is:

- a source-governed framework,
- with a locked physical kernel,
- and a lawful response-to-observable route,
- still bounded away from final observational closure.

The package is meant to be read as a **framework paper**, not as a completed
cosmology result.

## What is explicitly not claimed here

This package does **not** claim:

- completed cosmology,
- final observational validation,
- a post-hoc fitting patch,
- a learned emulator,
- or a finished global verdict on the full program.

## Why a reader may still care

If `Keystone I` shows a bounded bridge result, `Keystone II` tries to show the
larger law-bearing spine that makes that bounded result part of a coherent
program rather than an isolated technical gesture.

## Public reading order

Recommended first reading path:

1. `README.md`
2. `MAIN_SCIENTIFIC_PAPER_EN.md`
3. `LITERATURE_CONTEXT_NOTE.md`
4. `SOURCE_LAYER.md`

## What has been intentionally left out of the public package

This public package is meant to foreground the framework paper itself.

It is not meant to foreground:

- editorial routing notes,
- outward publication checklists,
- or packaging mechanics.
