# Keystone II / Source Layer

This file makes the source structure of the Keystone II English bundle explicit.

## Package class

- law-bearing framework paper
- curvature-response / cosmological-dynamics line
- still bounded away from completed observational cosmology

## Authored reader-facing materials in this package

- `START_HERE_FIRST.md`
- `README.md`
- `MAIN_SCIENTIFIC_PAPER_EN.md`
- `LITERATURE_CONTEXT_NOTE.md`
- `SOURCE_LAYER.md`

## Canonical theory sources this package relies on

Keystone II is not built on a loose slogan.
Its present law-bearing posture is carried by the white-law family and the theory index that define the three-part chain named in the paper:

- `QCT_Apex_Repo_Run/theory/SPEC-201_MASTER_ACTION_NORM.md`
- `QCT_Apex_Repo_Run/theory/SPEC-205_PHENOMENOLOGICAL_CLOSURE_CORRIGENDUM.md`
- `QCT_Apex_Repo_Run/theory/SPEC-206_DELTA_MAPPING.md`
- `QCT_Apex_Repo_Run/theory/THEORY_INDEX.md`
- `QCT_WHITE_LAW_FULL_SCIENTIFIC_PAPER_AR_20260414_v1.md`

These sources are the living local basis for the three-layer statement surfaced by Keystone II:

- one governing action
- one controlled closure relation
- one response-to-observable route

## Theory identity and publication posture dependencies

This bundle stands downstream of the theory identity already fixed in:

- `AUTHOR_AND_THEORY_FRONTMATTER_20260527`

It also remains consistent with the bounded publication posture already established in:

- `Keystone_I_The_First_Bearing_20260429`

## Operational support records behind the current local law-bearing reading

Keystone II is not an observational-victory paper.
But its claim to be more than decorative language depends on real local operating surfaces that show the white-law chain has been carried into cluster-facing work:

- `qct_world_snapshot_cluster_lensing_interpretive_sovereignty_execution_status.json`
- `macsj0416_first_non_reference_replay_run_status_20260405.json`
- `a370_target_specific_mapping_surface_draft_status_20260405.json`

These records support a narrower point:

- the line has real cluster-facing operational pressure
- `MACSJ0416` reached a governed first non-reference replay candidate state
- `A370` reached only a support-side mapping draft and is not a lawful runner claim

They do not promote Keystone II into completed observational cosmology.

## Direct external literature visibility

The present Keystone II package now surfaces a compact outward literature apparatus through:

- `LITERATURE_CONTEXT_NOTE.md`

That note does not pretend to be a full journal-style bibliography. Its job is narrower:

- make the outward response-language context explicit
- place the law-bearing chain next to scalar-tensor / matter-trace coupling traditions
- and separate direct source authority from broader related mathematical context

## Theory-wide mathematical arms not relied on directly here

The public mathematical arm associated with Mohamed Haj Yousef, including:

- `Dual-Time Topological Geometry and the Emergence of Temporal Asymmetry in Non-Equilibrium Dynamics`
- `https://www.mdpi.com/2227-7390/14/5/853`

is not a direct source authority for Keystone II.

In the current live workspace it is treated as:

- support for dual-time memory architecture
- broader mathematical context

not as the direct source of the governing action, the frozen closure relation, or the response-to-observable chain asserted by Keystone II.

## Outward related-resource acknowledgment

The following related work may still be acknowledged outward as supportive mathematical context:

- Dr. Mohamed Haj Yousef
- `Dual-Time Topological Geometry and the Emergence of Temporal Asymmetry in Non-Equilibrium Dynamics`
- DOI: `10.3390/math14050853`

Recommended outward relation type when a platform offers a related-resource field:

- `References`

## Editorial boundary

This source layer should be read as a hardened local-source map.
Keystone II currently rests on:

- real theory documents
- real cluster-facing operating records
- and an explicit absence of outward literature apparatus

It should not be inflated into a full bibliography-bearing paper that it is not yet.
