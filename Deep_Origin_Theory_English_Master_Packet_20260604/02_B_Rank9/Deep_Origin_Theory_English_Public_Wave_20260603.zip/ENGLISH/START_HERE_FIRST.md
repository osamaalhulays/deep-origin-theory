# Start Here First

This archive is the outward-facing English publication shelf for **Deep Origin Theory**, a single-author research program by **Osama Alhulays**.

If you are opening this archive for the first time, read this file before opening the individual bundles.

## What this theory is trying to do

Deep Origin Theory is presented here as a **source-governed physical framework** that aims to connect:

- a mathematical response structure,
- a lawful route from that structure to observables,
- and, later, a broader cosmological program.

The archive does **not** present a finished cosmology, a completed unification result, or a completed observational closure.

## What is actually claimed in the current public shelf

The strongest current public claims are narrower:

- **Keystone I** claims a bounded **bridge-viable response-unification** result.
- **Keystone II** claims a **law-bearing source-governed framework** for curvature response and cosmological dynamics.
- **Deep Origin Public Core** presents the bounded inner lineage of the theory.
- **Firstlight Public Face** presents the outward cosmology-facing identity without claiming completion.

This means the archive is best read as a **disciplined publication shelf for a developing theory**, not as a completed cosmology package.

## What has already been achieved through Rank 9

Before full observational opening, the program had already secured a bounded
set of nontrivial results. In particular, the public shelf already carries:

- a source-governed response architecture,
- a lawful common-parent route for the admitted pair,
- an explicit common-response manifest and harmonization map,
- exact embedding on one side and signed cell integration on the other,
- a bounded bridge-viability result on a declared common test basis,
- positive public bridge diagnostics under a declared robustness envelope,
- a reproducible 301-row predata model-prediction bundle in the normalized
  `H(z)` / `E(z)` background family, still kept upstream of observed data,
  likelihood, and fit,
- and a pre-observational kernel kept free of fit, smoothing, and hidden
  rescue devices.

If you want those gains stated directly and in one place, read:

- `WHAT_HAS_ALREADY_BEEN_ACHIEVED_THROUGH_RANK9.md`
- `Keystone_I_The_First_Bearing_20260429/RANK9_CLOSURE_AND_RANK10_BOUNDARY_NOTE.md`

## Current stage and prediction status

The current public shelf is at a **pre-cosmology / pre-fit** stage.

That means:

- it does make bounded technical claims already,
- it does carry stage-local numerical outputs already,
- but it does not yet promote those outputs into finished cosmological
  observables.

If you want the shortest direct explanation of what is predicted now and what
is still deferred, read:

- `CURRENT_STAGE_AND_PREDICTION_STATUS.md`
- `Keystone_I_The_First_Bearing_20260429/RANK9_CLOSURE_AND_RANK10_BOUNDARY_NOTE.md`

## What is explicitly not claimed here

The archive does **not** claim:

- a completed cosmology,
- a final `H(z)` law,
- a final `D_L(z)` model vector,
- Pantheon+ agreement,
- BAO/CMB closure,
- CMB completion,
- a completed unification result.

Those are deferred to later stages of the program.

## Why the work may still matter

The value of the current shelf is not that it finishes everything. Its value is that it tries to do three harder things honestly:

- state a bounded claim rather than an inflated one,
- expose falsifiers and non-claims clearly,
- and keep the route from formal structure to observables auditable.

This is a framework-first publication posture, not a fit-first posture.

## How to read this archive

Recommended reading order:

1. **This file** for orientation.
2. `WHAT_HAS_ALREADY_BEEN_ACHIEVED_THROUGH_RANK9.md`
3. `CURRENT_STAGE_AND_PREDICTION_STATUS.md`
4. `Keystone_I_The_First_Bearing_20260429/RANK9_CLOSURE_AND_RANK10_BOUNDARY_NOTE.md`
5. `Keystone_I_The_First_Bearing_20260429`
   Read `README.md`, then `CURRENT_STAGE_AND_PREDICTION_STATUS.md`, then `ABSTRACT.md`, then `MANUSCRIPT.md`.
6. `Keystone_II_Source_Governed_Framework_20260520`
   Read `README.md`, then `MAIN_SCIENTIFIC_PAPER_EN.md`, then `LITERATURE_CONTEXT_NOTE.md`.
7. `DEEP_ORIGIN_PUBLIC_CORE_20260528`
8. `FIRSTLIGHT_PUBLIC_FACE_20260528`
9. `AUTHOR_AND_THEORY_FRONTMATTER_20260527`
10. `SOURCE_LAYER_INDEX.md` only after the scientific reading if you want source visibility and package governance.

## Important note on archived wording

Some files retain traces of the program's archived internal wording.

For public scientific reading, the preferred external language in this shelf is:

- `finite-volume sector` rather than directional shorthand,
- `cluster-local sector` rather than directional shorthand,
- `bridge viability` or `bounded bridge result` rather than workflow status language,
- `common-parent setting` rather than governance shorthand,
- and `claim boundary` rather than triumphal stage language.

Those external phrases are the intended reading layer.
Any older wording should be treated as archival naming only, not as a claim of
external authority or as a replacement for standard physics terminology.

## What this archive is not optimized for

This shelf is optimized for:

- disciplined publication packaging,
- bounded claims,
- and source visibility.

It is **not yet optimized** as the best possible cold-start briefing packet for a brand-new external advisor.

That limitation is real. This file exists to reduce it.
