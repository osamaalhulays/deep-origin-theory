# Public Witness Card

This card states the strongest things a new reader can inspect **directly in
the public package** without opening inaccessible archive files.

## Publicly visible witness classes

The package makes the following witness classes visible:

- **formal witness**
  - the two traceless response objects are written explicitly in the manuscript
- **parent witness**
  - the common-parent declaration is written explicitly in the manuscript
- **basis witness**
  - the admitted comparison layer is stated to be a finite common test basis
    with no smoothing authority
- **construction witness**
  - the finite-volume sector is carried by exact embedding and the cluster-local sector by signed
    cell integration
- **vector witness**
  - the package now exposes how `H_S` and `H_N` are derived on the admitted
    5-anchor common basis before Xi is computed
- **diagnostic witness**
  - the package publishes `loss_S`, `loss_N`, `projection_debt`, `Xi_raw`,
    `Xi_hat`, and `Xi_hat_min`
- **robustness witness**
  - the package states that positivity survives the declared robustness
    envelope through `Xi_hat_min > 0`
- **scope witness**
  - the package states the claim boundary and the explicit non-claims
- **falsifier witness**
  - the package states the most direct kill conditions in the manuscript

## What a public reader can fairly verify from these witnesses

A public reader can fairly verify that the package:

- does make a bounded technical claim,
- does define the formal comparison objects,
- does state the admitted bridge discipline,
- does expose the public vector-derivation chain into `H_S` and `H_N`,
- does publish the stage-local bridge diagnostics,
- and does say clearly what is deferred to later cosmology layers.

## What is still not public in full

The package does **not** yet provide a complete raw archive of every internal
status file and intermediate engineering record.

That is a genuine limit.
The public package is therefore strongest when read as:

- a bounded scientific paper with a declared evidence surface,

not as:

- a fully open raw-data repository for the entire internal program history.
