# Literature Positioning Note

This note answers a simple external question:

**What in `Keystone I` comes from standard response-theory vocabulary, and what
is claimed here as program-specific?**

## What is standard or borrowed in language

The paper does not claim to invent:

- the traceless projector `Pi_0`,
- the basic language of retarded response,
- the use of response-side objects and self-energy vocabulary,
- or the idea that response objects can be discussed in linear-response terms.

The response-language anchors named in the package support that standard
vocabulary layer.

## What is specific to the present paper

What `Keystone I` claims as its own bounded contribution is narrower and more
specific:

- selecting two independently prepared traceless response contrasts,
- placing them under one declared common-parent response setting,
- putting them on a published common no-smoothing test basis,
- carrying one side by exact embedding and the other by signed cell
  integration,
- and publishing the bounded bridge diagnostics and falsifiers under that
  discipline.

## What is not yet claimed against the literature

The paper does **not** yet claim:

- a full alternative cosmological model,
- a background-distance victory over standard cosmology,
- a perturbation-level replacement,
- or a completed observational verdict.

The literature position of `Keystone I` is therefore:

- stronger than a purely philosophical sketch,
- weaker than a completed cosmological replacement paper,
- and best understood as a bounded response-unification stage with explicit
  falsifiers and deferred cosmology.
