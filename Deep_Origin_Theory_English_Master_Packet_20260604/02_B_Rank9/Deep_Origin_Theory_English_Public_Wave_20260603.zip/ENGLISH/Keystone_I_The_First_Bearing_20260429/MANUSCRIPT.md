# Keystone I: The First Bearing

## Bridge-Viable Response Unification in Deep Origin Theory

Osama Alhulays  
Independent researcher

Date: 2026-04-29

## Abstract

We present `Keystone I` of Deep Origin Theory as a bounded response-unification study. The paper asks whether two independently prepared traceless response objects, one associated with a finite-volume response sector and one associated with a same-cluster response sector, can be placed in a shared parent-response setting without smoothing, hidden parameter splitting, operator surplus, or uncontrolled promotion beyond their present claim boundaries.

The present claim is narrower than completed cosmology. On the published layer, the two objects are compared on a source-governed common test basis; the finite-volume object is embedded exactly, the same-cluster object is paired by signed cell integration, and the resulting bridge record carries zero projection debt, zero smoothing authority, and positive overlap diagnostics with canonical values `Xi_raw = 0.3148145037995458`, `Xi_hat = 0.7589533617835368`, and `Xi_hat_min = 0.751178834903882`. We treat this as a bounded common-response bridge rather than as a final cosmological closure.

This paper does not claim cosmology completion, a predictive `H(z)` law, a `D_L(z)` model vector, Pantheon+ agreement, BAO/CMB closure, perturbation closure, or a final public unification verdict. It offers instead a reviewable response-unification layer with explicit non-claims, explicit falsifiers, and later cosmology work kept separate from the present result.

## 1. Introduction

The problem addressed in this paper is narrower and more technical than a generic final-unification narrative. We ask whether one can lawfully connect two independently prepared traceless response objects inside one governed response architecture without cheating through smoothing, hidden sector parameters, operator surplus, or an uncontrolled change of parent object.

One object comes from a finite-volume response sector. The other comes from a same-cluster response sector. Older project shorthand survives in some archived records, but the public reading of this paper should follow the external phrasing used here.

These two sectors were then brought into contact through a common response manifest, a common test basis, and a constrained bridge evaluation whose engineering layer explicitly rejected earlier basis-map artifacts before accepting the final no-smoothing rerun.

The result is publishable now, but only under a strict claim boundary. We therefore do not present this paper as completed cosmology. We also do not present it as a final public unification announcement. What we do present is a bounded response-unification framework with a bridge-viable pair, together with the engineering tests, falsifiers, and boundedness conditions that make this claim reviewable.

## 2. Executive Claim and Scope

The externally reviewable claim of this paper is:

> Deep Origin Theory, in its Keystone I line, provides a governed common-response framework in which two independently prepared traceless response objects can be harmonized through a source-governed common test basis, yielding a bridge-viable common-parent layer without operator surplus, parameter split, kernel promotion, or uncontrolled promotion beyond the present claim boundary.

The paper is intentionally bounded by the following non-claims:

- no completed cosmology
- no final public unification claim
- no `H(z)` prediction
- no `D_L(z)` or `m_model(z)` model vector
- no Pantheon+ fit
- no BAO/CMB closure
- no perturbation closure
- no CMB Boltzmann completion

The internal program tracks stages with its own archived naming. This is mentioned only to explain continuity with the broader record. The paper does not ask the reader to accept any internal ladder as peer review. The reader is asked to evaluate the response-unification content directly.

## 3. Formal Objects and Notation

The common traceless projector is written as

`Pi_0(A) = A - (Tr(A)/M) I_M`

with the relevant support dimension specified per sector.

The finite-volume response object is

`R_S^circ = Pi_0(K_R^{Theta_S} - P_ThetaS)`

with finite-volume support dimension `63`.

At source level, the finite-volume carrier is not introduced as an empty
symbol. It comes from a bounded retarded-response route of the form

`K_R(omega) = P_Theta(omega) + sum_n [2 Omega_n Z_modal_n] / [Omega_n^2 - (omega+i0)^2]`

so the finite-volume side is anchored to a standard modal retarded-response
representation rather than to a purely decorative placeholder.

The cluster-local response object is

`R_N^circ_local = Pi_0(K_N - P_N)`

with cluster-local support dimension `65`.

At the present public stage, `K_N` is published through its bounded source
construction rather than through a completed transport operator law. In
schematic form, the cluster-local carrier is assembled as

`K_N = K_N[A2142; T_pd(r), S(r), M_hse(r), f_g(r), M(r), beta_v(r), N_th(r), ...]`

where the arguments denote the A2142 thermodynamic, kinematic, and adjacent
nonthermal support banks that are assembled into the 65-bin cluster-local
carrier before subtraction against `P_N`.

In the language of this paper, `K_R^{Theta_S}` and `K_N` are the
sector-native response carriers, while `P_ThetaS` and `P_N` are the
sector-specific reference pieces against which traceless response contrast is
formed. The present public claim does not treat these symbols as finished
cosmological observables. It treats them as the formal carriers from which the
bounded traceless response objects are extracted.

The governing common-parent declaration used in the published common-response layer is

`O_phi = T_m^ren`.

In the more explicit upstream canonicalized source-coupling language, the same
declaration appears in the form

`O_phi = -(alpha_star/M_P) T_m^ren`

which makes clear that the present bridge is being framed under a scalar-mediated
matter-trace coupling discipline rather than under two unrelated formal
backgrounds.

This common-parent declaration matters because the goal is not to place two unrelated arrays side-by-side, but to show that their descent to a shared response parent is lawful and remains lawful through harmonization and bridge review.

## 4. Finite-Volume Sector: Bounded Traceless Response Object

The finite-volume contribution is used here in a deliberately narrow way.
What matters for the present paper is not an unrestricted finite-volume program, but a
bounded traceless response object:

`R_S^circ = Pi_0(K_R^{Theta_S} - P_ThetaS)`

This object is carried only within a finite-volume-only, strictly bounded, non-escalatory
scope. In practical terms, the paper treats the finite-volume side as already closed at
the level required for bridge construction and does not reopen broader finite-volume
questions such as kernel promotion, denominator promotion, or higher
response-function claims.

That bounded treatment matters scientifically. It ensures that the finite-volume side
is not being used as a hidden source of extra freedom while the bridge is being
assembled. The present paper therefore uses the finite-volume object as a closed
traceless-response input, not as a back door for a larger unresolved program.

## 5. Cluster-Local Sector: Local Traceless Response Contrast

The cluster-local contribution is likewise used in a bounded way.
The public object is a local traceless response contrast

`R_N^circ_local = Pi_0(K_N - P_N)`

with support dimension `65`.

The important point is that the cluster-local sign structure is not interpreted here as
a free-standing positivity theorem. The cluster-local side is used as a same-cluster
traceless contrast around its native mean, not as a smuggled spectral-density
claim. This is why the paper can use the cluster-local object in bridge engineering
without pretending that cluster-local alone already establishes overlap, transport
positivity, or a larger unification result.

As with the finite-volume side, the cluster-local scope remains bounded. The paper does not
promote the cluster-local contribution into a second-stage claim beyond the present claim boundary, a standalone sector theorem,
or a bridge verdict by cluster-local evidence alone.

## 6. Common Response Manifest and Common-Parent Setting

The core structural move of the paper is to bind the finite-volume and cluster-local response
objects into one common-parent common-response setting.

The common-response layer matters because it blocks the most obvious skeptical
reading of any positive overlap signal: namely, that two unrelated arrays were
placed side-by-side and then post-processed until they looked compatible.

The paper therefore insists on three constraints before any bridge statement is
made:

- the pair must be declared common-parent,
- the pair must live on one governed common-response setting,
- and the pair must preserve contact/subtraction discipline without operator
  surplus or parameter split.

The role of the common-parent declaration `O_phi = T_m^ren` is precisely to
state that the bridge is being tested inside one declared response parent, not
across an uncontrolled juxtaposition of unrelated sectors.

## 7. Basis Harmonization and the No-Smoothing Layer

The publication-level bridge claim does not rest on a smoothing-based matching
trick.

Earlier in the project history, provisional surrogate layers existed for
operational purposes. The present paper does not treat those provisional layers
as public authority. The published public layer is narrower and cleaner: a
finite, source-governed common test basis on which the finite-volume object is embedded
exactly and the cluster-local object is paired by signed cell integration, with no
declared smoothing width required as authority.

This choice matters for two reasons.

First, it removes the simplest rescue mechanism available to a weak overlap
claim: arbitrary smoothing, width tuning, or post-hoc rescaling.

Second, it makes the result easier to falsify. If the bridge only survived
because mismatch was hidden by smoothing, then the bridge should fail when that
authority is removed. The present public claim is that it does not fail there.

The common test basis is finite and explicit. In the published layer it is a
five-anchor basis on the normalized common coordinate. The finite-volume side is
carried on it by exact embedding. The cluster-local side is carried on it by signed
cell integration. The resulting public claim is therefore a lawful common test
space, not a vague heuristic similarity claim.

## 8. Pair-Level Engineering and Public Diagnostics

The heart of the paper is the move from a conceptual common-parent story to a
reviewable engineering result.

On the published common-response layer, the public bridge quantities are:

- `loss_S = 0.0`
- `loss_N = 0.0`
- `projection_debt = 0.0`
- `Xi_raw = 0.3148145037995458`
- `Xi_hat = 0.7589533617835368`
- `Xi_hat_min = 0.751178834903882`

These are not presented as final cosmological observables.
They are presented as bridge diagnostics for the current response-unification
stage.

What makes them meaningful in the present paper is not positivity alone, but
the conjunction of several checks:

- common-parent descent remains consistent,
- the common-basis construction remains consistent,
- traceless compatibility is preserved,
- contact/subtraction discipline is preserved,
- unit and sign compatibility are preserved,
- the bridge remains robust under the declared perturbation envelope,
- and no projection debt or hidden surplus is needed to hold the result up.

The robustness condition is especially important.
The paper does not ask the reader to accept `Xi > 0` in isolation. The public
claim is stronger and narrower: the overlap remains positive under the declared
robustness envelope, with `Xi_hat_min > 0`, while staying within the
no-smoothing and zero-projection-debt discipline.

## 9. Bridge Viability and Its Public Consequence

The public consequence of the engineering result is **bridge viability** in the
limited sense used by this paper.

That means the pair has crossed the threshold required for a bounded
common-parent common-response bridge.
It does **not** mean that full unification, completed cosmology, kernel
promotion, or a final theory-level verdict has thereby been earned.

This distinction is essential.
The positive bridge result is not being inflated into a larger claim than its
evidence supports. The present paper stops at the bridge-viable
response-unification layer and treats anything beyond that as a later stage.

## 10. Scope Discipline and Why the Claim Boundary Is a Scientific Asset

The claim boundary of the paper is not cosmetic.
It is part of the scientific content because it keeps the result from being
rescued by claims that have not yet been earned.

The public scope can be summarized simply:

| Layer | Public status in this paper |
| --- | --- |
| Finite-volume traceless response object | established in bounded finite-volume scope |
| Cluster-local traceless response object | established in bounded cluster-local scope |
| Common-response manifest | established |
| Common test basis | established |
| No-smoothing basis harmonization | established |
| Common-parent pair | established |
| Bridge result | established as bridge-viable |
| Completed cosmology | not claimed |
| Kernel promotion | not claimed |
| second-stage claim beyond the present claim boundary | not claimed |

That boundedness is an asset.
A bridge-viable response-unification result with explicit kill criteria is
easier to evaluate, easier to falsify, and harder to confuse with rhetoric
than a premature totalizing announcement.

## 11. Falsifiers

The paper is meant to be killable if its central claim is wrong. The most direct falsifiers are:

`F1.` If the common-response bridge requires Lorentzian or Gaussian smoothing as authority, the present bridge claim fails.

`F2.` If a hidden sector-specific parameter, width, coupling, amplitude, or normalization must be introduced after harmonization, the no-parameter-split condition fails.

`F3.` If tracelessness is not preserved in the declared common test basis, the common-parent pair is invalid.

`F4.` If contact/subtraction terms create or hide the overlap signal, the bridge claim fails.

`F5.` If the accepted overlap survives only by discarding decisive nonmatching support, then the zero-loss / zero-projection-debt result is false and the bridge claim fails.

`F6.` If the future cosmology program requires residual fitting of `H0`, `M`, `alpha`, `gamma`, or initial scalar data in order to generate the first lawful background model vector, then the current framework may remain a bridge-viable response theory while the complete unification-facing cosmology program fails.

The key point is that the present paper already specifies how it could be wrong.

## 12. What This Paper Does Not Claim

This paper does not claim:

- a final `H(z)` law
- a final `D_L(z)` or `m_model(z)` vector
- Pantheon+ agreement
- BAO/CMB background closure
- perturbation closure
- CMB Boltzmann completion
- inflationary closure
- a final public verdict against `LambdaCDM`
- complete cosmology

These are not omissions hidden in the fine print. They are explicitly deferred
to the later cosmology program.

## 13. Deferred Cosmology Program

The next live front after `Keystone I` is the cosmology-completion program.
The first exact blocker named in the internal handoff is the absence of a
global cosmological law for `A(phi)` or `alpha(phi)`.

The remaining downstream tasks, in canonical order, are:

1. primitive freeze
2. background field equations
3. background solver
4. no-fit distance/model vector
5. Pantheon+ covariance evaluation
6. BAO/CMB background distances
7. linear perturbations and growth
8. CMB Boltzmann implementation
9. initial-conditions or inflation packet
10. falsifiers, reproducibility, and final cosmology review

The present paper is therefore best understood as the pre-cosmology publication of the response-unification architecture, not as the cosmology paper itself.

## 14. Reproducibility, Public Evidence, and Archived Provenance

The present package aims to be readable on two levels.

First, the bounded public claim should be understandable from the public bundle
itself:

- the formal objects are stated in the manuscript,
- the common-parent common-response construction is stated in the manuscript,
- the no-smoothing basis discipline is stated in the manuscript,
- the public bridge diagnostics are stated in the manuscript,
- the falsifiers are stated in the manuscript,
- the stage boundary is stated in `CURRENT_STAGE_AND_PREDICTION_STATUS.md`,
- and the bounded pre-Rank-10 gains are stated in
  `WHAT_HAS_ALREADY_BEEN_ACHIEVED_THROUGH_RANK9.md`.

Second, the broader project still maintains archived internal records for
provenance and exact packet history. Those archived records are useful for
program-level traceability, but they are not being offered here as a hidden
substitute for public scientific reading.

For a direct package-level map of the public evidence chain, see:

- `PUBLIC_EVIDENCE_APPENDIX.md`

## 15. Selected References

The response language used in this manuscript was not chosen arbitrarily. The
formal retarded-response vocabulary used in the finite-volume and parent-source
layers is aligned with the following references:

- `[1]` Koichi Hattori and Kazunori Itakura, *In-medium polarization tensor in
  strong magnetic fields (I): Magneto-birefringence at finite temperature and
  density*, arXiv:2205.04312 (2022).
- `[2]` Koichi Hattori and Kazunori Itakura, *In-medium polarization tensor in
  strong magnetic fields (II): Axial Ward identity at finite temperature and
  density*, arXiv:2205.06411 (2022).
- `[3]` Nirmalya Brahma and Katelin Schutz, *Photon conversion to axions and
  dark photons in magnetized plasmas: a finite-temperature field theory
  approach*, arXiv:2410.14771 (2024).

These references support language such as:

- the retarded polarization tensor as a linear response function,
- the prescription `omega -> omega + i epsilon`,
- retarded self-energy and mode mixing in a medium,
- and induced-current chains of the form `J_ind = -Pi_R A`.

They do not, by themselves, establish the broader Deep Origin Theory mission.
They are cited here to anchor the response-theory vocabulary used in the formal
sectors of this paper.

## 16. Conclusion

Keystone I is publishable now, but not as completed cosmology and not as a final public unification claim. What is publishable now is narrower and, in practice, stronger: a bridge-viable response-unification framework whose microscopic and macroscopic sectors are lawfully connected through a common-parent common-response architecture and a no-smoothing common test basis.

The paper is therefore meant to stand on three legs:

1. independently authorized finite-volume and cluster-local traceless response objects
2. a governed common-response and bridge-viability architecture
3. an explicit claim boundary that holds cosmology closed until the primitive-freeze program is completed

This combination is sufficient for a serious first paper. It establishes precedence, protects the claim against easy overreach, and leaves the cosmology program to be opened where it should be opened: at primitives, not at fitted observables.

## Appendix A. Archived Wording Crosswalk

Some archived project records preserve internal shorthand.
For public reading, this paper prefers the following external phrasing:

- `finite-volume sector`
- `cluster-local sector`
- `bridge-viable result`
- `claim boundary`
- `second-stage claim`

These public terms should control the scientific reading of the paper.
Archived shorthand is retained only for continuity with earlier internal records.

## Appendix B. Canonical Engineering Numbers

- `basis_map_v1_class = DISTRIBUTIONAL_PAIRING_MAP_NO_SMOOTHING`
- `loss_S = 0.0`
- `loss_N = 0.0`
- `projection_debt = 0.0`
- `Xi_raw = 0.3148145037995458`
- `Xi_hat = 0.7589533617835368`
- `Xi_hat_min = 0.751178834903882`

## Appendix C. Public One-Sentence Summary

> We publish Keystone I as a bridge-viable response-unification framework with cosmology explicitly held closed pending a separate primitive-freeze cosmology program.
