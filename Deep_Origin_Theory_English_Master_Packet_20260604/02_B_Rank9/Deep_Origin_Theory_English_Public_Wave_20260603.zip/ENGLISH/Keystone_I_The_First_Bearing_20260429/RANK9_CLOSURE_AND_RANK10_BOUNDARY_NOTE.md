# Rank 9 Closure And Rank 10 Boundary Note

This note answers one external question directly:

**If `Keystone I` stops before finished cosmological observables, is that an
accidental omission, or an intentional stage boundary?**

It is intentional.

The package is meant to show that Rank 9 closed successfully under its own
published discipline, while Rank 10 had not yet been claimed as complete.

## What Rank 9 was supposed to close

Rank 9 was the last **pre-observational closure stage**.

Its job was to secure, in bounded public form:

- a common-parent setting for the admitted pair,
- a governed common-response manifest,
- a finite common test basis with explicit harmonization,
- exact embedding and signed cell integration on that basis,
- public bridge diagnostics with positive bounded outputs,
- robustness under the declared no-smoothing discipline,
- and a kernel kept free of fit, hidden parameter rescue, and operator surplus.

Rank 9 was therefore meant to close the **formal bridge layer** and the
**pre-observational kernel**, not the final cosmology program.

## What counted as successful Rank 9 closure

Rank 9 counts as successfully closed when the public program has already
secured all of the following:

- the admitted pair can be placed on one governed common basis,
- the finite-volume and cluster-local constructions can be exported into that
  basis without projection debt,
- the bridge diagnostics remain positive under the declared robustness
  envelope,
- the result does not rely on smoothing, zero-padding, hidden fit rescue, or
  post hoc parameter repair,
- and the program reaches lawful observational preflight readiness without
  pretending that observational comparison has already happened.

That is the success criterion for Rank 9.

## What Rank 9 did not need to close

Rank 9 did **not** require the program to publish:

- a final `H(z)` law,
- a final `E(z)` or `D_L(z)` law,
- a Pantheon+ comparison,
- BAO background closure,
- CMB closure,
- likelihood or fit verdicts,
- or a public replacement verdict against `LambdaCDM`.

Those are not forgotten outputs from Rank 9.
They belong to the next stage.

## Where Rank 10 begins

Rank 10 begins when the program moves from a closed bridge layer to a lawful
**observational opening**.

That opening starts when the package stops speaking only in bridge diagnostics
and begins carrying observable-facing work such as:

- lawful `H(z)` / `E(z)` opening,
- distance-layer construction such as `D_L(z)` or `m_model(z)`,
- Pantheon+ covariance-facing evaluation,
- BAO background comparison,
- later perturbation layers,
- and eventually CMB-facing closure.

Rank 10 is therefore not "more explanation of Rank 9."
It is the first stage in which the program must answer to observational
comparison.

Later downstream closure work also clarifies that this opening should not be
imagined as one abrupt jump from pure theory to finished cosmology.

By the later bounded `Rank10` no-data corridor, the background normalized
`H(z)` / `E(z)` lane had already materialized:

- a bounded observed benchmark-row pack with `5` active rows,

while still keeping closed:

- `QCT`-side normalized `H100` prediction rows,
- likelihood,
- fit,
- and full observational claim.

So the boundary after Rank 9 is best read as a governed staircase:

- bounded bridge closure first,
- then lawful pre-observational and bounded benchmark readiness,
- and only later, if crossed lawfully, full observed comparison.

## Why the present omission is deliberate

The absence of finished cosmological observables in `Keystone I` is not a
hidden retreat.

It is the outward sign that:

- Rank 9 closed where it was supposed to close,
- Rank 10 had not yet been claimed as complete,
- and the package refuses to import observational verdicts before the program
  has lawfully opened them.

## One-sentence summary

**Rank 9 closed successfully because the bridge layer and the
pre-observational kernel were completed under their published discipline;
Rank 10 begins only when observable comparison itself opens.**
