# Response Object Provenance Note

This note answers a direct external question:

**Where do `K_R^{Theta_S}` and `K_N` actually come from in the current public
package?**

## Short answer

They come from **two different but explicitly bounded source routes**:

- a finite-volume modal response route on the finite-volume side,
- and an A2142-based local support route on the cluster-local side.

The public bridge claim does not hide this asymmetry.
It depends on it.

## Finite-volume-side provenance

The finite-volume side begins from a finite-volume modal response packet rather
than from a finished cosmological matter model.

What is already fixed in the witness layer is that this side is:

- finite-volume,
- modal,
- retarded-response framed,
- and explicitly marked as **toy-underlay only** at its own source level.

The witness packet records:

- a modal retarded-response carrier,
- a discrete-support ledger,
- a bounded shell structure behind the `63`-component support,
- and a modal formula of the form
  - `K_R(omega) = P_Theta(omega) + sum_n [2 Omega_n Z_modal_n] / [Omega_n^2 - (omega+i0)^2]`

So the finite-volume side is not being passed off as a finished cosmological
observable.
It is a bounded modal response-side source object used for bridge testing.

## Cluster-local-side provenance

The cluster-local side is anchored to real local material from **A2142**.

What is already fixed in the witness layer is that this side is:

- A2142-specific,
- radial,
- 65-bin,
- traceless after subtraction in all 65 bins,
- schematically carried as
  - `K_N = K_N[A2142; T_pd(r), S(r), M_hse(r), f_g(r), M(r), beta_v(r), N_th(r), ...]`,
- and built as
  - `R_N^circ_local = Pi_0(K_N - P_N)`.

The support banks feeding this side already include:

- pressure-density-derived temperature,
- entropy,
- hydrostatic mass,
- gas fraction,
- mass profiles,
- velocity-anisotropy profiles,
- caustic / dispersion-kurtosis / MAMPOSSt / Jeans-inversion inputs,
- and adjacent nonthermal support near the virial boundary.

So the cluster-local side is not a free symbolic array.
It is a local response contrast assembled from real A2142 radial support
material.

## What this provenance does and does not prove

This provenance already proves something important:

- the two response objects are not arbitrary late inventions,
- each one comes from a bounded and inspectable preparation route,
- and the public bridge is not built from naked similarity numbers alone.

But it does **not** yet prove that:

- the finite-volume side is already a finished physical matter sector,
- the cluster-local side is already a fully normalized external observable,
- or the whole pair has already been pushed through a completed cosmological
  transport derivation.

Those stronger claims remain outside the present paper.

## Best current reading

The honest current reading is:

- `K_R^{Theta_S}` comes from a bounded finite-volume modal response route,
- `K_N` comes from a bounded A2142 local support route,
- and `Keystone I` asks whether the resulting traceless contrasts can be
  lawfully compared under one published common-parent bridge discipline.
