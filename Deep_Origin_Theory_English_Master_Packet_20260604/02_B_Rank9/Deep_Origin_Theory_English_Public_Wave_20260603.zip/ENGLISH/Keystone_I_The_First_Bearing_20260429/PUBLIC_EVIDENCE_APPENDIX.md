# Public Evidence Appendix

This appendix is included for one practical reason:

**A new reader should be able to see what the bounded public claim rests on
without first trusting inaccessible internal status files.**

## Public evidence chain for the present claim

The present package makes the following public items available directly:

- `ABSTRACT.md`
  - the bounded claim and the canonical public diagnostics
- `MANUSCRIPT.md`
  - the formal objects, the common-response construction, the no-smoothing
    basis layer, the bridge diagnostics, and the falsifiers
- `WHAT_HAS_ALREADY_BEEN_ACHIEVED_THROUGH_RANK9.md`
  - the bounded scientific gains already secured before Rank 10
- `RANK9_CLOSURE_AND_RANK10_BOUNDARY_NOTE.md`
  - the explicit closure criterion for Rank 9 and the explicit observational
    opening that begins Rank 10
- `CURRENT_STAGE_AND_PREDICTION_STATUS.md`
  - what this paper predicts now and what it explicitly does not yet predict
- `PHYSICAL_INTERPRETATION_NOTE.md`
  - what the main formal objects are meant to represent at the current stage
- `RESPONSE_OBJECT_PROVENANCE_NOTE.md`
  - where the finite-volume and cluster-local response carriers actually come
    from before the bridge is formed
- `COMMON_BASIS_VECTOR_DERIVATION_NOTE.md`
  - how the public 5-component vectors are derived from the two response
    contrasts before Xi is computed
- `NUMERIC_REPRODUCTION_ROUTE_NOTE.md`
  - what a cold reader can recompute independently from the public witness rows
- `PARENT_OPERATOR_MEANING_NOTE.md`
  - what the compact statement `O_phi = T_m^ren` is doing at the current stage
- `CLUSTER_LOCAL_OBJECT_STATUS_NOTE.md`
  - what the cluster-local object physically is already anchored to, and what
    remains unfrozen
- `XI_DIAGNOSTIC_INTERPRETATION_NOTE.md`
  - what the public `Xi_*` values mean and do not mean
- `XI_SUCCESS_CRITERION_NOTE.md`
  - what currently counts as bridge-stage success and what would count as
    failure
- `PARENT_LAW_STATUS_NOTE.md`
  - what is already operationalized about the common-parent law and what remains
    incomplete
- `PUBLIC_WITNESS_CARD.md`
  - what a new reader can actually inspect in the package itself
- `LITERATURE_POSITIONING_NOTE.md`
  - what is standard response-theory vocabulary and what is specific here
- `LITERATURE_COMPARISON_NOTE.md`
  - where the paper truly aligns with cited response-theory work and where it
    adds a program-specific bridge construction
- `CLAIM_BOUNDARY_CARD.md`
  - the public claim boundary under which the current result is being published
- `REPRODUCIBILITY_NOTE.md`
  - the package-level reproducibility posture
- `SOURCE_LAYER.md`
  - the exact source structure and the provenance map for the present bundle

## What the public claim does rely on

The public claim relies on the following scientific content being readable in
the package itself:

- two traceless response objects are defined explicitly,
- a common-parent declaration is stated explicitly,
- a common-response setting is described explicitly,
- the final published basis layer is declared to be no-smoothing,
- exact embedding and signed cell integration are stated explicitly,
- the canonical public diagnostics are stated explicitly,
- the robustness requirement is stated explicitly,
- the falsifiers are stated explicitly,
- and later cosmology work is stated explicitly as deferred rather than implied.

## What remains archived rather than fully public

The broader project still maintains internal archive records and packet names
for provenance. Those remain useful for program-level traceability, but they
are **not** being offered here as a substitute for public scientific reading.

The intended public standard is narrower:

- the bounded claim should be understandable from the package itself,
- the package should state what has been achieved,
- the package should state what remains deferred,
- the package should explain what its formal objects and public diagnostics are
  supposed to mean physically at the current stage,
- the package should explain where its response carriers come from and what its
  compact parent-source statement is actually doing,
- the package should expose how the public common-basis vectors are derived and
  what part of the bridge arithmetic can be reproduced independently,
- the package should explain what its cluster-local object, Xi threshold, and
  common-parent law do and do not already establish,
- and no hidden status code should be required in order to understand the
  public scope of the paper.
