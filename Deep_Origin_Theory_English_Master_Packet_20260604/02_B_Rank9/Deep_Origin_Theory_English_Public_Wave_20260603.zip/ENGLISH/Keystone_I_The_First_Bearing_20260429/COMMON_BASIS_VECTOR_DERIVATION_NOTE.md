# Common-Basis Vector Derivation Note

This note answers the narrow pre-calculation question left open by many cold
readers:

**Where do the two published 5-component vectors actually come from before
`Xi_raw` and `Xi_hat` are computed?**

## Short answer

The bridge diagnostics are not computed directly on the raw finite-volume and
cluster-local arrays.

They are computed on their **authorized common-basis images**:

- `H_S`, the finite-volume image on the 5-anchor common test basis,
- `H_N`, the cluster-local image on the same 5-anchor common test basis.

The public Xi numbers are then computed on those two vectors, not on hidden
intermediate objects.

## Step 1. Start from the two traceless response contrasts

The public response contrasts are:

- `R_S^circ = Pi_0(K_R^{Theta_S} - P_ThetaS)`
- `R_N^circ_local = Pi_0(K_N - P_N)`

## Step 2. Move both objects into one common coefficient space

The admitted comparison space is the finite-dimensional common coefficient
space

- `V_C = signed source-governed test-basis coefficient space indexed by 5 south modal anchors on common coordinate u in [0,1]`.

## Step 3. Derive the finite-volume vector `H_S`

On the finite-volume side, the move is:

- **exact south distributional embedding onto the source-governed modal-anchor test basis**

with anchors

- `[0.0, 0.303392149209275, 0.548604745270056, 0.7787657587774851, 1.0]`

and coefficients

- `[0.8320376445347705, 0.1566514228819847, 0.010984959256316035, 0.00032040232859241436, 5.570998336357333e-06]`.

This is the public 5-component vector:

- `H_S`.

## Step 4. Derive the cluster-local vector `H_N`

On the cluster-local side, the move is:

- **signed cluster-local cell integration against source-governed Voronoi cells around the same modal anchors**

with common-basis bounds

- `[0.0, 0.1516960746046375, 0.4259984472396655, 0.6636852520237706, 0.8893828793887426, 1.0]`

and signed cell masses

- `[0.4209979425921674, -0.2209782644339726, -0.07555691068740665, -0.07747066318903328, -0.04699210428176666]`.

This is the public 5-component vector:

- `H_N`.

## Step 5. Compute Xi on the common-basis vectors

Once `H_S` and `H_N` are fixed, the published diagnostics are computed on this
shared basis:

- `Xi_raw = sum_j R_S^C[j] * R_N^C[j]`
- `Xi_hat = |<R_S^C,R_N^C>| / sqrt(<R_S^C,R_S^C><R_N^C,R_N^C>)`

with published values

- `Xi_raw = 0.3148145037995458`
- `Xi_hat = 0.7589533617835368`
- `Xi_hat_min = 0.751178834903882`.

## What this note settles

- the published Xi values do not appear from nowhere,
- they are computed on a declared 5-component common-basis realization,
- and the public package now exposes the origin of both vectors used in that
  computation.

## What this note does not settle

This note does **not** settle the deeper physics question by itself:

- why the finite-volume response carrier and the cluster-local carrier should
  belong to one true physical parent law.

That remains a stronger scientific question than the numerical derivation
chain itself.
