# Numeric Reproduction Route Note

This note tells a skeptical reader what can be reproduced independently from
the public witness surfaces **without** reopening the whole internal archive.

## Reproducible from the public witness rows

A reader with the common-basis witness rows can independently recompute:

- the 5-component finite-volume vector `H_S`,
- the 5-component cluster-local vector `H_N`,
- `Xi_raw`,
- `Xi_hat`,
- and the declared robustness floor `Xi_hat_min`.

The essential public witness rows are:

- `.../QCT_BRIDGE_BASIS_MAP_MINIMAL_PATCH_RERUN_20260429_MAP_ROWS_V1.tsv`
- `.../QCT_BRIDGE_BASIS_MAP_MINIMAL_PATCH_RERUN_20260429_XI_CANONICAL_ROWS_V1.tsv`
- `.../QCT_BRIDGE_BASIS_MAP_MINIMAL_PATCH_RERUN_20260429_ENGINEERING_TEST_ROWS_V1.tsv`

## What the reader can check directly

From those public rows, the reader can check that:

- the common basis has effective rank `5`,
- `H_S` is explicitly listed,
- `H_N` is explicitly listed,
- `loss_S = 0`,
- `loss_N = 0`,
- `projection_debt = 0`,
- `Xi_raw` matches the published overlap formula,
- and `Xi_hat_min > 0` survives the declared boundary-shift envelope.

## What still remains outside this reproduction route

This independent numeric route does **not** by itself establish:

- the full external physical normalization of the finite-volume carrier,
- the completed transport law of the cluster-local carrier,
- or the final cosmological status of the pair.

It is a public route for reproducing the bridge arithmetic, not a substitute
for later physical adjudication.
