# What Had Already Been Achieved Before Rank 9

## Galaxy-scale line, Apex split, and lensing discipline

- A late QCT galaxy-scale public line was built in English with explicit
  falsifiability, hard reviewer-facing scope, and named reproducible outputs.
- QCT v8.8 hardened the statistical line with Bayesian marginalization,
  stratified reporting, worst-case visibility, and a hard lensing
  discriminator instead of vague numerical optimism.
- The lensing front did not remain only rhetorical: before Rank 9 it had
  already advanced from a single-metric anti-photon-tailoring discriminator to
  an explicit mainline/alt branch policy, no-new-lensing-knob discipline, and
  a formal falsification runbook for later external execution.
- The Apex / CRL branch separated a law-like empirical branch from the earlier
  QCT statistical ceiling instead of blending unlike claims into one paper.
- The galactic line did more than remain favorable against `MOND`; it later
  hardened into a zero-lock anchor, cleared a bounded publication-grade
  empirical gate, and was no longer the main live weakness even while cross-domain
  closure remained explicitly open.
- The Apex / CRL line also advanced into explicit tail-driver localization:
  some broad fit pressure was already being diagnosed as concentrated in a
  small repeatable offender set rather than read immediately as uniform model
  collapse.
- The same late Apex line had also already entered a blind-protocol and
  tamper-evident capsule discipline, making later lensing and benchmark
  execution auditable under pinned environments and explicit unblind guards.
- The late support stack had also already localized the exact cluster/lensing
  frontier honestly: the line was still lawful on a bounded same-kernel family
  and later remained blocked first at same-kernel object-level `gamma_t`
  execution, after the semantic dictionary became explicit and the exact
  blocker was narrowed lawfully.
- Even before that frontier was crossed, the cluster/lensing observable
  vocabulary itself had already been materialized explicitly
  (`phi(R,0), Delta(R), gamma_t(R), DeltaSigma(R)`), with a named contract
  frontier for the later `delta -> gamma_t` execution step.
- The same late support layer later pushed the cluster/lensing reserve into a
  much stronger audit state: a deterministic `127`-case hash anchor, then a
  full `127/127` same-kernel hash-binding manifest, and explicit reserve-bound
  case geometry, so the blocker moved forward from "missing semantics/binding"
  to the narrower absence of one object-level `delta -> gamma_t` execution
  contract.
- The support stack also learned a reserve-promotion quarantine that kept
  hybrid/emulator lanes, visible raw bundles, dormant internal reserve
  bundles, and even fully bound reserve geometry from being misreported as
  current-lane execution.

## Galaxy-scale pressure against particle dark matter and MOND
- The galaxy-scale line had already become explicit about its
  no-particle-dark-matter posture, while still accepting falsification
  conditions rather than hiding behind hand-tailored rescue language.
- The visible v8.x runner line was already pressing toward shared global
  parameters and away from per-galaxy theory knobs, making the galaxy result
  materially stronger than a local rescue fit would have been.
- The Apex branch did not hide the galaxy-scale solver behind fake exactness:
  it labeled the closure as phenomenological, froze conventions, refused extra
  free parameters, and tied the closure to action-consistent spherical
  validation pressure.
- The related lensing line also preserved its own identity shift openly rather
  than burying it under silent branch confusion: the baryon-only branch was
  archived explicitly while the hybrid branch became the frozen mainline.
- A real pre-Rank-9 `MOND` comparison surface existed: the line was not only
  asking whether QCT fit galaxies, but whether it remained ahead of `MOND` on
  the adopted frozen line and whether the deeper law could stay non-reducible
  to the `MOND` family.
- The anti-`MOND` identity question did not remain purely verbal: a later
  morphology-survival white arm was formalized explicitly as a bounded,
  action-root-descended object rather than left as an unstructured residual
  label.
- The same late White-Law line also reached an explicit family-admissibility
  regime: one governed current carrier family was bound, radius-only was
  excluded as the true carrier, and comparative widening was kept blocked
  until real threshold readiness.
- The same broader comparative regime also matured beyond a single-family fog:
  a governed family-admissibility set, explicit current-family and
  alternative-family placeholder slots, explicit comparative inputs, and a
  read-only counterfactual readiness surface were all materialized without
  opening comparative execution.
- The stronger comparative-opening frontier was then made much sharper: the
  threshold-evaluation layer already showed `12` passed classes, `1`
  not-yet-passed class, and a comparative opening held closed by one dominant
  stronger-threshold blocker rather than a cloud of vague reasons.
- The regime also quantified the uplift route honestly: the exact remaining
  pressure gap, exact lawful uplift levers, exact unlawful touch set, and
  local headroom limit were all made explicit while comparison stayed closed.
- Supportive top-rank and cluster-stability structure was also preserved
  explicitly, but only as supportive/watch information; it was not allowed to
  overrule the true stronger-threshold blocker or impersonate opening
  authority.
- Comparative cleanliness itself became explicit too: aliasing classes,
  proxy-risk classes, and low current contamination scores were all made
  visible, yet low proxy risk was still forbidden from being misread as
  comparative-opening permission.
- The future family-selection policy also matured materially: placeholder
  pressure was demoted beneath explicit selectability, structural
  adjudication, early exterior viability, and survivability-through-gates, so
  raw pressure rank could not lawfully choose the next family on its own.
- The same uplift regime also learned how to say something harder than "more
  work is needed": no currently lawful upstream-base recovery path was visible
  while preserving the `12` already passed threshold conditions and the
  remaining local uplift headroom.

## Comparative grammar, support-stack maturity, and outward discipline

- The comparative regime also learned a stronger stop-state grammar: readiness
  was separated from authority, review from truth/release, and comparative
  readiness from comparative execution, with sovereign-only edges kept
  explicit rather than implied.
- Those blocked boundaries were not left as vague cautions either: family comparison,
  scientific truth, and final delivery all appeared in an explicit boundary
  audit, while the Phase-4 closure-pressure surface kept closure descriptive
  only and phase-jump/anti-false-readiness guards active.
- The same regime also gained a real anti-stale/non-regression layer:
  stronger-pressure references, stronger metrics, and blocked comparative-
  surface posture were all checked for drift or desync, and the audit layer
  stayed advisory rather than silently repairing or promoting anything.
- The support stack also learned how to speak outwardly in cleaner physics
  language: the Factory report foundation froze a live six-axis physics
  scoreboard (`MOND`, galactic, lensing, cosmology, cross-domain status, then
  the exact blocker) and explicitly refused repo/process chatter in that line.
- The same late line also learned a stricter novelty discipline: the
  cluster/lensing scoreboard did not treat every rerun as progress, but named
  exact trigger classes that would have to change before a further round could
  count as scientifically new.
- The broader upstream door also matured materially: Academy-side
  qualification, scientific writing, export preparation, and non-binding
  handoff posture were already separated from lab/runtime authority instead of
  being blended into one vague intake surface.
- An earlier archived Q Platform layer had already frozen a deeper platform
  doctrine too: architecture boundary = inputs plus adapter separation,
  explicit no-promotion-by-inference governance, strict run-context and
  return-block discipline, and source-index/hash-backed migration continuity.
- Even the raw-source world had already become more than storage: a control
  tower, Arabic-note signal router, and broader-source routing law were in
  place so later bounded scientific packets could draw from local stock
  without treating evidence possession itself as publication.
- The same support layer had also already matured into a dual-track and
  import-boundary discipline: theory work, factory execution, adapter import,
  and platform consumption were kept separate enough that even negative or
  blocked scientific outcomes could still travel lawfully without canonical
  drift.
- The broader cross-repo layer also stopped being a naming-drift zone: evidence,
  wording, and release posture were being kept aligned tightly enough to block
  naming drift, claim-ceiling drift, and broken packet identity before the
  later public shelf.
- The theory-office layer also became materially real: a bounded reading stack
  already tied together project vision, the official project statement, a
  governing-principle memo, and an honest rank-honesty statement
  that thickened the theory internally without inflating its external stage.

## White Law, stage doctrine, and publication boundary
- White Law also learned a stronger narrowing-cage discipline: operator
  dictionary closure came first, function-class closure came second, and the
  layer explicitly forbade candidate promotion, scientific-truth promotion,
  and branch widening while it narrowed the lawful search space.
- Inside that same manifold, the morphology-residual champion was later pushed
  to a maximally hardened state and marked ready for bounded external
  challenge, with one explicit strongest lawful claim rather than vague
  "best-so-far" language.
- The White-Law layer also learned a stricter root-mapping discipline:
  selected lines were not allowed to masquerade as roots, but were explicitly
  downgraded to derived status until a governed action-root mapping was
  materialized.
- That root discipline later became more concrete: one selected candidate line
  was made equation-level explicit with a frozen `lambda = 0.00625`, while
  still being kept as a derived line under `FMR` rather than promoted into
  white-root identity.
- Solar-System / local-safety recovery was already an explicit measured gate,
  not a later rhetorical promise: the visible line pinned `TG-4` as passed and
  preserved a concrete `epsilon(1 AU)` threshold witness.
- The staged phase doctrine was already explicit: white-law discovery,
  gravitational/lensing lift, cosmology consistency, and final decisive-prediction /
  global-stress testing were separated on purpose rather than blurred into one
  inflated claim.
- The doctrine had also already named the stronger anti-`MOND/QUMOND`
  threshold correctly: a real differential signature beyond fit quality. Just
  as importantly, the line did not falsely present that threshold as already
  closed when a clean public closure witness was not yet visible.
- The program froze a bounded initial publication posture: publish the closed
  core, isolate later lanes, and refuse organizer / warp / final-cosmology
  leakage.
- The same late pre-Rank-9 layer also learned how to form a lawful external
  publication object: a closed core in the main paper, a bounded open-gap
  supplement posture, and an explicit exclusion of unresolved lanes from the
  first deposit body.

## Pre-truth review, qct_core closure, and handoff

- The program also built a substantial pre-truth review stack around a
  candidate equation: governed-claim review, truth-boundary review, and
  sovereign truth-decision review were all materially present, yet scientific
  truth was still held at zero until the remaining execution and authority
  gaps could be crossed lawfully.
- The observable mapping chain itself also tightened materially: the
  `phi -> Delta -> V_model` path was locked under upstream `gamma_m` only,
  so the mapping layer was not being used as a late hiding place for fresh
  local parameters.
- An executable reproducibility line already existed, with packaged scripts and
  acceptance-gate metrics rather than prose-only claims about reproducibility.
- A mature admissibility grammar was also already present: the line could
  distinguish current non-admissibility from fully materialized
  reestablishment conditions, and could distinguish a negative scientific
  outcome from a structural readiness failure.
- Out-of-sample pressure was already being treated seriously: the visible phase
  grammar separated sentinel evidence from holdout admissibility and blocked
  promotion by inference from partial-stage success.
- The later staged out-of-sample layer also preserved a fixed manual six-case
  sentinel core (`NGC6946`, `NGC5055`, `NGC0247`, `NGC5585`, `UGC00128`,
  `NGC2998`) that matched the recurring stress/sentinel memory, so the
  sentinel front was no longer just an arbitrary slice.
- The program also matured into a reviewer-facing `QUMOND` benchmark culture:
  it enforced strict fairness rules, preserved favorable conservative signals
  where they existed, and still kept harsh broad aggregate outcomes visible
  instead of hiding them.
- Even under that harsher later `QUMOND` surface, the preserved interpretive
  memory was not anonymous: recurring stage-top pressure remained visible
  around `NGC0247`, `NGC6946`, and `UGC11914`.
- Honest negative closure was already part of the culture: unsupported inputs
  such as `f_gas` were frozen closed rather than quietly promoted.
- `qct_core` reached a closed scientific posture across `CORE-101..106` after
  the Action-vs-EPIC evidence was materially absorbed.
- The same-source `Action-vs-EPIC` validation path became numerically explicit
  at the level of `phi(r)` and `Delta(r)` with threshold-visible reports.
- The admissibility recovery path was made explicit rather than hidden behind
  wording, including what the old benchmark could no longer lawfully do.
- That recovery path did not stop at generic admissibility language: the
  compare mode, same-source embedding, same-profile identity, support-radius
  convention, boundary/matching contract, `phi -> Delta -> V_model`
  extraction rule, and shared validation window were all frozen explicitly on
  a reestablished canonical same-source benchmark surface.
- `CORE-106` did not merely wait on that surface passively: it later received
  a bound reestablished same-source closure verdict, so the old proxy bridge
  stayed retired while one named lawful path became citable for dossier
  closure.
- The same layer also learned controlled reduction honestly: `EPIC-30` stayed
  phenomenological, the current bridge stayed non-admissible, but the false
  blocker "no lawful same-source path exists beyond the current bridge" was
  explicitly retired.
- Cross-repo convergence itself became explicit: some late closure gaps were
  no longer scientific disagreement, but authority-absorption lag between
  live evidence surfaces and accepted closure wording.

## Final pre-Rank-9 stabilization and handoff

- White Law surfaced as a framework-facing layer with outward scope,
  non-claims, and open-gap discipline, while Rank-8 publication posture was
  stabilized as framework yes, final TOE no, and cosmology completion still
  held closed.
- A canonical Rank-8 to Rank-9 handoff was written explicitly rather than left
  as oral continuity, and the support stack (`Q platform`, `ZamaKan`,
  `Academy Plug`, `Factory V1 Trial`, raw-source layers, and packaging work)
  had already become substantial enough to contribute real closure, evidence,
  and publication discipline.
- By the end of this layer, the program had not yet closed Rank 9, but it had
  already earned the right to say that a serious pre-Rank-9 scientific and
  publication foundation existed.
