# Candidate Equation Lineage Without Root Theft Note

One subtle pre-Rank-9 gain was that the program learned how to expose an
explicit candidate-specific white-equation surface without stealing white-root
 status for that line.

## What became visible

The selected line was not left as a vague favorite or a hidden internal code.
It was given an explicit review-only equation surface:

- `Phi_CALFMB(R) = gamma0*core_auto_linear_filtered_morphology_balance_guard(R)`

with one frozen line-specific mechanism parameter:

- `lambda = 0.00625`

That surface is visible in:

- `candidate_specific_equation_progress_line_v1_status.json`

## Why this mattered

The important point is not only that an explicit candidate equation existed.

The more important point is that the line was kept in its correct place:

- relation class: `derived_from_fmr_root`
- root mapping state: `selected_line_fmr_root_mapping_materialized`
- root identity equivalence: `forbidden__derived_line_is_not_white_root_identity`

This means the program had already learned a difficult discipline:

- make the candidate explicit enough to review,
- freeze its lineage under the canonical `FMR` root,
- and still refuse to promote that candidate line into root identity.

That is a real gain in scientific hygiene.

## What this note does not claim

This note does not claim truth, promotion, closure, or release.

It claims something narrower:

- one candidate line became explicit and reviewable,
- its lineage under the white root was materially locked,
- and root theft was blocked even while the line was made legible.
