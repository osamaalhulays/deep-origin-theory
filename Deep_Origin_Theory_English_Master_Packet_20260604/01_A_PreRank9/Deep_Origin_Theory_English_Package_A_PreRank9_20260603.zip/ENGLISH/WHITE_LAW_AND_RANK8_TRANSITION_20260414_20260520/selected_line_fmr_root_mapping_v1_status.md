# Selected-Line FMR Root Mapping Status

- generated_at_utc: `2026-04-04T18:06:14Z`
- selected_candidate_id: `core_auto_linear_lambda_0p00625_filtered_morphology_balance_variant`
- white_root_id: `FMR`
- mapping_state: `selected_line_fmr_root_mapping_materialized__review_only`
- selected_line_root_mapping_state: `selected_line_fmr_root_mapping_materialized`
- mapping_relation_class: `candidate_specific_operational_projection_under_fmr_root`
- line_parameter_scope_state: `line_specific_parameters_retained_as_derived_only__not_white_root_fundamentals`
- root_identity_equivalence_state: `forbidden__derived_line_is_not_white_root_identity`

## Note
- This packet materializes one review-only mapping from the current selected line to the canonical FMR white root. It confirms that the selected line is a derived operational projection under FMR and that line-specific parameters such as lambda remain derived-line-only, not white-root fundamentals. It does not convert the selected line into the white root, and it does not claim truth, promotion, or closure.
