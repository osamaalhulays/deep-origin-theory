# Root-Mapping And Derived-Line Discipline Note

One of the most important hidden White-Law gains was not just that a
morphology-survival arm was written down.

It was that the line learned how to prevent a selected line from quietly
masquerading as the root.

## 1. What had already been formalized

The fixed-r morphology-survival white material shows that:

- the white object was treated as a descendant of the locked `SPEC-201`
  action root,
- `gamma` and `m` remained the only global theory parameters on that root,
- and any selected line such as `CALFMB` was to be treated only as a derived
  line unless an explicit root-mapping artifact existed.

The later status packet then says something stronger:

- `selected_line_root_mapping_state = selected_line_fmr_root_mapping_materialized`
- but the packet still remains `review_only`
- and the selected line remains downgraded to derived until that mapping is
  read under the governed post-white validation layer.

## 2. Why this matters

This is a real scientific gain because it blocks an easy inflation route:

- finding a strong selected line,
- then quietly speaking as if the selected line were the root,
- and only later discovering that the ascent depended on an unmapped
  derivation chain.

The White-Law layer did not allow that shortcut.

It required:

- explicit descent from the locked action root,
- explicit root-mapping materialization,
- and explicit downgrading of selected lines until that mapping existed.

## 3. What this means for Package A

Package A should not present the White-Law layer merely as:

- "morphology matters."

It should also show that the line had already matured enough to insist on:

- root before selected-line prestige,
- descent before rhetorical ascent,
- and mapping before promotion.

That is one of the clearest anti-self-deception gains in the late pre-Rank-9
history.

## 4. Best short reading

The fairest summary is:

- before Rank 9, the White-Law layer had already learned to keep selected
  lines subordinate to an explicit action-root mapping,
- and that root-mapping discipline was itself a real part of the scientific
  maturation of the program.
