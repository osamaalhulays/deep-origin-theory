# QCT Rank-8 Publish And Nonpublish Bundle

This bundle groups the rank-8 material into the two sides we actually need to handle together:

- `public_release/`
  - outward-facing publication material
- `internal_handoff/`
  - internal adjudication and handoff material

This is the correct "publish vs not-publish" split inside one zip.

It is not itself the external deposit object.
The outward-facing deposit posture is defined inside `public_release/`.

## Editorial status

The `public_release/` side now follows the locked editorial decision:

- official title fixed
- primary category fixed to `gr-qc`
- theory presented as one source-governed framework
- no Theory of Everything claim
- no final observational cosmology claim
