# QCT Rank-8 Public Release Bundle

This is the outward-facing publication package for the current rank-8 layer of QCT.

It follows the final editorial decision that QCT is presented as one theory with one primary arXiv identity, not as a pile of internal workflow fragments.

## Official positioning

- Official English title:
  - `Quantum Curvature Theory: A Source-Governed Framework for Curvature Response and Cosmological Dynamics`
- Official Arabic title:
  - omitted in this Package-A English shelf to keep the reading surface
    English-only; see the original Rank-8 bundle if bilingual title
    preservation is needed
- Primary arXiv category:
  - `gr-qc`

## Claim posture

QCT is presented here as:

- a source-governed theoretical framework
- a locked physical kernel
- a set of auditable response surfaces

QCT is not presented here as:

- a completed theory of everything
- a final observational cosmology
- a post-hoc data patch
- a learned emulator

## Included

- `QCT_WHITE_LAW_FULL_SCIENTIFIC_PAPER_AR_20260414_v1.md`
  - The main theory-facing manuscript draft.
- `QCT_THEORY_OF_EVERYTHING_ELIGIBILITY_GAP_REPORT_AR_20260414_v1.md`
  - Internal source file for the gap report.
  - For external use, this should be framed as:
    - `Supplementary Note S1: Scope, Non-Claims, and Open-Gap Register`
- `EDITORIAL_DECISION_20260520.md`
  - Final editorial framing for title, claim, category, and scope.
- `MANIFEST.json`
  - Machine-readable bundle inventory and deposit posture.
- `DEPOSIT_CHECKLIST.md`
  - Remaining pre-deposit tasks.

## Scope

This package is for public release preparation.

It is intentionally separate from:

- internal adjudication packets
- internal handoff packets
- stage-9 development archives
- unresolved construction chains

## Deposit posture

The core theory manuscript belongs in the main deposit.

The gap report does not belong as a main paper chapter.
It belongs either:

- as a supplementary note
- or as an internal document kept outside the main external deposit

## Naming intent

- `internal handoff bundle` = internal delivery and governance
- `public release bundle` = outward-facing publication package
