# Claim Boundary Card

## What this foundation bundle claims

This bundle claims that the pre-Rank-9 program already achieved a substantial,
publication-ready foundation:

- an explicit late-QCT galaxy-scale public line,
- a real pre-Rank-9 lensing-discipline front with explicit anti-tailoring,
  branch, falsification, and later auditability structure,
- a hardened `qct_core` scientific closure with a same-source recovery path,
  controlled reduction, and bounded closure wording,
- a bounded initial publication posture,
- an explicit staged doctrine and reproducibility/negative-closure discipline,
- a White Law / Rank-8 framework layer,
- an auditable support-and-continuity stack that kept evidence, wording, and
  release posture aligned,
- and a lawful handoff into the Rank-9 front.

## What this foundation bundle does not claim

This bundle does not claim:

- Rank-9 closure,
- Rank-10 observational comparison,
- external lensing confirmation,
- final cosmology,
- completed unification,
- private application or commercial bridge disclosure,
- or a finished replacement for `LambdaCDM`.

## Public reading rule

This bundle should be read as:

- a pre-Rank-9 scientific and publication foundation,
- not as the current Deep Origin Rank-9 shelf,
- and not as the final statement of the whole program.

## Merge rule

If this foundation bundle is later integrated with the Rank-9 shelf:

- the contents of this bundle should become the early foundation chapters,
- and the present Deep Origin Rank-9 shelf should become the next
  chronological layer,
- without forcing the reader to understand later internal bundle labels.
