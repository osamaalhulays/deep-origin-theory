# Pre-Rank-9 English Foundation Bundle

This English-only bundle gathers the major scientific, methodological, and
publication-relevant work that precedes the current Deep Origin Rank-9 shelf.

Its purpose is narrow:

- to preserve the real pre-Rank-9 effort across the screenshot workspaces,
- to make that effort readable as one disciplined sequence,
- and to prepare a future clean integration with the current Deep Origin
  Rank-9 shelf, so a later reader encounters one continuous sequence rather than
  separate internal bundle labels.

## What this bundle contains

- the late QCT public lineage and its galaxy-scale no-particle-dark-matter
  line before the later Deep Origin Rank-9 shelf,
- the Apex / CRL side line, including pre-Rank-9 lensing discipline,
  fair `QUMOND` pressure, bounded galactic hardening, tail-driver
  localization, and blind-protocol auditability,
- the White Law / Rank-8 framework layer, including morphology-survival,
  family-admissibility discipline, candidate/root discipline, and bounded
  external-challenge hardening,
- the `qct_core` closure of `CORE-101..106`, including the same-source
  `Action-vs-EPIC` evidence path, canonical reestablishment, `CORE-106`
  binding, controlled reduction, and cross-repo absorption without semantic
  disagreement,
- the late pre-Rank-9 comparative and admissibility layer, including the
  semantic observable dictionary, reserve auditability, mapping lock,
  stronger-threshold reduction, stop-state grammar, and anti-stale discipline,
- the publication-object layer, including a bounded initial publication
  posture,
  explicit non-claims, and lawful handoff into the Rank-9 front,
- the phase/reproducibility layer, including staged doctrine, executable
  reproducibility, sentinel/holdout discipline, honest negative closure, and
  refusal to counterfeit a not-yet-earned differential-signature separation,
- the support stack contributed by Factory, Academy, Q platform, ZamaKan,
  the archived Q Platform foundation, raw-source, adapter, and
  theory-office workspaces,
- and the cross-repo continuity discipline that kept evidence, wording, and
  release posture aligned across those workspaces.

## What this bundle does not contain

- it does not claim Rank-9 closure itself,
- it does not replace the current Deep Origin Rank-9 shelf,
- it does not claim Rank-10 observational confrontation,
- it does not expose private application systems or commercial bridge
  surfaces,
- and it does not attempt to present the whole program as one already-complete
  cosmology or one final unification result.

## Reading order

1. `START_HERE_FIRST.md`
2. `CLAIM_BOUNDARY_CARD.md`
3. `LAYER_BOUNDARIES_NOTE.md`
4. `PRE_RANK9_FOUNDATION_STATUS.md`
5. `WHAT_HAS_ALREADY_BEEN_ACHIEVED_BEFORE_RANK9.md`
6. `PUBLICATION_OBJECT_DISCIPLINE_NOTE.md`
7. `MOND_AND_DARK_MATTER_KEY_RESULTS_NOTE.md`
8. `QCT_LINEAGE_AND_APEX_20260218_20260228/`
9. `PHASE_ARCHITECTURE_AND_REPRODUCIBILITY_20260228_20260301/`
10. `QCT_CORE_CLOSURE_20260324/`
11. `WHITE_LAW_AND_RANK8_TRANSITION_20260414_20260520/`
12. `PROGRAM_SUPPORT_AND_METHOD_STACK_20260324_20260520/`
13. `SCREENSHOT_REPO_COVERAGE_AND_DECISION_MATRIX.md`
14. `SOURCE_LAYER_INDEX.md`

## Why this bundle matters

Without this foundation layer, an external reader can easily jump from the current
Deep Origin shelf straight into Rank-9 language and assume that everything
before it was minor or merely preparatory. That would misstate the record.

This bundle exists to show that the work before Rank 9 had already produced:

- closed scientific debt rather than only preparation for later shelves,
- a visible pre-Rank-9 galaxy-scale line with real pressure on particle dark
  matter, `MOND`, `QUMOND`, local-safety, and morphology rather than a thin
  fit-only narrative,
- an Apex / CRL branch that had already begun to localize broad fit pressure
  into a small repeatable tail and to move later benchmark/lensing execution
  under blind-protocol and tamper-evident capsule discipline,
- a White-Law / Rank-8 layer that already knew how to narrow the lawful search
  space, freeze candidate/root discipline, and push a current-manifold
  champion to a bounded external-challenge frontier,
- a `qct_core` layer that had already closed real debt through same-source
  evidence absorption, canonical reestablishment, `CORE-106` binding,
  controlled reduction, and late closure wording that could be identified as
  authority-absorption lag rather than scientific disagreement,
- a cluster/lensing front that had already advanced from vague future language
  into an explicit observable dictionary, reserve auditability, and exact
  blocker localization,
- a publication discipline in which the main public paper, the bounded gap
  layer, and the still-open fronts were already being separated lawfully,
- a phase/reproducibility discipline in which executable reproducibility,
  sentinel/holdout boundaries, honest negative closure, and the stronger
  not-yet-closed differential-signature threshold were all already stated
  openly rather than blurred away,
- a support stack that had already become part of scientific rigor through
  reproducibility pressure, admissibility honesty, stop-state grammar,
  physics-first scoreboard discipline, and novelty-trigger discipline,
- a cross-repo continuity layer that kept evidence, wording, and release
  posture aligned rather than letting the work fragment across desktop worlds,
- and a real handoff into the Rank-9 front rather than a vague transition.
