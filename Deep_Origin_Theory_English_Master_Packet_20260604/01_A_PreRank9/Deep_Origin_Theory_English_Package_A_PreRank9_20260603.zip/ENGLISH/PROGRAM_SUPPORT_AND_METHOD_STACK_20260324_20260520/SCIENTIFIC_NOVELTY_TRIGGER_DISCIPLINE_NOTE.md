# Scientific Novelty Trigger Discipline Note

Another quiet gain before Rank 9 is that the program had already learned how
to say when a further round would count as scientifically new, and when it
would not.

## What the scoreboard and theory-input surfaces show

The preserved current-physics scoreboard does not merely restate that the
lensing/cluster frontier is blocked.

It also says that no further round is scientifically new unless one exact
trigger class changes:

- `hard_stop_shift`
- `missing_quartet_change`
- `exclusion_axis_clearance`
- `execution_flip`

The accompanying theory-input index makes the frontier less mystical by naming
the actual primitive pack on which that frontier rests:

- `SameKernelHashBindingManifest`
- `reserve_bound_case_object_geometry_confirmation`
- `SPEC-702_hybrid_lensing_semantics`
- `gamma_t_first_primitives_package`
- `lensing_data_adapter_external_gamma_t_mainline_schema`
- `artifact_emulator_delta_reserve_provenance`

This is visible in:

- `FACTORY_V1_QCT_CURRENT_PHYSICS_SCOREBOARD_V1.md`
- `FACTORY_V1_QCT_THEORY_INPUT_INDEX_V1.md`

## Why this mattered

This is a real maturity gain because the program had moved past a weak loop
like:

- rerun more things,
- refine wording,
- and hope the frontier somehow moved.

Instead it had already reached:

- here are the exact trigger classes that would make a new round scientifically
  meaningful,
- and here is the primitive pack the frontier is actually sitting on.

That protects the program against fake progress and rerun theater.

## What this note does not claim

This note does not claim that any of those trigger classes had already fired.

It claims something narrower:

- the program had already built a discipline for distinguishing real frontier
  movement from repetition,
- and that distinction belongs to the pre-Rank-9 foundation.
