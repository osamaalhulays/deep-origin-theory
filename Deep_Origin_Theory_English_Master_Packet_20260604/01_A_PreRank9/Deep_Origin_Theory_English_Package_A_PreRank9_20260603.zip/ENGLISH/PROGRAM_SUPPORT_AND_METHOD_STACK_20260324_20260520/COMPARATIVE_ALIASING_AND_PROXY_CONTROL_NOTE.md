# Comparative Aliasing And Proxy Control Note

Before Rank 9, the comparative-pressure regime had also already learned a
useful contamination-control lesson:

- even when comparative cleanliness improves, cleanliness alone must not be
  mistaken for comparative opening authority.

## What became explicit

The preserved aliasing/proxy-control surface already bound:

- exact aliasing classes,
- exact proxy-risk classes,
- lawful read-only alias/proxy findings,
- and explicit no-opening guards even under low current contamination scores.

This is visible in:

- `comparative_aliasing_and_proxy_control_layer_status.md`

## Why this mattered

This meant the regime had moved past a vague posture like:

- "the signal looks cleaner, so perhaps the comparison can now open."

Instead it had reached:

- "clean and proxy-sensitive signals are distinguished explicitly,"
- "aliasing risk and proxy leak risk are measured explicitly,"
- and "current cleanliness still does not authorize comparative opening."

That is a real gain because it prevents a common failure mode:

- confusing cleaner comparative diagnostics with lawful comparative execution.

## What this note does not claim

This note does not claim that contamination-control closure had solved the
comparative-opening frontier.

It claims something narrower:

- the regime had already become clean enough to measure aliasing and proxy
  risk explicitly,
- while still refusing to let cleanliness masquerade as opening authority.
