# Family Comparison Pressure Uplift Review Layer Status

- generated_at_utc: `2026-03-19T07:48:10Z`
- regime_name: `AX3_MULTI_FAMILY_COMPARATIVE_PRESSURE_REGIME_V1__FAMILY_COMPARISON_PRESSURE_UPLIFT_REVIEW_ONLY`
- layer_mode: `read_only_only`
- statistical_scope: `AX3_multi_family_comparative_pressure_v1_read_only`
- latest_family_comparison_pressure_uplift_review_ref: `operator/context/registries/family_comparison_pressure_uplift_reviews/family_comparison_pressure_uplift_review__a093871ae9da3fb4.json`
- latest_comparative_opening_boundary_review_ref: `operator/context/registries/comparative_opening_boundary_reviews/comparative_opening_boundary_review__f96c14d72b5b5f51.json`
- uplift_state: `uplift_review_defined_gap_to_stronger_threshold`
- uplift_class_count: `4`
- lawful_uplift_candidate_count: `9`
- unlawful_uplift_candidate_count: `15`
- blocker_to_uplift_map_count: `2`
- current_uplifted_family_comparison_pressure: `0.373`
- remaining_local_uplift_headroom: `0.037`
- required_total_delta_to_stronger_floor: `0.177`
- required_upstream_base_pressure_floor: `0.43`

## Governance Guards
- `read_only_only`: `True`
- `no_comparative_opening`: `True`
- `no_comparative_execution`: `True`
- `no_counterfactual_execution`: `True`
- `no_statistical_pressure_execution`: `True`
- `no_trap_execution`: `True`
- `no_candidate_reopening`: `True`
- `no_reverse_mirror_reopening`: `True`
- `no_truth_authority`: `True`
- `no_release_or_delivery_authority`: `True`

## Summary
- Canonical family-comparison-pressure uplift review layer is now available as a read-only only uplift-review surface. It binds the exact lawful uplift levers, the exact unlawful touch set, and the exact gap between current family_comparison_pressure and the stronger comparative-opening threshold without opening comparison.
