# Reserve-Promotion Quarantine Note

One of the strongest late pre-Rank-9 methodological gains was easy to miss
because it does not look like a result number.

It is the quarantine law that prevented visible reserve material from being
misreported as current-lane execution.

That discipline mattered.

## 1. A visible numeric lane was explicitly excluded

The preserved Round-022 exclusion receipt states that the strongest visible
numeric lane was still:

- a hybrid-lensing lane,
- an artifact/emulator lane,
- and a benchmark/capsule lane,

rather than one current-lane same-kernel object-level `gamma_t` execution
candidate.

Its exclusion axes were named explicitly:

- `hybrid_lane_divergence`
- `artifact_emulator_provenance`
- `capsule_summary_insufficiency`

That is already a strong anti-self-deception move.

## 2. Dormant reserve activation law was absorbed without being promoted

The preserved Round-023 factory learning harvest goes even further.

It explicitly records that:

- future activation law may be absorbed when it becomes visible,
- dormant internal reserve bundles must **not** be promoted to live execution,
- and the factory must distinguish future activation legibility from live
  physics motion.

This is a major scientific-hygiene gain.

It means the program had already learned that:

- "I can now describe a future execution ladder"

is not the same thing as:

- "I already executed that physics on the live lane."

## 3. Raw bundles and reserve geometry were also kept below execution

The same logic continues in later preserved learning harvests:

- visible raw bundles were not allowed to masquerade as object-level
  execution,
- full `127/127` re-derivation was treated as a gate before any reserve
  promotion claim,
- and even full same-kernel hash binding still did **not** count as
  `gamma_t` execution by itself.

So the quarantine law did not vanish when the reserve became stronger.

It hardened with the reserve.

## 4. Why this is a real gain

Weak programs often confuse four different things:

- visible reserve material,
- future activation law,
- replayable bundle structure,
- and current-lane execution.

This program had already learned to keep those categories separate.

That is not clerical neatness.
It is scientific value.

It prevents false promotion at exactly the point where many research lines
begin to lie to themselves.

## 5. Best short reading

The fairest summary is:

- before Rank 9, the support stack had already built a quarantine law strong
  enough to keep hybrid/emulator lanes, dormant reserve bundles, raw bundle
  visibility, and even fully bound reserve geometry from being misreported as
  current-lane execution.

That is a real pre-Rank-9 methodological achievement.
