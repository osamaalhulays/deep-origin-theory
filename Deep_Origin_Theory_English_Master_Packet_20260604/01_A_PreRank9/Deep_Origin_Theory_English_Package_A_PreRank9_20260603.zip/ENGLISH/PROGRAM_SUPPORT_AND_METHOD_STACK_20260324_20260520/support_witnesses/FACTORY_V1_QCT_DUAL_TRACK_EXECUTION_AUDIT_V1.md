# Factory V1 QCT Dual-Track Execution Audit V1

- audit_state: `pass__dual_track_execution_materialized_without_canonicality_drift`
- plugin_telos_state: `pass__qct_plugin_declared`
- theory_input_sync_state: `pass__qct_sources_snapshot_pulled`
- theory_track_state: `pass__theory_track_materialized`
- factory_track_state: `pass__factory_track_materialized`
- feedback_packet_state: `pass__dual_track_feedback_packet_materialized`
- remaining_truth: `awaiting_first_operator_round`
