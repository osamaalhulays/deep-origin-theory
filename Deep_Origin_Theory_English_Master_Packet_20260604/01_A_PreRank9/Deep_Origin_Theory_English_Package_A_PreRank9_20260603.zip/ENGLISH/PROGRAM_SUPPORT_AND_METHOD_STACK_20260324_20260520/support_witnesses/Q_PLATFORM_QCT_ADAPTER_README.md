# QCT Adapter

This adapter is the bounded scientific import boundary between Q Platform and QCT.

It is the first active theory adapter, not the platform core.
It is also a clean plug surface: black-box after inputs, with no public leakage of upstream internal paths.

## What It Contains

- adapter definition and first-user workflow
- adapter-owned scientific producer entrypoints for Debt-1
- imported scientific status surfaces under `adapters/qct/imports/runtime_reports/`
- the adapter import manifest under `adapters/qct/imports/manifests/`
- black-box plug surfaces that expose opaque refs only after inputs
- one adapter self-check surface that states `ready_for_platform` or the precise structural blocker class
- scientific result surfaces that may be negative while the adapter remains structurally ready for platform consumption

It does not contain:

- platform governance truth
- platform queue ownership
- sovereign promotion, closure, or release authority

## First Run

For a first-time user, the intended path is:

1. ensure the external QCT repo and expected Python environment exist
2. run `python3 tools/q_phase16_operator.py active-adapter-debt1-scientific-import-suite-build`
3. run `python3 tools/q_phase16_operator.py active-adapter-admissibility-review-v1-build`
4. run `python3 tools/q_phase16_operator.py debt1-validation-suite-build`
5. inspect `operator/runtime/reports/active_adapter_admissibility_review_v1_status.json`
6. inspect the downstream stage report in `operator/runtime/reports/candidate_equation_progress_resolution_status.json`

## Ready For Work

The adapter is ready for work only when:

- this README exists
- `QCT_ADAPTER_DEFINITION.md` exists
- the adapter import suite entrypoint exists
- the latest import manifest exists
- the first-user workflow commands are declared in the manifest
- the required scientific import surfaces are materialized
- platform admissibility review passes

If any of those conditions fail, the platform must hold and refuse adapter consumption.

A materialized negative scientific result is not, by itself, an adapter readiness failure.
It is a valid adapter output that the platform may consume while escalating the scientific blocker downstream.

The adapter is not considered clean if any public manifest or runtime report exposes absolute source paths, source roots, or raw copy provenance after inputs.
