# Stronger Pressure Readiness Status

- generated_at_utc: `2026-04-04T17:59:57Z`
- regime_name: `AX3_MULTI_FAMILY_COMPARATIVE_PRESSURE_REGIME_V1`
- layer_mode: `read_only_only`
- statistical_scope: `AX3_multi_family_comparative_pressure_v1_read_only`
- latest_family_admissibility_set_ref: `operator/context/registries/family_admissibility_sets/family_admissibility_set__e02440db88ddf7db.json`
- latest_multi_family_comparative_input_ref: `operator/context/registries/stronger_pressure_inputs/multi_family_comparative_input__02b62cd3001b6e57.json`
- latest_stronger_pressure_readiness_record_ref: `operator/context/registries/stronger_pressure_readiness_records/stronger_pressure_readiness_record__e60b2d83ac366abd.json`
- latest_threshold_evaluation_ref: `operator/context/registries/family_comparison_threshold_evaluations/family_comparison_threshold_evaluation__7307d0adadd575f6.json`
- readiness_state: `threshold_defined_not_ready`
- family_comparison_pressure: `0.418`
- candidate_family_comparative_prior: `low`
- top_rank_margin: `0.106`
- rank_cluster_compaction: `0.31`
- cluster_decompression_stability: `0.391`
- family_comparison_surface_allowed: `False`

## Governance Guards
- `read_only_only`: `True`
- `no_execution_authority`: `True`
- `no_candidate_state_authority`: `True`
- `no_truth_authority`: `True`
- `no_release_or_delivery_authority`: `True`
- `no_family_comparison_surface_before_canonical_inputs`: `True`
- `no_family_comparison_surface_without_threshold_ready`: `True`

## Summary
- Canonical stronger statistical-pressure regime threshold is now rebuilt with one final post-binding read-only uplift. The regime is cleaner and stronger, but family-comparison readiness remains blocked until any remaining stronger threshold criteria clear.
