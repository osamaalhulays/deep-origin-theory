# Stage-Aware Family Selection Policy Note

One more hidden gain before Rank 9 is that the program had already learned
that raw comparative pressure cannot be treated as a lawful family-selection
engine.

## What the selection-policy surface says

The preserved `pipeline_v2_selection_policy_v1_status.md` surface does not
propose ranking families by pressure alone.

Instead it records several stronger lessons:

- placeholder pressure is exclusionary unless explicit selectability exists,
- deferred comparative priors must block family ranking,
- fatal structural adjudication must remain upstream of any later Einstein-side
  path,
- early exterior viability must act as a first-class filter,
- and stage survivability matters more than raw pressure rank.

## Why this mattered

This is a real methodological gain because it means the program had already
learned to treat family selection as:

- stage-aware,
- structure-aware,
- and survivability-aware,

rather than as a loose contest of partially prepared pressure scores.

That protects the program against a classic failure:

- choosing the "strongest-looking" family too early and then retrofitting the
  missing structure later.

## What this note does not claim

This note does not claim that a final next-family selection had already been
lawfully opened.

It claims something narrower:

- the policy grammar for future family selection had already become more
  disciplined than raw comparative ranking,
- and that discipline itself belongs to the pre-Rank-9 foundation.
