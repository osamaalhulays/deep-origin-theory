# CORE-104 Mapping Lock Status

- generated_at_utc: `2026-04-04T18:06:14Z`
- delta_mapping_lock_state: `locked_by_code_and_tests`
- v_model_mapping_lock_state: `locked_by_code_and_tests`
- mapping_parameterization_state: `non_parameterized__upstream_gamma_m_only`
- mapping_free_parameter_count: `-1`
- test_artifact_state: `targeted_phase3_mapping_tests_pass`

## Note
- CORE-104 mapping lock is now a governed platform reader over the active adapter scientific import. The platform may read the imported lock state, but it may not execute the mapping verification inline.
