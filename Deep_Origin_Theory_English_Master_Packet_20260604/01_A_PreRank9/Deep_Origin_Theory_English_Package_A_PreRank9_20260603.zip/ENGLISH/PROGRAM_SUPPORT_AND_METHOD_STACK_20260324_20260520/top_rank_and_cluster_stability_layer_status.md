# Top Rank And Cluster Stability Layer Status

- generated_at_utc: `2026-03-19T09:13:05Z`
- regime_name: `AX3_MULTI_FAMILY_COMPARATIVE_PRESSURE_REGIME_V1__TOP_RANK_AND_CLUSTER_STABILITY_LAYER_ONLY`
- layer_mode: `read_only_only`
- statistical_scope: `AX3_multi_family_comparative_pressure_v1_read_only`
- latest_top_rank_and_cluster_stability_ref: `operator/context/registries/top_rank_and_cluster_stability_records/top_rank_and_cluster_stability__bb4943b973010ea5.json`
- latest_multi_family_holdout_topology_ref: `operator/context/registries/multi_family_holdout_topologies/multi_family_holdout_topology__d20140048f50b4af.json`
- stability_state: `rank_cluster_watch_supportive_not_final_blocker_non_authorizing`
- top_rank_class_count: `3`
- cluster_stability_class_count: `3`
- blocker_to_rank_cluster_map_count: `4`
- held_state_class_count: `2`
- family_comparison_pressure: `0.373`
- top_rank_gap: `0.016`
- top_rank_margin: `0.085`
- rank_cluster_compaction: `0.483`
- cluster_decompression_stability: `0.753`

## Governance Guards
- `read_only_only`: `True`
- `no_comparative_opening`: `True`
- `no_comparative_execution`: `True`
- `no_counterfactual_execution`: `True`
- `no_statistical_pressure_execution`: `True`
- `no_trap_execution`: `True`
- `no_candidate_reopening`: `True`
- `no_reverse_mirror_reopening`: `True`
- `no_truth_authority`: `True`
- `no_release_or_delivery_authority`: `True`

## Summary
- Canonical top-rank and cluster-stability layer is now available as a read-only only rank-cluster surface. It shows that current top-rank margin and cluster stability remain supportive, while narrow top-rank gap and near-ceiling cluster compaction stay as watch conditions rather than the final real blocker, because family_comparison_pressure_below_stronger_threshold remains primary.
