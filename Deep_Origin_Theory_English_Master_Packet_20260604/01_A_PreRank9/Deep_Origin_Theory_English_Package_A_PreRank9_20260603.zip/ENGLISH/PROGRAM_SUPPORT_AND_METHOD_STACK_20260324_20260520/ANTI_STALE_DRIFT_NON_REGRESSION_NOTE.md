# Anti-Stale Drift Non-Regression Note

The comparative-pressure regime also gained something easy to miss:

- it became stable enough to audit whether the read-only surfaces were drifting
  away from one another.

## What the anti-stale surface made visible

The preserved anti-stale/drift surface already checks that:

- the stronger-pressure references resolve,
- the threshold-evaluation references resolve,
- the comparative surface remains intentionally unopened,
- the main stronger metrics still match across surfaces,
- and authority posture around `family_comparison_surface_allowed` remains
  aligned.

It also does something healthier than fake cleanliness:

- it reports the exact stale/pair/lineage mismatches still present,
- and it refuses to repair or promote anything by itself.

This is visible in:

- `anti_stale_drift_status.md`

## Why this mattered

This is a real gain because it means the regime had already moved beyond
producing isolated reports.

It could also ask:

- are the surfaces still aligned,
- are the blocked states still blocked everywhere,
- and are the stronger metrics still saying the same thing across layers?

That is anti-regression discipline, not just packet formatting.

## What this note does not claim

This note does not claim that the regime was perfectly clean.

It claims something narrower:

- the program had already become honest and structured enough to detect stale
  refs, pair-binding drift, and lineage desync without turning those findings
  into self-authorized repair or promotion.
