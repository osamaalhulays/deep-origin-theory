# Factory V1 QCT Round 030 Same-Kernel Hash Binding Manifest V1

- `round_id = round_030__same_kernel_hash_binding_manifest`
- `theory_motion_class = same_kernel_hash_binding_manifest_materialization`
- `written_at = 2026-03-27T04:52:44Z`
- `source_hash_match_count = 127/127`
- `exact_hash_match_count = 127/127`
- `reserve_join_match_count = 127/127`
- `object_geometry_matches_point_counts = yes__127_127`
- `ceiling = reserve_bound_objects_are_still_artifact_emulator_provenance_only`

## Theory Result

The live lane is now above one full `SameKernelHashBindingManifest`. The raw
127-case source archive was absorbed lawfully, maxima were materialized, the
retained `features_hash` values were re-derived exactly, and every case now joins
onto one retained reserve slice. The blocker is no longer missing maxima or
missing binding. The blocker is now the absence of one current-lane same-kernel
object-level `gamma_t` execution packet.
