# Comparative Aliasing And Proxy Control Layer Status

- generated_at_utc: `2026-03-19T08:44:28Z`
- regime_name: `AX3_MULTI_FAMILY_COMPARATIVE_PRESSURE_REGIME_V1__COMPARATIVE_ALIASING_AND_PROXY_CONTROL_LAYER_ONLY`
- layer_mode: `read_only_only`
- statistical_scope: `AX3_multi_family_comparative_pressure_v1_read_only`
- latest_comparative_aliasing_and_proxy_control_ref: `operator/context/registries/comparative_aliasing_and_proxy_controls/comparative_aliasing_and_proxy_control__e3258abba20671bd.json`
- latest_comparative_opening_boundary_review_ref: `operator/context/registries/comparative_opening_boundary_reviews/comparative_opening_boundary_review__f96c14d72b5b5f51.json`
- control_state: `controlled_aliasing_and_low_proxy_risk_visible_non_authorizing`
- aliasing_control_state: `controlled`
- aliasing_class_count: `3`
- proxy_risk_class_count: `4`
- lawful_read_only_alias_proxy_finding_count: `5`
- blocker_to_aliasing_map_count: `4`
- family_aliasing_risk: `0.167`
- comparative_proxy_leak_risk: `0.141`

## Governance Guards
- `read_only_only`: `True`
- `no_comparative_opening`: `True`
- `no_comparative_execution`: `True`
- `no_proxy_based_uplift_treated_as_lawful_opening`: `True`
- `no_counterfactual_execution`: `True`
- `no_statistical_pressure_execution`: `True`
- `no_trap_execution`: `True`
- `no_candidate_reopening`: `True`
- `no_reverse_mirror_reopening`: `True`
- `no_truth_authority`: `True`
- `no_release_or_delivery_authority`: `True`

## Summary
- Canonical comparative aliasing and proxy control layer is now available as a read-only only contamination-control surface. It binds exact aliasing and proxy-risk classes, distinguishes structurally clean signals from proxy-sensitive signals, and states that current cleanliness does not authorize comparative opening.
