# Factory V1 QCT Theory Input Index V1

- `round_id = round_031__delta_to_gamma_t_execution_contract_frontier`
- `primary_theory_inputs =`
  - `SameKernelHashBindingManifest`
  - `reserve_bound_case_object_geometry_confirmation`
  - `SPEC-702_hybrid_lensing_semantics`
  - `gamma_t_first_primitives_package`
  - `lensing_data_adapter_external_gamma_t_mainline_schema`
  - `artifact_emulator_delta_reserve_provenance`
