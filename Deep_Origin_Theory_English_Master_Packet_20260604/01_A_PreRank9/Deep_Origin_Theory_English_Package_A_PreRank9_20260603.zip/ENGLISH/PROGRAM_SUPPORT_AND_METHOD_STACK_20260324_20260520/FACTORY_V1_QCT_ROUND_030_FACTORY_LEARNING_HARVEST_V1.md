# Factory V1 QCT Round 030 Factory Learning Harvest V1

- `round_id = round_030__same_kernel_hash_binding_manifest`
- `harvest_class = factory_learning_from_same_kernel_hash_binding_manifest_materialization`
- `written_at = 2026-03-27T04:52:44Z`

## Learned

- source-hash-matched raw archives can lawfully unlock retained bundles without widening the lane
- exact `127/127` re-derivation should be treated as a gate before any reserve promotion claim
- full binding manifest does not by itself equal `gamma_t` execution; provenance walls still matter after geometry is explicit
