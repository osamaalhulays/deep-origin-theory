# Factory V1 QCT Round 029 Deterministic Case Hash Anchor Confirmation V1

- `round_id = round_029__deterministic_case_hash_anchor_confirmation`
- `theory_motion_class = deterministic_case_hash_anchor_confirmation`
- `motion_result = feature_hash_generation_law_visible__127_case_to_hash_pairs_stable__full_127_rederivation_still_blocked_by_missing_case_arrays`
- `plugin_id = qct__cluster_lensing__phase1_dual_track`

## Physics Result

- `feature_vector_schema = [gamma, m_eV, R_max, v_bar_max]`
- `feature_hash_function = sha256__canonical_float64_bytes`
- `unique_cases_count = 127`
- `stable_case_to_hash_pairs_count = 127`
- `seed_count = 5`
- `visible_case_arrays_present = no`
- `visible_case_maxima_present = no`
- `full_127_rederivation_possible_now = no`
- `minimum_missing_primitive = case-level R_max and v_bar_max or raw case arrays under the same manifest anchor`
- `first_hard_stop = executed_same_kernel_numeric_emission_to_gamma_t`

## Honest Meaning

This round completed honestly by proving that the visible release already
contains one stable deterministic `case_id -> features_hash` anchor, but still
does not contain the case-level numeric inputs needed for one full `127/127`
re-derivation.
