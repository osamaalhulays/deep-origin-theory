# Governed Stop-State Surface

- generated_at_utc: `2026-03-17T17:19:36Z`
- stop_state_class: `foundation_active_governed_stop_visibility`
- charter_status: ``CANONICAL / GOVERNED / FOUNDATION_ACTIVE``
- permissions_matrix_status: ``CANONICAL / GOVERNED / FOUNDATION_ACTIVE``
- stop_rule_class_count: `8`
- sovereign_edge_count: `9`
- boundary_count: `6`

## Active Stop Conditions
- `current_candidate_parked_line_freeze`: `active` — current candidate is parked cleanly and may not reopen without explicit sovereign decision
- `rtoosh_execution_lock_active`: `active` — RTOOSH remains under active execution lock and may not reopen at pack level by inference
- `promotion_by_inference_forbidden`: `active` — promotion by inference remains a hard stop and may not be smuggled through review or readiness language
- `recommendation_is_not_sovereign_action`: `active` — platform may recommend; sovereign alone may approve, reopen, promote, or release
- `readiness_is_not_authority`: `active` — readiness may measure proximity only; it may not grant surface-opening, execution, truth, or release authority
- `review_is_not_truth_release_or_closure`: `active` — review may restrict claims; it may not promote scientific truth, release, deliver, or close law
- `comparison_readiness_is_not_comparative_execution`: `active` — even if a family-comparison readiness surface later becomes lawful, comparative execution remains separately blocked unless explicitly opened

## Advisory Readings
- `canonical_governance_foundation_status`: `active` — operator charter and permissions matrix are canonical and foundation-active for authority hardening
- `stop_rules_registry_status`: `active` — 8 governed stop classes are registered as machine-readable hard stops
- `sovereign_edge_registry_status`: `active` — 9 sovereign-only edges remain reserved outside platform enactment
- `authority_boundary_registry_status`: `active` — 6 authority boundaries are active, including parked-line freeze and readiness-vs-authority separation

## Sovereign Edges
- `task_approval_clearance`: owner=`sovereign_only`, enact=`False`
- `parked_line_reopen`: owner=`sovereign_only`, enact=`False`
- `family_comparison_surface_open`: owner=`sovereign_only`, enact=`False`
- `comparative_execution_open`: owner=`sovereign_only`, enact=`False`
- `counterfactual_execution_open`: owner=`sovereign_only`, enact=`False`
- `candidate_state_change`: owner=`sovereign_only`, enact=`False`
- `scientific_truth_promotion`: owner=`sovereign_only`, enact=`False`
- `release_delivery_closure`: owner=`sovereign_only`, enact=`False`
- `governance_rule_change`: owner=`sovereign_only`, enact=`False`

## Lawful Next Non-Executive Posture
- `keep_current_candidate_parked`: `lawful_now` — preserve the current candidate as parked cleanly and do not reopen by inference
- `keep_rtoosh_execution_locked`: `lawful_now` — preserve RTOOSH execution lock and do not treat deferred/reference packs as executable now
- `continue_read_only_governance_review`: `lawful_now` — continue canonical/advisory governance review surfaces only, without opening execution, truth, release, or reopening authority
- `advance_platform_maximization_only_through_authorized_packets`: `lawful_now` — advance Platform Maximization through explicit sovereign-authorized read-only foundation packets only

## Note
- Governed stop-state surface is advisory only. It may separate hard stops, sovereign edges, and lawful next non-executive posture, but it may not clear stops, grant authority, reopen lines, execute, promote, release, or deliver.
