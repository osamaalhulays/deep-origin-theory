# Anti-Stale / Drift Status

- generated_at_utc: `2026-04-04T18:00:07Z`
- overall_status: `warn`
- stale_ref_issue_count: `1`
- report_drift_issue_count: `0`
- pair_binding_issue_count: `4`
- id_ref_alignment_issue_count: `0`
- lineage_desync_issue_count: `2`

## Stale Ref Checks
- `cross_engine_latest_engineering_input_ref_exists`: `pass` — latest_engineering_input_ref resolves to an existing artifact
- `cross_engine_latest_statistical_input_ref_exists`: `pass` — latest_statistical_input_ref resolves to an existing artifact
- `cross_engine_latest_interpretation_record_ref_exists`: `pass` — latest_interpretation_record_ref resolves to an existing artifact
- `statistical_pressure_latest_pressure_input_ref_exists`: `pass` — latest_pressure_input_ref resolves to an existing artifact
- `statistical_pressure_latest_pressure_readiness_record_ref_exists`: `pass` — latest_pressure_readiness_record_ref resolves to an existing artifact
- `statistical_pressure_latest_comparative_surface_ref_empty`: `pass` — latest_comparative_surface_ref is intentionally empty in both registry and report
- `counterfactual_surface_latest_counterfactual_surface_ref_exists`: `pass` — latest_counterfactual_surface_ref resolves to an existing artifact
- `stronger_pressure_latest_family_admissibility_set_ref_exists`: `pass` — latest_family_admissibility_set_ref resolves to an existing artifact
- `stronger_pressure_latest_multi_family_comparative_input_ref_exists`: `pass` — latest_multi_family_comparative_input_ref resolves to an existing artifact
- `stronger_pressure_latest_stronger_pressure_readiness_record_ref_exists`: `pass` — latest_stronger_pressure_readiness_record_ref resolves to an existing artifact
- `stronger_pressure_latest_threshold_evaluation_ref_exists`: `pass` — latest_threshold_evaluation_ref resolves to an existing artifact
- `platform_ceiling_cross_engine_ref_match`: `fail` — platform ceiling latest cross-engine reference mismatch: left='operator/context/registries/cross_engine_interpretations/cross_engine_interpretation_record__1270c5d25ef4b276.json' right='operator/context/registries/cross_engine_interpretations/cross_engine_interpretation_record__039afe6a4593ef97.json'

## Report Drift Checks
- `cross_engine_agreement_state_match`: `pass` — cross-engine agreement_state matches
- `cross_engine_decision_code_match`: `pass` — cross-engine decision_code matches
- `cross_engine_response_level_match`: `pass` — cross-engine response_level matches
- `statistical_decision_code_match`: `pass` — statistical decision_code matches
- `statistical_counterfactual_probe_readiness_match`: `pass` — statistical counterfactual_probe_readiness matches
- `statistical_family_comparison_pressure_match`: `pass` — statistical family_comparison_pressure matches
- `counterfactual_decision_code_match`: `pass` — counterfactual decision_code matches
- `counterfactual_probe_readiness_match`: `pass` — counterfactual probe readiness matches
- `stronger_family_comparison_pressure_match`: `pass` — stronger family_comparison_pressure matches
- `stronger_candidate_family_comparative_prior_match`: `pass` — stronger candidate_family_comparative_prior matches
- `stronger_top_rank_margin_match`: `pass` — stronger top_rank_margin matches
- `stronger_rank_cluster_compaction_match`: `pass` — stronger rank_cluster_compaction matches
- `stronger_cluster_decompression_stability_match`: `pass` — stronger cluster_decompression_stability matches
- `stronger_family_comparison_surface_allowed_match`: `pass` — stronger family_comparison_surface_allowed matches
- `authority_posture_family_comparison_surface_allowed_match`: `pass` — authority posture family_comparison_surface_allowed matches

## Pair Binding Checks
- `current_context_matches_latest_task_compiled_context`: `fail` — current compiled context id vs latest cleared task compiled context id mismatch: left='d88174cb4fa9' right='20067c8d0a1a'
- `current_compiled_context_ref_exists`: `pass` — current compiled context path exists
- `current_run_card_ref_exists`: `pass` — current run-card path exists
- `run_card_source_compiled_context_matches_current`: `fail` — run-card source compiled context id vs current compiled context id mismatch: left='20067c8d0a1a' right='d88174cb4fa9'
- `compiled_context_target_candidate_matches_task`: `fail` — compiled context target candidate vs latest task target candidate mismatch: left='core_auto_linear_lambda_0p00625_filtered_morphology_balance_variant' right='B1P3A'
- `run_card_target_candidate_matches_task`: `pass` — run-card target candidate vs latest task target candidate matches
- `compiled_context_target_round_matches_task`: `fail` — compiled context target round vs latest task target round mismatch: left='candidate-equation-round--same-line-vertical-pressure-execution-selected-line-core-auto-linear-lambda-0p00625-filtered-morphology-balance-variant' right='candidate-equation-round--same-line-vertical-pressure-execution-b1p3a'
- `run_card_target_round_matches_task`: `pass` — run-card target round vs latest task target round matches
- `compiled_context_governance_scope_matches_run_card`: `pass` — compiled context governance scope vs run-card governance scope matches

## Id Ref Alignment Checks
- `cross_engine_interpretation_record_id_alignment`: `pass` — reference suffix aligns with payload record_id
- `statistical_pressure_record_id_alignment`: `pass` — reference suffix aligns with payload record_id
- `counterfactual_surface_id_alignment`: `pass` — reference suffix aligns with payload surface_id
- `family_admissibility_set_id_alignment`: `pass` — reference suffix aligns with payload admissibility_set_id
- `multi_family_comparative_input_id_alignment`: `pass` — reference suffix aligns with payload input_id
- `stronger_readiness_record_id_alignment`: `pass` — reference suffix aligns with payload record_id
- `stronger_threshold_evaluation_id_alignment`: `pass` — reference suffix aligns with payload evaluation_id

## Lineage Desync Checks
- `counterfactual_anchor_candidate_matches_cross_engine`: `pass` — counterfactual current candidate vs cross-engine target candidate matches
- `counterfactual_anchor_family_matches_cross_engine`: `fail` — counterfactual current family id vs cross-engine family id mismatch: left='fixed_r_morphology_residual_form' right=''
- `counterfactual_anchor_object_matches_cross_engine`: `pass` — counterfactual current object id vs cross-engine object id matches
- `family_admissibility_anchor_candidate_matches_cross_engine`: `pass` — family admissibility current candidate vs cross-engine target candidate matches
- `family_admissibility_anchor_family_matches_cross_engine`: `fail` — family admissibility current family id vs cross-engine family id mismatch: left='fixed_r_morphology_residual_form' right=''
- `family_admissibility_anchor_object_matches_cross_engine`: `pass` — family admissibility current object id vs cross-engine object id matches
- `multi_family_input_family_admissibility_ref_matches_registry`: `pass` — multi-family input family_admissibility_set_ref vs stronger registry latest family_admissibility_set_ref matches

## Note
- Anti-stale/drift status is advisory only. It may detect stale refs, pair-binding drift, latest-vs-current confusion, ref/id mismatch, and silent lineage desynchronization, but it may not repair, reopen, execute, promote, release, or deliver anything.
