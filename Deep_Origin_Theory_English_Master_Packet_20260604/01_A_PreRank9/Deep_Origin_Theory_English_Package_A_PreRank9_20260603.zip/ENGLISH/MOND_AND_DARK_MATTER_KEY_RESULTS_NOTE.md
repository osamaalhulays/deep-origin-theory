# MOND And Dark-Matter Key Results Note

This note gathers one of the most important pre-Rank-9 result families into a
single reader-facing place.

Without it, the evidence is present but too scattered.

## 1. What the pre-Rank-9 line was already saying about particle dark matter

The late QCT galaxy-scale public line was already explicit about its intended
physical posture:

- it aimed to reproduce galaxy rotation curves **without particle dark matter**,
- it did so through a baryon-sourced modification rather than a hidden dark
  sector,
- and it refused a hand-tailored two-metric photon patch.

The strongest early English statement of that posture appears in `QCT_v8_3`,
which presents:

- a single-metric covariant bookkeeping,
- a massive-matter-sector modification,
- and a falsifiable lensing discriminator in which lensing tracks baryons while
  dynamics may differ.

The later Apex line did not simply drop this front.
It hardened it into an explicit branch discipline:

- `OptionA(Mainline)` vs `OptionB(Alt)`,
- no hidden branch mixing,
- no new lensing parameters,
- and a formal falsification gate for later external execution.

This is not a final cosmology claim. It is a serious galaxy-scale no-particle-
dark-matter research line with explicit falsification conditions.

Just as importantly, this bundle should not be misread as if it had already
closed the strongest historical cluster-scale objections to `MOND`-like
alternatives.

In particular, it does **not** claim that pre-Rank-9 work had already settled:

- Bullet Cluster,
- galaxy-group scale objections,
- or early-universe fronts such as `CMB` / `BAO`.

Those remain outside the lawful claim boundary of this bundle.

## 2. What the pre-Rank-9 line had earned against MOND

The package contains more than one distinct `MOND` / `QUMOND` result layer.

### Layer A: fair statistical comparison

The late QCT statistical line already insisted on:

- fair comparison to `MOND`,
- worst-case rather than average-only reporting,
- and conservative uncertainty handling.

That matters because it means `MOND` was not being treated as a straw opponent.

### Layer B: adopted-line scoreboard advantage

A later frozen pre-Rank-9 physics scoreboard explicitly reports that the
adopted galactic anchor was still ahead of `MOND` on the selected line:

- `holdout delta = -0.1015304918243296`
- `full delta = -0.0049032025474169405`

and the strongest supporting rerun remained favorable:

- `holdout = -0.09938244625451276`
- `full = -0.0037438311206046127`

This should be read carefully.

It does **not** mean that the entire long-range scientific case against `MOND`
was already completed. It means that, on the adopted frozen galactic line, the
program had a live scoreboard surface that still read as favorable against
`MOND`.

### Layer B2: the galactic line stopped being the live weakness

The later support layer also records a quieter but very important change in
status:

- the galactic anchor became `COMPLETE_ZERO_LOCK_HARDENED`,
- the local proxy window was killed and frozen in rejection memory,
- and a bounded publication-grade empirical gate was marked cleared.

That does **not** mean final victory over `MOND`, halo closure, or cross-domain
completion.

It means something narrower and important:

- by that late pre-Rank-9 stage, the galactic line was no longer best read as
  the live weak leg of the program.

The unresolved pressure had already moved outward.

### Layer C: benchmark honesty under a harder `QUMOND` surface

The package also preserves a later and harder gain:

- a strict `QUMOND` benchmark plan with locked fairness rules,
- a production-ready benchmark path with transparent parameter counting,
- and visible aggregate outputs even when the broader run became harsh.

That broader surface should not be misread as a victory line.

Its value is different:

- it proves that the program did not protect itself by weakening the opponent,
- and it kept a reviewer-facing benchmark culture alive even when that benchmark
  became painful.

The benchmark surface is also more decomposable than a cold first reading may
suggest.

The safest current count reading is:

- `175` unique valid cases,
- expanded into `875 = 175 x 5` seeded report rows at the multiseed layer,
- while the surviving `880` counter belongs to an older summary layer rather
  than to hidden extra benchmark rows in the preserved later archive.

Later preserved interpretive surfaces also show that this harsher benchmark was
not an anonymous statistical fog.

A stable recurring panel remained visible across the surviving memory:

- `NGC0247` at the sentinel front,
- `NGC6946` at the holdout front,
- `UGC11914` at the fullset front.

In one preserved Compass surface, each of these names recurred `5/5` times at
its stage top-case position.

At the sentinel front specifically, `NGC0247` now reads as the cleanest
current named spear rather than as one offender among many.

That still falls short of a full reviewer-grade causal decomposition of the
aggregate `QUMOND` surface.

But it does matter, because it shows that the broad harshness was already being
read as structured tail pressure rather than as a completely opaque collapse.

### Layer D: morphology-survival formalization

The deeper identity question also progressed further than a fit scoreboard.

The morphology problem was later advanced
into an explicit white-arm formalization in which morphology is treated as what
survives after the radius-only explanatory subspace is projected out.

That is not final proof of non-reducibility to the `MOND` family.

But it is also not empty rhetoric.

It is a real step from:

- "morphology must matter,"

to:

- "a morphology-survival white object has been formalized explicitly under the
  action-root discipline."

## 3. What the program itself said would count as the real MOND separation

The deeper pre-Rank-9 doctrine did not stop at "better fit than `MOND`".

It explicitly stated that the stronger identity test would be:

- non-reducibility to the `MOND` family,
- persistence of morphology as a necessary ingredient,
- holdout / sentinel / safety success,
- and local high-acceleration safety.

In other words, the program already knew that:

- beating `MOND` numerically is valuable,
- but escaping reduction to `MOND` is the more important scientific threshold.

This also means the bundle does **not** yet present one named galaxy plus one
named measured observable as a public non-reducibility witness against
`MOND/QUMOND`.

It preserves the threshold correctly, and it preserves real pressure toward
that threshold, but it does not pretend the final per-galaxy closure had
already been earned here.

The later staged export surfaces also kept that boundary honest explicitly:

- no `MOND` reducibility claim without an explicit test result,
- and no `CMB` / `BAO` / `LSS` readiness claim at this layer.

## 4. Local-safety discipline also mattered

The pre-Rank-9 line did not only chase galaxy-scale wins.

It also treated local recovery as a gate:

- clean return to Newton,
- Solar-System limit recovery,
- and no obvious local breakdown before any later lift to lensing or cosmology.

That is why the package includes repeated emphasis on:

- `local-safety`,
- `Limit Recovery (Solar System)`,
- and pinned reproducibility around that gate.

## 5. Best short reading

The cleanest fair summary is:

- before Rank 9, the program already had a serious galaxy-scale line that tried
  to avoid particle dark matter without hand-tailored photon rescue,
- it was already pushing that line under global-parameter rather than
  per-galaxy rescue discipline,
- it already had visible comparative pressure against `MOND`,
- it later accepted a harder and fairer `QUMOND` benchmark surface without
  hiding harsh aggregate outcomes,
- it also turned the lensing question into a governed discriminator front
  rather than a last-minute rescue surface,
- and it had already identified the stronger scientific threshold as
  non-reducibility plus morphology necessity, not fit vanity alone.

That is a real achievement.

It is still narrower than final cosmology, narrower than Rank 9 closure, and
far narrower than Rank 10 observational confrontation.
