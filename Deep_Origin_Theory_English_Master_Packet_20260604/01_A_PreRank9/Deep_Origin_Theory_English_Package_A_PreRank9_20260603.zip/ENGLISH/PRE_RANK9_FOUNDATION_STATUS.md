# Pre-Rank-9 Foundation Status

This note marks, plainly, where this bundle stops and where the current
Rank-9 shelf begins.

## What is treated as closed here

Inside this bundle, the following are treated as already achieved before the
Rank-9 public shelf:

- the late QCT galaxy-scale public line, together with its split from the
  separate Apex / CRL branch,
- the explicit staged doctrine that already reserved cosmology consistency and
  decisive-prediction work for later stages,
- the pre-Rank-9 galaxy-scale key-result surface on no-particle-dark-matter
  posture, `MOND` / `QUMOND` pressure, global-parameter discipline,
  local-safety discipline, bounded galactic hardening, tail-driver
  localization, and blind-protocol/tamper-evident auditability,
- the pre-Rank-9 lensing front as a governed discriminator line, including
  branch/falsification discipline, frontier localization, semantic observable
  dictionary materialization, reserve auditability, and reserve-promotion
  quarantine,
- the White-Law / Rank-8 framework layer, including morphology-survival
  formalization, lawful narrowing-cage discipline, candidate/root discipline,
  family-admissibility discipline, and bounded external-challenge hardening
  inside the current manifold,
- the comparative/admissibility regime, including multi-family scaffolding,
  stronger-threshold reduction, lawful-uplift quantification, supportive
  non-authorizing signals, aliasing/proxy control, stage-aware family
  selection, upstream-base honesty, governed stop-state, boundary audit, and
  anti-stale/non-regression discipline,
- the support-stack outward grammar, including physics-first scoreboard,
  scientific-novelty trigger, Academy boundary, raw-source control-tower
  discipline, dual-track/import-boundary discipline, cross-repo continuity,
  theory-office synthesis, and an archived platform doctrine around input
  boundaries, no-promotion-by-inference, return-block discipline, and
  source-index continuity,
- the executable reproducibility, honest negative-closure, local-safety, and
  sentinel/holdout discipline that blocked promotion by inference, including
  preserved memory of a fixed manual six-case sentinel core rather than an
  arbitrary out-of-sample slice,
- the `qct_core` scientific closure of `CORE-101..106`, together with the
  same-source `Action-vs-EPIC` evidence path, canonical reestablishment,
  `CORE-106` binding, controlled reduction, and cross-repo absorption of live
  evidence without semantic disagreement, including late authority-absorption
  lag between live evidence and accepted closure wording,
- the late pre-Rank-9 publication-object discipline in which the main public
  paper, bounded supplementary gap layer, and nonpublishable open fronts were
  separated explicitly,
- the bounded initial publication posture,
- the pre-truth review-stack and non-parameterized mapping lock around the
  candidate equation and the `phi -> Delta -> V_model` chain, with `16` of
  `18` visible pre-truth conditions already satisfied while two
  truth-transition conditions remained explicitly open,
- and the Rank-8 to Rank-9 canonical handoff posture.

## What is not treated as closed here

This bundle does not treat as closed:

- the current Deep Origin Rank-9 public closure,
- the pre-observational cosmology kernel as finally packaged in the later
  Rank-9 bundle,
- the first lawful `H(z)` / `E(z)` / distance confrontation,
- any public galaxy-group or Bullet-Cluster-style resolution claim,
- Pantheon+, BAO, or CMB-facing comparison work,
- any live Rank-10 lane,
- or any private application or commercial bridge surface.

That explicit exclusion includes the historical Bullet-Cluster objection as a
named unresolved front rather than a silently forgotten one.

## The exact boundary

This foundation bundle stops at the line:

- `publish_rank8_now = True`
- `publish_as_final_toe_publicly = False`
- `next_front = cosmology_completion`

In other words:

- the framework layer is stabilized,
- the staged doctrine already says that final decisive-prediction and full
  cosmology claims belong later,
- the cosmology front is still held closed,
- and the next major work is identified but not yet claimed as completed.

That is the last lawful point of this bundle's claim boundary.

## Why this boundary matters

It prevents two errors:

- under-crediting the work before Rank 9 as if nothing serious was closed,
- and over-claiming Rank-9 or Rank-10 work that belongs to a later shelf.
