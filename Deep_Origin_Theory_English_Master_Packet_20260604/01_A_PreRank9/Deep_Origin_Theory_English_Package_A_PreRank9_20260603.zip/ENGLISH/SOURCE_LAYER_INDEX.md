# Source Layer Index

This package is a curated English reading shelf built from multiple desktop
workspaces. The list below states the main source families behind each major
section.

## Root bundle notes

- `README.md`
- `START_HERE_FIRST.md`
- `CLAIM_BOUNDARY_CARD.md`
- `PRE_RANK9_FOUNDATION_STATUS.md`
- `WHAT_HAS_ALREADY_BEEN_ACHIEVED_BEFORE_RANK9.md`
- `PUBLICATION_OBJECT_DISCIPLINE_NOTE.md`
- `LAYER_BOUNDARIES_NOTE.md`
- `MOND_AND_DARK_MATTER_KEY_RESULTS_NOTE.md`
- `SCREENSHOT_REPO_COVERAGE_AND_DECISION_MATRIX.md`
- `SOURCE_LAYER_INDEX.md`
- `PACKAGE_A_TO_PACKAGE_B_CONTINUITY_NOTE.md`

Primary source families:

- `QCT 2026`
- `QCT_Apex_Repo_Run`
- `ZamaKan`
- `Q platform`
- `Q Platform Archive (كيو بلاتفورم الارشيف)`
- `World of Q Map (خريطة عالم Q)`
- `Academy Plug`
- `Factory V1 Trial`
- `Raw Sources (مصادر خام)`
- `Library (مكتبتي)`

## `QCT_LINEAGE_AND_APEX_20260218_20260228/`

Primary sources:

- `QCT 2026`
- `QCT_Apex_Repo_Run`
- `Q platform` (for the preserved B1Y sentinel witness route)

This section preserves the pre-Rank-9 lensing-discipline witnesses from the
Apex line:

- single-metric anti-tailoring public language,
- LG-1 mainline/alt branch policy,
- LG-2 shear-pipeline specification,
- LG-3 falsification runbook,
- and the explicit identity-change record that archived baryon-only lensing as
  an alt branch rather than silently rewriting history.

## `QCT_CORE_CLOSURE_20260324/`

Primary sources:

- `ZamaKan`
- `Q platform`
- `Academy Plug`

Role emphasis:

- `ZamaKan` supplies accepted closure posture, lineage hygiene, and final
  closure wording,
- `Q platform` supplies same-source evidence, contracts, and benchmark-path
  materialization,
- `Academy Plug` supplies initial-publication boundary and bounded publication
  discipline.

## `PHASE_ARCHITECTURE_AND_REPRODUCIBILITY_20260228_20260301/`

Primary sources:

- `QCT 2026`
- `QCT_Apex_Repo_Run`
- `Q platform`

Role emphasis:

- `QCT 2026` supplies the staged doctrine and early public-phase framing,
- `QCT_Apex_Repo_Run` supplies sentinel/holdout, fair-pressure, and
  negative-closure discipline under live program pressure,
- and `Q platform` supplies executable reproducibility and supporting
  continuity surfaces.

## `WHITE_LAW_AND_RANK8_TRANSITION_20260414_20260520/`

Primary sources:

- `Q platform`
- `World of Q Map (خريطة عالم Q)`
- `Library (مكتبتي)`
- `Adapter (الادابتور)`
- current `Keystone II` English shelf for outward continuity only

Role emphasis:

- `Q platform` supplies the working law-search, admissibility, and candidate
  lineage material,
- `World of Q Map (خريطة عالم Q)` supplies the bounded public Rank-8 release
  posture and handoff framing,
- `Library (مكتبتي)` supplies preserved source originals behind the white-law
  and open-gap layer,
- and `Adapter (الادابتور)` supplies continuity-preserving staging and
  archival mirroring into the present package.

## `PROGRAM_SUPPORT_AND_METHOD_STACK_20260324_20260520/`

Primary sources:

- `Factory V1 Trial`
- `Academy Plug`
- `Q platform`
- `Q Platform Archive (كيو بلاتفورم الارشيف)`
- `ZamaKan`
- `Raw Sources (مصادر خام)`
- `Adapter (الادابتور)`

Role emphasis:

- `Factory V1 Trial` supplies physics-first scoreboard and blocker wording,
- `Q platform` supplies contract, admissibility, and observable-surface
  material,
- `Q Platform Archive (كيو بلاتفورم الارشيف)` supplies early architecture,
  governance, input-boundary, run-context, return-block, and source-index
  doctrine,
- `ZamaKan` supplies authority/wording hygiene,
- `Raw Sources (مصادر خام)` supplies evidence-feed continuity,
- and `Adapter (الادابتور)` supplies bundle identity, staging continuity, and
  archival preservation.

Private application and commercial bridge systems are intentionally omitted
from this source index because they are outside the public scientific
foundation layer of this bundle.
