# Division Table For Targets Across Phases 2–5

| Target | Short description | Why this phase, and not another one? |
|---|---|---|
| Extract a white law | Turn Phase 1 from a black box into an explicit law | No gravity or cosmology can be built on top of a black box; this is the first logical requirement after Phase 1 |
| Reduce the parameter count | Prevent complexity inflation and curve-fitting accusations | This must be settled early, because parameter inflation contaminates everything that follows |
| Test reducibility to `MOND` | Ask whether the law is only a disguised `ν(a_N)` | This is a question about the law's identity, so its natural place is Phase 2 |
| Test morphology dependence | Ask whether baryonic structure is genuinely required for prediction | This is a purely galactic property and should be settled before lensing and cosmology |
| Produce a differential signature | Find a predictive difference absent in `MOND/QUMOND` | Without such a difference, later stages have no strategic point |
| Holdout / Safety / Sentinel | Show that the law generalizes rather than memorizes | Theory promotion is not meaningful before basic predictive honesty is shown |
| Local high-acceleration safety | Return cleanly to Newton and avoid damaging the Solar System | This must be checked before lifting the theory into lensing or relativistic form |
| Define an effective potential | Prepare the law to act on light and spacetime | Lensing cannot be calculated without an effective potential, so this begins in Phase 3 |
| Compute lensing | Test the law on light, not only on stars | This is the first genuinely gravitational test after galactic success |
| Test galaxy lensing | Compare deflection predictions to real lensing data | Cosmology should not be entered before local or galactic lensing is settled |
| Re-test local safety after the upgrade | Confirm that the new formulation did not damage local physics | Lensing or relativistic upgrades can re-break local limits |
| Preliminary cluster analysis | Measure how serious the crisis is beyond galaxies | Clusters are harder than galaxies, but still earlier than full cosmology |
| Build a cosmic expansion model | Derive `H(t)` from the theory | Cosmology should not open before a gravitational or lensing structure exists that can be lifted |
| Test `CMB` | Ask whether the theory can live in the early universe | This is an explicitly cosmological test and does not belong to Phase 2 or 3 |
| Test `BAO` | Ask whether baryonic structure survives on cosmic scales | This belongs to expansion and large-scale structure, not to single-galaxy dynamics |
| Structure growth | Study galaxy and cluster formation from perturbations | This requires a cosmological framework and therefore belongs to Phase 4 |
| Large-scale galaxy distribution | Compare against the observed cosmic web | This is a global cosmological test and should not precede cosmic-model construction |
| Smoking-gun prediction | A decisive observable separating the theory from `ΛCDM` and `MOND` | It is not trustworthy until the minimum cosmological construction is complete |
| Global stress test | One test spanning all scales | It is neither fair nor useful before the previous stages are complete |
| Full comparison with `ΛCDM` | Compare the complete program against the standard model | This is a final comparison and should not precede program completion |
| Full theoretical stability test | Confirm the absence of general collapse modes | This appears with the complete model, not with a partial galactic stage |
| Parameter-sensitivity test | Ask whether success is robust or fragile | This is a final maturity test before large claims |
