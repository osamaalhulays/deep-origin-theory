# Phase Architecture And Reproducibility

This folder captures a class of pre-Rank-9 achievements that can be missed if
one only reads the later public shelves:

- the program had already written down a staged doctrine for what belongs to
  white-law discovery, what belongs to cosmology, and what belongs only to a
  final stress test,
- executable reproducibility was already treated as a real deliverable,
- and honest negative closures were already being counted as scientific
  discipline rather than embarrassment.

At its strongest, this folder shows that the pre-Rank-9 line already knew how
to do three difficult things at once:

- name the stronger scientific threshold correctly,
- refuse to pretend that threshold had already been crossed,
- and freeze unsupported lanes instead of letting them drift forward by habit
  or inference.

Recommended order:

1. `PHASED_PREDICTION_DISCIPLINE_NOTE.md`
2. `SENTINEL_HOLDOUT_DISCIPLINE_NOTE.md`
3. `DIFFERENTIAL_SIGNATURE_STATUS_NOTE.md`
4. `REPRODUCIBILITY_AND_NEGATIVE_CLOSURE_NOTE.md`
5. `05_PHASE_DIVISION_TABLE.md`
6. `04_PHASE_5_OBJECTIVES.md`
7. `cfsc_v1_3_repro.py`
