# Sentinel / Holdout Discipline Note

One quiet pre-Rank-9 achievement was the program's refusal to confuse
early-stage signal with full scientific admissibility.

That sounds procedural, but it is actually scientific culture.

## 1. The phase doctrine separated partial evidence from full judgment

The visible phase surfaces already distinguished:

- `sentinel` as an early-stage signal gate,
- `holdout` as required out-of-sample pressure,
- and fuller judgment as something that should not be inferred prematurely.

This matters because it blocks a common failure mode:

- treating one encouraging partial result as if it were already a final
  challenger, successor, or law claim.

## 2. The program said this explicitly

The visible candidate-card grammar and exported candidate surfaces already
carried rules such as:

- no promotion by inference,
- do not treat sentinel success as full judgment,
- and do not collapse data-materialization failure into theoretical failure.

That is not empty governance language.

It is the operational form of a real scientific discipline:

- partial evidence may be interesting,
- but it is not yet the same thing as admissible generalization.

## 3. Why B1Y is a useful witness

The conservative `B1Y` export line is valuable here not because it proves a
final result, but because it shows the discipline in action.

This public bundle preserves `B1Y` as a conservative witness route only.
It does **not** preserve a public case-selection protocol explaining why that
sentinel export contains exactly `6` valid cases.

Later preserved staging surfaces narrow that unresolved point materially.
They freeze a manual core of six sentinel/stress galaxies:

- `NGC6946`
- `NGC5055`
- `NGC0247`
- `NGC5585`
- `UGC00128`
- `NGC2998`

and the same six names recur in the surviving Phase-2 stress/sentinel memory.

That means the remaining public gap is no longer:

- "which six were they?"

but the narrower reviewer-facing question:

- "why did this recurring stress core become the fixed manual set?"

Its exported posture separated:

- a signal-bearing probe,
- from an active challenger,
- from a promotion-ready line.

It also kept the case unresolved when canonical holdout materialization was not
complete, instead of laundering that incompleteness into a victory claim.

## 4. Why this is a hidden achievement

If this discipline had not existed, the pre-Rank-9 history could have produced
much louder claims much earlier.

Instead, the visible record shows something harder and more respectable:

- staged evidence,
- explicit out-of-sample pressure,
- and repeated refusal to promote a line beyond what the available stage
  actually justified.

That is part of why the later shelves were able to remain scientifically
bounded instead of collapsing into early triumphalism.
