# cfsc_v1_3_repro.py
# CFSC v1.3 — Reproducibility package (no SciPy).
# Generates figures + prints acceptance-gate metrics.
#
# Dependencies: numpy, matplotlib.
#
# This script focuses on the three 'blood' demands:
# (1) Transmission-line H_line(ω) with reflections (ripple dips)
# (2) ≥5-level leakage/heating check (Duffing truncation) + leakage metric
# (3) Second-order Magnus proxy ||Ω2||/||Ω1|| vs ωm (Floquet trap bound)
#
# It also includes:
# - Golden equation kernel J1(β) via a convergent series (no SciPy)
# - Auto-calibration curve A_corr(ωm)=1/|H_line(ωm)|

import os, math
import numpy as np
import matplotlib.pyplot as plt

def bessel_j(n, x, n_terms=200):
    x = np.asarray(x, dtype=float)
    term = (x/2.0)**n / math.factorial(n)
    res = term.copy()
    for k in range(1, n_terms):
        term *= -(x/2.0)**2 / (k*(n+k))
        res += term
    return res

def tl_transfer_function(freq_hz, l_m=1.5, vp=2.0e8, alpha0=0.18, alpha1=0.05, gamma_s=0.12, gamma_l=0.22):
    f = np.asarray(freq_hz, dtype=float)
    w = 2*np.pi*f
    alpha = alpha0 + alpha1*np.sqrt(np.abs(f)/1e9)
    beta = w/vp
    gamma = alpha + 1j*beta
    return np.exp(-gamma*l_m) * (1+gamma_l) / (1 - gamma_s*gamma_l*np.exp(-2*gamma*l_m))

def destroy(N):
    a = np.zeros((N,N), dtype=complex)
    for m in range(1,N):
        a[m-1,m] = np.sqrt(m)
    return a

def kron3(A,B,C):
    return np.kron(np.kron(A,B),C)

def smoothstep01(s):
    s = np.clip(s,0,1)
    return 10*s**3 - 15*s**4 + 6*s**5

def evolve_multilevel(T, dt, params):
    # 3 Duffing modes (A,B,C), truncated to >=5 levels each, unitary midpoint integrator.
    Na=params.get("Na",5); Nb=params.get("Nb",5); Nc=params.get("Nc",5)
    a=destroy(Na); b=destroy(Nb); c=destroy(Nc)
    Ia=np.eye(Na); Ib=np.eye(Nb); Ic=np.eye(Nc)
    aA=kron3(a,Ib,Ic); aB=kron3(Ia,b,Ic); aC=kron3(Ia,Ib,c)
    nA=aA.conj().T@aA; nB=aB.conj().T@aB; nC=aC.conj().T@aC

    MHz_to_rad_ns = 2*np.pi*1e-3
    DeltaB = params.get("DeltaB_MHz",400.0)*MHz_to_rad_ns
    alphaA = params.get("alphaA_MHz",250.0)*MHz_to_rad_ns
    alphaB = params.get("alphaB_MHz",300.0)*MHz_to_rad_ns
    alphaC = params.get("alphaC_MHz",250.0)*MHz_to_rad_ns
    gAB0 = params.get("gAB_MHz",30.0)*MHz_to_rad_ns
    gBC0 = params.get("gBC_MHz",30.0)*MHz_to_rad_ns
    eps_cr = params.get("eps_cr",0.03)
    wm = params.get("wm_MHz",200.0)*MHz_to_rad_ns
    m_depth = params.get("m_depth",0.65)
    phi = params.get("phi",0.0)

    H0 = DeltaB*nB \
        -0.5*alphaA*(nA@(nA-np.eye(nA.shape[0]))) \
        -0.5*alphaB*(nB@(nB-np.eye(nB.shape[0]))) \
        -0.5*alphaC*(nC@(nC-np.eye(nC.shape[0])))

    exch_AB = aA.conj().T@aB + aA@aB.conj().T
    exch_BC = aB.conj().T@aC + aB@aC.conj().T
    pair_AB = aA@aB + aA.conj().T@aB.conj().T
    pair_BC = aB@aC + aB.conj().T@aC.conj().T

    def envelope(t):
        s=t/T
        return smoothstep01(s)*smoothstep01(1-s)

    dim = Na*Nb*Nc
    psi = np.zeros(dim, dtype=complex)
    idx0 = 1*(Nb*Nc) + 0*Nc + 0
    psi[idx0]=1.0

    keep = np.zeros(dim, dtype=float)
    for aa in range(Na):
        for bb in range(Nb):
            for cc in range(Nc):
                idx = aa*(Nb*Nc)+bb*Nc+cc
                if aa<=1 and bb<=1 and cc<=1:
                    keep[idx]=1.0

    def pop_B1(psi):
        p=0.0
        for aa in range(Na):
            for cc in range(Nc):
                idx=aa*(Nb*Nc)+1*Nc+cc
                p+=abs(psi[idx])**2
        return p

    def pop_C1(psi):
        p=0.0
        for aa in range(Na):
            for bb in range(Nb):
                idx=aa*(Nb*Nc)+bb*Nc+1
                p+=abs(psi[idx])**2
        return p

    nsteps=int(np.ceil(T/dt))
    tgrid=np.linspace(0,T,nsteps+1)
    PB=np.zeros_like(tgrid); PC=np.zeros_like(tgrid); L=np.zeros_like(tgrid)

    for k,t in enumerate(tgrid):
        PB[k]=pop_B1(psi)
        PC[k]=pop_C1(psi)
        L[k]=1.0 - np.sum(keep*(np.abs(psi)**2))
        if k==len(tgrid)-1:
            break

        e=envelope(t)
        mod = 1.0 + m_depth*np.cos(wm*t + phi)
        gAB = gAB0*e*mod
        gBC = gBC0*e*mod
        H = H0 + gAB*exch_AB + gBC*exch_BC + (eps_cr*gAB)*pair_AB + (eps_cr*gBC)*pair_BC

        k1=-1j*(H@psi)
        psi_mid=psi+0.5*dt*k1

        tm=t+0.5*dt
        em=envelope(tm)
        modm = 1.0 + m_depth*np.cos(wm*tm + phi)
        gABm=gAB0*em*modm
        gBCm=gBC0*em*modm
        Hm = H0 + gABm*exch_AB + gBCm*exch_BC + (eps_cr*gABm)*pair_AB + (eps_cr*gBCm)*pair_BC

        k2=-1j*(Hm@psi_mid)
        psi = psi + dt*k2
        psi = psi/np.linalg.norm(psi)

    return tgrid, PB, PC, L

def magnus_ratio_vs_wm(wm_list_MHz, amp_MHz=30.0, Delta_MHz=400.0, mod_depth=0.6, Nt=90):
    # 3-level effective model; computes ||Ω2||/||Ω1|| (Frobenius) over one period.
    MHz_to_rad_ns = 2*np.pi*1e-3
    ratios=[]
    for wm_MHz in wm_list_MHz:
        wm = wm_MHz*MHz_to_rad_ns
        Tper = 2*np.pi/(wm_MHz*1e6)
        dt = Tper/Nt
        t = np.arange(0, Tper, dt)
        A = amp_MHz*MHz_to_rad_ns
        Delta = Delta_MHz*MHz_to_rad_ns
        Hs=[]
        for tt in t:
            g = A*(1+mod_depth*np.cos(wm*tt))
            Hs.append(np.array([[0,g,0],[g,Delta,g],[0,g,0]], dtype=complex))
        Hs=np.array(Hs)
        Om1 = np.sum(Hs, axis=0)*dt
        Om2 = np.zeros_like(Om1)
        for i in range(len(t)):
            Hi=Hs[i]
            for j in range(i):
                Hj=Hs[j]
                Om2 += (Hi@Hj - Hj@Hi)
        Om2 *= 0.5*(dt**2)
        n1=np.linalg.norm(Om1, ord='fro')
        n2=np.linalg.norm(Om2, ord='fro')
        ratios.append(n2/max(n1,1e-12))
    return np.array(ratios)

def main():
    out="cfsc_v1_3_figs"
    os.makedirs(out, exist_ok=True)

    # Golden equation plot J1(beta)
    beta=np.linspace(0,6.0,400)
    J1=bessel_j(1,beta)
    plt.figure()
    plt.plot(beta,J1)
    plt.axhline(0, linewidth=1)
    plt.xlabel("β"); plt.ylabel("J1(β)")
    plt.tight_layout()
    plt.savefig(os.path.join(out,"golden_equation_J1.png"), dpi=200)
    plt.close()

    # TL ripples plot
    f=np.linspace(1e6,600e6,1200)
    H=tl_transfer_function(f)
    plt.figure()
    plt.plot(f/1e6, 20*np.log10(np.abs(H)+1e-15))
    plt.xlabel("Frequency [MHz]"); plt.ylabel("|H| [dB]")
    plt.tight_layout()
    plt.savefig(os.path.join(out,"tl_transfer_ripples.png"), dpi=200)
    plt.close()

    # Gain drift vs ωm + correction
    wm_scan=np.linspace(50e6,320e6,800)
    gain=np.abs(tl_transfer_function(wm_scan))
    gain_norm=gain/np.max(gain)
    corr=1/(gain+1e-12); corr=corr/np.min(corr)
    plt.figure()
    plt.plot(wm_scan/1e6, gain_norm, label="|H(ωm)| norm.")
    plt.plot(wm_scan/1e6, corr/np.max(corr), label="A_corr norm.")
    plt.xlabel("ωm/2π [MHz]"); plt.ylabel("Normalized")
    plt.legend(); plt.tight_layout()
    plt.savefig(os.path.join(out,"gain_ripples_and_correction.png"), dpi=200)
    plt.close()

    # Multi-level example (acceptance numbers)
    params=dict(Na=5,Nb=5,Nc=5,DeltaB_MHz=400.0,
                alphaA_MHz=250.0,alphaB_MHz=300.0,alphaC_MHz=250.0,
                gAB_MHz=30.0,gBC_MHz=30.0,wm_MHz=200.0,m_depth=0.65,phi=0.0,eps_cr=0.03)
    tgrid, PB, PC, L = evolve_multilevel(T=50e-9, dt=0.08e-9, params=params)
    plt.figure()
    plt.plot(tgrid*1e9, PC, label="P_C")
    plt.plot(tgrid*1e9, PB, label="P_B")
    plt.plot(tgrid*1e9, L, label="Leakage")
    plt.xlabel("t [ns]"); plt.ylabel("Population")
    plt.legend(); plt.tight_layout()
    plt.savefig(os.path.join(out,"multilevel_transfer_leakage.png"), dpi=200)
    plt.close()

    # Magnus proxy vs ωm
    wm_list=np.linspace(80,420,12)
    rat=magnus_ratio_vs_wm(wm_list, Nt=90)
    plt.figure()
    plt.plot(wm_list, rat, marker="o", label="||Ω2||/||Ω1||")
    plt.axhline(0.1, linestyle="--", label="10%")
    plt.xlabel("ωm/2π [MHz]"); plt.ylabel("ratio")
    plt.legend(); plt.tight_layout()
    plt.savefig(os.path.join(out,"magnus_second_order_ratio.png"), dpi=200)
    plt.close()

    # Print gate metrics (example)
    print("Gate metrics (example run):")
    print("  P_C(T) =", float(PC[-1]))
    print("  max P_B =", float(np.max(PB)))
    print("  max leakage =", float(np.max(L)))
    print("  Magnus ratio @200 MHz =", float(magnus_ratio_vs_wm(np.array([200.0]), Nt=90)[0]))
    print("Saved figures to", out)

if __name__=="__main__":
    main()
