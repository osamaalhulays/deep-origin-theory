# Reproducibility And Negative-Closure Note

Another underexposed pre-Rank-9 gain is that reproducibility and negative
verdict discipline were already treated as first-class obligations.

## Reproducibility

The included `cfsc_v1_3_repro.py` is not just a memo. It is an executable
reproducibility surface that:

- regenerates figures,
- prints acceptance-gate metrics,
- and makes reproducibility a concrete obligation instead of a rhetorical one.

This matters because it shows that, even before the later Deep Origin public
shelves, the program was already trying to bind claims to rerunnable surfaces.

## Honest negative closure

The pre-Rank-9 line also learned to close unsupported side paths honestly.

The February Apex / CRL release explicitly treated `f_gas` as closed for the
then-current pipeline because the needed gas fields were not present. That is a
small but important scientific virtue:

- unsupported inputs were frozen closed,
- not quietly promoted,
- and not used to counterfeit broader coverage than the pipeline truly had.

## Why this belongs in Package A

Without these points, a later reader can misread the pre-Rank-9 era as pure
theory language. That would be unfair. It already contained executable
reproducibility pressure and explicit negative closures.
