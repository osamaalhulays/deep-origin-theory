# Layer Boundaries Note

This public foundation bundle is easier to read if three layers are kept
separate from the start.

## 1. Theory layer

This is the scientific layer proper.

It includes:

- the late QCT galaxy-scale line,
- the Apex / CRL branch,
- the White Law / Rank-8 framework layer,
- the `qct_core` closure layer,
- the staged doctrine,
- and the lawful handoff into the later Rank-9 shelf.

If a file helps state, bound, or justify a scientific claim, it belongs here.

## 2. Support and governance layer

This is not the theory itself, but it is part of why the theory became
reviewable and publishable.

It includes only those support surfaces that materially affect:

- reproducibility,
- admissibility,
- source continuity,
- claim-boundary honesty,
- publication discipline,
- or cross-repo transport without semantic drift.

In this bundle, that narrower support role is represented by selected material
from `Factory V1 Trial`, `Academy Plug`, `Q platform`,
`Q Platform Archive (كيو بلاتفورم الارشيف)`, `ZamaKan`,
`Raw Sources (مصادر خام)`, and `Adapter (الادابتور)`.

In practice, this means software/runtime, import, audit, and
publication-governance surfaces rather than new physics.

These layers matter because they helped preserve the scientific object without
pretending to be the scientific object.

## 3. Private application layer

This bundle intentionally omits the private application layer.

That omitted layer includes:

- commercial application systems,
- operational bridges,
- interface products,
- and other reader-facing or product-facing practical surfaces that are not
  part of the public scientific foundation itself.

Those surfaces may matter operationally, but they do not belong in this public
foundation bundle.

## Short reading rule

The simplest rule is:

- if it helps define a scientific claim or its lawful reproducibility boundary,
  it may belong in this bundle,
- if it belongs to a private application or commercial product surface, it is
  intentionally outside this bundle.
