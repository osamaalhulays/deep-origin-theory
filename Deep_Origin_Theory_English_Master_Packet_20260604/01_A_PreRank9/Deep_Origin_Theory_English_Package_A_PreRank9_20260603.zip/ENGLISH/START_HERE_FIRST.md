# Start Here First

If you are new to this bundle, read in this order:

1. `CLAIM_BOUNDARY_CARD.md`
2. `LAYER_BOUNDARIES_NOTE.md`
3. `PRE_RANK9_FOUNDATION_STATUS.md`
4. `WHAT_HAS_ALREADY_BEEN_ACHIEVED_BEFORE_RANK9.md`
5. `PUBLICATION_OBJECT_DISCIPLINE_NOTE.md`
6. `MOND_AND_DARK_MATTER_KEY_RESULTS_NOTE.md`
7. `QCT_LINEAGE_AND_APEX_20260218_20260228/README.md`
8. `PHASE_ARCHITECTURE_AND_REPRODUCIBILITY_20260228_20260301/README.md`
9. `QCT_CORE_CLOSURE_20260324/README.md`
10. `WHITE_LAW_AND_RANK8_TRANSITION_20260414_20260520/README.md`
11. `PROGRAM_SUPPORT_AND_METHOD_STACK_20260324_20260520/README.md`
12. `SCREENSHOT_REPO_COVERAGE_AND_DECISION_MATRIX.md`
13. `SOURCE_LAYER_INDEX.md`

## One-sentence orientation

This bundle shows what had been built and lawfully closed before the
current Deep Origin Rank-9 shelf: early QCT lineages, a staged doctrine for later
cosmology and decisive-prediction work, the `qct_core` scientific closure, the White
Law / Rank-8 public layer, the Rank-8 to Rank-9 handoff, and the support
stack that kept those layers auditable, dual-tracked, and import-clean.

## What this bundle makes clear

This bundle puts four things in one place:

- what the pre-Rank-9 line was saying against particle dark matter at
  galaxy scale,
- what it had and had not yet earned against `MOND` / `QUMOND`,
- what the White-Law / Rank-8 and `qct_core` layers had closed
  structurally,
- and what kind of support stack existed to keep the whole line
  reviewable instead of improvised.

## Main scientific gains already visible before Rank 9

- the galaxy line was already being pushed under global-parameter discipline
  rather than per-galaxy theory rescue,
- local-safety and out-of-sample discipline were already treated as real
  scientific gates,
- the anti-`MOND` question had advanced into an explicit morphology-survival
  white arm rather than remaining only a phase label,
- the line had already identified the stronger anti-`MOND/QUMOND` threshold
  as differential signature beyond fit quality, while refusing to pretend
  that threshold had already been closed,
- the line had matured into a fair `QUMOND` benchmark culture that remained
  visible even when the broader aggregate comparison turned harsh,
- the lensing question had matured into a governed discriminator front with
  strict branch labels, no-hidden-mixing rules, an explicit observable
  dictionary, and an explicit later falsification route,
- the Apex / CRL branch had already begun to localize broad fit pressure into
  a small repeatable tail rather than treating all aggregate failure as
  undifferentiated collapse,
- that same Apex line had already moved later benchmark and lensing execution
  into blind-protocol and tamper-evident capsule discipline rather than
  leaving those fronts loosely rerunnable,
- the galactic line had hardened enough to clear a bounded publication-grade
  empirical gate and stop being the live weakness, even while later
  cluster/lensing, cosmology, and cross-domain closure remained open,
- and the cluster/lensing frontier had already been localized honestly: first
  to a same-kernel execution blocker, then to the narrower missing
  object-level `delta -> gamma_t` contract after reserve auditability had been
  materialized.

## White-Law and qct_core gains already visible before Rank 9

- the White-Law manifold had become a lawful narrowing cage, so candidate
  promotion, truth promotion, and branch widening were blocked while the
  search space was tightened under governed rules,
- one selected candidate line had already become equation-level explicit and
  root-mapped under `FMR`, while still being kept derived-only rather than
  silently upgraded into white-root identity,
- the White-Law line had moved into an explicit family-admissibility regime in
  which one governed current carrier family was bound while comparative
  widening remained blocked until real readiness thresholds were cleared,
- inside that same manifold, the morphology-residual champion had already been
  pushed to a maximally hardened bounded external-challenge frontier,
- the `Action-vs-EPIC` line had not stopped at generic admissibility recovery,
  but had frozen one lawful canonical same-source benchmark path and then
  bound `CORE-106` closure to that path while retiring the rejected proxy
  bridge,
- the same `qct_core` layer had also learned controlled reduction:
  `EPIC-30` stayed explicitly phenomenological, the current bridge stayed
  non-admissible, and the false blocker that claimed no lawful same-source
  path existed beyond that bridge was retired,
- some late `qct_core` closure gaps had already become legible as
  authority-absorption lag between live evidence and accepted closure wording
  rather than as unresolved scientific disagreement,
- a substantial pre-truth review stack already existed, but scientific truth
  was still held at zero on purpose even after claim-boundary, governed-claim,
  and truth-boundary review passes,
- and the observable mapping chain `phi -> Delta -> V_model` had already been
  locked without opening a fresh mapping-parameter loophole.

## Comparative and support-stack gains already visible before Rank 9

- the later multi-family comparative regime had already materialized explicit
  current-family binding, alternative-family placeholder slots, comparative
  inputs, and read-only counterfactual placeholders without opening
  comparative execution,
- the stronger comparative-opening frontier had already been reduced to
  `12/13` passed threshold classes plus one dominant stronger-threshold
  blocker rather than a vague "not ready yet" cloud,
- the same regime had already quantified its lawful uplift path, including the
  exact remaining gap, exact lawful uplift levers, and exact unlawful touch
  set, while keeping comparison closed,
- supportive top-rank and cluster-stability signals were already visible, but
  the line still refused to convert those supportive signals into opening
  authority,
- comparative cleanliness itself had already become explicit through aliasing
  and proxy-control surfaces, yet the program still refused to let low proxy
  risk masquerade as lawful comparative opening,
- the family-selection policy had already become stage-aware and
  survivability-first, refusing to rank families by placeholder pressure
  alone,
- the program had already materialized a governed stop-state that separated
  readiness from authority, review from truth/release, and comparative
  readiness from comparative execution,
- blocked family comparison, blocked scientific truth, and blocked final
  delivery had already become auditable boundary states rather than rhetorical
  cautions,
- the stronger comparative regime had already gained an anti-stale /
  non-regression layer that checked cross-surface alignment and preserved the
  blocked comparative posture without self-authorized repair,
- the support stack had already learned to quarantine reserve material itself,
  so visible raw bundles, dormant reserve ladders, and even fully bound
  reserve geometry were not silently promoted into live execution claims,
- the Factory line had already frozen a physics-first scoreboard grammar, so a
  live reader could see `MOND`, galactic, lensing, cosmology, cross-domain
  status, and the exact blocker without parsing repo/process chatter,
- the late cluster/lensing line had already learned to state when a future
  round would count as scientifically new by naming exact trigger classes
  rather than treating every rerun as progress,
- the broader system had already materialized a bounded Academy-side upstream
  qualification and export door, without pretending that packaging or writing
  alone granted lab authority,
- executable reproducibility, sentinel/holdout separation, and honest
  negative closure were already treated as scientific discipline rather than
  embarrassment or afterthought,
- unsupported lanes were already being frozen closed rather than drifting
  forward by habit or inference,
- the raw-source world had already become a control tower with Arabic-note
  signal routing and broader-source routing logic rather than an undifferentiated
  evidence reservoir,
- the project already had a bounded theory-office layer that held together a
  high-level vision, a project statement, a governing-principle attempt, and
  an honest rank-honesty statement,
- theory work, factory execution, adapter import, and platform consumption
  were already kept dual-tracked and import-clean enough to transport bounded
  outputs without canonical drift,
- and the broader cross-repo layer had already become continuity-safe enough
  to keep evidence, wording, and release posture aligned without naming drift,
  claim-ceiling drift, or packet-identity breakage.

## Best way to read it

Read this bundle as a **foundation and transition bundle**.

It is not the current Deep Origin public shelf itself.
It is the foundation layer that explains how the program reached the point at
which the current Rank-9 shelf became publishable at all.

It also intentionally omits private application and commercial bridge layers.
Those surfaces are not being treated here as part of the public scientific
foundation.

## Where this bundle ends

This bundle ends at the line:

- Rank 8 stabilized,
- cosmology still held closed,
- and the next lawful front identified as the Rank-9 / cosmology-completion
  front.

That boundary is deliberate.
The current Rank-9 shelf begins only after that line.
