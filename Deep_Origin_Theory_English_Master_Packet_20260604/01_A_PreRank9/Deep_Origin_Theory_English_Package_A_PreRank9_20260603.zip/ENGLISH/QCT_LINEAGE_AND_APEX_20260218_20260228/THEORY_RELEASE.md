## Naming
- Official (formal): Curvature Response Law (CRL)
- Brand handle (informal): CURL
- Classification: empirical / phenomenological law-like relation within rotation-curve phenomenology (not a fundamental-law claim)

# Curvature Response Law (CRL) — Release Pack (2026-02-28)

## Scope
- QCT physics is **locked (read-only)**. No modifications to Phase-1/2/3 or TG/LG.
- Only the **external emulator predictions** are altered for diagnostic/upper-bound analysis.

## Primary claim (Option2 — Minimal)
By applying an oracle-diagnostic replacement of \Delta(r) for only **three** repeatable long-tail offenders:
- UGC11914
- NGC6195
- NGC5907

we obtain:
- global_mean_delta_aic ≤ 0 (see `option2_minimal/rc_run_multiseed_summary.json`)
- wins reported in the same summary.

Interpretation: the global fit quality is controlled by a small, identifiable tail driven by emulator-side error, not by broad model failure.

## Robustness claim (Option1 — Larger margin)
Extending the patched tail set by two additional cases:
- IC4202
- ESO079-G014

increases the negative margin (see `option1_robust/rc_run_multiseed_summary.json`).

## Why sigma-only patching is not the answer
Raising \sigma_\Delta can increase the likelihood penalty (e.g., log terms), and may worsen AIC even if it avoids numerical cliffs. The successful route is improving \Delta(r) accuracy for the tail.

## Data / feature decision: f_gas
A probe over the active pipeline `real_rc_data` found:
- files_with_any_gas_key = 0
- files_with_v_gas_key = 0

Therefore `f_gas` is **closed for now** as unsupported by the current data pipeline.

## Governance locks
- Option labels must remain literal: `OptionA(Mainline)`, `OptionB(Alt)`.
- Fail-loudly policy.
- Capsule hygiene: `production_capsule.zip` must not include `table2.dat`, any `.dat`, or `real_rc_data/`.

## Artifacts
- Option2 (Minimal): `option2_minimal/production_capsule.zip`
- Option1 (Robust): `option1_robust/production_capsule.zip`
- Evidence zips: `option*/evidence_bundle.zip`
- Anchoring: `_meta/manifest_hash.txt`
- Manifest: `release_manifest.json`

