# QCT Lineage And Apex

This folder preserves the late public QCT line before the later Deep Origin
Rank-8 / Rank-9 shelf.

It serves two functions:

- to show that the program already had serious English-facing scientific
  surfaces before Rank 9,
- and to keep the older QCT / Apex effort from disappearing once the current
  Deep Origin framing becomes the dominant public layer.

At its strongest, this folder shows that the pre-Rank-9 galaxy line had
already moved beyond raw fit rhetoric into global-parameter pressure,
local-safety discipline, governed lensing structure, fair `QUMOND` pressure,
tail-driver localization, and blind-protocol auditability.

Recommended order:

1. `QCT_V8_LINEAGE_NOTE.md`
2. `LENSING_DISCIPLINATOR_AND_BRANCH_DISCIPLINE_NOTE.md`
3. `GLOBAL_PARAMETER_DISCIPLINE_NOTE.md`
4. `SOLAR_LOCAL_SAFETY_PINNING_NOTE.md`
5. `PHENOMENOLOGICAL_CLOSURE_VALIDATION_NOTE.md`
6. `QUMOND_BENCHMARK_HONESTY_NOTE.md`
7. `APEX_CRL_POSITIONING_NOTE.md`
8. `TAIL_DRIVER_LOCALIZATION_NOTE.md`
9. `BLIND_PROTOCOL_AND_RESULTS_CAPSULE_DISCIPLINE_NOTE.md`
10. `QUMOND_COMPARISON_PLAN.md`
11. `PLAN_PROGRESS_REPORT.md`
12. `STATS_FINAL_SIGNOFF.md`
13. `B1Y_SENTINEL_MULTISEED_SUMMARY.json`
14. `QUMOND_PRODUCTION_SUMMARY.json`
15. `QCT_v8_3_Full_English.tex`
16. `QCT_v8_8_Full_English.pdf`
17. `THEORY_INDEX_RC1_3.md`
18. `REFERENCE_THEORY_INDEX_RC1_1.md`
19. `SPEC-204_TG4_ACTIONCONSISTENT.md`
20. `SPEC-204_TG4_BENCHMARKS_CORRECTED.md`
21. `SPEC-205_PHENOMENOLOGICAL_CLOSURE_CORRIGENDUM.md`
22. `SPEC-701_LG1_LENSING_MECHANISM.md`
23. `SPEC-702_LG2_SHEAR_PIPELINE.md`
24. `DECISION_LOG_LG1_MAINLINE_OPTIONA.md`
25. `RUNBOOK_UNBLIND_LG3.md`
26. `CHANGE_RECORD_IDENTITY.md`
27. `FINAL_SIGNOFF.md`
28. `FINAL_RELEASE_SIGNOFF.md`
29. `NOTE_REFEREE_ATTACKS_AND_MITIGATIONS.md`
30. `THEORY_RELEASE.md`
