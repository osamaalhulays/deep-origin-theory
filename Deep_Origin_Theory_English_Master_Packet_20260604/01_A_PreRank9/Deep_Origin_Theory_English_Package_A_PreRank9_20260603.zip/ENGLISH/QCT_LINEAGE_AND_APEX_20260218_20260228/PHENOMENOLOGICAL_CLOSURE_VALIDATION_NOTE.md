# Phenomenological-Closure Validation Note

One more pre-Rank-9 achievement that can easily be missed is how the Apex line
handled the galaxy-scale closure itself.

It did not pretend that the galaxy solver had already been derived exactly from
the action under all controlled approximations.

Instead, it did something more disciplined.

## 1. The closure was labeled honestly

The Apex theory surfaces explicitly described the galaxy-scale PDE as a
**phenomenological closure**.

That honesty matters.

It means the line did not try to hide a practical solver behind false
fundamental-law rhetoric.

## 2. Honest labeling was not the only safeguard

The same surfaces also insisted on two stronger conditions:

- no new free parameters should be introduced by the closure itself,
- and the closure should be checked against the exact action-consistent
  spherical equation rather than trusted by declaration alone.

This is the opposite of silent ad-hoc drift.

It is a bounded empirical closure under validation pressure.

## 3. The visible mitigation statement is stronger than it first looks

The referee-facing mitigation note states that:

- the galaxy-scale PDE is phenomenological,
- it is validated against the exact action-consistent equation for spherical
  test cases,
- the target validation error is below `1%`,
- and the only free parameters remain `gamma` and `m`.

That cluster of statements is a real gain.

It means the line was already trying to separate:

- a practical galaxy solver,
- from uncontrolled free-parameter inflation,
- and from false claims of exact derivation.

## 4. Why this belongs in Package A

Without this note, a reader can wrongly assume that the pre-Rank-9 line had
only two options:

- either an exact derivation everywhere,
- or an unconstrained ad-hoc fit device.

The visible record shows a narrower and more respectable middle position:

- phenomenological closure admitted honestly,
- conventions frozen,
- no extra free parameters,
- and validation explicitly tied to action-consistent spherical checks.

That is a real scientific and methodological achievement in the pre-Rank-9
history.
