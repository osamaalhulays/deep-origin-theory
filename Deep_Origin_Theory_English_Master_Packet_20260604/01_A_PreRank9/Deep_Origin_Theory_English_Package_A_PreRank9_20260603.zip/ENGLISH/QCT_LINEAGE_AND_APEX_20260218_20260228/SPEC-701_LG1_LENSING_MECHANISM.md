# SPEC-701: LG-1 Lensing Mechanism (Option A Mainline)

> **Option Naming Map (Notice to Reviewers):**
> - **Option A (Mainline):** Hybrid Lensing (scalar field energy density gravitates and contributes to \(\Sigma_{\text{total}}\)). **This is the official baseline.**
> - **Option B (Alt Branch):** Baryon-only Lensing (photons blind to \(\phi\)). Archived for comparison.
>
> *(Earlier drafts may have used the reverse A/B naming. This definition is final and supersedes all prior nomenclature.)*

**Status:** CANONICAL — **BINDING** (LG-1 committee decision)

## 1) Identity Resolution (Hybrid Framework)
The model identity is explicitly **Hybrid**:

- **Modified Inertia (Galaxy Rotation):** \(\phi\) modifies the effective inertial response of test particles, producing the rotation-curve boost without dark matter.
- **Modified Gravity (Lensing):** \(\phi\) is a dynamical field with physical energy density \(\rho_\phi\). Consistent with GR, this stress-energy contributes to the metric sourcing lensing. Photons follow the metric sourced by baryons + \(\rho_\phi\).

This is stated explicitly to avoid any ambiguity in peer review.

## 2) Mainline Lensing Formulation (Option A)
In the weak-field limit, the convergence is:

\[
\kappa = \frac{\Sigma_{\text{total}}}{\Sigma_{\text{crit}}}, \qquad \Sigma_{\text{total}} = \Sigma_{\text{baryon}} + \Sigma_\phi
\]

where

\[
\Sigma_\phi(R) = \int_{-\infty}^{+\infty} \rho_\phi^{\text{mass}}(R,z) \, dz
\]

and \(\rho_\phi^{\text{mass}}\) is computed directly from the EPIC-30 field output \(\phi(R,z)\) using **SPEC-702** (no new free parameters).

## 3) Alt Branch Policy (Option B)
Option B (baryon-only lensing) is **not deleted**. It is maintained as an **ALT branch** strictly for:
- comparison plots / sanity checks
- future theoretical exploration

All official outputs must be tagged `OptionA(Mainline)`.

## 4) Constraints
- **No new parameters**: \(\Sigma_\phi\) uses only frozen global parameters \((\gamma, m)\) plus fixed constants.
- **Falsifiable**: The difference between Option A and Option B feeds directly into LG-3.
