# QCT v8 Lineage Note

The v8.x line matters because it already displayed several traits that later
remained central to the stronger publication posture:

- hard falsifiability,
- explicit scope limits,
- reproducibility pressure,
- hostile-reviewer framing,
- and refusal to disguise failure modes behind averaged claims.

## What v8.3 already did

`QCT_v8_3_Full_English.tex` shows a galaxy-scale framework built around:

- a modified-inertia posture,
- a single-metric discipline,
- a lensing kill-switch style discriminator,
- and a narrow scope that explicitly refused to pretend that clusters or full
  cosmology were already solved.

## What v8.8 tightened

`QCT_v8_8_Full_English.pdf` hardened the same line by adding:

- Bayesian marginalization over stellar mass-to-light uncertainty,
- explicit model averaging over discrete hyper-model families,
- worst-case rather than average-only reporting,
- fair comparison to MOND under the same uncertainty handling,
- and conservative complexity accounting.

Within this bundle, `QCT_v8_8_Full_English.pdf` is preserved as an archived
short public-line paper object.
This bundle does **not** preserve a documented journal-submission record for
that PDF.

## Why this matters to Package A

Package A does not treat the late-QCT line as identical to the later Deep
Origin public shelf.

It treats it as an important predecessor layer that already demonstrated:

- scientific boundedness,
- hostile-audit awareness,
- named reproducible outputs,
- and a program willing to publish under kill conditions rather than under
  triumphal language.
