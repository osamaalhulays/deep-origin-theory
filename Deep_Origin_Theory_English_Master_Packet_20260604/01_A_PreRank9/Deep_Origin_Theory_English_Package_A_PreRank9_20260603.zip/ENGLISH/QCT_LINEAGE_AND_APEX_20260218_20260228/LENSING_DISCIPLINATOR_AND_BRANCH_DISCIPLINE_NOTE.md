# Lensing Discriminator And Branch Discipline Note

This note records a real pre-Rank-9 achievement that can easily disappear if
the older QCT / Apex line is remembered only as a galaxy-rotation program.

The lensing front was not already observationally closed here.
But it had already advanced into a serious, review-facing discipline.

## 1. What v8.3 had already done

`QCT_v8_3_Full_English.tex` did not treat lensing as an afterthought.
It already made three strong moves:

- it rejected ad-hoc `two-metric / photon-path tailoring`,
- it retained a single-metric covariant bookkeeping,
- and it made the lensing consequence intentionally falsifiable.

The core public posture was sharp:

- dynamics might differ from the baryonic expectation,
- but light propagation was not to be rescued by a hand-tailored photon path,
- so lensing would become a kill-switch rather than a decorative appendix.

That is a meaningful scientific gain even before any later external
observational execution.

## 2. What the Apex line added

The later Apex line did more than repeat the old lensing rhetoric.
It turned the lensing question into a governed branch structure with frozen
labels, explicit constraints, and a falsification route.

The package now preserves primary witnesses showing that:

- a mainline lensing branch and an alternative branch were frozen explicitly,
- branch mixing without literal labeling was forbidden,
- no new lensing parameters were allowed,
- the lensing comparison was wired into a formal falsification gate,
- and the later external execution route was already governed by manifest-hash
  discipline and no-raw-data capsule hygiene.

That matters because it means the program was no longer saying only
"lensing will matter later."

It had already built a controlled language for:

- `OptionA(Mainline)` / `OptionB(Alt)`,
- branch-specific identity,
- branch-specific tagging,
- and branch-specific kill conditions.

## 3. What should count as the real gain here

The defensible gain is not:

- "lensing was solved,"
- or "the external data already confirmed the line."

The defensible gain is narrower and stronger:

- the program refused photon-path rescue,
- then formalized lensing as a bounded discriminator,
- then froze a branch policy instead of hiding the ambiguity,
- and then built an execution doctrine for how a later external lensing test
  would lawfully kill or spare the line.

This is a real pre-Rank-9 maturation step.

## 4. Why the identity shift must stay visible

This same lensing front also preserves an honest tension.

The line did not remain perfectly static from the early modified-inertia /
baryon-only posture to the later Apex framing.

The package witnesses show that:

- the earlier baryon-only lensing idea survived as a preserved comparison
  branch,
- the mainline later shifted into a hybrid identity,
- and that identity shift was recorded explicitly rather than quietly buried.

That is important for credibility.

It means this package should be read as preserving a disciplined lensing
transition, not pretending that the old line always had a single frozen answer
from day one.

## 5. What is and is not claimed here

What is claimed:

- a serious anti-tailoring lensing discipline existed before Rank 9,
- a mainline/alt branch policy was frozen explicitly,
- a no-new-lensing-knob rule was stated,
- and a falsification runbook existed for later external execution.

What is not claimed:

- that external lensing data had already been lawfully confronted,
- that the lensing identity question never evolved,
- or that this package already contains a final observational lensing victory.

## 6. Best short reading

The fairest summary is:

- before Rank 9, the program had already transformed lensing from a vague
  future promise into a disciplined kill-front,
- and it did so under single-metric / anti-tailoring pressure, strict branch
  labeling, no-hidden-lensing-knob rules, and an explicit external
  falsification doctrine.

That is a real achievement.
It is not yet the later observational closure itself.
