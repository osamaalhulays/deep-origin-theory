# Solar / Local-Safety Pinning Note

Another pre-Rank-9 gain that can disappear if it is not named explicitly is
the local-safety line.

The program did not treat galaxy-scale success as sufficient on its own.

It also required the line to remain locally safe in the high-acceleration
regime.

## 1. Local safety was already part of the phase identity test

The phase doctrine did not define success only by fit quality or by apparent
distance from `MOND`.

It also required:

- clean Newtonian recovery,
- no obvious Solar-System breakdown,
- and explicit local-safety checking before any later lift to lensing or full
  cosmology.

So local safety was not a late cosmetic add-on.

It was already part of the scientific identity filter.

## 2. The Apex gate surface did not leave this vague

The Apex theory index already recorded:

- `TG-4 | Limit Recovery (Solar System) | PASS (Pinned)`

and tied that gate to two concrete science documents:

- `SPEC-204_TG4_ACTIONCONSISTENT.md`
- `SPEC-204_TG4_BENCHMARKS_CORRECTED.md`

Those documents matter because they do not speak in slogans.

They define:

- the exact action-consistent spherical test,
- the benchmark diagnostics,
- the conservative `m -> 0` worst-case reading,
- and the acceptance condition `epsilon(1 AU) < 1e-5`.

## 3. A visible measured witness also existed

The copied support witness in this package reports:

- `tg4_pinning_state = theory_index_tg4_pass_pinned`
- `epsilon_1au_gate_state = pass__epsilon_below_threshold`
- `epsilon_1au_threshold = 1e-05`
- `epsilon_1au_value = 1.6803848644424598e-211`
- `worst_case_prior_point = { gamma = 0.1, m_eV = 1e-30 }`

In other words:

- the line did not merely promise local safety,
- it exposed a concrete local metric,
- and the visible witness reads as overwhelmingly below the accepted threshold.

## 4. Why this belongs in Package A

Without this note, a reader can mistakenly think the pre-Rank-9 line was only
a galaxy-fit effort with postponed physical discipline.

That would be false.

The pre-Rank-9 line had already insisted that a credible candidate must be:

- galaxy-scale alive,
- methodologically bounded,
- and locally safe under an explicit Solar-System recovery gate.

That is a real scientific gain, not packaging.
