# QUMOND Benchmark Honesty Note

This note records a pre-Rank-9 gain that should not be hidden just because it
is not a simple victory slogan.

The program did not treat `MOND` / `QUMOND` as a soft straw opponent.

It built a harder comparison path and left that path visible even when the
results became harsh.

## 1. The package contains more than one comparison layer

Inside this pre-Rank-9 history there are at least three distinct comparison
surfaces:

- an adopted frozen galactic line that remained favorable against `MOND` on the
  chosen scoreboard,
- a conservative sentinel probe whose small admissible summary also remained
  favorable at that stage,
- and a broader reviewer-hard `QUMOND` benchmark harness that was later opened
  under strict fairness rules.

These are not the same thing and should not be blurred together.

## 2. What counts as the favorable signal

The selected pre-Rank-9 scoreboard already preserved a visible favorable line:

- the frozen galactic anchor still read as ahead of `MOND` on the adopted line,
- and the conservative `B1Y` sentinel summary reported:
  - `total_valid_cases = 6`
  - `total_mcmc_runs = 30`
  - `global_mean_delta_aic = -66.77047386606402`
  - `qct_overall_wins = 2`

That did **not** yield a final holdout verdict, because holdout materialization
failed on missing case directories.

So the right reading is:

- a favorable conservative signal existed,
- but it did not lawfully expand into a full admissible victory claim.

## 3. What counts as the harder benchmark achievement

The broader Apex benchmarking line then did something more important for
scientific credibility:

- it used the strict galaxy-scale `QUMOND` baseline defined in
  `QUMOND_COMPARISON_PLAN.md`,
- it fixed the `QUMOND` baseline definition,
- locked identical data splits,
- locked identical nuisance-prior treatment,
- made parameter counting transparent,
- and used a strict obs-only model-selection comparator for both sides.

This is not just "more evaluation."

It is a reviewer-hard fairness structure.

For this public bundle, the most important identity facts are:

- this is the galaxy-scale `QUMOND` benchmark surface,
- its locked baseline uses fixed `a0 = 1.2 × 10^-10 m/s^2`,
- its locked interpolating function is the `simple` `nu(y)` form,
- and its `875` count belongs to that galaxy benchmark only.

It is **not** the same count as the later `127`-case cluster/lensing
same-kernel reserve-binding audit. Those `127` cases belong to a different
front, a different object family, and a different blocker history.

And the same line kept the aggregate benchmark outcome visible when it turned
harsh:

- `total_cases = 875`
- `qct_wins = 165`
- `qumond_wins = 710`
- `mean_delta_aic_total = 1863.7747084828175`

This bundle preserves that result as an aggregate benchmark outcome.
It does **not** yet preserve a public case-by-case decomposition explaining why
the aggregate `delta_AIC` becomes this large across all `875` cases.

That outcome is not a physics victory for QCT.

But preserving it is still a scientific achievement of a different kind:

- the program did not protect itself by weakening the opponent,
- did not hide adverse aggregate outputs,
- and did not quietly move the goalposts after opening a fair benchmark path.

## 4. Why this belongs in Package A

Package A is not only about positive numbers.

It is also about whether the pre-Rank-9 line had already become serious enough
to accept hard pressure under public rules.

On that question, the answer is yes.

The line had already earned three distinct things:

- a galaxy-scale no-particle-dark-matter posture,
- a visible favorable selected-line comparison surface against `MOND`,
- and a benchmark culture strong enough to keep even painful `QUMOND` outcomes
  on the record once the broader fairness machinery was opened.

## 5. Best fair reading

The best fair reading is:

- the pre-Rank-9 line did achieve real anti-`MOND` pressure on selected and
  conservative lines,
- but it also matured into a benchmark culture where broader `QUMOND`
  confrontation was allowed to stay visible even when it cut against QCT,
- and that honesty is itself part of what makes the line scientifically
  respectable rather than merely enthusiastic.
