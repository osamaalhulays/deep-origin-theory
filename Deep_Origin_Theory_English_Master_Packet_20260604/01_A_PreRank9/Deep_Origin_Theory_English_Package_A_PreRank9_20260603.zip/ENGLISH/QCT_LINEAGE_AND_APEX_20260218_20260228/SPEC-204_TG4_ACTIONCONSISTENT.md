# SPEC-204: TG-4 Engineering Recipe (Action‑Consistent Solar System Test)

## 1. Grid Setup

- **Radial range:** \(r_{\min}=10^{-4}\,\text{AU}\) to \(r_{\max}=10^4\,\text{AU}\).
- **Spacing:** Logarithmic, number of points \(N\) chosen such that doubling \(N\) changes \(\phi(1\,\text{AU})\) by <1%.
- **Smoothing radius:** \(r_c = 0.01 R_\odot\). Inside \(r_c\), set \(\mathcal{G}=0\) (or compute from a uniform density sphere; the exact regularization is irrelevant for the exterior solution as long as it is smooth). The solver should treat the source as zero for \(r<r_c\).

## 2. Field Equation

Solve the static, spherically symmetric ODE:

\[
\frac{1}{r^2}\frac{d}{dr}\!\left(r^2\frac{d\phi}{dr}\right) - m_{\text{inv}}^2\,\phi = -\alpha_{\text{GB}}\,\mathcal{G}(r),
\]

where for \(r \ge r_c\):

\[
\mathcal{G}(r) = \frac{48\,G^2 M_\odot^2}{c^4 r^6},
\]

and for \(r < r_c\): \(\mathcal{G}(r)=0\) (or a smooth regularization).

**Boundary conditions:**
- At \(r_{\min}\): \(\partial_r\phi = 0\) (regularity).
- At \(r_{\max}\): \(\phi = 0\) (field decays).

## 3. From \(\phi\) to the Gravitational Potential Correction

1. Compute the scalar energy density in J/m³:

   \[
   \rho_\phi^{\text{J/m³}}(r) = \frac{M_P^{\text{kg}} c^2}{2}\left[\left(\frac{d\phi}{dr}\right)^2 + m_{\text{inv}}^2 \phi^2\right].
   \]

2. Convert to mass density (kg/m³):

   \[
   \rho_\phi^{\text{mass}}(r) = \frac{\rho_\phi^{\text{J/m³}}(r)}{c^2}.
   \]

3. Solve the Poisson equation for the additional Newtonian potential \(\Phi_\phi\):

   \[
   \frac{1}{r^2}\frac{d}{dr}\!\left(r^2\frac{d\Phi_\phi}{dr}\right) = 4\pi G\,\rho_\phi^{\text{mass}}(r),
   \]

   with boundary conditions \(\Phi_\phi(\infty)=0\) and regularity at \(r_{\min}\).

4. The total Newtonian potential is \(\Phi_{\text{total}} = \Phi_N + \Phi_\phi\), where \(\Phi_N(r) = -GM_\odot/r\).

5. Compute the fractional correction:

   \[
   \varepsilon(r) \equiv \frac{|\Phi_\phi(r)|}{|\Phi_N(r)|}.
   \]

   Acceptance criterion: **\(\varepsilon(1\,\text{AU}) < 10^{-5}\)** for every point in the frozen prior.

## 4. Integration of Benchmark Hooks

The solver must also compute the diagnostic quantities from SPEC‑204_TG4_BENCHMARKS_CORRECTED.md (e.g., \(Q(r)=r^4\phi(r)\), logarithmic slope) and verify they meet the stated tolerances. These checks are to be performed **after** solving the ODE but before the Poisson step; they serve as unit tests for the numerical implementation.

## 5. Parameter Scan and Acceptance

- Run the test for 1000 random draws from the frozen prior (\(\gamma\) log‑uniform, \(m\) log‑uniform).  
- If any draw yields \(\varepsilon(1\,\text{AU}) > 10^{-5}\), the prior must be tightened (e.g., reduce \(\gamma_{\max}\) or increase \(m_{\min}\)) and the test repeated.  
- The final accepted prior ranges must be documented in the code repository.
