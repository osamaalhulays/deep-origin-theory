# QCT v10.0 Apex: Production Run Plan & LG-3 Runbook

This runbook outlines the strict procedural steps required to unblind the LG-3 Falsification Gate and run it against real observational datasets (e.g., Euclid, CFHTLenS, KiDS) to produce a **publication-grade, audit-clean Results Capsule**.

## 1. Option Naming (Canonical Map)

To prevent reviewer confusion, the naming below is final:

- **Option A (Mainline):** Hybrid Lensing (SPEC-702). Photons respond to \(\Sigma_{\rm total} = \Sigma_{\rm baryon} + \Sigma_\phi\).
- **Option B (Alt):** Baryon-only lensing. Preserved strictly for comparisons.

All outputs MUST be labeled:
- `lensing_mode_mainline = "OptionA(Mainline)"`
- `lensing_mode_alt = "OptionB(Alt)"`

## 2. Sample-Size Strategy (Pre-requisite)

To maximize falsification power:

- **Focus on high \(\Delta\):** prioritize galaxies/stacks where \(\Delta(R) > 0.1\) over a significant radial range.
- **Focus on outer regions:** require shear quality well beyond the disk (\(R > 2 R_d\)) with `sigma_gamma_t < 0.02` and `S/N > 5` in at least one outer bin.
- **Target batch size:** recommend **\(N \ge 20\)** high-quality stacks/galaxies (more is better).

## 3. Environment & Reproducibility Pinning

Before executing any code, ensure your environment strictly matches the certified baseline defined in `ENVIRONMENT_PINNING.md`. **This is a mandatory prerequisite for TG-4 reproducibility and audit compliance.**

During capsule generation (`make_results_capsule.py`), the tool will automatically capture the environment fingerprint (`python -m qct.cli.print_env_fingerprint`) and include cryptographic SHA256 hashes of the pinning files (`requirements.*.lock.txt`, `ENVIRONMENT_PINNING.md`) inside `run_metadata.json`.

Before executing, ensure your environment matches the certified baseline:

```bash
python -V
# Expected: Python 3.10.12

pip freeze | egrep "numpy|pytest|scipy"
# Expected:
# numpy==1.26.4
# pytest==7.4.3
# scipy==1.11.4
```

## 4. Prepare External JSON Cases (No Raw Data in Repo)

External datasets must NOT be committed to the repository. Prepare them locally in a dedicated directory. Each case must match `SCHEMA_LG3_INPUT.json`.

**Units (MANDATORY):**
- `R_grid`, `R_d` in **meters** (m)
- `gamma_t_obs`, `sigma_gamma_t`, `gamma_t_mainline`, `gamma_t_alt` **dimensionless**
- `delta_1d` **dimensionless**

Example:

```json
{
  "is_synthetic": false,
  "R_d": 2.5e19,
  "R_grid": [1.0e19, 2.0e19, 4.0e19, 6.0e19],
  "delta_1d": [0.05, 0.12, 0.18, 0.22],
  "gamma_t_obs": [0.060, 0.040, 0.025, 0.015],
  "sigma_gamma_t": [0.010, 0.008, 0.005, 0.004],
  "gamma_t_mainline": [0.060, 0.040, 0.025, 0.015],
  "gamma_t_alt": [0.060, 0.030, 0.010, 0.002]
}
```

## 5. Production Run Checklist (Strict Sequence)

### Step A: Lock the Manifest & Generate Tokens

Create a `config_dir/` and lock the manifest:

```python
import qct.config.manifest as mf
mf.lock_manifest({"priors": {"gamma": 0.1, "m_eV": 1e-25}}, "config_dir/")
```

Read the hash from `config_dir/manifest_hash.txt` and set:

```bash
export QCT_UNBLIND="YES"
export QCT_MANIFEST_HASH="<insert_sha256_hash_here>"
```

### Step B: Preflight Validation (Dry-Run)

Validate schemas without running physics:

```bash
for f in /path/to/external/json_cases/*.json; do python -m qct.cli.validate_lg3_input "$f"; done
```

### Step C: Execute Unblinded Batch

```bash
python -m qct.cli.run_lg3_batch   --source-dir /path/to/external/json_cases/   --mode unblinded   --manifest-dir config_dir/ > results.ndjson
```

### Step D: Validate Output Integrity

```bash
python -m qct.cli.validate_ndjson results.ndjson
```

### Step E: Post-Process + Produce Audit-Clean Capsule (REQUIRED)

This step generates summary JSON/CSV and a shareable ZIP capsule **without raw data**.
**It will FAIL loudly** unless you provide a non-trivial manifest hash anchor.

```bash
python -m qct.cli.postprocess_lg3   --ndjson results.ndjson   --source-dir /path/to/external/json_cases/   --manifest-hash $QCT_MANIFEST_HASH   --output-prefix production_run_01
```

Outputs:
- `production_run_01_summary.json` (includes `testable_fraction`, `falsified_fraction`, ID lists, and error grouping)
- `production_run_01_summary.csv` (publication-ready table)
- `production_run_01_capsule.zip` (NDJSON + summaries + `run_metadata.json`, **no raw data**)

## 6. Artifact Review

Deliver `production_run_01_capsule.zip` to the review committee. It contains:
- `results.ndjson`
- `*_summary.json`
- `*_summary.csv`
- `run_metadata.json` (python version, pip subset, input/output SHA256 hashes, manifest hash anchor)

**No raw observational input files are included.**
