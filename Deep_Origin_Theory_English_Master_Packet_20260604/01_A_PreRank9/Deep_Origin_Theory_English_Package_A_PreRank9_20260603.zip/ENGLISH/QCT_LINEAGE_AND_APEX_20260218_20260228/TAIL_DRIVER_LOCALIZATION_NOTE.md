# Tail-Driver Localization Note

This note surfaces a pre-Rank-9 gain that is easy to miss if the Apex / CRL
line is read only as a broad fit scoreboard.

The key point is not that the line was already universally victorious.
The key point is that it had already learned something structured about where
its broad pressure was coming from.

## 1. What the February CRL release pack actually says

`THEORY_RELEASE.md` does not present a vague recovery story.
It states a specific diagnostic result:

- a small repeatable long-tail set was isolated,
- replacing `Delta(r)` only for that tiny set was enough to recover
  `global_mean_delta_aic <= 0` in the minimal option,
- and extending that set by two more cases increased the negative margin in
  the more robust option.

The named repeatable tail in the minimal release is:

- `UGC11914`
- `NGC6195`
- `NGC5907`

The larger-margin extension adds:

- `IC4202`
- `ESO079-G014`

## 2. Why this matters

This is a meaningful scientific and methodological gain because it says
something more precise than either of the two lazy readings below:

- not "the whole line already worked everywhere,"
- and not "the whole line failed everywhere."

Instead, the release pack argues for a third reading:

- the broad pressure was controlled by a small, identifiable tail,
- that tail looked emulator-side rather than like immediate universal
  law-level collapse,
- and the program had already become capable of naming that structure rather
  than hiding it under aggregate blur.

## 3. What the package should and should not infer from this

What it is fair to infer:

- the late pre-Rank-9 line had already progressed from generic scoreboard
  pain to structured tail diagnosis,
- it had evidence that the stress was not evenly spread across the case set,
- and it had begun to identify which deficit routes were likely numerical /
  emulator-side rather than broad physical incoherence.

What it is not fair to infer:

- that the law itself was already universally vindicated,
- that all tail behavior was solved,
- or that the CRL branch erased the need for the harder later benchmark and
  observational fronts.

## 4. Why sigma-only rescue was not accepted

The same release pack is also useful because it records what was rejected.

It states plainly that raising `sigma_Delta` was not accepted as the answer,
because it could worsen model-selection penalties even while softening local
numerical cliffs.

That means the line was not trying to rescue itself by broadening uncertainty
until the scoreboard looked better.

The preferred interpretation route was:

- localize the repeatable tail,
- improve the tail mechanism directly,
- and keep the broader claim bounded.

## 5. Best short reading

The fairest summary is:

- before Rank 9, the Apex / CRL branch had already learned that some of the
  broad galaxy-pressure surface was tail-driven rather than uniformly fatal,
- and it preserved that diagnostic honestly as a bounded localization result
  rather than inflating it into a universal success claim.

That is a real pre-Rank-9 gain.
