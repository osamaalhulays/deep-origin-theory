# QCT v10.0 Apex: Progress Report & Statistical Roadmap

## 1. Current Status (Phases 1–4: Completed, Audit-Clean)
The foundational mathematical and operational phases are closed:
* **Theory Gates (TG‑1..TG‑4):** PASS, with TG‑4 **PASS (Pinned)** via strict environment lockfiles.
* **Lensing Gates (LG‑1..LG‑3):** PASS under **Option A (Mainline)**, with blinded/unblinded security, NDJSON outputs, and cryptographically sealed Results Capsules.

## 2. Statistical Track (Phases 5–6): Implemented and Secured
With the physics engine locked, the project moved to global statistical validation and fair benchmarking:
* Likelihood + priors implemented (Gaussian likelihood; log‑normal prior in log10 space for stellar M/L).
* Emulator governance scaffold and uncertainty propagation (`sigma_model`) hooks implemented.
* Deterministic Metropolis‑Hastings sampler + deterministic split-variance (k-fold partitions; no training) harness implemented.
* Rotation‑curve case schema (`rc_case_schema.json`) implemented and enforced.
* **QUMOND baseline** implemented with fixed constants and locked interpolating function.
* Benchmark harness computes AIC/BIC with transparent parameter counting.
* **Obs‑only likelihood** is designated as the official comparator for AIC/BIC (fairness), while QCT also reports obs+model likelihood for operational transparency.
* Statistical runs are packaged into audit‑clean Benchmark Capsules (NDJSON + summaries + hashes), with blind/unblind guards enforced.

## 3. Mechanism-Impact Notes (Workflow, not Physics)
The following rounds introduce *mechanism-impact* (new evaluation/packaging workflow) without changing physics:

* **Round 12D:** Introduced deterministic inference workflow (sampler + split-variance harness).
* **Round 12E:** Locked the formal posterior wiring (likelihood + prior) and introduced strict RC case schema.
* **Round 12F/12F1:** Wired the forward model to the emulator predictions and corrected the exact Phase‑3 mapping and uncertainty derivative.
* **Round 12G:** Added QUMOND baseline + fair benchmarking harness (AIC/BIC/χ²).
* **Round 12H:** Tightened fairness: AIC/BIC computed from **obs‑only** likelihood.
* **Round 12I:** Real feature wiring from locked manifest + case structure, with hash tracking.
* **Round 12J:** Emulator artifact protocol + no‑silent‑stub enforcement; provenance required for production benchmarking.
* **Round 12K:** Production guards + batch CLI + NDJSON validator + benchmark capsule post‑processing.
* **Round 12L:** Executable emulator artifact (`.npz`) support + stricter capsule audit provenance requirements.
* **Round 12M:** Pre‑publication statistical closure (5-seed split-variance test, Worst-40, parameter recovery, prior sensitivity).

## 4. Remaining Work (Outside-Repo / Operational)
1. **Train a real emulator artifact externally** (no raw training data committed), validate it meets accuracy targets, and generate its metadata (`EMU‑META‑v1`) with hashes and training manifest anchoring.
2. **Run production benchmarking on real rotation‑curve datasets** (e.g., SPARC), using the same blind protocol and capsule outputs.
3. Optionally extend MOND baselines (e.g., “standard” interpolating function) if required by reviewers, while keeping fairness constraints and parameter counting transparent.


> **MECHANISM-IMPACT NOTE (Round 12N):** Production benchmarking seals nuisance-prior width at `0.1 dex` and records `upsilon_sigma_dex_used` in all audit outputs. This hardens the statistical execution criteria without altering any QCT physics.
