# Global-Parameter Discipline Note

One of the easiest ways to under-read the pre-Rank-9 galaxy line is to treat it
as if it won only by using hidden per-galaxy freedom.

That is not what the strongest visible v8.x surfaces were trying to do.

## 1. The line was already moving toward one shared theory posture

The visible runner lineage shows a steady tightening:

- `QCT v8.3` described a **multi-galaxy global fit** with one shared parameter
  set `{chi, zeta, kappa0}` across multiple real galaxies, explicitly stating
  that there were **no per-galaxy theory knobs**.
- `QCT v8.5` pushed the same logic to the full `SPARC-175` line, again
  emphasizing that there were no per-galaxy theory knobs beyond photometric
  structure entering through measured galaxy inputs.
- `QCT v8.6` tightened the discipline further by reducing the galactic theory
  side to **two global parameters** with fixed exponent, while treating stellar
  mass-to-light as a nuisance quantity to be marginalized rather than a free
  per-galaxy rescue dial.

This matters because it means the galaxy line was already trying to answer the
harder scientific question:

- can one law-like structure survive across many galaxies,
- instead of fitting each galaxy by its own hidden tuning freedoms?

## 2. Why this is a real scientific gain

The no-particle-dark-matter posture would be much less interesting if it were
achieved by introducing quiet local knobs galaxy by galaxy.

What the runner lineage shows instead is a deliberate pressure toward:

- shared parameters,
- photometry-derived inputs,
- nuisance marginalization instead of arbitrary rescue fitting,
- and reporting that remained fold-aware and worst-case aware.

That does not by itself prove final correctness.

But it does prove that the program was already trying to earn credibility under
the right kind of pressure:

- fewer theory freedoms,
- more cross-galaxy exposure,
- and less room for hand-shaped victory.

## 3. Best short reading

The fair short summary is:

- before Rank 9, the galaxy line was not merely saying "QCT can fit galaxies,"
- it was already trying to do so under **global-parameter discipline**,
- and that makes the anti-dark-matter and anti-`MOND` comparisons materially
  stronger than a local-knob fit would have been.
