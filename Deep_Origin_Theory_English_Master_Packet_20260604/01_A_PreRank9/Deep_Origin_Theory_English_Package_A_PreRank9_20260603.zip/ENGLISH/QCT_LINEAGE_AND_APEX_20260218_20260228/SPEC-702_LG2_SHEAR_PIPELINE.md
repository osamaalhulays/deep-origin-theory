# SPEC-702: LG‑2 Shear Pipeline Specification

## 1. Inputs

- From 2D solver: \(\phi(R,z)\) on a cylindrical grid \((R,z)\) covering the galaxy.
- Baryonic density \(\rho_b(R,z)\) from SPARC metadata (exponential disk: \(\rho_b(R,z) = \Sigma_0 e^{-R/R_d} \frac{1}{2h_z}\text{sech}^2(z/h_z)\)).
- Galaxy metadata: redshift \(z_l\) (lens), source redshift \(z_s\) (if available; otherwise use a fixed representative value for the survey). Angular diameter distances \(D_l, D_s, D_{ls}\) are computed from a standard \(\Lambda\)CDM cosmology (Planck 2018).

## 2. Computing \(\rho_\phi\) from \(\phi\)

From the master normalization (SPEC‑201), the scalar field energy density in J/m³ is:

\[
\rho_\phi^{\text{J/m³}}(R,z) = \frac{M_P^{\text{kg}} c^2}{2}\left[ (\nabla\phi)^2 + m_{\text{inv}}^2 \phi^2 \right],
\]

with \((\nabla\phi)^2 = (\partial_R\phi)^2 + (\partial_z\phi)^2\). This is converted to mass density:

\[
\rho_\phi^{\text{mass}}(R,z) = \frac{\rho_\phi^{\text{J/m³}}(R,z)}{c^2}.
\]

## 3. Surface Mass Density

\[
\Sigma(R) = \int_{-\infty}^{\infty} \big[ \rho_b(R,z) + \rho_\phi(R,z) \big] \, dz.
\]


**Note for Modified‑Inertia baseline:** In the baseline identity, the scalar field does not contribute to the metric; therefore the lensing prediction uses \(\rho_\phi=0\) (and thus \(\Sigma_\phi=0\)). The pipeline may still compute \(\rho_\phi\) as a diagnostic quantity, but it must not be used in the likelihood for lensing.

(The Gauss–Bonnet contribution is omitted; it is expected to be <1% and will be bounded later.)

## 4. Lensing Observables

The critical surface density for a source at \(z_s\) and lens at \(z_l\) is:

\[
\Sigma_{\text{crit}} = \frac{c^2}{4\pi G} \frac{D_s}{D_l D_{ls}}.
\]

Convergence:

\[
\kappa(R) = \frac{\Sigma(R)}{\Sigma_{\text{crit}}}.
\]

For an axisymmetric lens, the tangential shear at projected radius \(R\) is:

\[
\gamma_t(R) = \frac{\bar{\kappa}(<R) - \kappa(R)}{1 - \kappa(R)},
\]

where \(\bar{\kappa}(<R) = \frac{2}{R^2}\int_0^R \kappa(R') R' dR'\) is the mean convergence inside \(R\). For weak lensing (\(\kappa\ll1\)), the denominator can be ignored.

## 5. Approximations

- **Thin lens approximation:** valid because the galaxy thickness is much smaller than the distances.
- **Born approximation:** light path is unperturbed; valid for weak fields.
- **Axisymmetry:** we use the spherically averaged convergence profile. For galaxies with known inclination, a full 2D shear map can be computed in future work.

## 6. Acceptance Tests

- **Subsample:** Select 10–20 galaxies from SPARC spanning low, mid, and high acceleration regimes, with reliable photometric scale lengths and redshifts.

- **AT1 (>1% difference):** Define outer bins \(R \in (2R_d, 3R_d]\) and \(R > 3R_d\). For each galaxy, compute \(\gamma_t^{\text{total}}\) (with \(\phi\)) and \(\gamma_t^{\text{bar}}\) (baryons only). Pass if for at least one galaxy the fractional difference \(|\gamma_t^{\text{total}} - \gamma_t^{\text{bar}}| / \gamma_t^{\text{bar}} > 0.01\) in either bin.

- **AT2 (consistency with existing data):** For the same galaxies, compare the predicted \(\kappa(R)\) with stacked shear measurements from surveys like CFHTLenS or KiDS for galaxies of similar mass and redshift. The model is considered **not yet falsified** if the predicted shear lies within the 2σ confidence interval of the stacked data in all radial bins. If such data are unavailable, this test is flagged as “pending external data”.

- **AT3 (solver consistency):** For a galaxy with negligible \(\phi\) (e.g., very low \(\gamma\) or very high \(m\)), the pipeline must return \(\kappa\) and \(\gamma_t\) matching the baryon‑only solution within 1%.
