# SPEC-204: TG‑4 Benchmarks (Action‑Consistent)

## 1. Exact m→0 Solution with Boundary Conditions

For the exterior of a point mass \(M_\odot\), the static spherical equation with \(m=0\) is:

\[
\frac{1}{r^2}\frac{d}{dr}\!\left(r^2\frac{d\phi}{dr}\right) = -\alpha_{\text{GB}}\,\mathcal{G}(r),\qquad
\mathcal{G}(r)=\frac{48 G^2 M_\odot^2}{c^4 r^6}.
\]

Integrating once:

\[
r^2\frac{d\phi}{dr} = \alpha_{\text{GB}}\frac{16 G^2 M_\odot^2}{c^4 r^3} + C_1.
\]

Integrating again:

\[
\phi(r) = -\alpha_{\text{GB}}\frac{4 G^2 M_\odot^2}{c^4 r^4} - \frac{C_1}{r} + C_2.
\]

- **Boundary condition at infinity:** \(\phi(\infty)=0\) ⇒ \(C_2 = 0\).
- **Regularity at the origin** after smoothing (a smoothing radius \(r_c\) is introduced, inside which \(\mathcal{G}\) is regularized). Matching a regular interior solution forces the coefficient of the singular \(1/r\) term to vanish: \(C_1 = 0\).

Thus the **physical solution** for \(r > r_c\) is uniquely:

\[
\phi(r) = -\alpha_{\text{GB}}\frac{4 G^2 M_\odot^2}{c^4 r^4}.
\]

## 2. Robust Numerical Benchmark Diagnostics

| Diagnostic | Target | Tolerance |
|------------|--------|-----------|
| \(Q(r) = r^4 \phi(r)\) | constant \(= -\alpha_{\text{GB}}\frac{4 G^2 M_\odot^2}{c^4}\) | relative error <1% for \(r \gg r_c\) |
| Logarithmic slope \(\frac{d\ln|\phi|}{d\ln r}\) | \(-4\) at \(r \gg r_c\) | ±0.05 |
| Detection of spurious \(1/r\) term | \(Q(r)\) should not increase as \(r^3\) (would indicate \(C_1\neq0\)) | \(Q(r)\) flat in \(r\) |

The constant value of \(Q\) must also be compared to the analytic expression:

\[
Q_{\text{expected}} = -\alpha_{\text{GB}}\frac{4 G^2 M_\odot^2}{c^4}.
\]

In the asymptotic region (e.g., \(r > 100 R_\odot\) and \(r < 10\,\text{AU}\)), the mean of \(Q(r)\) should match \(Q_{\text{expected}}\) within 5%.

## 3. Monotonicity and m‑Dependence

- **Compton wavelengths:**  
  \(m_{\min}=10^{-30}\,\text{eV}\) ⇒ \(m_{\text{inv}} \approx 5.07\times10^{-24}\,\text{m}^{-1}\), \(1/m_{\text{inv}} \approx 1.97\times10^{23}\,\text{m} \gg 1\,\text{AU}\).  
  \(m_{\max}=10^{-10}\,\text{eV}\) ⇒ \(m_{\text{inv}} \approx 5.07\times10^{-4}\,\text{m}^{-1}\), \(1/m_{\text{inv}} \approx 1970\,\text{m} \ll 1\,\text{AU}\).

For nonzero \(m\), the solution is Yukawa‑suppressed: at large \(r\) it behaves as \(\phi \sim e^{-m_{\text{inv}} r}/r\). The effect at 1 AU decreases monotonically with increasing \(m\). Hence the **worst case** (largest possible Solar‑System correction) is the \(m\to0\) limit. The \(m=0\) benchmark therefore provides a **conservative upper bound** for all allowed \(m\).

## 4. Analytic Upper Bound for ε(1 AU)

Using the \(m=0\) solution, the scalar energy density is:

\[
\rho_\Phi(r) = \frac{M_P^2}{2}\left(\frac{d\phi}{dr}\right)^2,\quad
\frac{d\phi}{dr} = 16\alpha_{\text{GB}}\frac{G^2 M_\odot^2}{c^4 r^5}.
\]

Substituting \(\alpha_{\text{GB}} = \gamma/M_P^2\) gives:

\[
\rho_\Phi(r) = 128\,\gamma^2 \frac{G^4 M_\odot^4}{M_P^2 c^8 r^{10}}.
\]

The total scalar mass enclosed within a radius \(r_c\) (where the density is regularized) is:

\[
M_\phi \approx \int_{r_c}^\infty \frac{\rho_\Phi(r)}{c^2}\,4\pi r^2 dr = \frac{512\pi\,\gamma^2 G^4 M_\odot^4}{M_P^2 c^{10}} \int_{r_c}^\infty r^{-8} dr = \frac{512\pi\,\gamma^2 G^4 M_\odot^4}{7\,M_P^2 c^{10} r_c^7}.
\]

For \(\gamma=0.1\) and \(r_c = 0.01 R_\odot = 6.96\times10^6\,\text{m}\), this yields \(M_\phi / M_\odot \ll 10^{-30}\). Consequently \(\Phi_\phi\) at 1 AU is negligible, and

\[
\varepsilon(1\,\text{AU}) \ll 10^{-5}.
\]

Thus the entire frozen prior is automatically safe; no tightening is required. This analytic bound serves as a sanity check for the numerical results.
