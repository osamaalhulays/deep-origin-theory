# SPEC-205: Phenomenological Closure for Galaxy‑Scale Solver (Corrigendum)

## 1. Context

The galaxy‑scale PDE used in the 2D solver (EPIC‑30) is **not** directly derived from the action under controlled approximations; it is a phenomenological closure designed to capture the essential screening behavior while keeping the numerical implementation tractable. This document clarifies the status, the fixed conventions, and the validation plan.

## 2. The Phenomenological PDE

The equation solved for the dimensionless field \(\phi(R,z)\) in the axisymmetric galaxy setting is:

\[
\frac{1}{R}\frac{\partial}{\partial R}\!\left(R\frac{\partial\phi}{\partial R}\right) + \frac{\partial^2\phi}{\partial z^2} - m_{\text{eff}}^2(\rho_b)\,\phi = \beta\,\kappa\,\rho_b(R,z),
\]

with

\[
m_{\text{eff}}^2 = m_{\text{inv}}^2 + \beta_\alpha\,\kappa\,\rho_b,
\qquad
\kappa \equiv \left(\frac{8\pi G}{c^2}\right).
\]

Dimensional audit (SI):
- \([\phi]=1\) (dimensionless), so \([\nabla^2\phi]=\text{m}^{-2}\).
- \([\rho_b]=\text{kg}/\text{m}^3\).
- \([\kappa]=\text{m}/\text{kg}\), hence \([\kappa\rho_b]=\text{m}^{-2}\).
Therefore all terms in the PDE are strictly homogeneous in \(\text{m}^{-2}\).

**No new free parameters:**
- \(\beta\) (source coupling) and \(\beta_\alpha\) (screening coupling) are **fixed dimensionless conventions**, frozen to exactly \(1\).
- \(\kappa\) is constructed solely from fundamental constants \(G,c\) already present in SPEC‑201, introducing **no new scale**.

This closure is phenomenological; its accuracy is verified against the action‑consistent equation via the validation plan in Section 4.

## 3. No New Free Parameters

- The only global free parameters of the theory remain \(\gamma\) and \(m\).  
- The coefficients \(\beta\) and \(\beta_\alpha\) are **fixed conventions**, not varied during fitting. Their values are set once and for all and are part of the phenomenological model definition.  
- The mapping between the action and the phenomenological closure is approximate; any deviation is absorbed into the validation error budget.

## 4. Validation Plan (EPIC‑30)

To ensure that the phenomenological closure does not introduce significant bias, the following validation must be performed:

1. **Spherical symmetry test cases:** For a spherical galaxy (or a point mass in a smooth background), solve both the exact action‑consistent equation (as in TG‑4) and the phenomenological PDE. Compare the resulting \(\phi(r)\) and \(\Delta(r)\).
2. **Error metric:** The maximum relative error in \(\phi(r)\) over the region \(0.1 R_d \le r \le 10 R_d\) must be <1%.
3. **Acceptance:** If the error exceeds 1%, the phenomenological closure must be adjusted (e.g., by tuning fixed conventions or the functional form) **without introducing new free parameters**. The chosen conventions must then be frozen and documented.

This validation will be part of the solver development and must be reported in the code repository.
