# QCT v10.0 Apex: Statistical Track Final Sign-Off

**Date:** 2026-02-21  
**Status:** PRODUCTION-READY, AUDIT-CLEAN & REVIEWER-HARDENED

## 1. Executive Conclusion
The Statistical & Benchmarking Track (Phases 5–6) is formally closed. The pipeline operationalizes a fair comparison between:
- **Option A (Mainline):** QCT / SPEC-702 Hybrid Lensing
- **Option B (Alt):** Baryon-only / QUMOND baseline

No physical equations were altered (Phase-1/2/3 + TG/LG logic remain READ-ONLY). No new free parameters were introduced.

## 2. No-Knobs Enforcement (Production Path)
To prevent p-hacking / parameter-tuning during publication runs, the production benchmarking path is sealed:
- **Locked nuisance prior width:** The stellar M/L prior width is enforced at **0.1 dex** for all official benchmarking runs.
- **Audit trail:** Every benchmark output records `upsilon_sigma_dex_used`.
- **Fair likelihood comparator:** AIC/BIC are computed from **obs-only** likelihood (`sigma_model=None`) for both models. QCT also reports obs+model likelihood diagnostically.

## 3. Evaluation Nomenclature
Because the emulator is trained externally (not inside folds), the multi-seed evaluation protocol is designated a:
**Multi-Seed Split-Variance Test** (k-fold partitions used only to estimate split-variance; no training occurs in folds).

## 4. Diagnostics
Prior-sensitivity and parameter-recovery suites are explicitly **diagnostic-only** and cannot override production benchmarking rules.

