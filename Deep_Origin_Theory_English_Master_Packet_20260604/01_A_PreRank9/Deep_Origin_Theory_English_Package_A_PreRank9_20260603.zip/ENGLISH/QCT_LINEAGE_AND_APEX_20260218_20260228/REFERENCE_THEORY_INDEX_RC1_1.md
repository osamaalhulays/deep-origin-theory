# QCT v10.0 Apex – Theory Index (RC1.1)

This document maps each gate to the required theory documents and their current status.

| Gate | Title | Required Documents | Status | Remaining Steps |
|------|-------|--------------------|--------|-----------------|
| TG‑1 | Single Action | SPEC-201 | **PASS** | None – final. |
| TG‑2 | Ghost‑free / EFT‑safe | SPEC-201 (Section 5) | **PASS** | None – final. |
| TG‑3 | Universality | SPEC-201, SPEC-205 (no manual Rd constants, strictly normalized closure) | **PASS** | None – final. |
| TG‑4 | Limit Recovery (Solar System) | SPEC-204_ACTIONCONSISTENT, SPEC-204_BENCHMARKS_CORRECTED | **PASS (Pinned)** | Strict environment pinning applied via lockfiles for absolute reproducibility. |
| LG‑1 | Lensing Mechanism | SPEC-CR-701 (Change Request) | **PENDING** | Two reviews + committee approval; not binding yet. |
| LG‑2 | Shear Pipeline | SPEC-702 | **PENDING** | Implementation after 2D solver; depends on LG‑1 approval. |
| LG‑3 | Falsification Statement | LG-3_FALSIFICATION_FINAL | **PENDING** | Final wording after LG‑1 approval; ready for use. |

**Additional documents:**
- `SPEC-205_PHENOMENOLOGICAL_CLOSURE_CORRIGENDUM.md` clarifies the galaxy‑scale solver’s phenomenological nature and ensures strict dimensional consistency.
- `NOTE_REFEREE_ATTACKS_AND_MITIGATIONS.md` summarizes responses to potential referee critiques.
- `APPENDIX_A_VERBATIM_SOURCE.md` is the original causal‑diamond construction text.

**Notes:**
- No new parameters have been introduced.
- Frozen priors remain: \(\gamma \in [10^{-6},10^{-1}]\) log‑uniform, \(m \in [10^{-30},10^{-10}]\) eV log‑uniform, \(\lambda=0\).
