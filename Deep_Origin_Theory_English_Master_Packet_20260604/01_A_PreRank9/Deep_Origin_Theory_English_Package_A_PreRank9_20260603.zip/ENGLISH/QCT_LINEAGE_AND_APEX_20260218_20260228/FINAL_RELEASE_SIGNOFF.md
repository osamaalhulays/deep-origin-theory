# QCT v10.0 Apex: Final Release Sign-Off

**Date:** 2026-02-21
**Baseline:** Round 12N
**Environment:** Python 3.10.12 (Strictly Pinned via lockfiles)
**Status:** PRODUCTION-LOCKED & ARCHIVAL-READY

## 1. Physics & Model Invariants
The core theoretical engine is mathematically and operationally locked:
* **Physics Read-Only:** Phase-1, Phase-2, Phase-3, and all Theory/Lensing Gates (TG-1..4, LG-1..3) are permanently frozen. No physical equations have been altered, and no new free parameters have been introduced.
* **Option Labels (Lensing):** All outputs and comparisons strictly and literally enforce the tags **`OptionA(Mainline)`** (Hybrid Lensing) and **`OptionB(Alt)`** (Baryon-only Lensing / QUMOND Baseline).

## 2. Statistical Track & Reviewer-Proofing
The benchmarking and inference pipeline is fully sealed against external manipulation or methodological bias:
* **Locked Nuisance Prior:** The Bayesian prior width for the stellar mass-to-light ratio is strictly hardcoded in production. All generated audits will explicitly read `audit.upsilon_sigma_dex_used == 0.1`.
* **Fail-Loudly Architecture:** Any deviation from expected schemas, physical domains (e.g., negative uncertainties), or missing configuration files will immediately crash the pipeline rather than failing silently.

## 3. Security & Governance (Blind Protocol)
* **Data Privacy:** Absolutely zero raw observational data is committed to the repository or included in the output capsules. Capsules contain only hashed metadata, aggregated statistics, and cryptographically verified audit trails.
* **Unblind Guards:** Production execution requires the presence of the locked `manifest.json` and explicit environment tokens (`QCT_UNBLIND=YES`, `QCT_MANIFEST_HASH`).

## 4. Final Verification Verification
The final system state has been completely validated within the locked Python 3.10.12 environment using the standard test suite:
* **Command:** `python -m pytest -q --strict-markers`
* **Result:** `120 passed in ~2.14s`

## 5. Archival Artifacts
The official deliverables for this project are packaged via an external archival helper (not tracked in the core repository) into three specific formats:
1. **Full Repo ZIP:** A complete, structural copy of the codebase.
2. **Single-Container ZIP (Flat):** All files flattened into a single directory, accompanied by a `PATH_MAP.json` for path reconstruction.
3. **MegaFile.md:** A unified markdown document containing the entire repository's tree and file contents for easy reference and AI-ingestion.

**Sign-off:** *QCT Engineering/Execution Lead*
