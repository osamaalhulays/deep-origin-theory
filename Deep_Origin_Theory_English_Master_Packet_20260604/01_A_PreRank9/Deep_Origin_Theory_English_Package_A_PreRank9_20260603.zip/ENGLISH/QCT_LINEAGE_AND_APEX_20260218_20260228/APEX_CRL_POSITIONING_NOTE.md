# Apex / CRL Positioning Note

The Apex material should not be confused with the later Deep Origin Rank-9
public shelf.

Its value inside Package A is different.

## What Apex contributes

The Apex / CRL line contributes evidence of a strong gate-based scientific
discipline:

- explicit pass / pending logic,
- separation between a statistical ceiling and a physical branch,
- explicit phenomenological-closure honesty instead of fake exactness,
- strict falsification posture,
- and an insistence that methodological gains not be inflated into universal
  closure claims.

## What the February release pack shows

`THEORY_RELEASE.md` presents the Curvature Response Law as:

- empirical,
- phenomenological,
- narrow in scope,
- intentionally distinguished from a fundamental-law claim,
- and willing to close unsupported side inputs instead of quietly inflating the
  dataset surface.

## What the theory indexes show

`THEORY_INDEX_RC1_3.md` and `REFERENCE_THEORY_INDEX_RC1_1.md` show that the
program already knew how to:

- name gates cleanly,
- separate passed from pending fronts,
- keep the galaxy closure bounded to frozen conventions rather than letting it
  drift into extra free parameters,
- preserve pinned reproducibility expectations,
- and tie public posture to concrete theory documents rather than to loose
  enthusiasm.

## Why it belongs here

Apex is not included because it is the same object as the later Deep Origin
framework.

It is included because it records a real branch of disciplined scientific
labor that belongs to the pre-Rank-9 history and deserves to remain visible.
