# Committee Decision — LG-1 Identity Resolution (Mainline + Alt Branch)

**Date:** 2026-02-20  
**Baseline:** QCT v10.0 Apex RC1.2+  
**Subject:** Lensing mechanism identity and branching policy

## 1) Decision
**Option A (SPEC-702) is adopted as the official Mainline baseline.**

Identity is resolved as a **Hybrid framework**:
- Modified inertia governs rotation-curve phenomenology.
- Modified gravity governs lensing via \(\rho_\phi\) contributing to the metric.

## 2) Branch Policy
**Option B (baryon-only lensing) is preserved as an ALT branch.**
It is retained for comparison and potential future development only, not as the publication baseline.

## 3) Governance Constraints
1. **No New Parameters:** \(\Sigma_\phi\) must use only the frozen global parameters \((\gamma, m)\).
2. **Strict Tagging:** Every report/plot must declare `LensingMode=OptionA(Mainline)` or `OptionB(Alt)`.
3. **No Cross-Contamination:** Mixing outputs from the branches without explicit labeling is forbidden.

## 4) Immediate Repo Actions
- Promote LG-1 mechanism to `SPEC-701_LG1_LENSING_MECHANISM.md`.
- Lock the mainline dependency: `SPEC-701 -> SPEC-702`.
