# QCT v10.0 Apex: Final Engineering Sign-Off

**Date:** 2026-02-20  
**Baseline:** RC1.2  
**Status:** PRODUCTION-READY & AUDIT-CLEAN  

## 1. Executive Conclusion & Model Identity
The QCT (Quantized Causal Theory) Lensing Pipeline (LG-1 through LG-3) is officially closed for development and certified for observational execution. The theory operates strictly under a **Hybrid Framework**:

- **Option A (MAINLINE):** **SPEC-702 Hybrid Lensing.** The scalar field modifies inertia dynamically for galaxy rotation, while its physical energy density ($\rho_\phi$) explicitly contributes to the gravitational lensing convergence ($\Sigma_{\text{total}} = \Sigma_{\text{baryon}} + \Sigma_\phi$). This is the sole predictive baseline.
- **Option B (ALT):** **Baryon-only lensing.** Retained purely as an archived control branch for statistical divergence testing.

## 2. Governance & Integrity
The pipeline enforces a mathematically rigorous Phase-2 Blind Protocol. Execution on real data is physically impossible without a cryptographic manifest hash (`QCT_MANIFEST_HASH`). All production runs automatically generate a tamper-evident Results Capsule containing environment fingerprints and SHA256 hashes of all inputs/outputs, without ever retaining the raw observational data.

## 3. What is Proven vs. Assumed
### Proven (implementation & mathematical consistency)
- The computational pipeline deterministically implements the mathematical model defined in **SPEC-201 / SPEC-205 / SPEC-702**.
- The integration from EPIC-30 outputs to weak-lensing shear ($\gamma_t$) is mathematically stable under the pinned environment.
- Fail-loudly safeguards correctly trap non-physical / unstable numerical regimes (e.g., $\Sigma_\phi < -\text{tol}$) without contaminating statistics.
- The LG-3 falsification gate deterministically distinguishes between Option A and Option B when data quality is sufficient.

> **Note:** “Proven” here refers to correctness of the **code implementation** and **mathematical consistency** with the stated specifications, not a proof of the physical correctness of the theory itself.

### Assumed (physics-model assumptions held fixed)
- The phenomenological closure assumptions (SPEC-205) hold universally across evaluated datasets.
- Frozen priors ($\gamma, m$) are strictly maintained without local fitting or hidden knobs.

## 4. Summary of Stress-Test Executions (Runs 01–04)
Across four production run templates (scaling from $N=23$ to $N=200$) the pipeline demonstrated extreme robustness:

- **Throughput:** Processed 350+ valid cases (across runs).
- **Discriminatory Power:** Pre-selection improved the **testable fraction** from ~68% (Run01) to ~98% (Run04).
- **Falsification Status:** **0.0% falsified** under LG-3 in the reported run summaries.
- **Error Pattern:** A stable ~2% attrition rate due to expected numerical boundary limits at extreme radii, safely isolated by fail-loudly guards.

## 5. Release Statement
This repository is now in a **production & audit** state. Further modifications to physics logic, priors, gates, or option naming require a new governance change record and explicit committee approval.
