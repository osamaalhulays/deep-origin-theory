# QCT v10.0 Apex – Theory Index (RC1.3)

> **FINAL ENGINEERING STATUS (2026-02-20):**
> The LG-1, LG-2, and LG-3 gates are **PRODUCTION-READY** and **AUDIT-CLEAN**. The environment is strictly pinned, the blind protocol is cryptographically secured, and all outputs are packaged into tamper-evident Results Capsules. Changes to physics/priors/gates require a new change record and explicit approval.


This document maps each gate to the required theory documents and their current status.
All code and validations must strictly adhere to the baselines defined here.

| Gate | Title | Required Documents | Status | Remaining Steps |
|------|-------|--------------------|--------|-----------------|
| TG‑1 | Single Action | SPEC-201 | **PASS** | None – final. |
| TG‑2 | Ghost‑free / EFT‑safe | SPEC-201 (Section 5) | **PASS** | None – final. |
| TG‑3 | Universality | SPEC-201, SPEC-205 (Phenomenological closure) | **PASS** | None – final. |
| TG‑4 | Limit Recovery (Solar System) | SPEC-204_ACTIONCONSISTENT, SPEC-204_BENCHMARKS | **PASS (Pinned)** | Strict environment pinning applied via lockfiles for absolute reproducibility. |
| LG‑1 | Lensing Mechanism | SPEC-701, DECISION_LOG_LG1_MAINLINE_OPTIONA | **PASS (Mainline)** | Option A adopted. Option B archived as Alt branch. |
| LG‑2 | Shear Pipeline | SPEC-702 | **PASS** | Engineering implementation completed under Option A (Mainline). |
| LG‑3 | Falsification Statement | LG-3_FALSIFICATION_FINAL | **PASS** | Operational gate + blind/unblind harness + batch tooling. |

## Canonical Option Naming (FINAL)
- **Option A (Mainline):** Hybrid lensing baseline (SPEC-702).
- **Option B (Alt):** Baryon-only lensing (archived branch).

All official outputs must be tagged:
- `OptionA(Mainline)` or `OptionB(Alt)`.

## Additional documents
- `SPEC-205_PHENOMENOLOGICAL_CLOSURE_CORRIGENDUM.md`
- `NOTE_REFEREE_ATTACKS_AND_MITIGATIONS.md`
- `APPENDIX_A_VERBATIM_SOURCE.md`

## Operational / governance artifacts
- `SCHEMA_LG3_INPUT.json`, `SCHEMA_LG3_REPORT.json`
- `RUNBOOK_UNBLIND_LG3.md`