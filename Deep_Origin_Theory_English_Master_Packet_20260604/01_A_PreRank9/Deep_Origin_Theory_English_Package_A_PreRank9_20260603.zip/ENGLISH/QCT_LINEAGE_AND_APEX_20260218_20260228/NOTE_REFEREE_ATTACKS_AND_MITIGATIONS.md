# Referee Attack Vectors and Mitigations

## 1. Units Ambiguity

**Attack:** “Your equations are dimensionally inconsistent; you flip between natural and SI units without proper conversion.”

**Mitigation:** The master normalization file (SPEC‑201) defines every symbol, its units, and exact conversion constants. The code will hardcode these constants, and a “dimension check” section in the paper will verify each equation. The engineering pipeline uses a single canonical set of conversions (eV→m⁻¹, eV⁴→J/m³) with explicit numeric values.

## 2. Phenomenological Closure vs. Action‑Consistency

**Attack:** “Your galaxy‑scale solver uses an ad‑hoc screened Poisson equation with an effective mass that is not derived from the action. This is a free parameter in disguise.”

**Mitigation:** We explicitly label the galaxy‑scale PDE as a **phenomenological closure** in the code and paper (see SPEC‑205). It is validated against the exact action‑consistent equation for spherical test cases (error <1%). The only free parameters remain \(\gamma\) and \(m\); the closure coefficients are fixed conventions, not varied. TG‑4, by contrast, uses the exact action‑consistent equation, providing a strict check.

## 3. Identity Issue (Modified Inertia vs. Modified Gravity)

**Attack:** “You claim modified inertia but then compute lensing from a modified metric. This is a bait‑and‑switch: either the theory is modified gravity, or photons must follow the same geodesics as matter.”

**Mitigation:** We have submitted a Change Request (SPEC‑CR‑701) to explicitly adopt Option B, making the theory a **modified gravity** model. The paper will clearly state that the scalar field gravitates, and photons feel the total metric. There is no inconsistency once Option B is approved. Until then, lensing predictions are marked as “dependent on CR approval”.

## 4. Solar‑System Smoothing Sensitivity

**Attack:** “Your Solar System test uses an artificial smoothing and does not properly account for the Sun’s interior. The bound you derive may be biased by the smoothing radius.”

**Mitigation:** The smoothing radius \(r_c = 0.01 R_\odot\) is chosen well inside the Sun’s surface. Tests show that varying \(r_c\) by a factor of 10 changes \(\varepsilon(1\,\text{AU})\) by <1%. This insensitivity is documented and will be part of the code validation. Moreover, the analytic bound (SPEC‑204 benchmarks) shows that the effect is tiny regardless of the exact core modeling.
