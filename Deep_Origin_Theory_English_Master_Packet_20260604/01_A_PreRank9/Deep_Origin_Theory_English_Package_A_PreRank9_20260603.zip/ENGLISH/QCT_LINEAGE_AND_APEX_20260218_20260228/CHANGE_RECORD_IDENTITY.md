# Identity Resolution & Deviation Record

**Date:** 2026-02-20  
**Subject:** Formal Deviation from "Modified Inertia + Baryon-only Lensing"

## 1. The Original Assumption
Early iterations of the QCT development plan assumed the scalar field $\phi$ operated *exclusively* as a modification to inertia (MI), suggesting that photons would only be lensed by the baryonic mass (what is now strictly designated as **Option B (Alt)**).

## 2. The Required Deviation
During the execution of the Lensing Gates (LG-1), the Theory Lead established that maintaining Option B as the mainline was theoretically inconsistent and observationally inadequate:
1.  **General Relativity Consistency:** The scalar field $\phi$ is a dynamical degree of freedom with a non-zero energy-momentum tensor. Ignoring its physical energy density ($\rho_\phi$) in the computation of spacetime curvature ($g_{\mu\nu}$) is an uncontrolled and mathematically invalid approximation.
2.  **Observational Reality:** Pure baryon-only lensing predictions fall severely short of the observed weak lensing shear ($\gamma_t$) in outer galactic halos. Option B is inadequate to explain the empirical lensing data without dark matter.

## 3. The Resolution
The committee formally adopted **Option A (Mainline / SPEC-702 Hybrid Lensing)**.  
QCT is now defined as a Hybrid: it utilizes Modified Inertia to solve the dynamic rotation curves without dark matter, while correctly accounting for the scalar field's energy density ($\rho_\phi \rightarrow \Sigma_\phi$) as a Modified Gravity contribution to the lensing metric. Option B is permanently archived as an `Alt` baseline for statistical comparison only.

