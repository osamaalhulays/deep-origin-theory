# Screenshot Repo Coverage And Decision Matrix

This matrix answers one practical question:

**Which screenshot workspaces were harvested into this foundation bundle, and how?**

## Direct scientific-source contributors

- `QCT 2026`
  - harvested as the late QCT public lineage source
  - especially the v8.x English manuscripts
- `QCT_Apex_Repo_Run`
  - harvested as the Apex / CRL branch source
  - theory indexes, release posture, reviewer-facing `QUMOND` benchmark
    discipline, and explicit lensing branch/falsification witnesses included
- `ZamaKan`
  - harvested as the accepted authority for `qct_core` closure posture
  - also provides closure wording and lineage hygiene for accepted-core status
- `Q platform`
  - harvested as the English evidence and contract source for the
    Action-vs-EPIC closure path
  - also harvested as the source of the morphology-survival white-arm
    formalization and the preserved `B1Y` sentinel witness route
- `World of Q Map (خريطة عالم Q)`
  - harvested as the Rank-8 public bundle and Rank-8 to Rank-9 handoff source

## Direct support contributors

- `Academy Plug`
  - used for the initial-publication boundary and publication-strategy discipline
- `Factory V1 Trial`
  - used for physics-first scoreboard, live blocker wording, and observable
    dictionary support
- `Q Platform Archive (كيو بلاتفورم الارشيف)`
  - used as an upstream support-stack source
  - contributes architecture-foundation, governance-charter, input-contract,
    run-context, return-block, and sources-index discipline
- `Adapter (الادابتور)`
  - used as assembly and archival staging workspace
  - also used as a packet-identity and continuity-preservation workspace across
    bundle generations
  - also contains preserved copies of Rank-8 / Rank-9 bundle artifacts

## Indirect or source-reservoir contributors

- `Raw Sources (مصادر خام)`
  - used as evidence-feed and source-reservoir context
  - not exposed as a main reader-facing shelf
- `Library (مكتبتي)`
  - used as source reservoir for the White Law and gap-report originals

## Excluded from the public surface of this foundation bundle by design

- `Kreib (كريب)`
  - reserved mainly for the Rank-9 / Rank-10 live execution world
  - belongs structurally to the later Rank-9 and Rank-10 bundles
- `Friends (الاصدقاء)`
  - inspected and not harvested into this foundation bundle
  - contains MACS1206 external-replication kits, friend return reports, and
    Windows one-click/one-file delivery packaging
  - belongs to the later MACS1206 / cluster-lensing replication boundary
    rather than to the pre-Rank-9 foundation layer
- private application/interface workspaces
  - inspected and intentionally not harvested into this public bundle
  - belong to the private application and commercial-bridge layer rather
    than to the public scientific foundation itself
- `Kreib recovery backups (كريب__recovery_backups_2026-04-03)`
  - backup only
  - not a public-facing scientific source for this foundation bundle

## Why this matters

No screenshot workspace was silently ignored.

Each one was either:

- harvested directly,
- harvested indirectly,
- or excluded explicitly because it belongs to later bundles or to backup-only
  storage.
