# Action-vs-EPIC Reestablishment Support Radius Identity Lock Status

- generated_at_utc: `2026-03-23T18:21:46Z`
- support_radius_identity_lock_state: `locked__shared_smooth_no_edge_convention_declared_for_reestablishment_path`
- declaration_state: `sovereign_approved`
- declared_shared_convention: `shared_smooth_no_edge`
- required_next_declaration: `same_support_radius_source_edge_convention_must_be_declared_before_reestablishment_lock_can_close`

## Required Shared Convention Options
- shared_compact_edge
- shared_smooth_no_edge

## Note
- This packet keeps the support-radius/source-edge condition honest for the authoritative reestablishment path. At the current stage the missing item is an explicit shared convention, not a hidden numerical tweak.
