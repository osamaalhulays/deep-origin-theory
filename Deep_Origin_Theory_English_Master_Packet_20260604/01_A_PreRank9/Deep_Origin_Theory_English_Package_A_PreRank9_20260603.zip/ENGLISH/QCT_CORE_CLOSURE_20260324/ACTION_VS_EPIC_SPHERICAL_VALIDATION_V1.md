# Action-vs-EPIC Spherical Validation V1

Status: CANONICAL_READ_ONLY_FOUNDATION_ACTIVE

## Scope

This contract defines the canonical governed Debt-1 packet for comparing the action-consistent spherical solution against the EPIC-30 phenomenological closure on a shared source class.

Its purpose is to:

- bind the current selected line to the canonical `FMR` white root and locked `SPEC-201` action root
- expose whether a shared-source spherical benchmark is actually materialized
- expose the `phi(r)` and `Delta(r)` acceptance surface required by `SPEC-205`
- expose whether the current benchmark is legitimate enough for that numeric compare to become governing
- keep the whole layer below truth, promotion, closure, release, and candidate-state mutation

## Canonical Inputs

- `operator/runtime/reports/candidate_specific_equation_progress_line_v1_status.json`
- `operator/runtime/reports/fixed_r_morphology_survival_white_law_formalization_v1_status.json`
- `operator/runtime/reports/candidate_exact_vs_closure_direct_compare_v1_status.json`
- `operator/runtime/reports/action_vs_epic_benchmark_legitimacy_lock_v1_status.json`
- `operator/runtime/reports/action_vs_epic_benchmark_canonical_admissibility_reestablishment_v1_status.json`
- `operator/runtime/reports/action_vs_epic_reestablished_canonical_benchmark_materialization_v1_status.json`
- `adapters/qct/imports/manifests/qct_debt1_scientific_imports.latest.json`
- `adapters/qct/imports/runtime_reports/qct_adapter_action_vs_epic_spherical_validation_status.json`
- `docs/sources/ACTION_VS_EPIC_BENCHMARK_LEGITIMACY_EXTERNAL_VERDICT_C.md`

## Required Output

- one canonical `action_vs_epic_spherical_validation_record`
- one canonical registry that points to the latest record and latest advisory status
- one advisory `action_vs_epic_spherical_validation_status`

## Validation Rule

This layer governs the Debt-1 spherical validation requirement from `SPEC-205` by reading the current QCT adapter import, not by running the scientific producer inside the platform:

- compare `phi(r)` over `0.1 R_d <= r <= 10 R_d`
- compare `Delta(r)` over the same window
- accept only if both maximum relative errors are `< 1%`

If a shared-source spherical benchmark is not actually materialized yet, this layer must say so explicitly and stay diagnostic-only.

If the QCT adapter import itself is missing, this layer must surface that missing adapter boundary explicitly and remain diagnostic-only.

If benchmark legitimacy is still under-specified under the current external verdict, this layer must keep the numeric compare visible but classify it as:

- `diagnostic_only`
- `not_yet_governing_for_stage14_numeric_failure`

until the following legitimacy locks are materialized:

- `action_vs_epic_epic30_source_class_admissibility_must_be_locked`
- `action_vs_epic_shared_source_definition_must_be_locked`
- `action_vs_epic_boundary_conditions_and_matching_must_be_locked`
- `action_vs_epic_phi_delta_mapping_identity_scope_must_be_locked`
- `action_vs_epic_validation_window_regime_admissibility_must_be_locked`

If benchmark reestablishment later becomes complete while the imported active-adapter surface still points to the old rejected proxy benchmark, this layer must keep the numeric compare visible but classify it as:

- `diagnostic_only`
- `reestablished_canonical_benchmark_not_yet_materialized`

until the active adapter materially exports the new same-source canonical benchmark surface.

It must never:

- convert a legacy point-mass diagnostic compare into a shared-source pass
- convert plan language into a numeric result
- convert a numeric mismatch into a governing failure while benchmark legitimacy is still under-specified
- or convert the presence of references into a cleared validation by inference

## Hard Boundary

This packet is advisory only.

It may not:

- claim scientific truth
- unlock stage 14 by wording alone
- authorize closure
- authorize release or delivery
- mutate candidate state

## Non-Authority Rule

Action-vs-EPIC spherical validation is governed visibility only.

It is not truth.
It is not promotion.
It is not closure.
