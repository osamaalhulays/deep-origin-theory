# QCT Adapter Action-vs-EPIC Spherical Validation

- generated_at_utc: `2026-03-23T18:21:18Z`
- selected_candidate_id: `not_applicable__adapter_root_packet`
- validation_state: `pass__shared_source_benchmark_within_threshold`
- shared_source_class_state: `materialized`
- source_relation: `qct_adapter_scientific_result_not_platform_core`
- benchmark_materialization_state: `materialized__reestablished_canonical_same_source_benchmark_result`
- reestablished_canonical_benchmark_binding_state: `bound__reestablished_canonical_same_source_benchmark`
