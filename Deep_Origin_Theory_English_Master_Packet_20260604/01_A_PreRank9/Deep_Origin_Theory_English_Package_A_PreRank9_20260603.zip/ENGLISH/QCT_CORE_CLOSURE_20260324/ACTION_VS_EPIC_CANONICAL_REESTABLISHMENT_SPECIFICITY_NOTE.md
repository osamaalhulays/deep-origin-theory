# Action-vs-EPIC Canonical Reestablishment Specificity Note

One important pre-Rank-9 gain can be missed if a reader sees only
`benchmark pass` language.

The stronger gain was narrower and more technical:
the program did not merely hope that a lawful same-source benchmark could be
restored later. It eventually spelled out, locked, and materially exposed the
exact canonical shape that such a benchmark had to take.

## What had been wrong before

The earlier `Action-vs-EPIC` bridge was not rejected because the idea of a
same-source comparison was meaningless.

It was rejected because the active comparison was not canonically shared
between exact and closure sides:

- the exact side was still tied to an extended `rho(r)` source,
- the closure side still leaned on a point-mass exterior surrogate,
- same-profile identity was not preserved,
- support-radius / source-edge identity was not preserved,
- and the benchmark therefore could not be cited as a lawful canonical
  same-source object.

That earlier condition is visible in
`action_vs_epic_shared_source_definition_lock_v1_status.md`.

## What later became materially explicit

The later gain was that the reestablishment path stopped being vague.
It became a fully specified canonical same-source path with named locks:

- the closure-side compare mode was repinned from
  `point_mass_exterior_surrogate_mode` to
  `extended_spherical_source_mode`,
- the closure-side source field was frozen through the direct spherical
  embedding `rho_b(R,z) := rho(sqrt(R^2 + z^2))`,
- same extended profile identity was declared without substitution or
  exterior-only surrogate,
- a shared support-radius / source-edge convention was frozen,
- boundary and matching conditions were frozen under the same-source
  convention,
- the `phi(R,z) -> phi(r), Delta(r), V_model(r)` extraction rule was frozen,
- and the same validation window and acceptance rule were retained:
  `0.1 R_d <= r <= 10 R_d` with a visible `< 1%` threshold surface.

Those locks are visible in:

- `action_vs_epic_reestablishment_compare_mode_declaration_v1_status.json`
- `action_vs_epic_reestablishment_source_object_embedding_lock_v1_status.json`
- `action_vs_epic_reestablishment_shared_profile_identity_lock_v1_status.json`
- `action_vs_epic_reestablishment_support_radius_identity_lock_v1_status.md`
- `action_vs_epic_reestablishment_boundary_conditions_and_matching_lock_v1_status.json`
- `action_vs_epic_reestablishment_phi_radial_extraction_rule_lock_v1_status.json`
- `action_vs_epic_reestablishment_validation_window_regime_lock_v1_status.json`

## Why this counts as a real gain

This changed the program from:

- "the old benchmark passed numerically but is not canonically admissible"

to:

- "a replacement canonical same-source benchmark has an explicitly frozen
  compare mode, source object, profile identity, support convention,
  boundary/matching contract, extraction rule, and validation window."

That is not a stylistic improvement.
It is a scientific admissibility improvement.

It means the program had already learned how to say, in governed form, what
the lawful exact-vs-closure comparison object actually had to be.

## What this note does not claim

This note does not claim that the earlier rejected bridge became valid after
the fact.

It claims something narrower:

- the rejected proxy benchmark stayed rejected,
- its reuse as canonical stayed forbidden,
- and a materially specified reestablished same-source benchmark surface was
  exposed on the active adapter instead.

That is a genuine pre-Rank-9 closure gain.
