# QCT Core Closure

This folder captures the strongest closed scientific layer that clearly
preceded the Rank-9 Deep Origin public shelf:

- the `qct_core` closure of `CORE-101..106`,
- the same-source `Action-vs-EPIC` evidence path,
- the bounded first-paper discipline around that closure,
- and the late recognition that some remaining wording gaps were
  authority-absorption lag rather than unresolved scientific disagreement.

Recommended order:

1. `CORE_101_106_CLOSURE_NOTE.md`
2. `ACTION_VS_EPIC_EVIDENCE_NOTE.md`
3. `ACTION_VS_EPIC_CANONICAL_REESTABLISHMENT_SPECIFICITY_NOTE.md`
4. `CORE106_BOUND_REESTABLISHED_PATH_CLOSURE_NOTE.md`
5. `CONTROLLED_REDUCTION_AND_FALSE_BLOCKER_RETIREMENT_NOTE.md`
6. `CROSS_REPO_ABSORPTION_CONVERGENCE_NOTE.md`
7. `PAPER_A_BOUNDARY_NOTE.md`
8. `SCIENTIFIC_WRITER_QCT_CORE_CLOSURE_DIGEST_V2.md`
9. `qct_adapter_action_vs_epic_spherical_validation_status.md`
10. `qct_adapter_action_vs_epic_shared_source_benchmark_result.md`
11. `action_vs_epic_benchmark_canonical_admissibility_reestablishment_v1_status.md`
12. `action_vs_epic_reestablished_canonical_benchmark_materialization_v1_status.json`
13. `core_102_controlled_reduction_note_v1_status.json`
14. `core_106_reestablished_same_source_binding_v1_status.json`
15. `ACTION_VS_EPIC_SPHERICAL_VALIDATION_V1.md`
