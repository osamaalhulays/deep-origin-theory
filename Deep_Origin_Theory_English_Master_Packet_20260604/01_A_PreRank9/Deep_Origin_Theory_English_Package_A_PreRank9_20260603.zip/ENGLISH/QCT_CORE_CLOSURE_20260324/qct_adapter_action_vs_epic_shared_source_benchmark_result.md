# QCT Adapter Action-vs-EPIC Shared-Source Benchmark

- benchmark_state: `materialized`
- benchmark_source_class: `same_extended_spherical_source__rho_r_direct_spherical_compare_mode`
- benchmark_compare_mode: `extended_spherical_source_mode`
- exact_reference_state: `tg4x_actionconsistent_same_source_spherical_exact_materialized_on_reestablished_same_source_window`
- exact_solver_artifact_name: `TG4X_ACTIONCONSISTENT_SAME_SOURCE_SPHERICAL_EXACT`
- epic_compare_mode_artifact_name: `EPIC30_DEDICATED_SAME_SOURCE_SPHERICAL_COMPARE_MODE`
- epic_grid_shape: `1D_radial_4001`
- validation_state: `pass__phi_and_delta_below_threshold`
- phi_max_relative_error: `0.0`
- delta_max_relative_error: `0.0`
- acceptance_threshold_rel_error_max: `0.01`
