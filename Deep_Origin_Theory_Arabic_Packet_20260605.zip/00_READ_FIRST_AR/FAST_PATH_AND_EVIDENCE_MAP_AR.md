# مسار سريع وخريطة الأدلة

التاريخ: `2026-06-05`

هذه الورقة هي أقصر طريق ذي قيمة عبر الحزمة.

## إذا كان لديك 15 دقيقة فقط

اقرأ بالترتيب:

1. `START_HERE_FIRST_AR.md`
2. `KEY_QUESTIONS_AND_SCOPE_AR.md`
3. `EXTERNAL_MATHEMATICAL_CONTEXT__MOHAMED_HAJ_YOUSEF_AR_20260605.md`
4. `DIFFERENTIAL_WITNESS_CAPSULE__NGC0247__AR_V1.md`
5. `DIFFERENTIAL_WITNESS_APPENDIX__NGC0247__ROW_TABLE__AR_V1.md`
6. `FIXED_QUMOND_COMPARATOR_APPENDIX__NGC0247__SOURCE_LOCKED_AR_V1.md`
7. `NGC0247_PHASE2_CASELOCK_AND_FORWARD_MODEL_NOTE_AR_20260605.md`
8. `NGC0247_LATE_BRANCH_PROVENANCE_AND_EXCLUSION_NOTE_AR_20260605.md`
9. `SECOND_DIFFERENTIAL_WITNESS_CAPSULE__NGC6946__AR_V1.md`
10. `DEFERRED_SCOPE_AND_ACTIVE_DEBTS_AR.md`

## إذا كان لديك 45 دقيقة

بعد الملفات التسعة أعلاه، افحص:

### A

- `01_A_PreRank9/Deep_Origin_Theory_English_Package_A_PreRank9_20260603.zip`
- `01_A_PreRank9/Deep_Origin_Theory_A_PreRank9_Arabic_Guide_20260605.zip`
- وداخل صورة `A` الحالية ركّز أيضًا على:
  - `NGC0247_PHASE2_CASELOCK_AND_FORWARD_MODEL_NOTE_AR_20260605.md`
  - `NGC0247_LATE_BRANCH_PROVENANCE_AND_EXCLUSION_NOTE_AR_20260605.md`
  - `SECOND_DIFFERENTIAL_WITNESS_CAPSULE__NGC6946__AR_V1.md`

### B

- `02_B_Rank9/Deep_Origin_Theory_Arabic_Public_Wave_20260603.zip`
- وداخلها ابدأ بـ:
  - `FAST_PATH.md`
  - `Keystone_I_The_First_Bearing_20260429/START_HERE_FIRST.md`
  - `Keystone_I_The_First_Bearing_20260429/QUICK_ROUTE.md`
  - `Keystone_I_The_First_Bearing_20260429/CURRENT_STAGE_AND_PREDICTION_STATUS.md`

### C

- `03_C_Cluster/Deep_Origin_Theory_C_Cluster_Arabic_Dossier_20260605.zip`
- وداخلها ابدأ بـ:
  - `README.md`
  - `L0_CROSSING_TRUTH_AUDIT_EN.md`
  - `L2_SECOND_GENERATION_HOLDOUT_STATUS_NOTE_AR.md`
  - `C_HARVEST_NOTE_EN.md`

## أقوى الشواهد الظاهرة حسب الرف

### A

- شاهد مسمى: `NGC0247`
- جدول صفي محدود
- ملحق مقارن ثابت ضد `QUMOND`
- مسار `Phase-2 case-lock` محفوظ لنفس الحالة
- مذكرة صريحة تستبعد الفروع المتأخرة غير القانونية من claim الحزمة
- شاهد تفاضلي ثانٍ محدود: `NGC6946`

### B

- نتيجة جسرية محدودة
- مسار مشترك الأصل ومشترك الأساس
- تشخيصات `Xi_*`
- حد واضح بين `Rank 9` و`Rank 10`

### C

- `MACS1206` = دعم محدود لا إغلاق صعود نهائي
- `L0` = authorization وreadiness ظاهرتان لكن crossing غير مثبتة
- `L2` = نضج تشخيصي منضبط من غير refit ولا claim، ثم توقف عند blocker
  باريوني خارجي
- `A370` = جبهة شمالية ثقيلة تاريخيًا، انتهت داخل عائلة `parked-map`
  لأن أسطح الدعم لم تتحول إلى consumer قانوني runner-grade
