# Reviewer Audit Bundle Expected Outputs

Date: `2026-06-09`

This mini-bundle is meant for one cold reviewer pass through the current
English packet without requiring a long narrative read first.

## Run order

Run:

- `REVIEWER_AUDIT_BUNDLE_V1/RUN_AUDIT_ALL.sh`

## Expected success shape

The run is healthy if all of the following happen:

1. `packet_root_sha_check.txt` is produced and contains only `OK` lines.
2. `shelf_A_sha_check.txt` is produced and contains only `OK` lines.
3. `shelf_B_sha_check.txt` is produced and contains only `OK` lines.
4. `shelf_C_sha_check.txt` is produced and contains only `OK` lines.
5. `ngc0247_current_stack.json` is produced and is valid JSON.
6. `ngc0247_current_row_comparator.json` is produced and is valid JSON.
7. `ngc0247_parity_ready_pilot_object.json` is produced and is valid JSON.
8. `ngc0247_matched_nuisance_policy_lock.json` is produced and is valid JSON.
9. `ngc0247_phase2_matched_nuisance_window_replay.json` is produced and is valid JSON.
10. `ngc0247_executed_parity_witness_scoring_shell.json` is produced and is valid JSON.
11. `ngc6946_fixed_qumond_summary.json` is produced and is valid JSON.
12. `macs1206_public_source_profile.json` is produced.
13. `reviewer_audit_contract_check.json` is produced and is valid JSON.
14. the run prints one unique temporary audit-directory path at the end.

The run is also healthy only if the packet-root and inner-shelf ledgers are:

- relative-path portable
- free of absolute-path entries
- free of derived artifacts such as `__pycache__` or `.pyc`
- and the semantic checker reports `all_checks_pass = true`

For the `NGC0247` pilot-object bounded audit surface, also expect:

- `pilot_object_materialized = true`
- `numeric_readiness_gate_closed = true`
- verdict =
  `NGC0247_PARITY_READY_PILOT_OBJECT_MATERIALIZED__PROMOTE_THIS_OBJECT_NOT_THE_HISTORICAL_CONTROL_SHELL`

For the `NGC0247` matched-nuisance policy-lock bounded audit surface, also
expect:

- `policy_lock_closed = true`
- `count_level_alignment_with_current_rotmod_rows = true`
- verdict =
  `NGC0247_MATCHED_NUISANCE_SOURCE_POLICY_LOCK_CLOSED__NEXT_EXECUTION_TOOTH_IS_NUISANCE_SHIFTED_ROW_REMATERIALIZATION`

For the `NGC0247` matched-nuisance window replay bounded audit surface, two
outcomes are acceptable:

- cold packet default:
  - `historical_delta_surface_replay_mode = packet_visible_delta_1d_replay_only`
  - `optional_external_archive_check.status = skipped_optional_archive_not_bundled`
  - `rescue_seen_within_1sigma_box = false`
  - verdict =
    `NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_CLOSED__LAWFUL_DI_BOX_DOES_NOT_RESCUE_QCT`
- author-side archival enrichment opt-in:
  - `historical_delta_surface_replay_mode = V1_fixed_delta_surface`
  - `optional_external_archive_check.status = verified_optional_archive`
  - `rescue_seen_within_1sigma_box = false`
  - verdict =
    `NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_CLOSED__LAWFUL_DI_BOX_DOES_NOT_RESCUE_QCT`

For the `NGC0247` executed parity witness scoring-shell replay surface, also
expect:

- `faithful_delta_aic_total = -15.398764714420167`
- `component_aware_delta_aic_total = -39.63154845025974`
- `fixed_public_delta_aic_total = -13.914066963632308`
- `scoring_shell_replay_closed = true`
- verdict =
  `NGC0247_EXECUTED_PARITY_WITNESS_SCORING_SHELL_REPLAY_CLOSED__SUPPORT_RECEIPTS_AND_PACKET_SHELLS_ARE_NUMERICALLY_CONCORDANT`

For the `NGC6946` bounded audit surface, also expect:

- `all_QUMOND_residuals_negative = true`
- `delta_true_sign_split_label = 29 negative / 29 positive`
- one small nonzero recompute error budget caused by row-table rounding rather
  than by comparator drift

## Acceptable `MACS1206` outcomes

Two `MACS1206` audit outcomes are acceptable:

- full local replay available:
  - JSON shows `row_count = 4`
  - and includes the emitted CSV path
- optional external FITS not bundled:
  - JSON shows
    `status = skipped_external_fits_dependency_not_bundled`
  - and lists the missing FITS paths

The second outcome is intentionally accepted. It means the dossier preserves
the derived public-source table, while the optional external replay footing is
not bundled with the cold review copy.

## What counts as a real failure

Treat these as real regressions:

- any root or inner-shelf SHA check failure
- any absolute-path ledger entry
- any `__pycache__` or `.pyc` ledger entry
- any raw traceback from the two `NGC0247` reproduction scripts
- any raw traceback from the `NGC0247` parity-ready pilot-object script
- any raw traceback from the `NGC0247` matched-nuisance policy-lock script
- any raw traceback from the `NGC0247` matched-nuisance window replay script
- any raw traceback from the `NGC0247` executed parity witness scoring-shell replay script
- any raw traceback from the `NGC6946` bounded audit script
- any hard crash from the `MACS1206` script
- any `MACS1206` output state other than:
  - the four-row summary
  - or the explicit skip-safe external-dependency state
