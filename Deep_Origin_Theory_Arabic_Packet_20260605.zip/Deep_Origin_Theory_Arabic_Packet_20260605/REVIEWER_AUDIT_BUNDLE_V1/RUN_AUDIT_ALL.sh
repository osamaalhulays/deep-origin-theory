#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PACKET_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
AUDIT_DIR="$(mktemp -d "${TMPDIR:-/tmp}/deep_origin_reviewer_audit_XXXXXX")"
export PYTHONDONTWRITEBYTECODE=1
export QCT_COLD_REVIEW="${QCT_COLD_REVIEW:-1}"
export QCT_ALLOW_OPTIONAL_EXTERNAL_ARCHIVE="${QCT_ALLOW_OPTIONAL_EXTERNAL_ARCHIVE:-0}"

print_audit_dir() {
  local exit_code=$?
  echo
  if [[ $exit_code -eq 0 ]]; then
    echo "Outputs saved under:"
  else
    echo "Audit stopped early. Partial outputs saved under:"
  fi
  echo "$AUDIT_DIR"
}

trap print_audit_dir EXIT

verify_inner_zip() {
  local zip_path="$1"
  local label="$2"
  local extract_dir="$AUDIT_DIR/$label"
  local ledger_path
  local ledger_dir

  mkdir -p "$extract_dir"
  unzip -q "$zip_path" -d "$extract_dir"

  ledger_path="$(find_first_file "$extract_dir" "SHA256SUMS.txt")"
  if [[ -z "$ledger_path" ]]; then
    echo "Could not find SHA256SUMS.txt inside $label." >&2
    exit 1
  fi

  assert_clean_tree "$extract_dir" "$label"
  ledger_dir="$(cd "$(dirname "$ledger_path")" && pwd)"
  assert_portable_ledger "$ledger_path" "$label"

  (
    cd "$ledger_dir"
    shasum -a 256 -c SHA256SUMS.txt
  ) > "$AUDIT_DIR/${label}_sha_check.txt"
}

assert_portable_ledger() {
  local ledger_path="$1"
  local label="$2"

  if grep -nE '^[0-9a-fA-F]{64}[[:space:]]+/' "$ledger_path" > "$AUDIT_DIR/${label}_absolute_path_ledger_entries.txt"; then
    echo "$label ledger contains absolute-path entries and is not portable." >&2
    exit 1
  fi
  rm -f "$AUDIT_DIR/${label}_absolute_path_ledger_entries.txt"

  if grep -nE '(^|/)(__pycache__)(/|$)|\.pyc$' "$ledger_path" > "$AUDIT_DIR/${label}_derived_artifact_ledger_entries.txt"; then
    echo "$label ledger contains derived-artifact entries and is not cold-review clean." >&2
    exit 1
  fi
  rm -f "$AUDIT_DIR/${label}_derived_artifact_ledger_entries.txt"
}

assert_clean_tree() {
  local root_dir="$1"
  local label="$2"

  find "$root_dir" \( -type d -name '__pycache__' -o -type f -name '*.pyc' \) -print > "$AUDIT_DIR/${label}_derived_tree_artifacts.txt"
  if [[ -s "$AUDIT_DIR/${label}_derived_tree_artifacts.txt" ]]; then
    echo "$label tree contains derived artifacts and is not cold-review clean." >&2
    exit 1
  fi
  rm -f "$AUDIT_DIR/${label}_derived_tree_artifacts.txt"
}

find_first_file() {
  local root_dir="$1"
  local target_name="$2"

  find "$root_dir" -type f -name "$target_name" -print -quit
}

echo "[1/11] Verifying packet-root SHA256 ledger"
assert_clean_tree "$PACKET_DIR" "packet_root"
assert_portable_ledger "$PACKET_DIR/SHA256SUMS.txt" "packet_root"
(
  cd "$PACKET_DIR"
  shasum -a 256 -c SHA256SUMS.txt
) > "$AUDIT_DIR/packet_root_sha_check.txt"

echo "[2/11] Verifying inner shelf ledgers for A, B, and C"
verify_inner_zip \
  "$PACKET_DIR/01_A_PreRank9/Deep_Origin_Theory_English_Package_A_PreRank9_20260603.zip" \
  "shelf_A"
verify_inner_zip \
  "$PACKET_DIR/02_B_Rank9/Deep_Origin_Theory_English_Public_Wave_20260603.zip" \
  "shelf_B"
verify_inner_zip \
  "$PACKET_DIR/03_C_Cluster/Deep_Origin_Theory_C_Cluster_Dossier_20260605.zip" \
  "shelf_C"

echo "[3/11] Rebuilding the current NGC0247 stack"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC0247_CURRENT_STACK_V1.py" \
  > "$AUDIT_DIR/ngc0247_current_stack.json"

echo "[4/11] Rebuilding the current NGC0247 row comparator"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC0247_PHASE2_CURRENT_QCT_ROW_COMPARATOR_V1.py" \
  > "$AUDIT_DIR/ngc0247_current_row_comparator.json"

echo "[5/11] Rebuilding the NGC0247 parity-ready pilot object"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC0247_PARITY_READY_PILOT_OBJECT_V1.py" \
  > "$AUDIT_DIR/ngc0247_parity_ready_pilot_object.json"

echo "[6/11] Rebuilding the NGC0247 matched-nuisance policy lock"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC0247_MATCHED_NUISANCE_POLICY_LOCK_V1.py" \
  > "$AUDIT_DIR/ngc0247_matched_nuisance_policy_lock.json"

echo "[7/11] Replaying the NGC0247 matched-nuisance window"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_V1.py" \
  > "$AUDIT_DIR/ngc0247_phase2_matched_nuisance_window_replay.json"

echo "[8/11] Replaying the NGC0247 executed parity witness scoring shell"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC0247_EXECUTED_PARITY_WITNESS_SCORING_SHELL_V1.py" \
  > "$AUDIT_DIR/ngc0247_executed_parity_witness_scoring_shell.json"

echo "[9/11] Auditing the second named fixed-QUMOND witness"
python3 \
  "$PACKET_DIR/00_READ_FIRST/REPRODUCE_NGC6946_FIXED_QUMOND_SUMMARY_V1.py" \
  > "$AUDIT_DIR/ngc6946_fixed_qumond_summary.json"

echo "[10/11] Probing the MACS1206 public-source replay contract"

C_SCRIPT_PATH="$(find_first_file "$AUDIT_DIR/shelf_C" "REPRODUCE_MACS1206_PUBLIC_SOURCE_PROFILE_V1.cjs")"

if [[ -z "$C_SCRIPT_PATH" ]]; then
  echo "Could not find REPRODUCE_MACS1206_PUBLIC_SOURCE_PROFILE_V1.cjs inside extracted shelf C." >&2
  exit 1
fi

node \
  "$C_SCRIPT_PATH" \
  > "$AUDIT_DIR/macs1206_public_source_profile.json"

echo "[11/11] Verifying semantic expectations against runtime outputs"
python3 \
  "$SCRIPT_DIR/VERIFY_EXPECTED_OUTPUTS.py" \
  --audit-dir "$AUDIT_DIR" \
  > "$AUDIT_DIR/reviewer_audit_contract_check.json"

echo
echo "Audit complete."
