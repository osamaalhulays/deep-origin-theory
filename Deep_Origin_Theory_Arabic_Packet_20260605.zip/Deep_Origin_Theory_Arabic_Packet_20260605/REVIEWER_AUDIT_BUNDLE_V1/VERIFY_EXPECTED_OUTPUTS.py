#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

FLOAT_TOLERANCE = 1e-12
WINDOW_ACCEPTED_STATES = {
    (
        "packet_visible_delta_1d_replay_only",
        "skipped_optional_archive_not_bundled",
        False,
    ): "cold_packet_default",
    (
        "V1_fixed_delta_surface",
        "verified_optional_archive",
        False,
    ): "author_side_archival_enrichment",
}
PILOT_VERDICT = (
    "NGC0247_PARITY_READY_PILOT_OBJECT_MATERIALIZED__PROMOTE_THIS_OBJECT_NOT_THE_HISTORICAL_CONTROL_SHELL"
)
POLICY_VERDICT = (
    "NGC0247_MATCHED_NUISANCE_SOURCE_POLICY_LOCK_CLOSED__NEXT_EXECUTION_TOOTH_IS_NUISANCE_SHIFTED_ROW_REMATERIALIZATION"
)
WINDOW_VERDICT = (
    "NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_CLOSED__LAWFUL_DI_BOX_DOES_NOT_RESCUE_QCT"
)
SCORING_VERDICT = (
    "NGC0247_EXECUTED_PARITY_WITNESS_SCORING_SHELL_REPLAY_CLOSED__SUPPORT_RECEIPTS_AND_PACKET_SHELLS_ARE_NUMERICALLY_CONCORDANT"
)


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha_check_passes(path: Path):
    lines = [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not lines:
        return False, "sha check file is empty"
    if any("FAILED" in line for line in lines):
        return False, "sha check file contains FAILED lines"
    if any(": OK" not in line for line in lines):
        return False, "sha check file contains non-OK lines"
    return True, f"{len(lines)} OK lines"


def close_enough(left, right):
    return abs(left - right) <= FLOAT_TOLERANCE


def check(checks, name, passed, detail):
    checks[name] = {
        "passed": bool(passed),
        "detail": detail,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-dir", required=True)
    args = parser.parse_args()

    audit_dir = Path(args.audit_dir).resolve()
    checks = {}

    for name in (
        "packet_root_sha_check.txt",
        "shelf_A_sha_check.txt",
        "shelf_B_sha_check.txt",
        "shelf_C_sha_check.txt",
    ):
        passed, detail = sha_check_passes(audit_dir / name)
        check(checks, name, passed, detail)

    pilot = load_json(audit_dir / "ngc0247_parity_ready_pilot_object.json")
    nested_pilot_gate = pilot.get("parity_readiness_gate", {}).get("numeric_readiness_gate_closed")
    pilot_passed = (
        pilot.get("pilot_object_materialized") is True
        and pilot.get("numeric_readiness_gate_closed") is True
        and nested_pilot_gate is True
        and pilot.get("verdict") == PILOT_VERDICT
    )
    check(
        checks,
        "ngc0247_parity_ready_pilot_object",
        pilot_passed,
        {
            "pilot_object_materialized": pilot.get("pilot_object_materialized"),
            "numeric_readiness_gate_closed": pilot.get("numeric_readiness_gate_closed"),
            "nested_numeric_readiness_gate_closed": nested_pilot_gate,
            "verdict": pilot.get("verdict"),
        },
    )

    policy = load_json(audit_dir / "ngc0247_matched_nuisance_policy_lock.json")
    nested_policy_alignment = policy.get("mask_family", {}).get(
        "count_level_alignment_with_current_rotmod_rows"
    )
    policy_passed = (
        policy.get("policy_lock_closed") is True
        and policy.get("count_level_alignment_with_current_rotmod_rows") is True
        and nested_policy_alignment is True
        and policy.get("verdict") == POLICY_VERDICT
    )
    check(
        checks,
        "ngc0247_matched_nuisance_policy_lock",
        policy_passed,
        {
            "policy_lock_closed": policy.get("policy_lock_closed"),
            "count_level_alignment_with_current_rotmod_rows": policy.get(
                "count_level_alignment_with_current_rotmod_rows"
            ),
            "nested_count_level_alignment_with_current_rotmod_rows": nested_policy_alignment,
            "verdict": policy.get("verdict"),
        },
    )

    window = load_json(audit_dir / "ngc0247_phase2_matched_nuisance_window_replay.json")
    window_state = (
        window.get("historical_delta_surface_replay_mode"),
        window.get("optional_external_archive_check", {}).get("status"),
        window.get("rescue_seen_within_1sigma_box"),
    )
    accepted_window_mode = WINDOW_ACCEPTED_STATES.get(window_state)
    window_passed = accepted_window_mode is not None and window.get("verdict") == WINDOW_VERDICT
    check(
        checks,
        "ngc0247_phase2_matched_nuisance_window_replay",
        window_passed,
        {
            "accepted_mode": accepted_window_mode,
            "historical_delta_surface_replay_mode": window_state[0],
            "optional_external_archive_check.status": window_state[1],
            "rescue_seen_within_1sigma_box": window_state[2],
            "verdict": window.get("verdict"),
        },
    )

    scoring = load_json(audit_dir / "ngc0247_executed_parity_witness_scoring_shell.json")
    expected_scoring = {
        "faithful_delta_aic_total": -15.398764714420167,
        "component_aware_delta_aic_total": -39.63154845025974,
        "fixed_public_delta_aic_total": -13.914066963632308,
    }
    scoring_passed = (
        scoring.get("scoring_shell_replay_closed") is True
        and scoring.get("verdict") == SCORING_VERDICT
        and all(
            close_enough(scoring.get(key), value) for key, value in expected_scoring.items()
        )
        and all(scoring.get("consistency_checks", {}).values())
    )
    check(
        checks,
        "ngc0247_executed_parity_witness_scoring_shell",
        scoring_passed,
        {
            **{key: scoring.get(key) for key in expected_scoring},
            "scoring_shell_replay_closed": scoring.get("scoring_shell_replay_closed"),
            "all_consistency_checks_pass": all(scoring.get("consistency_checks", {}).values()),
            "verdict": scoring.get("verdict"),
        },
    )

    ngc6946 = load_json(audit_dir / "ngc6946_fixed_qumond_summary.json")
    ngc6946_passed = (
        ngc6946.get("all_QUMOND_residuals_negative") is True
        and ngc6946.get("delta_true_sign_split_label") == "29 negative / 29 positive"
    )
    check(
        checks,
        "ngc6946_fixed_qumond_summary",
        ngc6946_passed,
        {
            "all_QUMOND_residuals_negative": ngc6946.get("all_QUMOND_residuals_negative"),
            "delta_true_sign_split_label": ngc6946.get("delta_true_sign_split_label"),
        },
    )

    macs1206 = load_json(audit_dir / "macs1206_public_source_profile.json")
    macs1206_status = macs1206.get("status")
    if macs1206_status == "skipped_external_fits_dependency_not_bundled":
        macs1206_passed = bool(macs1206.get("missing_paths")) and bool(macs1206.get("output_csv"))
        macs1206_detail = {
            "accepted_mode": "skip_safe_external_dependency_not_bundled",
            "status": macs1206_status,
            "missing_path_count": len(macs1206.get("missing_paths", [])),
            "output_csv": macs1206.get("output_csv"),
        }
    else:
        macs1206_passed = macs1206.get("row_count") == 4 and bool(macs1206.get("output_csv"))
        macs1206_detail = {
            "accepted_mode": "full_local_replay_available",
            "status": macs1206_status,
            "row_count": macs1206.get("row_count"),
            "output_csv": macs1206.get("output_csv"),
        }
    check(checks, "macs1206_public_source_profile", macs1206_passed, macs1206_detail)

    payload = {
        "surface": "reviewer_audit_contract_check",
        "audit_dir": str(audit_dir),
        "all_checks_pass": all(item["passed"] for item in checks.values()),
        "checks": checks,
    }
    print(json.dumps(payload, indent=2, sort_keys=True))

    if not payload["all_checks_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
