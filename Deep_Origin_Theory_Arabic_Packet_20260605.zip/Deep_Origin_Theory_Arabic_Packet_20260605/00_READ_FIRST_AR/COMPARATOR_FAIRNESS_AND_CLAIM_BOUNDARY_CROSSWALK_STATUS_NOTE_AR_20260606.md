# جدول عدالة المقارنات وحدود الادعاء

التاريخ: `2026-06-06`

هذه الورقة تمنع خلط lanes المقارنة ببعضها.

الفكرة الأساسية:

- fixed pressure lane
- current bounded reconstructed lane
- historical fitted replay lane
- later matched-nuisance parity lane
- later best-dressed adversarial lane

ليست نتيجة واحدة collapsed.

بل lanes مترابطة لكن غير متبادلة السلطة.

## الخلاصة

الحزمة أصبحت أقوى عندما تُقرأ عبر crosswalk حاكمة،
لا عبر slogan واحدة من نوع:

- "النظرية الحالية فازت" أو "المقارن فشل" بلا تحديد lane.
