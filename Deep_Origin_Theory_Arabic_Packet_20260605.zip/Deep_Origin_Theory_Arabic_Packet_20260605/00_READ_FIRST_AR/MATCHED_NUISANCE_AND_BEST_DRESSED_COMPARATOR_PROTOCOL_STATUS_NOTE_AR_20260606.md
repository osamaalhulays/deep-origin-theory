# بروتوكول matched-nuisance وbest-dressed comparator

التاريخ: `2026-06-06`

هذه الورقة تضع قاعدة بسيطة:

الجواب على سؤال العدالة المقارنية ليس الشكوى،
بل تشغيل عدة lanes تحت قواعد معلنة.

## suite المقارنة

- Lane A: strict-austere
- Lane B: matched-nuisance parity
- Lane C: best-dressed adversarial

## القاعدة الذهبية

المسموح:

- nuisance parity

والممنوع:

- theory rescue

وبهذا تصبح comparator fairness جسمًا علميًا محكومًا،
لا مجرد انطباع أو اعتراض خطابي.
