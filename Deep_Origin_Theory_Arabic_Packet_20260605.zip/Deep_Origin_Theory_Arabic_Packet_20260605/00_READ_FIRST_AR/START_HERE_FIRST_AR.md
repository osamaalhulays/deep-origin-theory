# الحزمة العربية لنظرية الأصل العميق

التاريخ: `2026-06-05`

هذه هي الحزمة العربية الحالية للحالة المرئية من `A + B + C`.

وهي تُبقي الرفوف الثلاثة منفصلة عمدًا:

- `A` = الأساس السابق لـ `Rank 9`
- `B` = موجة `Rank 9` الحالية
- `C` = الدوسيه العنقودي المحدود الحالي

ولا تدّعي هذه الحزمة أن الرفوف الثلاثة قد انصهرت علميًا في إغلاق نهائي واحد.

وظيفتها أن تجعل الحالة الحالية قابلة للقراءة من غير إخفاء ما بقي مؤجلًا.

## ترتيب القراءة المقترح

1. `FAST_PATH_AND_EVIDENCE_MAP_AR.md`
2. `KEY_QUESTIONS_AND_SCOPE_AR.md`
3. `DEFERRED_SCOPE_AND_ACTIVE_DEBTS_AR.md`
4. `DIFFERENTIAL_WITNESS_CAPSULE__NGC0247__AR_V1.md`
5. `DIFFERENTIAL_WITNESS_APPENDIX__NGC0247__ROW_TABLE__AR_V1.md`
6. `FIXED_QUMOND_COMPARATOR_APPENDIX__NGC0247__SOURCE_LOCKED_AR_V1.md`
7. `NGC0247_PHASE2_CASELOCK_AND_FORWARD_MODEL_NOTE_AR_20260605.md`
8. `NGC0247_LATE_BRANCH_PROVENANCE_AND_EXCLUSION_NOTE_AR_20260605.md`
9. `SECOND_DIFFERENTIAL_WITNESS_CAPSULE__NGC6946__AR_V1.md`
10. `01_A_PreRank9`
11. `02_B_Rank9`
12. `03_C_Cluster`

## الرفوف الداخلية

### 01_A_PreRank9

- `Deep_Origin_Theory_English_Package_A_PreRank9_20260603.zip`
- `Deep_Origin_Theory_A_PreRank9_Arabic_Guide_20260605.zip`

وللقارئ الذي يريد أحدث صورة للشاهد الحالي في `A`، ابدأ أيضًا بالتركيز على:

- `NGC0247_PHASE2_CASELOCK_AND_FORWARD_MODEL_NOTE_AR_20260605.md`
- `NGC0247_LATE_BRANCH_PROVENANCE_AND_EXCLUSION_NOTE_AR_20260605.md`
- `SECOND_DIFFERENTIAL_WITNESS_CAPSULE__NGC6946__AR_V1.md`

### 02_B_Rank9

- `Deep_Origin_Theory_Arabic_Public_Wave_20260603.zip`

### 03_C_Cluster

- `Deep_Origin_Theory_C_Cluster_Arabic_Dossier_20260605.zip`

## القاعدة

اقرأ هذه الحزمة بوصفها حزمة عامة حالية ذات حدود ادعاء صريحة، لا بوصفها
إعلانًا بأن كل الجبهات اللاحقة قد أُغلقت بالفعل.
