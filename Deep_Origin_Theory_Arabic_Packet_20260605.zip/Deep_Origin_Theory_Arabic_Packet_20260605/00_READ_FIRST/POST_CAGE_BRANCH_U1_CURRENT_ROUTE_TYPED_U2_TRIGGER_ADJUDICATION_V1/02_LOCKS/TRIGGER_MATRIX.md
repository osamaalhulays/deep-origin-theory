# Trigger Matrix

Date: `2026-06-10`

## Strong-field family

- typed: `true`
- currently forced: `false`
- current reason:
  no reviewer-visible proof yet that one second transport-bearing companion,
  one extra transport sector, or one non-minimal strong-field widening is
  already unavoidable

## South-substrate family

- typed: `true`
- currently forced: `false`
- current reason:
  no reviewer-visible proof yet that one independent south carrier or one
  non-`Q`-owned source-quality coefficient route is already unavoidable

## Ledger-honesty family

- typed: `true`
- currently forced: `false`
- current reason:
  the current route still banks no forced external exchange-current patch and
  no forced second transport-bearing companion

## Global reading

- `U2 trigger classes`: typed
- `current trigger state`: not yet fired
- `next honest move`: ownership-preserving exact-vanishing attempt
