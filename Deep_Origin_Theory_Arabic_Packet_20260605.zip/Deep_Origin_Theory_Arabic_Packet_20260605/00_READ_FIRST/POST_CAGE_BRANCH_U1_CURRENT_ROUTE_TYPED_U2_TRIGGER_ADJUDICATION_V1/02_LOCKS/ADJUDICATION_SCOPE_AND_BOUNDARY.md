# Adjudication Scope And Boundary

Date: `2026-06-10`

## Scope

This adjudication is scoped to:

- the current repo-visible snapshot,
- the frozen post-cage `U1` route,
- the already typed `U2` trigger families,
- and the present trigger state of those families.

It includes:

- `artifacts/debt_board_20260530/`
- `Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/`
- the current route verdict-order, ownership, and trigger notes

It does **not** depend on:

- future unpublished author supply,
- external email arrivals,
- empirical payload arrivals,
- or hypothetical later material outside the current repo-visible route.

## Exact meaning

`typed U2 trigger adjudication` means:

- the relevant widening triggers are already explicit,
- and the current record is now judged against them.

It does **not** mean:

- permanent exclusion of `U2`,
- or proof that `U1` will survive.

## Forbidden false readings

Do **not** read this object as:

- "U2 is impossible,"
- "U1 is already safe,"
- or "the route is already closed."

The object says something narrower:

- `U2` has exact trigger classes,
- but the current route has not yet fired them.

## Exact supersession rule

This adjudication is superseded immediately if later lawful work shows:

1. one genuine transport-bearing companion is unavoidable
2. one independent south carrier is unavoidable
3. one external exchange-current patch is unavoidable
4. or the supposed same-carrier route survives only by one hidden second
   architecture
