# Evidence Map

Date: `2026-06-10`

## Core evidence surfaces

1. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_VERSUS_U2_PIVOT_DISCIPLINE_NOTE_20260608.md`
   - types the three trigger families
   - states that `U1` remains alive while `U2` is not yet forced
   - states that `U2` opens only once one trigger class fires cleanly

2. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_V1/04_OUTPUTS/status_summary.json`
   - confirms the present exact wound is one `U1` authority-step failure
   - explicitly preserves `u2_already_forced = false`

3. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_RR0_BS1_EARLIEST_UNRESOLVED_TOOTH_CLASSIFICATION_NOTE_20260608.md`
   - localizes the first visible wound to coefficient / authority freeze
   - explicitly says forced companionhood is not yet the first current verdict

4. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_TQ_OWNERSHIP_FIRST_GATE_LOCALIZES_TO_SAME_CARRIER_VARIATIONAL_LEDGER_ADMISSION_NOTE_20260608.md`
   - preserves no forced `T_S`
   - preserves no forced external exchange-current patch
   - preserves no forced second transport-bearing companion

5. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_FINAL_LOCAL_VERDICT_SPLITS_TO_OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT_BEFORE_TYPED_U2_TRIGGER_VERDICT_NOTE_20260608.md`
   - fixes the verdict order:
     exact-vanishing attempt first,
     widening only if a typed trigger fires
   - preserves no forced independent south carrier in the current record

## Evidence logic

Together these surfaces imply:

1. the widening triggers are already typed,
2. the current route is already strong enough to judge them,
3. the current record still fails at the authority tooth rather than at
   forced widening,
4. the presently visible trigger state is therefore `not yet fired`,
5. so the next honest move is one ownership-preserving exact-vanishing
   attempt rather than one premature `U2` jump.
