from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


SCRIPT_PATH = Path(__file__).resolve()
OBJECT_ROOT = SCRIPT_PATH.parents[1]
ROOT = SCRIPT_PATH.parents[4]
OUTPUTS = OBJECT_ROOT / "04_OUTPUTS"

NOTE_CHECKS = [
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_VERSUS_U2_PIVOT_DISCIPLINE_NOTE_20260608.md",
        "fragments": [
            "`U1` remains alive",
            "`U2` is not yet forced",
            "its trigger classes are now already typed",
            "open `U2` immediately once one trigger class fires cleanly",
        ],
        "meaning": "the trigger classes are typed while U2 is not yet forced",
    },
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_TQ_OWNERSHIP_FIRST_GATE_LOCALIZES_TO_SAME_CARRIER_VARIATIONAL_LEDGER_ADMISSION_NOTE_20260608.md",
        "fragments": [
            "no `T_S`",
            "no external exchange-current patch",
            "no hidden second transport-bearing companion",
        ],
        "meaning": "the current route still banks no forced transport companion or external patch at T_Q admission grade",
    },
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_FINAL_LOCAL_VERDICT_SPLITS_TO_OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT_BEFORE_TYPED_U2_TRIGGER_VERDICT_NOTE_20260608.md",
        "fragments": [
            "no forced `T_S`",
            "no forced external exchange-current patch",
            "no forced second transport-bearing companion",
            "no forced independent south carrier",
            "V_U2^(only if typed trigger fires)",
        ],
        "meaning": "the current final verdict order still places widening only after a typed trigger fires",
    },
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_RR0_BS1_EARLIEST_UNRESOLVED_TOOTH_CLASSIFICATION_NOTE_20260608.md",
        "fragments": [
            "not yet forced companionhood.",
            "companion necessity remains one possible later verdict,",
            "not the first current verdict.",
        ],
        "meaning": "the first visible wound is still earlier than forced companionhood",
    },
]

AUTHORITY_FAILURE_STATUS_PATH = (
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_V1/04_OUTPUTS/status_summary.json"
)
AUTHORITY_FAILURE_VERDICT_PATH = (
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_V1/04_OUTPUTS/verdict.json"
)


def relative(path: Path) -> str:
    return str(path.relative_to(ROOT))


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "path": relative(item["path"]),
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def load_authority_failure_inputs() -> dict:
    status = json.loads(AUTHORITY_FAILURE_STATUS_PATH.read_text(encoding="utf-8"))
    verdict = json.loads(AUTHORITY_FAILURE_VERDICT_PATH.read_text(encoding="utf-8"))
    return {
        "status_path": relative(AUTHORITY_FAILURE_STATUS_PATH),
        "verdict_path": relative(AUTHORITY_FAILURE_VERDICT_PATH),
        "status": status,
        "verdict": verdict,
        "passed": (
            status["verdict"]
            == "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_MATERIALIZED"
            and status["u2_already_forced"] is False
            and status["all_note_checks_pass"] is True
        ),
    }


def build_report(status: dict, note_checks: list[dict]) -> str:
    lines = [
        "# Post-Cage Branch U1 Current-Route Typed U2 Trigger Adjudication Report",
        "",
        f"Generated at: `{status['generated_at_utc']}`",
        "",
        f"Verdict: `{status['verdict']}`",
        "",
        "## Summary",
        "",
        f"- authority-step failure input confirmed: `{str(status['authority_failure_input_confirmed']).lower()}`",
        f"- strong-field trigger forced now: `{str(status['strong_field_trigger_forced']).lower()}`",
        f"- south-substrate trigger forced now: `{str(status['south_substrate_trigger_forced']).lower()}`",
        f"- ledger-honesty trigger forced now: `{str(status['ledger_honesty_trigger_forced']).lower()}`",
        f"- note checks passed: `{str(status['all_note_checks_pass']).lower()}`",
        "",
        "## Note checks",
        "",
    ]
    for check in note_checks:
        lines.append(f"- `{check['path']}` -> `{str(check['passed']).lower()}`")
    lines.extend(
        [
            "",
            "## Reading",
            "",
            "- typed U2 trigger classes are present,",
            "- the current route still banks no forced companion, no forced independent south carrier, and no forced external exchange-current patch,",
            "- the current route therefore remains typed-but-not-fired on U2 triggers,",
            "- so widening is not yet presently earned.",
            "",
            "## Next exact move",
            "",
            "- materialize one ownership-preserving exact-vanishing attempt before any honest widening verdict",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    OUTPUTS.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    authority_failure_inputs = load_authority_failure_inputs()

    status = {
        "object_kind": "post_cage_branch_u1_current_route_typed_u2_trigger_adjudication_status",
        "generated_at_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "scope": "current_repo_visible_frozen_u1_route_only",
        "authority_failure_input_confirmed": authority_failure_inputs["passed"],
        "strong_field_trigger_forced": False,
        "south_substrate_trigger_forced": False,
        "ledger_honesty_trigger_forced": False,
        "u2_currently_forced": False,
        "all_note_checks_pass": all(check["passed"] for check in note_checks),
        "verdict": "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_MATERIALIZED",
    }

    trigger_matrix = {
        "strong_field": {
            "typed": True,
            "currently_forced": False,
        },
        "south_substrate": {
            "typed": True,
            "currently_forced": False,
        },
        "ledger_honesty": {
            "typed": True,
            "currently_forced": False,
        },
        "global_reading": {
            "u2_trigger_classes": "typed",
            "current_trigger_state": "not_yet_fired",
            "next_honest_move": "OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT",
        },
    }

    verdict = {
        "verdict": status["verdict"],
        "scope": status["scope"],
        "why": [
            "the route already types the U2 trigger classes explicitly",
            "the current authority-step failure input is confirmed while u2_already_forced remains false",
            "the current record still banks no forced T_S, no forced independent south carrier, no forced external exchange-current patch, and no forced second transport-bearing companion",
            "the first visible wound remains earlier than forced widening",
        ],
        "next_exact_move": "OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT_BEFORE_ANY_HONEST_WIDENING_VERDICT",
        "ceiling": [
            "not a permanent exclusion of U2",
            "not proof that U1 will succeed",
            "not a full-program closure verdict",
        ],
    }

    report = build_report(status, note_checks)

    (OUTPUTS / "note_checks.json").write_text(
        json.dumps(note_checks, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "authority_failure_inputs.json").write_text(
        json.dumps(authority_failure_inputs, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "trigger_matrix.json").write_text(
        json.dumps(trigger_matrix, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "status_summary.json").write_text(
        json.dumps(status, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "verdict.json").write_text(
        json.dumps(verdict, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "TYPED_U2_TRIGGER_ADJUDICATION_REPORT.md").write_text(
        report,
        encoding="utf-8",
    )

    if not authority_failure_inputs["passed"]:
        raise SystemExit("authority failure input is not in the expected state")
    if not all(check["passed"] for check in note_checks):
        raise SystemExit("required note evidence check failed")


if __name__ == "__main__":
    main()
