from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[4]
OBJECT_ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = OBJECT_ROOT / "04_OUTPUTS"
OUTPUTS.mkdir(parents=True, exist_ok=True)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


authoring_gate = ROOT / "artifacts/debt_board_20260530/L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/01_BACKBONE/MANUSCRIPT.md"
discriminator = ROOT / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_V1/01_BACKBONE/MANUSCRIPT.md"
triad = ROOT / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_REOPENING_TRIAD_AFTER_FORMABC_NO_GO_V1/01_BACKBONE/MANUSCRIPT.md"
ownership_failure = ROOT / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_V1/01_BACKBONE/MANUSCRIPT.md"
crossing_gate = ROOT / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_GRADE_WITNESS_DECISION_GATE_V1/01_BACKBONE/MANUSCRIPT.md"

checks = [
    {
        "path": str(authoring_gate.relative_to(ROOT)),
        "meaning": "authoring gate still defines Form D as source-governed operator engine producing outputs",
        "required_snippets": [
            "`Form D`: source-governed operator engine producing those outputs",
        ],
    },
    {
        "path": str(discriminator.relative_to(ROOT)),
        "meaning": "discriminator still defines Form D as engine-grade supersession from above",
        "required_snippets": [
            "engine-grade supersession event",
            "`Form D` = one source-governed operator engine producing the needed",
        ],
    },
    {
        "path": str(triad.relative_to(ROOT)),
        "meaning": "reopening triad still keeps one real reviewer-visible Form D operator engine as exact above-line class",
        "required_snippets": [
            "one real reviewer-visible `Form D` operator engine",
            "lawfully reopens",
        ],
    },
    {
        "path": str(ownership_failure.relative_to(ROOT)),
        "meaning": "ownership-failure verdict still treats missing reviewer-visible Form D engine as exact surviving reopening class",
        "required_snippets": [
            "reviewer-visible `Form D` operator",
            "lawfully reopen the same ladder from above",
        ],
    },
    {
        "path": str(crossing_gate.relative_to(ROOT)),
        "meaning": "crossing gate still sends Form D to supersession rather than same-route crossing",
        "required_snippets": [
            "one real reviewer-visible `Form D` engine appears first",
            "It is superseded by:",
        ],
    },
]

note_checks = []
for item in checks:
    text = read(ROOT / item["path"])
    passed = all(snippet in text for snippet in item["required_snippets"])
    note_checks.append(
        {
            "path": item["path"],
            "meaning": item["meaning"],
            "passed": passed,
            "required_snippets": item["required_snippets"],
        }
    )

materialized = all(item["passed"] for item in note_checks)

minimum_signature = [
    "source-governed operator engine rather than naming or symbolic grammar only",
    "lawful production of the frozen needed outputs",
    "reviewer-visible engine-grade objecthood",
    "supersession-class route effect from above rather than same-route crossing",
    "non-U2 reading that does not launder widening into engine language",
]

verdict = {
    "object": "POST_CAGE_BRANCH_U1_FORMD_MINIMUM_ENGINE_SIGNATURE_V1",
    "generated_at": datetime.now(timezone.utc).isoformat(),
    "materialized": materialized,
    "minimum_signature": minimum_signature,
}

status_summary = {
    "verdict": (
        "POST_CAGE_BRANCH_U1_FORMD_MINIMUM_ENGINE_SIGNATURE_MATERIALIZED"
        if materialized
        else "POST_CAGE_BRANCH_U1_FORMD_MINIMUM_ENGINE_SIGNATURE_NOT_MATERIALIZED"
    ),
    "note_checks_passed": materialized,
    "signature_item_count": len(minimum_signature),
}

report = "\n".join(
    [
        "# Post-Cage Branch U1 Form D Minimum Engine Signature Report",
        "",
        f"Generated at: `{verdict['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- note checks passed: `{materialized}`",
        f"- minimum signature item count: `{len(minimum_signature)}`",
        "",
        "## Minimum signature",
        "",
        *[f"- {item}" for item in minimum_signature],
        "",
        "## Note checks",
        "",
        *[
            f"- `{item['path']}` -> `{item['passed']}`"
            for item in note_checks
        ],
        "",
        "## Reading",
        "",
        "- Form D is now frozen as engine-grade rather than name-grade,",
        "- the route already binds it to lawful output production,",
        "- the route already binds it to reviewer-visible objecthood,",
        "- and the route already keeps it distinct from both same-route crossing and fired U2.",
        "",
        "## Bottom line",
        "",
        "- future Form D claims now have one exact minimum signature before any no-go or admission reading.",
    ]
)

(OUTPUTS / "note_checks.json").write_text(json.dumps(note_checks, indent=2), encoding="utf-8")
(OUTPUTS / "verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")
(OUTPUTS / "status_summary.json").write_text(json.dumps(status_summary, indent=2), encoding="utf-8")
(OUTPUTS / "FORMD_MINIMUM_ENGINE_SIGNATURE_REPORT.md").write_text(report + "\n", encoding="utf-8")
