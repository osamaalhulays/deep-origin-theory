# Evidence Map

1. `artifacts/debt_board_20260530/L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/01_BACKBONE/MANUSCRIPT.md`
   - defines `Form D` as one source-governed operator engine producing the
     needed outputs
2. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_V1/01_BACKBONE/MANUSCRIPT.md`
   - defines `Form D` as one engine-grade supersession event from above
3. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_REOPENING_TRIAD_AFTER_FORMABC_NO_GO_V1/01_BACKBONE/MANUSCRIPT.md`
   - keeps one real reviewer-visible `Form D` operator engine in the exact
     reopening triad
4. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_V1/01_BACKBONE/MANUSCRIPT.md`
   - fixes the missing reviewer-visible `Form D` engine as one exact surviving
     reopening class
5. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_GRADE_WITNESS_DECISION_GATE_V1/01_BACKBONE/MANUSCRIPT.md`
   - routes `Form D` to supersession rather than same-route crossing
