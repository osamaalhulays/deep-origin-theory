# Gate Test Matrix

Date: `2026-06-12`

Status: `test matrix`

The current gate counts as materially supported only if all of the
following remain true:

1. the minimum freeze signature is already materialized
2. the current repo-visible no-go is already materialized
3. candidate-grade binding is already present below the freeze tooth
4. selector-only candidates remain below the freeze tooth
5. the bound-candidate / ordered-pair / corridor / gradient-shadow grammar
   is already fixed for the live tooth

If any of those fails,
the current gate fails.
