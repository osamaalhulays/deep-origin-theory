#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"

SIGNATURE_VERDICT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_MINIMUM_SIGNATURE_V1/04_OUTPUTS/verdict.json"
CURRENT_NO_GO_VERDICT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_CURRENT_REPO_NO_GO_V1/04_OUTPUTS/verdict.json"
BINDING_VERDICT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_V1/04_OUTPUTS/verdict.json"
SELECTOR_VERDICT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_PAIRWISE_COEFFICIENT_CANDIDATE_OCCUPANT_SELECTOR_V1/04_OUTPUTS/verdict.json"
SIGNATURE_PRESENT_JSON = "artifacts/debt_board_20260530/G1_PRESENT_MATERIALS_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_MINIMUM_SIGNATURE_MATERIALIZED_20260612.json"


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
if WORKSPACE_ROOT is None:
    raise RuntimeError("could not locate workspace root from pairwise-freeze decision gate runner")


def read_json(logical_relative_path: str) -> dict:
    return json.loads(
        (WORKSPACE_ROOT / logical_relative_path).read_text(encoding="utf-8", errors="ignore")
    )


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def tf(value: bool) -> str:
    return str(value).lower()


def collect_note_checks() -> list[dict]:
    results = []

    signature_verdict = read_json(SIGNATURE_VERDICT)
    results.append(
        {
            "key": "signature_materialized",
            "path": SIGNATURE_VERDICT,
            "meaning": "the minimum freeze signature is frozen",
            "checks": {"verdict": signature_verdict.get("verdict")},
            "passed": (
                signature_verdict.get("verdict")
                == "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_MINIMUM_SIGNATURE_MATERIALIZED"
            ),
        }
    )

    current_no_go_verdict = read_json(CURRENT_NO_GO_VERDICT)
    results.append(
        {
            "key": "current_repo_no_go_materialized",
            "path": CURRENT_NO_GO_VERDICT,
            "meaning": "the current repo-visible route already fails the admit side of the gate",
            "checks": {"verdict": current_no_go_verdict.get("verdict")},
            "passed": (
                current_no_go_verdict.get("verdict")
                == "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_CURRENT_REPO_NO_GO_MATERIALIZED"
            ),
        }
    )

    binding_verdict = read_json(BINDING_VERDICT)
    results.append(
        {
            "key": "binding_below_line_present",
            "path": BINDING_VERDICT,
            "meaning": "candidate-grade binding is present but still below the freeze tooth",
            "checks": {
                "verdict": binding_verdict.get("verdict"),
                "grade": binding_verdict.get("grade"),
            },
            "passed": (
                binding_verdict.get("verdict")
                == "POST_CAGE_BRANCH_U1_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_MATERIALIZED"
                and binding_verdict.get("grade") == "candidate_grade_pairwise_binding"
            ),
        }
    )

    selector_verdict = read_json(SELECTOR_VERDICT)
    results.append(
        {
            "key": "selector_below_line_present",
            "path": SELECTOR_VERDICT,
            "meaning": "selector-only candidates remain below the freeze tooth",
            "checks": {
                "verdict": selector_verdict.get("verdict"),
                "grade": selector_verdict.get("grade"),
            },
            "passed": (
                selector_verdict.get("verdict")
                == "POST_CAGE_BRANCH_U1_PAIRWISE_COEFFICIENT_CANDIDATE_OCCUPANT_SELECTOR_MATERIALIZED"
                and selector_verdict.get("grade") == "candidate_occupant_selection_grade"
            ),
        }
    )

    signature_present = read_json(SIGNATURE_PRESENT_JSON)
    results.append(
        {
            "key": "freeze_tooth_grammar_locked",
            "path": SIGNATURE_PRESENT_JSON,
            "meaning": "bound-candidate / ordered-pair / corridor / gradient-shadow grammar is already fixed",
            "checks": {
                "bound_candidate_occupant": signature_present.get("bound_candidate_occupant"),
                "ordered_pair": signature_present.get("ordered_pair"),
                "bound_corridor": signature_present.get("bound_corridor"),
                "gradient_status": signature_present.get("gradient_status"),
            },
            "passed": (
                signature_present.get("bound_candidate_occupant") == "C_Q_kinetic"
                and signature_present.get("ordered_pair")
                == "(I_amp^(0), I_geo^(0)) with I_geo^(0) > I_amp^(0)"
                and signature_present.get("bound_corridor") == "B_Q-free A_Q^(0)[I_geo^(0)]"
                and signature_present.get("gradient_status")
                == "shadow pressure only, not coequal first owner"
            ),
        }
    )

    return results


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    gate_result = (
        "reject_current_repo_visible_pairwise_candidates" if all_note_checks_pass else "gate_not_ready"
    )
    verdict_name = (
        "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_DECISION_GATE_MATERIALIZED"
        if all_note_checks_pass
        else "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_DECISION_GATE_NOT_MATERIALIZED"
    )

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": verdict_name,
        "signature_materialized": note_check_map["signature_materialized"],
        "current_repo_no_go_materialized": note_check_map["current_repo_no_go_materialized"],
        "binding_below_line_present": note_check_map["binding_below_line_present"],
        "selector_below_line_present": note_check_map["selector_below_line_present"],
        "freeze_tooth_grammar_locked": note_check_map["freeze_tooth_grammar_locked"],
        "current_route_gate_result": gate_result,
        "all_note_checks_pass": all_note_checks_pass,
    }

    verdict = {
        "verdict": verdict_name,
        "current_route_gate_result": gate_result,
        "admit_if": [
            "one reviewer-visible authority-grade pairwise-freeze surface becomes materially visible for the bound C_Q_kinetic occupant",
            "the ordered shell-typed pair remains explicit",
            "the B_Q-free A_Q^(0)[I_geo^(0)] corridor remains explicit",
            "C_Q_gradient remains shadow pressure only rather than one coequal first owner at that grade",
            "the witness stays below silent final pairwise-law inflation and below hidden higher-grade import",
            "the witness is reviewer-visible enough to count as a freeze-grade package",
        ],
        "reject_if": [
            "pair-order contract only",
            "candidate occupant selection only",
            "candidate-grade pairwise binding only",
            "final-law naming with no reviewer-visible freeze surface",
            "flat coequal {C_Q_kinetic, C_Q_gradient} freeze cloud at this grade",
            "silent loss of ordered-pair or corridor discipline",
            "hidden higher-grade import not really carried by the current route",
            "switching the bound first owner away from C_Q_kinetic without one stronger lawful reread",
        ],
        "supersede_if": [
            "a final public pairwise coefficient formula or stronger lawful carrier-law object directly discharges the same tooth",
            "a later lawful reread explicitly overturns the current C_Q_kinetic-first / gradient-shadow-only order",
        ],
    }

    report_lines = [
        "# Bound `C_Q_kinetic` Authority-Grade Pairwise Freeze Decision Gate Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- minimum freeze signature frozen: `{tf(status_summary['signature_materialized'])}`",
        f"- current-repo no-go already materialized: `{tf(status_summary['current_repo_no_go_materialized'])}`",
        f"- candidate-grade binding below-line presence confirmed: `{tf(status_summary['binding_below_line_present'])}`",
        f"- selector below-line presence confirmed: `{tf(status_summary['selector_below_line_present'])}`",
        f"- freeze-tooth grammar already locked: `{tf(status_summary['freeze_tooth_grammar_locked'])}`",
        f"- current route gate result: `{status_summary['current_route_gate_result']}`",
        f"- all note checks pass: `{tf(status_summary['all_note_checks_pass'])}`",
        "",
        "## Gate grammar",
        "",
        "- `ADMIT` if one freeze-grade witness satisfies the frozen minimum signature.",
        "- `REJECT` if the candidate stays below the line or violates freeze-grade honesty.",
        "- `SUPERSEDE` if the real event is one stronger direct discharge or one stronger lawful reread rather than this freeze tooth itself.",
        "",
        "## Current route result",
        "",
        "- current repo-visible pairwise candidates are rejected at this stage.",
        "",
        "## Ceiling",
        "",
        "- this report does not claim permanent impossibility,",
        "- it does not claim final pairwise law is impossible,",
        "- it does not claim G1 is closed.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    (OUTPUT_ROOT / "BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_DECISION_GATE_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
