#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

NONTERMINAL_BOUNDARY_PATH = HERE / "CURRENT_FULL_HEAD_CONCENTRATED_BUT_NONTERMINAL_BOUNDARY_V1.json"
CROSS_OBSERVABLE_SCOPE_PATH = HERE / "NO_MAKEUP_MOND_QUMOND_CROSS_OBSERVABLE_COURT_SCOPE_SELECTION_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    nonterminal = load_json(NONTERMINAL_BOUNDARY_PATH)
    cross_observable = load_json(CROSS_OBSERVABLE_SCOPE_PATH)

    selected_scope_contains = set(cross_observable["selected_scope_contains"])
    not_supported_cross = set(cross_observable["not_supported_now"])

    consistency_checks = {
        "present_head_is_already_strongly_concentrated": (
            nonterminal["concentration_surface"]["structured_pair_fraction_of_full_head_public_delta_aic_total"]
            > 0.88
        ),
        "present_head_is_explicitly_nonterminal": (
            "the present concentration already authorizes final whole-head terminal closure language"
            in nonterminal["not_supported_now"]
            and nonterminal["consistency_checks"]["terminal_full_head_closure_is_not_admissible_now"]
        ),
        "selected_scope_is_no_makeup_cross_observable_court": (
            cross_observable["selected_scope"] == "no_makeup_mond_qumond_cross_observable_court"
        ),
        "selected_scope_carries_all_four_lanes": selected_scope_contains == {
            "fixed_comparator_rotation_witness_court",
            "matched_nuisance_parity_court",
            "best_dressed_adversarial_hardening_court",
            "same_kernel_macs1206_secondary_deltasigma_rail",
        },
        "rotation_side_is_unusually_exposed": (
            cross_observable["rotation_fixed_public_qumond_crosscheck_count_with_zero_public_gap"] == 174
        ),
        "macs1206_side_remains_same_kernel_no_new_knobs": (
            cross_observable["macs1206_secondary_deltasigma"]["same_kernel_only"]
            and cross_observable["macs1206_secondary_deltasigma"]["no_new_knobs"]
        ),
        "cross_observable_scope_not_executed_yet": (
            "Cross-observable court already executed" in not_supported_cross
        ),
        "cross_observable_scope_not_closed_yet": (
            "Whole cross-observable court already closed" in not_supported_cross
        ),
        "whole_family_defeat_not_supported_yet": (
            "Whole-family MOND_QUMOND defeat" in not_supported_cross
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "bounded_packet_facing_same_observable_ceiling_and_cross_observable_escalation",
        "surface": "current_full_head_same_observable_ceiling_and_cross_observable_escalation",
        "present_head_state": {
            "structured_pair_fraction_of_full_head_public_delta_aic_total": nonterminal[
                "concentration_surface"
            ]["structured_pair_fraction_of_full_head_public_delta_aic_total"],
            "pocket_fraction_of_full_head_public_delta_aic_total": nonterminal[
                "concentration_surface"
            ]["pocket_fraction_of_full_head_public_delta_aic_total"],
            "terminal_full_head_closure_not_admissible_now": nonterminal["consistency_checks"][
                "terminal_full_head_closure_is_not_admissible_now"
            ],
        },
        "selected_next_scope": {
            "selected_scope": cross_observable["selected_scope"],
            "selected_scope_contains": cross_observable["selected_scope_contains"],
            "rotation_fixed_public_qumond_crosscheck_count_with_zero_public_gap": cross_observable[
                "rotation_fixed_public_qumond_crosscheck_count_with_zero_public_gap"
            ],
            "macs1206_secondary_deltasigma": cross_observable["macs1206_secondary_deltasigma"],
        },
        "structural_reading": {
            "the_same_observable_head_has_already_yielded_a_strong_concentrated_but_nonterminal_reading": True,
            "the_next_honest_gain_is_not_more_same_head_rhetoric_but_cross_observable_escalation": True,
            "the_packet_now_has_one_explicit_bridge_from_present_head_ceiling_to_next_selected_court": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the current full head has already produced a strong same-observable concentration result",
            "that same-observable result is still explicitly nonterminal",
            "the next highest-leverage scope is therefore the selected no-makeup cross-observable court",
            "the packet no longer needs reader improvisation about what comes after the present full-head ceiling",
        ],
        "not_supported_now": [
            "more same-observable head rhetoric alone can honestly substitute for cross-observable escalation",
            "the selected cross-observable court is already executed or already closed",
            "whole-family MOND_QUMOND defeat is already established",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_frontier": cross_observable["next_honest_continuation"],
    }

    output["verdict"] = (
        "CURRENT_FULL_HEAD_SAME_OBSERVABLE_CEILING_AND_CROSS_OBSERVABLE_ESCALATION_CLOSED__THE_PRESENT_HEAD_IS_ALREADY_STRONG_BUT_NONTERMINAL_SO_THE_NEXT_HONEST_GAIN_IS_THE_SELECTED_NO_MAKEUP_CROSS_OBSERVABLE_COURT"
        if all(consistency_checks.values())
        else "CURRENT_FULL_HEAD_SAME_OBSERVABLE_CEILING_AND_CROSS_OBSERVABLE_ESCALATION_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
