# Large-Scale Multiseed Effort Front Card

Date: `2026-06-06`

This front card exists to make one under-expressed strength explicit:

the galaxy line was not produced by a light spreadsheet pass.

It was produced by a large repeated dual-model multiseed benchmark campaign.

## What is already confirmed

The packet already preserves the broad reading:

- `175` unique valid cases
- `875 = 175 x 5` valid multiseed reports
- and one broader packet-facing `175 / 875 / 880` reading

It also preserves a narrowed later release lane carrying:

- `127` valid galaxies
- `645` total multiseed runs
- and negative aggregate `delta_AIC` in both preserved narrowed variants

It now also preserves a stronger intermediate narrowing:

- one recovered `2026-02-28` body snapshot with `wins = 65`,
- `k_star = 2`,
- and `trim2 < 0`,
- meaning the trimmed body was already below zero once the top two offenders
  were removed.

It can now also state the preserved sampler-scale arithmetic more explicitly:

- broad raw chain states across both models:
  `175 x 5 x 2 x 1000 = 1,750,000`
- broad retained post-burn-in states across both models:
  `175 x 5 x 2 x 500 = 875,000`
- broad retained post-burn-in states for the current model alone:
  `175 x 5 x 500 = 437,500`
- narrowed raw chain states across both models:
  `127 x 5 x 2 x 1000 = 1,270,000`
- narrowed retained post-burn-in states across both models:
  `127 x 5 x 2 x 500 = 635,000`
- narrowed retained post-burn-in states for the current model alone:
  `127 x 5 x 500 = 317,500`

## Why this matters

This effort produced several packet-level gains:

- it localized harsh pressure into named offender cores,
- it showed that one preserved body snapshot was top-two dominated rather than
  broadly broken,
- it elevated `NGC0247` into a real reviewer-readable differential spear,
- it preserved five-seed stability on the same witness line,
- and it enabled narrowed audited release variants rather than leaving the
  program trapped inside one harsh bulk benchmark surface.

For the cleanest recovered summary of that sequence, also see:

- `RECOVERED_DATED_KSTAR2_BODY_AND_NARROW_NEGATIVE_CROSSING_NOTE_20260606.md`

## What remains under-expressed

The packet already surfaces:

- witness quality,
- benchmark consequences,
- and replication posture.

What it still says less clearly is one simple truth:

- the underlying campaign operated at explicit six- and seven-figure sampler
  scale,
- not merely a few visible benchmark tables.

That does not change the science.
But it does change the reader's sense of how much empirical work already sits
behind the current witness structure.

## Best outward-safe reading

The galaxy line should be read not as:

- a small benchmark with one interesting case,

but as:

- a large multiseed dual-model benchmark campaign whose visible packet-level
  witnesses are the distilled product of that much larger empirical effort.
