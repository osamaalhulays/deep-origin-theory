# Evidence Map

Date: `2026-06-11`

Status: `evidence routing`

## Governing evidence surfaces

1. `Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/POST_CAGE_BRANCH_U1_BOUNDED_PROBE_VERSUS_PROMOTABLE_AUTHORITY_NOTE_20260608.md`
   - fixes bounded probe as real but insufficient
   - fixes the missing jump to promotable authority

2. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_SINGLE_CARRIER_OWNERSHIP_TEST_NOTE_20260608.md`
   - fixes that `Q` must own the jump to promotable authority

3. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_MINIMUM_ACTION_WORKSHEET_NOTE_20260608.md`
   - fixes one future `Q`-owned jump to promotable response authority in the
     minimum worksheet

4. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EXACT_VANISHING_LANDING_TEST_V1/02_LOCKS/LANDING_CRITERIA_AND_FAILURE_SIGNATURES.md`
   - fixes same-route authority visibility as part of landing criteria

5. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_V1/04_OUTPUTS/AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_REPORT.md`
   - fixes authority crossing as non-`Form D` landing-class event
