# Signature Scope And Boundary

Date: `2026-06-11`

Status: `scope lock`

## This object claims

- bounded probe is below same-route authority crossing,
- the same carrier `Q` must own the jump to promotable authority,
- same-route authority crossing is a landing-class event,
- and `Form D` or widening may not be laundered into that crossing signature.

## This object does not claim

- that the crossing already happened,
- that the whole landing theorem already happened,
- that `Form D` already happened,
- or that widening is already forced.

## This object fails if

1. bounded probe is no longer fenced below promotable authority,
2. the ownership test no longer requires `Q` to own the jump to promotable
   authority,
3. the minimum worksheet no longer reserves one future `Q`-owned authority
   jump,
4. landing criteria no longer require same-route authority visibility,
5. or the class discriminator no longer keeps authority crossing distinct
   from `Form D` supersession.
