# Signature Test Matrix

Date: `2026-06-11`

Status: `test matrix`

## Required confirmations

1. bounded probe remains present but insufficient.
2. the missing jump to promotable authority remains explicit.
3. the same carrier `Q` still must own that jump.
4. the minimum worksheet still reserves one future `Q`-owned authority jump.
5. landing criteria still require same-route authority visibility.
6. the non-collapse discriminator still distinguishes authority crossing
   from `Form D`.

## Passing interpretation

If all six confirmations hold,
the current minimum same-route authority-crossing signature is frozen.

## Failing interpretation

If any confirmation fails,
the live tooth must be recomputed before this signature is reused.
