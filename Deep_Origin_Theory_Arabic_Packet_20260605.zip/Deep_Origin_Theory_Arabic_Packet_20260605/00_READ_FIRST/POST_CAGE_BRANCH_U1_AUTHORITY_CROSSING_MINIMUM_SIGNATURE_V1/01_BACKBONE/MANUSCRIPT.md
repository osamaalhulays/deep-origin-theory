# Post-Cage Branch U1 Authority Crossing Minimum Signature

Date: `2026-06-11`

Status: `reviewer-facing crossing-signature object`

## Purpose

This object does **not** claim:

- that one lawful authority crossing already exists,
- that exact landing already happened,
- that one reviewer-visible `Form D` engine already exists,
- that widening is already forced,
- or that true `L0` crossing already exists.

It claims something narrower and operationally decisive:

1. the current route already localizes its live tooth to authority crossing,
2. the route already distinguishes that class from `Form D` supersession and
   from widening,
3. and the minimum signature of what would count as same-route authority
   crossing can now be frozen exactly.

## Short verdict

The minimum same-route authority-crossing signature is no longer one vague
request for “more authority somehow.”

It is the smallest lawful package in which:

1. the same carrier `Q` owns the jump from bounded probe
   to promotable source-governed evaluator / value authority,
2. one lawful `Q`-owned promotable response-authority surface becomes
   materially visible on the same route,
3. that visibility is not borrowed from one second carrier,
   one external patch,
   or one prior `Form D` supersession,
4. and the event therefore counts as a landing-class same-route crossing
   rather than one renamed replacement from above.

That is now the exact minimum crossing signature.

## 1. Why bounded probe is below the line

The current line already preserves:

- one source-to-total response rule,
- one nontrivial response operator,
- one bounded no-claim probe.

But the bounded-probe note is already explicit:

- the surviving wound is the missing jump from bounded probe
  to promotable source-governed authority.

So crossing does **not** mean:

- one bounded probe became rhetorically impressive.

It means the route actually crossed the missing jump above that probe.

## 2. Why the same carrier `Q` must own that jump

The ownership test already fixes that `U1` survives only if the same carrier
`Q` owns:

1. the rule,
2. the operator,
3. the bounded probe,
4. and the jump to promotable source-governed evaluator / value authority.

So the crossing signature is not only:

- some authority surface appears.

It is:

- the same carrier `Q` owns the jump to that authority surface.

If that jump is owned elsewhere,
the event is not same-route authority crossing.

It is architecture leakage.

## 3. Why minimum worksheet discipline already constrains this signature

The minimum `U1` worksheet already freezes:

- one future `Q`-owned jump to promotable response authority.

So the current crossing signature does not float outside the constructive
line.

It already has one exact slot inside the minimum worksheet:

- future authority route under the same ownership map.

That is why the signature is now killable rather than atmospheric.

## 4. Why the crossing signature is not full landing

The landing criteria already show that authority crossing is necessary for
same-route landing,
but it is not the whole landing theorem by itself.

Crossing sits inside a larger package:

- typed `U2` triggers still not fired,
- ledger and closure gates still intact,
- no hidden widening imports,
- no prior `Form D` supersession.

So this object freezes:

- the minimum signature of the crossing event,

not:

- the whole success theorem above it.

## 5. Why the crossing signature is not `Form D`

The class discriminator already fixes:

- authority crossing = landing-class same-route event,
- `Form D` = engine-grade supersession from above.

So the crossing signature may not be read as:

- one operator engine arrived.

It must be read as:

- the present route crossed its own authority tooth while preserving its own
  ownership map.

## 6. Exact minimum signature

The present exact minimum signature is therefore:

1. bounded probe no longer stands as the top live object,
2. one `Q`-owned promotable evaluator / value authority is materially
   visible on the same route,
3. the ownership of that jump remains with `Q`,
4. no hidden widening import is needed to make the event survive,
5. and no prior `Form D` supersession is doing the real work.

Anything weaker than that remains below the line.

## 7. What should supersede this object

This object should be superseded immediately if later lawful work shows:

1. one actual same-route authority crossing and a new landing-class verdict
   can be issued,
2. one real reviewer-visible `Form D` engine appears first and route
   supersession becomes the honest read,
3. or one fired typed `U2` trigger makes the whole same-route crossing
   question downstream to honest widening.

Until then,
this is the cleanest minimum signature the present route allows.

## Bottom line

The live tooth is now not only localized.

Its minimum crossing signature is also frozen.

That means the route is no longer waiting for:

- one vague future authority idea.

It is waiting for:

- one `Q`-owned jump from bounded probe to promotable authority that remains
  same-route, pre-widening, and non-`Form D`.
