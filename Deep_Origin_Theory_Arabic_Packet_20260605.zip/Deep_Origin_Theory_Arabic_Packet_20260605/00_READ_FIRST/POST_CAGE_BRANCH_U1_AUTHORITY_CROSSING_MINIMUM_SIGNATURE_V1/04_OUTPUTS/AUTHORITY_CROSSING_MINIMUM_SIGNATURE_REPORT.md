# Authority Crossing Minimum Signature Report

Generated at: `2026-06-12T15:30:03.139249+00:00`

Verdict: `POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_MINIMUM_SIGNATURE_MATERIALIZED`

## Summary

- bounded probe remains insufficient: `true`
- the same carrier `Q` must own the jump: `true`
- the minimum worksheet reserves the future `Q`-owned jump: `true`
- landing still requires same-route authority visibility: `true`
- crossing remains non-`Form D`: `true`
- all note checks pass: `true`

## Reading

- bounded probe is below the live tooth, not equal to it,
- the same carrier `Q` must own the jump to promotable authority,
- the crossing signature already has one reserved slot inside the minimum worksheet,
- and the event must remain same-route and non-`Form D` to count as authority crossing.

## Ceiling

- this report does not claim the crossing already happened,
- it does not claim the whole landing theorem already happened,
- it does not claim widening is already forced.
