#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"

BOUNDED_PROBE_NOTE = "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/POST_CAGE_BRANCH_U1_BOUNDED_PROBE_VERSUS_PROMOTABLE_AUTHORITY_NOTE_20260608.md"
OWNERSHIP_NOTE = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_SINGLE_CARRIER_OWNERSHIP_TEST_NOTE_20260608.md"
WORKSHEET_NOTE = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_MINIMUM_ACTION_WORKSHEET_NOTE_20260608.md"
LANDING_CRITERIA = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EXACT_VANISHING_LANDING_TEST_V1/02_LOCKS/LANDING_CRITERIA_AND_FAILURE_SIGNATURES.md"
DISCRIMINATOR_REPORT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_V1/04_OUTPUTS/AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_REPORT.md"

NOTE_CHECKS = [
    {
        "key": "bounded_probe_is_insufficient",
        "path": BOUNDED_PROBE_NOTE,
        "fragments": [
            "4. but the surviving wound is still the missing jump from bounded probe",
            "to true-closure-grade source-governed authority.",
            "So the bounded probe is useful,",
            "but it is not yet one promotable authority surface.",
        ],
        "meaning": "bounded probe remains present but insufficient for crossing",
    },
    {
        "key": "q_must_own_the_jump",
        "path": OWNERSHIP_NOTE,
        "fragments": [
            "4. and the jump to promotable source-governed evaluator / value authority",
            "If the final authority step requires one second hidden carrier or one external",
            "patch, `U1` has failed its ownership test.",
        ],
        "meaning": "the same carrier Q must own the jump to promotable authority",
    },
    {
        "key": "worksheet_reserves_future_q_owned_authority_jump",
        "path": WORKSHEET_NOTE,
        "fragments": [
            "4. one future `Q`-owned jump to promotable response authority",
            "If the last step requires one second carrier or one non-variational patch,",
            "`U1` fails.",
        ],
        "meaning": "the minimum worksheet already reserves one future Q-owned authority jump",
    },
    {
        "key": "landing_requires_authority_visibility",
        "path": LANDING_CRITERIA,
        "fragments": [
            "5. one lawful `Q`-owned promotable response-authority surface is materially",
            "visible on the same route,",
        ],
        "meaning": "same-route authority visibility remains part of the landing criteria",
    },
    {
        "key": "crossing_is_non_formd",
        "path": DISCRIMINATOR_REPORT,
        "fragments": [
            "- authority crossing is one landing-class same-route event,",
            "- `Form D` is one engine-grade supersession-class event from above,",
            "- do not treat `Form D` arrival as silent proof that the current route crossed its own authority tooth,",
        ],
        "meaning": "authority crossing remains distinct from Form D supersession",
    },
]


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
if WORKSPACE_ROOT is None:
    raise RuntimeError("could not locate workspace root from authority-crossing signature runner")


def read_text(logical_relative_path: str) -> str:
    return (WORKSPACE_ROOT / logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": item["path"],
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def tf(value: bool) -> str:
    return str(value).lower()


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": (
            "POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_MINIMUM_SIGNATURE_MATERIALIZED"
            if all_note_checks_pass
            else "POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_MINIMUM_SIGNATURE_NOT_MATERIALIZED"
        ),
        "bounded_probe_is_insufficient": note_check_map["bounded_probe_is_insufficient"],
        "q_must_own_the_jump": note_check_map["q_must_own_the_jump"],
        "worksheet_reserves_future_q_owned_authority_jump": note_check_map["worksheet_reserves_future_q_owned_authority_jump"],
        "landing_requires_authority_visibility": note_check_map["landing_requires_authority_visibility"],
        "crossing_is_non_formd": note_check_map["crossing_is_non_formd"],
        "same_route_authority_crossing_landed": False,
        "all_note_checks_pass": all_note_checks_pass,
    }

    verdict = {
        "verdict": status_summary["verdict"],
        "minimum_signature": [
            "bounded probe no longer stands as the top live object",
            "one Q-owned promotable evaluator/value authority is materially visible on the same route",
            "the ownership of that jump remains with Q",
            "no hidden widening import is needed",
            "no prior Form D supersession is doing the real work",
        ],
        "crossing_class": "landing-class same-route event",
    }

    report_lines = [
        "# Authority Crossing Minimum Signature Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- bounded probe remains insufficient: `{tf(status_summary['bounded_probe_is_insufficient'])}`",
        f"- the same carrier `Q` must own the jump: `{tf(status_summary['q_must_own_the_jump'])}`",
        f"- the minimum worksheet reserves the future `Q`-owned jump: `{tf(status_summary['worksheet_reserves_future_q_owned_authority_jump'])}`",
        f"- landing still requires same-route authority visibility: `{tf(status_summary['landing_requires_authority_visibility'])}`",
        f"- crossing remains non-`Form D`: `{tf(status_summary['crossing_is_non_formd'])}`",
        f"- all note checks pass: `{tf(status_summary['all_note_checks_pass'])}`",
        "",
        "## Reading",
        "",
        "- bounded probe is below the live tooth, not equal to it,",
        "- the same carrier `Q` must own the jump to promotable authority,",
        "- the crossing signature already has one reserved slot inside the minimum worksheet,",
        "- and the event must remain same-route and non-`Form D` to count as authority crossing.",
        "",
        "## Ceiling",
        "",
        "- this report does not claim the crossing already happened,",
        "- it does not claim the whole landing theorem already happened,",
        "- it does not claim widening is already forced.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    (OUTPUT_ROOT / "AUTHORITY_CROSSING_MINIMUM_SIGNATURE_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
