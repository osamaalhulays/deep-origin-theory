# Gate Test Matrix

1. the minimum `Form D` signature object is materialized.
2. the current-repo `Form D` no-go object is materialized.
3. the route still distinguishes same-route crossing from `Form D`.
4. the current typed `U2` state still reads not yet fired.
5. the current route therefore sends present repo-visible `Form D` candidates
   to `REJECT`.

## Pass condition

- all five checks pass.

## Failure meaning

- the current route no longer carries one governed `Form D` admission gate.
