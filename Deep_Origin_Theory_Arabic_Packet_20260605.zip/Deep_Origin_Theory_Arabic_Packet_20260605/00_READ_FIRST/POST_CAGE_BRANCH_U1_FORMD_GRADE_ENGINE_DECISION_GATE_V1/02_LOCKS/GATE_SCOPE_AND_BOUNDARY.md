# Gate Scope And Boundary

- This gate routes `Form D` claims only.
- It does not itself materialize one `Form D` engine.
- It does not replace the crossing gate.
- It does not replace typed `U2` trigger adjudication.

## Kill conditions

This gate must be refreshed if any of the following happen:

1. the minimum `Form D` signature changes,
2. the current-repo no-go no longer holds,
3. same-route crossing and `Form D` are no longer kept distinct,
4. `U2` widening and `Form D` are no longer kept distinct,
5. or one real candidate flips the gate away from the current `REJECT` state.
