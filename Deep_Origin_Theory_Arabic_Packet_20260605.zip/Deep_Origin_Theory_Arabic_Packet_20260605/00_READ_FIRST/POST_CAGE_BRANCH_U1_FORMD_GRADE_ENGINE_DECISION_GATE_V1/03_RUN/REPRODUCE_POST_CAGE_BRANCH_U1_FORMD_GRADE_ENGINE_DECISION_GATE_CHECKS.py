from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[4]
OBJECT_ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = OBJECT_ROOT / "04_OUTPUTS"
OUTPUTS.mkdir(parents=True, exist_ok=True)


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


min_signature_status = read_json(
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_FORMD_MINIMUM_ENGINE_SIGNATURE_V1/04_OUTPUTS/status_summary.json"
)
no_go_status = read_json(
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_FORMD_MINIMUM_ENGINE_SIGNATURE_CURRENT_REPO_NO_GO_V1/04_OUTPUTS/status_summary.json"
)
discriminator_report = read_text(
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_V1/04_OUTPUTS/AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_REPORT.md"
)
u2_report = read_text(
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_V1/04_OUTPUTS/TYPED_U2_TRIGGER_ADJUDICATION_REPORT.md"
)

checks = [
    {
        "name": "minimum_signature_materialized",
        "passed": min_signature_status["verdict"]
        == "POST_CAGE_BRANCH_U1_FORMD_MINIMUM_ENGINE_SIGNATURE_MATERIALIZED",
    },
    {
        "name": "current_repo_no_go_materialized",
        "passed": no_go_status["verdict"]
        == "POST_CAGE_BRANCH_U1_FORMD_MINIMUM_ENGINE_SIGNATURE_CURRENT_REPO_NO_GO_MATERIALIZED",
    },
    {
        "name": "crossing_still_distinct_from_formd",
        "passed": "landing-class same-route event" in discriminator_report
        and "engine-grade supersession-class event from above" in discriminator_report,
    },
    {
        "name": "u2_still_not_fired",
        "passed": "typed-but-not-fired on U2 triggers" in u2_report
        and "strong-field trigger forced now: `false`" in u2_report
        and "south-substrate trigger forced now: `false`" in u2_report
        and "ledger-honesty trigger forced now: `false`" in u2_report,
    },
]

materialized = all(item["passed"] for item in checks)
current_route_gate_result = (
    "reject_current_repo_visible_formd_candidates" if materialized else "gate_unstable"
)
generated_at = datetime.now(timezone.utc).isoformat()

verdict = {
    "object": "POST_CAGE_BRANCH_U1_FORMD_GRADE_ENGINE_DECISION_GATE_V1",
    "generated_at": generated_at,
    "materialized": materialized,
    "current_route_gate_result": current_route_gate_result,
    "outcomes": [
        "ADMIT_FORMD",
        "REJECT",
        "REDIRECT_CROSSING",
        "REDIRECT_U2",
    ],
}

status_summary = {
    "verdict": (
        "POST_CAGE_BRANCH_U1_FORMD_GRADE_ENGINE_DECISION_GATE_MATERIALIZED"
        if materialized
        else "POST_CAGE_BRANCH_U1_FORMD_GRADE_ENGINE_DECISION_GATE_NOT_MATERIALIZED"
    ),
    "minimum_signature_confirmed": checks[0]["passed"],
    "current_repo_no_go_confirmed": checks[1]["passed"],
    "crossing_distinction_confirmed": checks[2]["passed"],
    "u2_not_fired_confirmed": checks[3]["passed"],
    "current_route_gate_result": current_route_gate_result,
}

report_lines = [
    "# Post-Cage Branch U1 Form D-Grade Engine Decision Gate Report",
    "",
    f"Generated at: `{generated_at}`",
    "",
    f"Verdict: `{status_summary['verdict']}`",
    "",
    "## Summary",
    "",
    f"- minimum signature confirmed: `{checks[0]['passed']}`",
    f"- current repo no-go confirmed: `{checks[1]['passed']}`",
    f"- crossing distinction confirmed: `{checks[2]['passed']}`",
    f"- U2 not fired confirmed: `{checks[3]['passed']}`",
    f"- current route gate result: `{current_route_gate_result}`",
    "",
    "## Gate outcomes",
    "",
    "- `ADMIT_FORMD`",
    "- `REJECT`",
    "- `REDIRECT_CROSSING`",
    "- `REDIRECT_U2`",
    "",
    "## Reading",
    "",
    "- present repo-visible Form D claims no longer enter by naming or grammar,",
    "- they already route to reject on the current frozen route,",
    "- same-route crossing remains fenced to its own gate,",
    "- and fired U2 remains fenced to widening adjudication.",
    "",
    "## Bottom line",
    "",
    "- Form D now has one exact governed decision gate rather than one free-floating reopening hope.",
]

(OUTPUTS / "checks.json").write_text(json.dumps(checks, indent=2), encoding="utf-8")
(OUTPUTS / "verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")
(OUTPUTS / "status_summary.json").write_text(json.dumps(status_summary, indent=2), encoding="utf-8")
(OUTPUTS / "FORMD_GRADE_ENGINE_DECISION_GATE_REPORT.md").write_text(
    "\n".join(report_lines) + "\n",
    encoding="utf-8",
)
