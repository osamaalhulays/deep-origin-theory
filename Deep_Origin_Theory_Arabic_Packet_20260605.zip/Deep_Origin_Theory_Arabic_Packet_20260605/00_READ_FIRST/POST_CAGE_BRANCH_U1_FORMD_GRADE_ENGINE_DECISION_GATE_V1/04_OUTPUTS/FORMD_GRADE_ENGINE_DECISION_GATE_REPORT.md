# Post-Cage Branch U1 Form D-Grade Engine Decision Gate Report

Generated at: `2026-06-12T15:30:04.456737+00:00`

Verdict: `POST_CAGE_BRANCH_U1_FORMD_GRADE_ENGINE_DECISION_GATE_MATERIALIZED`

## Summary

- minimum signature confirmed: `True`
- current repo no-go confirmed: `True`
- crossing distinction confirmed: `True`
- U2 not fired confirmed: `True`
- current route gate result: `reject_current_repo_visible_formd_candidates`

## Gate outcomes

- `ADMIT_FORMD`
- `REJECT`
- `REDIRECT_CROSSING`
- `REDIRECT_U2`

## Reading

- present repo-visible Form D claims no longer enter by naming or grammar,
- they already route to reject on the current frozen route,
- same-route crossing remains fenced to its own gate,
- and fired U2 remains fenced to widening adjudication.

## Bottom line

- Form D now has one exact governed decision gate rather than one free-floating reopening hope.
