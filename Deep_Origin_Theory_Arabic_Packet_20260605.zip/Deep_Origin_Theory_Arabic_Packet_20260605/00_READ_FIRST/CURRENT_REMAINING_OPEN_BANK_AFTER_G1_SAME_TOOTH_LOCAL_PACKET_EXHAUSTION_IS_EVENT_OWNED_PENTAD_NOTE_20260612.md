# Current Remaining Open Bank After `G1` Same-Tooth Local-Packet Exhaustion Is One Event-Owned Pentad

Date: `2026-06-12`

Purpose:

State the exact current reading of the remaining open bank after the `G1`
same-tooth battlefield has already been gate-disciplined and locally
exhausted into watch-only / wait-only.

## Short verdict

The fair current reading is:

- the remaining open bank is now one event-owned pentad

More exactly:

- `G1` = fresh same-tooth witness-package owned
  or typed superseding-package owned
- `G5` = terminal carrier arrival-owned
- `G6` = empirical payload arrival-owned
- `G7` = real external dispatch-owned
- `G8` = broader independent replication-owned

## What this means

This does **not** mean the bank is closed.

It means something narrower:

- the remaining bank is no longer best read as one still-spendable local
  packet cloud.

## Read with

- `CURRENT_G1_SAME_TOOTH_FREEZE_WITNESS_UNIFIED_DECISION_GATE_MATERIALIZED_NOTE_20260612.md`
- `CURRENT_G1_SAME_TOOTH_FREEZE_WITNESS_ARRIVAL_GRAMMAR_MATERIALIZED_NOTE_20260612.md`
- `CURRENT_G1_SAME_TOOTH_SUPERSEDING_ARRIVAL_GRAMMAR_MATERIALIZED_NOTE_20260612.md`
- `CURRENT_G1_SAME_TOOTH_FREEZE_WITNESS_LOCAL_PACKET_EXHAUSTION_AND_WATCH_ONLY_NOTE_20260612.md`
- `CURRENT_NON_G1_REMAINING_OPEN_BANK_AFTER_G4_RETIREMENT_IS_EXTERNAL_OWNED_EVENT_QUARTET_NOTE_20260612.md`
