# Signature Scope And Boundary

Date: `2026-06-12`

Status: `scope boundary`

This signature object is scoped to the current repo-visible frozen
pairwise-freeze tooth only.

It does **not** claim:

1. one freeze object already exists
2. final pairwise law already exists
3. exact transport closure already exists
4. the whole `G1` route is solved

It claims something narrower:

1. the lower pairwise chain is already materially present,
2. the live tooth above it is now already exact enough to freeze a minimum
   signature,
3. and anything weaker than that signature remains below the current line.
