# Signature Test Matrix

Date: `2026-06-12`

Status: `test matrix`

The current minimum signature counts as materially supported only if all of
the following remain true:

1. the ordered shell-typed pair is already frozen as
   `I_geo^(0) > I_amp^(0)`
2. the bound candidate is already `C_Q_kinetic`
3. candidate-grade binding is already present below the live tooth
4. the live blocker is already one missing reviewer-visible freeze object
5. the current route already rules out hidden higher-grade repo witnesses at
   that tooth
6. `C_Q_gradient` remains shadow pressure only rather than one coequal first
   owner
7. final public pairwise formula remains unclaimed at this grade

If any of those fails,
the current minimum signature fails.
