#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"

PAIR_CONTRACT_VERDICT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_IAMP0_IGEO0_PAIR_ORDER_BEARING_CARRIER_CONTRACT_V1/04_OUTPUTS/verdict.json"
BINDING_VERDICT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_V1/04_OUTPUTS/verdict.json"
BINDING_PRESENT_JSON = "artifacts/debt_board_20260530/G1_PRESENT_MATERIALS_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_MATERIALIZED_AND_NEXT_TOOTH_IS_ONE_AUTHORITY_GRADE_PAIRWISE_COEFFICIENT_FREEZE_20260612.json"
FREEZE_NO_GO_JSON = "artifacts/debt_board_20260530/G1_PRESENT_MATERIALS_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_CURRENT_REPO_NO_GO_MATERIALIZED_AND_BLOCKER_LOCALIZES_TO_ONE_MISSING_REVIEWER_VISIBLE_FREEZE_OBJECT_20260612.json"
FREEZE_NO_GO_VERDICT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_CURRENT_REPO_NO_GO_V1/04_OUTPUTS/verdict.json"


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
if WORKSPACE_ROOT is None:
    raise RuntimeError("could not locate workspace root from pairwise-freeze signature runner")


def read_json(logical_relative_path: str) -> dict:
    return json.loads(
        (WORKSPACE_ROOT / logical_relative_path).read_text(encoding="utf-8", errors="ignore")
    )


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def tf(value: bool) -> str:
    return str(value).lower()


def collect_note_checks() -> list[dict]:
    results = []

    pair_contract = read_json(PAIR_CONTRACT_VERDICT)
    results.append(
        {
            "key": "pair_order_locked",
            "path": PAIR_CONTRACT_VERDICT,
            "meaning": "the ordered shell-typed pair is already frozen",
            "checks": {
                "binding_pair": pair_contract.get("binding_pair"),
                "frozen_internal_order": pair_contract.get("frozen_internal_order"),
            },
            "passed": (
                pair_contract.get("binding_pair") == "(I_amp^(0), I_geo^(0))"
                and pair_contract.get("frozen_internal_order") == "I_geo^(0) > I_amp^(0)"
            ),
        }
    )

    binding = read_json(BINDING_VERDICT)
    results.append(
        {
            "key": "bound_candidate_locked",
            "path": BINDING_VERDICT,
            "meaning": "the bound candidate is already C_Q_kinetic and points upward to the freeze tooth",
            "checks": {
                "bound_candidate_occupant": binding.get("bound_candidate_occupant"),
                "next_exact_tooth": binding.get("next_exact_tooth"),
            },
            "passed": (
                binding.get("bound_candidate_occupant") == "C_Q_kinetic"
                and binding.get("next_exact_tooth")
                == "authority_grade_pairwise_coefficient_freeze_for_bound_C_Q_kinetic"
            ),
        }
    )

    binding_present = read_json(BINDING_PRESENT_JSON)
    results.append(
        {
            "key": "binding_below_freeze_and_gradient_shadow_only",
            "path": BINDING_PRESENT_JSON,
            "meaning": "candidate-grade binding is below the live tooth and gradient remains shadow-only",
            "checks": {
                "new_object": binding_present.get("new_object"),
                "gradient_status": binding_present.get("gradient_status"),
                "bound_corridor": binding_present.get("bound_corridor"),
            },
            "passed": (
                binding_present.get("new_object") == "candidate-grade pairwise binding"
                and binding_present.get("gradient_status")
                == "shadow pressure only, not coequal first owner"
                and binding_present.get("bound_corridor") == "B_Q-free A_Q^(0)[I_geo^(0)]"
            ),
        }
    )

    freeze_no_go = read_json(FREEZE_NO_GO_JSON)
    results.append(
        {
            "key": "freeze_blocker_and_hidden_repo_witness_ruled_out",
            "path": FREEZE_NO_GO_JSON,
            "meaning": "the live blocker is one missing freeze object and hidden higher-grade repo witnesses are already ruled out",
            "checks": {
                "new_blocker": freeze_no_go.get("new_blocker"),
                "hidden_higher_grade_repo_witness_ruled_out": freeze_no_go.get(
                    "hidden_higher_grade_repo_witness_ruled_out"
                ),
            },
            "passed": (
                freeze_no_go.get("hidden_higher_grade_repo_witness_ruled_out") is True
                and freeze_no_go.get("new_blocker", "").startswith(
                    "one missing reviewer-visible authority-grade pairwise-freeze object"
                )
            ),
        }
    )

    freeze_no_go_verdict = read_json(FREEZE_NO_GO_VERDICT)
    results.append(
        {
            "key": "freeze_no_go_materialized",
            "path": FREEZE_NO_GO_VERDICT,
            "meaning": "the current route already fails cleanly as a current-materialization target at this tooth",
            "checks": {
                "verdict": freeze_no_go_verdict.get("verdict"),
            },
            "passed": (
                freeze_no_go_verdict.get("verdict")
                == "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_CURRENT_REPO_NO_GO_MATERIALIZED"
            ),
        }
    )

    results.append(
        {
            "key": "final_public_pairwise_formula_unclaimed",
            "path": FREEZE_NO_GO_JSON,
            "meaning": "final public pairwise formula remains unclaimed at this grade",
            "checks": {
                "final_public_pairwise_formula_already_claimed": freeze_no_go.get(
                    "final_public_pairwise_formula_already_claimed"
                )
            },
            "passed": freeze_no_go.get("final_public_pairwise_formula_already_claimed") is False,
        }
    )

    return results


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    verdict_name = (
        "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_MINIMUM_SIGNATURE_MATERIALIZED"
        if all_note_checks_pass
        else "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_MINIMUM_SIGNATURE_NOT_MATERIALIZED"
    )

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": verdict_name,
        "pair_order_locked": note_check_map["pair_order_locked"],
        "bound_candidate_locked": note_check_map["bound_candidate_locked"],
        "binding_below_freeze_and_gradient_shadow_only": note_check_map[
            "binding_below_freeze_and_gradient_shadow_only"
        ],
        "freeze_blocker_and_hidden_repo_witness_ruled_out": note_check_map[
            "freeze_blocker_and_hidden_repo_witness_ruled_out"
        ],
        "freeze_no_go_materialized": note_check_map["freeze_no_go_materialized"],
        "final_public_pairwise_formula_unclaimed": note_check_map[
            "final_public_pairwise_formula_unclaimed"
        ],
        "all_note_checks_pass": all_note_checks_pass,
    }

    verdict = {
        "verdict": verdict_name,
        "minimum_signature": [
            "candidate-grade binding no longer stands as the top live object",
            "one reviewer-visible authority-grade pairwise-freeze surface is materially visible for the bound C_Q_kinetic occupant",
            "the ordered shell-typed pair (I_amp^(0), I_geo^(0)) remains explicit",
            "the B_Q-free A_Q^(0)[I_geo^(0)] corridor remains explicit",
            "C_Q_gradient remains shadow pressure only rather than one coequal first owner at that grade",
            "the event remains below silent final pairwise-law inflation or hidden higher-grade import",
        ],
        "freeze_class": "reviewer-visible authority-grade pairwise freeze above bound candidate",
    }

    report_lines = [
        "# Bound `C_Q_kinetic` Authority-Grade Pairwise Freeze Minimum Signature Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- pair order already locked: `{tf(status_summary['pair_order_locked'])}`",
        f"- bound candidate already locked: `{tf(status_summary['bound_candidate_locked'])}`",
        f"- candidate-grade binding already sits below the freeze tooth with gradient shadow-only: `{tf(status_summary['binding_below_freeze_and_gradient_shadow_only'])}`",
        f"- live blocker already excludes hidden higher-grade repo witnesses: `{tf(status_summary['freeze_blocker_and_hidden_repo_witness_ruled_out'])}`",
        f"- current-repo no-go already materialized at this tooth: `{tf(status_summary['freeze_no_go_materialized'])}`",
        f"- final public pairwise formula still unclaimed: `{tf(status_summary['final_public_pairwise_formula_unclaimed'])}`",
        f"- all note checks pass: `{tf(status_summary['all_note_checks_pass'])}`",
        "",
        "## Reading",
        "",
        "- candidate-grade binding is below the live tooth, not equal to it,",
        "- any later freeze must preserve the already bound candidate and the already fixed carrier corridor,",
        "- gradient remains below the first freeze line as shadow pressure only,",
        "- and the freeze event remains smaller than full final pairwise-law completion.",
        "",
        "## Ceiling",
        "",
        "- this report does not claim the freeze already landed,",
        "- it does not claim final pairwise law already landed,",
        "- it does not claim G1 is closed.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    (OUTPUT_ROOT / "BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_MINIMUM_SIGNATURE_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
