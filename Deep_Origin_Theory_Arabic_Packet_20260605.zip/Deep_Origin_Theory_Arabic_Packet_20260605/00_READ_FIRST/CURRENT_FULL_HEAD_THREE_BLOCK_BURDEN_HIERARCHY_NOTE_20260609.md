# Current Full-Head Three-Block Burden Hierarchy Note

Date: `2026-06-09`

Status: `packet-contained three-block burden hierarchy closure`

Purpose:

The packet had already shown three things separately:

- one `O7`-reinforced heptad outweighs the other seven full-head cases combined
- that losing seven-case half is itself all quality-`1`
- inside that half, a protected clean-anchor quartet sits beside a narrow exact-`QUMOND` pocket

This note turns those separate reads into one explicit ordering surface.

Machine-readable companion:

- `CURRENT_FULL_HEAD_THREE_BLOCK_BURDEN_HIERARCHY_V1.json`

Reproduction script:

- `REPRODUCE_CURRENT_FULL_HEAD_THREE_BLOCK_BURDEN_HIERARCHY_V1.py`

It should be read after:

- `CURRENT_FULL_HEAD_COUNT_BALANCED_BURDEN_ASYMMETRIC_SPLIT_NOTE_20260609.md`
- `CURRENT_FULL_HEAD_ALL_QUALITY1_COMPLEMENT_VS_MIXED_HEPTAD_NOTE_20260609.md`

## Short verdict

The current full head now admits one explicit three-block burden ordering:

1. dominant `O7`-reinforced heptad
2. protected clean-anchor quartet
3. localized exact-`QUMOND`-protected quality-`1` pocket

The three blocks carry:

- heptad: `7` cases, `53.70934938115022%` of full-head public burden
- quartet: `4` cases, `34.45341820567513%` of full-head public burden
- pocket: `3` cases, `11.837232413174664%` of full-head public burden

So the head is no longer best described as only a flat `7` versus `7` split.

It also has a stronger internal hierarchy.

## 1. The dominant block

The heptad remains the total-burden leader.

It outweighs:

- the clean-anchor quartet by `1.558897554388472x`
- the narrow pocket by `4.537323210902956x`

It also remains the only one of the three blocks that spans four distinct
`O7` layers.

## 2. The middle block

The protected clean-anchor quartet is:

- `NGC5055`
- `NGC3198`
- `NGC7331`
- `NGC2841`

It is not the dominant block, but it is clearly the middle block.

Inside the seven-case complement it carries:

- `74.42845962429726%` of complement burden

The narrow pocket carries only:

- `25.57154037570274%` of complement burden

So the complement is not pocket-dominated.

It is quartet-dominated.

## 3. One useful surprise

The clean-anchor quartet is denser per case than the dominant heptad.

Average public burden per case:

- heptad: `14626.302040045415`
- quartet: `16419.314083868936`
- pocket: `7521.62376518194`

So the quartet is the densest block per case, even though the heptad still
wins in total burden because it combines high burden with larger size and
cross-layer reinforcement.

That is a stronger and more honest reading than treating the quartet as either
trivial or dominant.

## 4. Meaning

This gives the packet a cleaner sentence about the current head:

- the present burden is organized into one dominant reinforced majority block,
  one dense protected middle block, and one narrow exact-`QUMOND` continuation
  pocket

That is more informative than:

- seven cases versus seven cases

or:

- quality `1` versus mixed quality

because it shows where the burden actually lives.

## 5. What this does not authorize

This note does **not** authorize the claims that:

- per-case density alone decides the global verdict
- the narrow pocket is physically irrelevant
- whole-family `MOND/QUMOND` closure already exists

## Best outward-safe reading

One mature outward-safe sentence is:

> The current full head is not only a count-balanced `7` versus `7` split. It
> now resolves into three burden blocks: a dominant `O7`-reinforced heptad, a
> dense protected clean-anchor quartet, and a narrow exact-`QUMOND`-protected
> quality-`1` pocket. The quartet is denser per case, but the heptad still
> leads in total burden.
