# Forbidden Authoring Ledger

Date: `2026-06-10`

Status: `anti-shortcut lock`

The later archive already forbids the following as fake closure routes for
the internal `L2` gate:

1. empirical `RAR` fit
2. McGaugh `RAR` formula as `QCT`
3. `MOND` interpolation
4. fitted `a0`
5. `SPARC` observed `gobs` as prediction
6. residual-derived `Delta`
7. halo profile fit
8. baryonic tuning
9. mass-to-light fit
10. individual galaxy fitting
11. likelihood-optimized values
12. chi-square-minimized values
13. post-hoc calibration
14. claim language inflation
15. `QCT` pass/fail claims
16. full cosmology claims

## Bottom line

The gate may reopen only through lawful source-governed author content, not
through empirical rescue or rhetorical overreach.
