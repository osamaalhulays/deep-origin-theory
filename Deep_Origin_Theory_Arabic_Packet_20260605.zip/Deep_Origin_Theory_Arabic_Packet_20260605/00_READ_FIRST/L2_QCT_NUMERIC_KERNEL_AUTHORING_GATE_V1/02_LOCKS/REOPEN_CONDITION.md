# Reopen Condition

Date: `2026-06-10`

Status: `restart rule`

## Exact restart rule

The archive already freezes:

- `reopen_allowed_if = one_lawful_Form_A_B_C_or_D_package_materialized`
- `reopen_forbidden_if = empirical_RAR_fit_or_MOND_or_SPARK_tuning_or_fit_or_likelihood`

## Next lawful probe after author supply

`RANK10_COSMOLOGY_L2_RAR_TRUE_CLOSURE_PROBE_AFTER_VALID_NONTRIVIAL_QCT_NUMERIC_KERNEL_NO_FIT_NO_CLAIM`

## Bottom line

The gate does not reopen because of optimism, wording, or external pressure.

It reopens only after one lawful authoring package truly exists.
