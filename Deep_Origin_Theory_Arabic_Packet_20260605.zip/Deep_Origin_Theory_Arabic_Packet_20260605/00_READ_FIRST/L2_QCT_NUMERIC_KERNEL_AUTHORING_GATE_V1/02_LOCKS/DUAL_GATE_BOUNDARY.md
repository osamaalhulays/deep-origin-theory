# Dual-Gate Boundary

Date: `2026-06-10`

Status: `boundary lock`

## Internal theory-side gate

The current internal gate asks:

- where does the lawful source-governed nontrivial `QCT` numeric response
  kernel come from?

## External empirical gate

The separate empirical gate asks:

- where do machine-readable baryonic component curves and uncertainties come
  from?

## Locked boundary

These two gates are:

- related
- both under `L2`
- but not identical

Solving the internal theory-side gate does **not** automatically solve the
external payload gate.

Solving the external payload gate does **not** automatically solve the
internal theory-side gate.

## Bottom line

No later writing should collapse these two lawful gate classes into one
unfinished blob.
