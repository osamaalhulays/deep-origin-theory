# Allowed Authoring Forms

Date: `2026-06-10`

Status: `scope lock`

## Exact target

The exact target remains:

`AUTHOR_SUPPLY_L2_QCT_NONTRIVIAL_NUMERIC_GALACTIC_RESPONSE_EVALUATOR_CONTENT`

with:

- required operator:
  `L2_QCT_INTERNAL_NONTRIVIAL_DELTA_RESPONSE_OPERATOR_V1`
- required rule:
  `L2_QCT_SOURCE_TO_TOTAL_GALACTIC_RESPONSE_RULE_V1`

## Lawful forms

The lawful authoring forms are frozen as:

1. `Form A`
   direct `Delta_QCT_L2(x_i)` table at the required `SPARC` bins
2. `Form B`
   `Xi_QCT_L2(gbar_i)` response table with exact conversion rule
3. `Form C`
   source-governed evaluator function for `Delta_QCT_L2(x)` or
   `Xi_QCT_L2(gbar)`
4. `Form D`
   source-governed operator engine producing those outputs

## Umbrella requirement

`exact_required_author_content = one_of_Form_A_Delta_table_Form_B_Xi_table_Form_C_evaluator_function_Form_D_operator_engine`

## Bottom line

The gate is not waiting for any arbitrary “theory.”

It is waiting for one lawful package inside this already frozen form class.
