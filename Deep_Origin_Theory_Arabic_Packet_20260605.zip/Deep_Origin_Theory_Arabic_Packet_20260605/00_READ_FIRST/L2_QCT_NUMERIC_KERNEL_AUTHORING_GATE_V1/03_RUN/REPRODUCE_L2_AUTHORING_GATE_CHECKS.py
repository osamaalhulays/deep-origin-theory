#!/usr/bin/env python3

from __future__ import annotations

import json
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"
PACKET_PREFIX = "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"
ARTIFACT_PREFIX = "artifacts/debt_board_20260530/"


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (parent / "artifacts").exists():
            return parent
    return None


def find_packet_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if parent.name == "00_READ_FIRST" and (parent / "START_HERE_FIRST.md").exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
SCRIPT_PACKET_ROOT = find_packet_root()
if SCRIPT_PACKET_ROOT is not None:
    PACKET_ROOT = SCRIPT_PACKET_ROOT
    RUNNING_FROM_PACKET = True
elif WORKSPACE_ROOT is not None:
    PACKET_ROOT = WORKSPACE_ROOT / "Deep_Origin_Theory_English_Packet_20260605" / "00_READ_FIRST"
    RUNNING_FROM_PACKET = False
else:
    raise RuntimeError("could not locate workspace or packet root from authoring-gate runner")


CHECKS = {
    "single_authoring_target_materialized": {
        "expected_state": "materialized",
        "sources": [
            (
                "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"
                "RANK10_CURRENT_MATERIALS_FINAL_COMPRESSION_TO_SINGLE_L2_AUTHORING_TARGET_NOTE_20260608.md",
                [
                    "blocked_pending_genuine_numeric_theory_authoring",
                    "AUTHOR_SUPPLY_L2_QCT_NONTRIVIAL_NUMERIC_GALACTIC_RESPONSE_EVALUATOR_CONTENT",
                ],
            ),
        ],
        "reason": "The gate exists only if current materials really compress to one singled-out target.",
    },
    "required_operator_and_rule_materialized": {
        "expected_state": "materialized",
        "sources": [
            (
                "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"
                "O10_AUTHORING_MICROFRONT_AFTER_POST_SEAL_PATH2_EXHAUSTION_NOTE_20260609.md",
                [
                    "L2_QCT_INTERNAL_NONTRIVIAL_DELTA_RESPONSE_OPERATOR_V1",
                    "L2_QCT_SOURCE_TO_TOTAL_GALACTIC_RESPONSE_RULE_V1",
                ],
            ),
            (
                "artifacts/debt_board_20260530/"
                "L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/01_BACKBONE/MANUSCRIPT.md",
                [
                    "L2_QCT_INTERNAL_NONTRIVIAL_DELTA_RESPONSE_OPERATOR_V1",
                    "L2_QCT_SOURCE_TO_TOTAL_GALACTIC_RESPONSE_RULE_V1",
                ],
            ),
        ],
        "reason": "The gate must preserve the exact operator and rule grammar.",
    },
    "allowed_forms_frozen": {
        "expected_state": "materialized",
        "sources": [
            (
                "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"
                "RANK10_CURRENT_MATERIALS_FINAL_COMPRESSION_TO_SINGLE_L2_AUTHORING_TARGET_NOTE_20260608.md",
                [
                    "Form A",
                    "Form B",
                    "Form C",
                    "Form D",
                    "exact_required_author_content = one_of_Form_A_Delta_table_Form_B_Xi_table_Form_C_evaluator_function_Form_D_operator_engine",
                ],
            ),
            (
                "artifacts/debt_board_20260530/"
                "L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/02_LOCKS/ALLOWED_AUTHORING_FORMS.md",
                [
                    "Form A",
                    "Form B",
                    "Form C",
                    "Form D",
                ],
            ),
        ],
        "reason": "The gate counts as typed only if the four lawful forms are explicit.",
    },
    "dimensional_no_go_materialized": {
        "expected_state": "materialized",
        "sources": [
            (
                "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"
                "RANK10_CURRENT_MATERIALS_FINAL_COMPRESSION_TO_SINGLE_L2_AUTHORING_TARGET_NOTE_20260608.md",
                [
                    "log10_gobs_QCT(x) = x + Delta_QCT_L2(x)",
                    "nontrivial_QCT_L2_numeric_kernel_status = not_materialized",
                    "true_closure_L2_numeric_probe_status = blocked",
                ],
            ),
        ],
        "reason": "The gate must preserve why current materials cannot lawfully fake the missing kernel.",
    },
    "forbidden_authoring_ledger_materialized": {
        "expected_state": "materialized",
        "sources": [
            (
                "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"
                "RANK10_CURRENT_MATERIALS_FINAL_COMPRESSION_TO_SINGLE_L2_AUTHORING_TARGET_NOTE_20260608.md",
                [
                    "empirical `RAR` fit",
                    "`MOND` interpolation",
                    "`SPARC` observed `gobs` as prediction",
                    "full cosmology claim",
                ],
            ),
            (
                "artifacts/debt_board_20260530/"
                "L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/02_LOCKS/FORBIDDEN_AUTHORING_LEDGER.md",
                [
                    "empirical `RAR` fit",
                    "`MOND` interpolation",
                    "`SPARC` observed `gobs` as prediction",
                    "full cosmology claims",
                ],
            ),
        ],
        "reason": "The anti-shortcut grammar must remain explicit and packet-visible.",
    },
    "reopen_condition_materialized": {
        "expected_state": "materialized",
        "sources": [
            (
                "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"
                "RANK10_CURRENT_MATERIALS_FINAL_COMPRESSION_TO_SINGLE_L2_AUTHORING_TARGET_NOTE_20260608.md",
                [
                    "reopen_allowed_if = one_lawful_Form_A_B_C_or_D_package_materialized",
                    "reopen_forbidden_if = empirical_RAR_fit_or_MOND_or_SPARK_tuning_or_fit_or_likelihood",
                ],
            ),
            (
                "artifacts/debt_board_20260530/"
                "L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/02_LOCKS/REOPEN_CONDITION.md",
                [
                    "reopen_allowed_if = one_lawful_Form_A_B_C_or_D_package_materialized",
                    "reopen_forbidden_if = empirical_RAR_fit_or_MOND_or_SPARK_tuning_or_fit_or_likelihood",
                ],
            ),
        ],
        "reason": "The restart rule must remain exact rather than discretionary.",
    },
    "dual_gate_distinction_materialized": {
        "expected_state": "materialized",
        "sources": [
            (
                "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"
                "RANK10_L2_DUAL_GATE_TOPOLOGY_EMPIRICAL_PAYLOAD_GATE_VERSUS_NUMERIC_KERNEL_AUTHORING_GATE_NOTE_20260608.md",
                [
                    "machine-readable baryonic component curves",
                    "lawful source-governed nontrivial `QCT` numeric response",
                    "not interchangeable",
                ],
            ),
            (
                "artifacts/debt_board_20260530/"
                "L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/02_LOCKS/DUAL_GATE_BOUNDARY.md",
                [
                    "machine-readable baryonic component curves and uncertainties",
                    "lawful source-governed nontrivial `QCT` numeric response",
                    "not identical",
                ],
            ),
        ],
        "reason": "The internal theory gate must stay distinct from the external payload gate.",
    },
    "observed_crossing_claimed": {
        "expected_state": "not_claimed",
        "sources": [
            (
                "artifacts/debt_board_20260530/"
                "L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/01_BACKBONE/MANUSCRIPT.md",
                [
                    "does **not** claim",
                    "observed-row crossing already happened",
                ],
            ),
        ],
        "reason": "This object must not fake an L0 crossing.",
    },
    "fit_or_likelihood_claimed": {
        "expected_state": "not_claimed",
        "sources": [
            (
                "artifacts/debt_board_20260530/"
                "L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/01_BACKBONE/MANUSCRIPT.md",
                [
                    "does **not** claim",
                    "likelihood or fit already opened",
                ],
            ),
        ],
        "reason": "This object must not fake fit or likelihood opening.",
    },
    "full_cosmology_closure_claimed": {
        "expected_state": "not_claimed",
        "sources": [
            (
                "artifacts/debt_board_20260530/"
                "L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/01_BACKBONE/MANUSCRIPT.md",
                [
                    "does **not** claim",
                    "full cosmology closure already exists",
                ],
            ),
        ],
        "reason": "This object must keep full cosmology closure explicitly unclaimed.",
    },
}


def load_text(relative_path: str) -> str:
    candidates: list[Path] = []

    def add(path: Path) -> None:
        if path not in candidates:
            candidates.append(path)

    if RUNNING_FROM_PACKET:
        if relative_path.startswith(PACKET_PREFIX):
            add(PACKET_ROOT / relative_path[len(PACKET_PREFIX) :])
        elif relative_path.startswith(ARTIFACT_PREFIX):
            add(PACKET_ROOT / relative_path[len(ARTIFACT_PREFIX) :])
        else:
            add(PACKET_ROOT / relative_path)

    if WORKSPACE_ROOT is not None:
        add(WORKSPACE_ROOT / relative_path)
        if relative_path.startswith(PACKET_PREFIX):
            add(PACKET_ROOT / relative_path[len(PACKET_PREFIX) :])
        elif relative_path.startswith(ARTIFACT_PREFIX):
            add(PACKET_ROOT / relative_path[len(ARTIFACT_PREFIX) :])

    for path in candidates:
        if path.exists():
            return path.read_text(encoding="utf-8")

    searched = "\n".join(str(path) for path in candidates)
    raise FileNotFoundError(f"could not resolve authoring-gate surface: {relative_path}\n{searched}")


def evaluate_check(name: str, spec: dict[str, object]) -> dict[str, object]:
    evidence = []
    all_found = True
    for relative_path, phrases in spec["sources"]:
        text = load_text(relative_path)
        matched = [phrase for phrase in phrases if phrase in text]
        missing = [phrase for phrase in phrases if phrase not in text]
        if missing:
            all_found = False
        evidence.append(
            {
                "source": relative_path,
                "matched_phrases": matched,
                "missing_phrases": missing,
            }
        )

    expected_state = spec["expected_state"]
    if expected_state == "materialized":
        actual_state = "materialized" if all_found else "broken"
    elif expected_state == "not_claimed":
        actual_state = "not_claimed" if all_found else "broken"
    else:
        raise ValueError(f"Unsupported expected state for {name}: {expected_state}")

    return {
        "name": name,
        "expected_state": expected_state,
        "actual_state": actual_state,
        "pass": actual_state == expected_state,
        "reason": spec["reason"],
        "evidence": evidence,
    }


def build_report(results: list[dict[str, object]]) -> str:
    lines = [
        "# Authoring Gate Report",
        "",
        "Date: `2026-06-10`",
        "",
        "Status: `reproduced from packet-native surfaces`",
        "",
        "## Summary",
        "",
    ]

    passed = [result for result in results if result["pass"]]
    failed = [result for result in results if not result["pass"]]
    lines.append(f"- passed checks: `{len(passed)}`")
    lines.append(f"- failed checks: `{len(failed)}`")
    lines.append("")
    lines.append("## Check table")
    lines.append("")

    for result in results:
        marker = "PASS" if result["pass"] else "FAIL"
        lines.append(
            f"- `{result['name']}`: `{marker}` "
            f"(`expected={result['expected_state']}`, "
            f"`actual={result['actual_state']}`)"
        )
        lines.append(f"  reason: {result['reason']}")

    lines.extend(
        [
            "",
            "## Bounded verdict",
            "",
            "- one reviewer-facing internal G4 authoring-gate object is "
            "materialized if all authoring-gate checks pass and the non-claim "
            "ceiling remains explicit",
            "- this is real progress because the remaining internal L2 theory "
            "gate is now typed, fenced, and restart-governed",
            "- this is not an observed-row crossing, not fit, not likelihood, "
            "and not full cosmology closure",
            "",
        ]
    )

    if failed:
        lines.append("## Failing surfaces")
        lines.append("")
        for result in failed:
            lines.append(f"- `{result['name']}`")
        lines.append("")

    return "\n".join(lines) + "\n"


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    results = [evaluate_check(name, spec) for name, spec in CHECKS.items()]
    object_materialized = all(result["pass"] for result in results)

    status_summary = {
        "date": "2026-06-10",
        "object": "L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1",
        "authoring_gate_object_materialized": object_materialized,
        "checks": results,
    }

    verdict = {
        "date": "2026-06-10",
        "object": "L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1",
        "authoring_gate_object_materialized": object_materialized,
        "single_authoring_target_materialized": next(
            result["pass"]
            for result in results
            if result["name"] == "single_authoring_target_materialized"
        ),
        "allowed_forms_frozen": next(
            result["pass"] for result in results if result["name"] == "allowed_forms_frozen"
        ),
        "forbidden_authoring_ledger_materialized": next(
            result["pass"]
            for result in results
            if result["name"] == "forbidden_authoring_ledger_materialized"
        ),
        "dual_gate_distinction_materialized": next(
            result["pass"]
            for result in results
            if result["name"] == "dual_gate_distinction_materialized"
        ),
        "observed_crossing_claimed": False,
        "fit_or_likelihood_claimed": False,
        "full_cosmology_closure_claimed": False,
    }

    (OUTPUT_ROOT / "status_summary.json").write_text(
        json.dumps(status_summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUT_ROOT / "verdict.json").write_text(
        json.dumps(verdict, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUT_ROOT / "AUTHORING_GATE_REPORT.md").write_text(
        build_report(results),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
