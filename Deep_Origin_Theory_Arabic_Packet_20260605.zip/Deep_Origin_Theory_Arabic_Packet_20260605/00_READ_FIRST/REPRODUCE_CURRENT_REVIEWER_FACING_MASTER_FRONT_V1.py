#!/usr/bin/env python3
import json
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

NGC0247_CURRENT_STACK_SCRIPT = HERE / "REPRODUCE_NGC0247_CURRENT_STACK_V1.py"
NGC6946_FIXED_QUMOND_SUMMARY_SCRIPT = HERE / "REPRODUCE_NGC6946_FIXED_QUMOND_SUMMARY_V1.py"

NGC0247_PARITY_READY_PILOT_OBJECT_PATH = HERE / "NGC0247_PARITY_READY_PILOT_OBJECT_V1.json"
NGC0247_MATCHED_NUISANCE_POLICY_LOCK_PATH = HERE / "NGC0247_MATCHED_NUISANCE_POLICY_LOCK_V1.json"
NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_PATH = (
    HERE / "NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_V1.json"
)
NGC0247_EXECUTED_PARITY_WITNESS_PROMOTION_BOUNDARY_PATH = (
    HERE / "NGC0247_EXECUTED_PARITY_WITNESS_PROMOTION_BOUNDARY_V1.json"
)
NGC0247_EXECUTED_PARITY_WITNESS_OUTWARD_SCORING_SHELL_PATH = (
    HERE / "NGC0247_EXECUTED_PARITY_WITNESS_OUTWARD_SCORING_SHELL_V1.json"
)
CURRENT_FULL_HEAD_CONCENTRATED_BUT_NONTERMINAL_BOUNDARY_PATH = (
    HERE / "CURRENT_FULL_HEAD_CONCENTRATED_BUT_NONTERMINAL_BOUNDARY_V1.json"
)
CURRENT_FULL_HEAD_SAME_OBSERVABLE_CEILING_AND_CROSS_OBSERVABLE_ESCALATION_PATH = (
    HERE / "CURRENT_FULL_HEAD_SAME_OBSERVABLE_CEILING_AND_CROSS_OBSERVABLE_ESCALATION_V1.json"
)
NO_MAKEUP_MOND_QUMOND_CROSS_OBSERVABLE_COURT_SCOPE_SELECTION_PATH = (
    HERE / "NO_MAKEUP_MOND_QUMOND_CROSS_OBSERVABLE_COURT_SCOPE_SELECTION_V1.json"
)
EMPIRICAL_TENSION_PATH = (
    HERE / "CURRENT_REVIEWER_FACING_ROUTE_SPLIT_AND_FULL_BODY_EMPIRICAL_TENSION_V1.json"
)


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def run_json_script(script_path: Path):
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(
        [sys.executable, str(script_path)],
        cwd=str(HERE),
        check=True,
        capture_output=True,
        text=True,
        env=env,
    )
    return json.loads(result.stdout)


def main():
    ngc0247_current = run_json_script(NGC0247_CURRENT_STACK_SCRIPT)
    ngc6946_fixed = run_json_script(NGC6946_FIXED_QUMOND_SUMMARY_SCRIPT)

    pilot = load_json(NGC0247_PARITY_READY_PILOT_OBJECT_PATH)
    policy_lock = load_json(NGC0247_MATCHED_NUISANCE_POLICY_LOCK_PATH)
    lawful_window = load_json(NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_PATH)
    promotion_boundary = load_json(NGC0247_EXECUTED_PARITY_WITNESS_PROMOTION_BOUNDARY_PATH)
    outward_shell = load_json(NGC0247_EXECUTED_PARITY_WITNESS_OUTWARD_SCORING_SHELL_PATH)
    nonterminal_boundary = load_json(CURRENT_FULL_HEAD_CONCENTRATED_BUT_NONTERMINAL_BOUNDARY_PATH)
    ceiling_bridge = load_json(
        CURRENT_FULL_HEAD_SAME_OBSERVABLE_CEILING_AND_CROSS_OBSERVABLE_ESCALATION_PATH
    )
    next_scope = load_json(NO_MAKEUP_MOND_QUMOND_CROSS_OBSERVABLE_COURT_SCOPE_SELECTION_PATH)
    empirical_tension = load_json(EMPIRICAL_TENSION_PATH)

    consistency_checks = {
        "two_named_witnesses_are_now_explicit": (
            ngc0247_current["row_count"] == 26 and ngc6946_fixed["row_count"] == 58
        ),
        "both_named_witnesses_keep_all_fixed_qumond_residuals_negative": (
            ngc0247_current["all_QUMOND_residuals_negative"]
            and ngc6946_fixed["all_QUMOND_residuals_negative"]
        ),
        "ngc0247_pilot_object_is_materialized": pilot["pilot_object_materialized"],
        "ngc0247_policy_lock_is_closed": policy_lock["policy_lock_closed"],
        "ngc0247_lawful_window_shows_no_rescue": not lawful_window["rescue_seen_within_1sigma_box"],
        "ngc0247_live_parity_witness_is_pro_qct": promotion_boundary["live_matched_nuisance_witness"][
            "live_witness_is_pro_qct_on_all_visible_parity_surfaces"
        ],
        "ngc0247_outward_headline_is_pro_qct": (
            outward_shell["headline_live_parity_score"]["delta_aic_total"] < 0.0
        ),
        "ngc0247_hardening_companion_strengthens_the_same_direction": (
            outward_shell["hardening_companion"]["delta_aic_total"]
            < outward_shell["headline_live_parity_score"]["delta_aic_total"]
        ),
        "present_full_head_is_concentrated": nonterminal_boundary["concentration_surface"][
            "structured_pair_fraction_of_full_head_public_delta_aic_total"
        ]
        > 0.88,
        "present_full_head_is_explicitly_nonterminal": nonterminal_boundary["consistency_checks"][
            "terminal_full_head_closure_is_not_admissible_now"
        ],
        "next_scope_is_already_selected": ceiling_bridge["consistency_checks"][
            "selected_scope_is_no_makeup_cross_observable_court"
        ]
        and next_scope["selected_scope"] == "no_makeup_mond_qumond_cross_observable_court",
        "next_scope_still_preserves_same_kernel_no_new_knobs": (
            next_scope["macs1206_secondary_deltasigma"]["same_kernel_only"]
            and next_scope["macs1206_secondary_deltasigma"]["no_new_knobs"]
        ),
        "the_front_now_sits_above_one_explicit_local_route_split_versus_larger_body_tension_surface": (
            empirical_tension["structural_reading"][
                "the_ngc0247_route_split_is_real_but_does_not_erase_the_larger_bodywide_anti_qct_burden"
            ]
            and empirical_tension["structural_reading"][
                "the_larger_bodywide_anti_qct_burden_is_real_but_does_not_erase_the_local_ngc0247_route_split"
            ]
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "packet_contained_reviewer_facing_master_front",
        "surface": "current_reviewer_facing_master_front",
        "four_pillars": [
            "two_named_witnesses",
            "one_executed_live_parity_stack",
            "one_concentrated_but_nonterminal_present_head_reading",
            "one_selected_next_cross_observable_court",
        ],
        "named_witnesses": {
            "combined_visible_row_count": ngc0247_current["row_count"] + ngc6946_fixed["row_count"],
            "combined_delta_true_sign_split": {
                "negative_rows": (
                    ngc0247_current["delta_true_negative_rows"] + ngc6946_fixed["delta_true_negative_rows"]
                ),
                "positive_rows": (
                    ngc0247_current["delta_true_positive_rows"] + ngc6946_fixed["delta_true_positive_rows"]
                ),
            },
            "ngc0247": {
                "witness_role": "executed_live_parity_witness",
                "row_count": ngc0247_current["row_count"],
                "fixed_qumond_lane_chi2_total": ngc0247_current["chi2_total_QUMOND_source_locked"],
                "delta_true_sign_split_label": ngc0247_current["delta_true_sign_split_label"],
                "all_fixed_qumond_residuals_negative": ngc0247_current["all_QUMOND_residuals_negative"],
            },
            "ngc6946": {
                "witness_role": "fixed_public_companion_witness",
                "row_count": ngc6946_fixed["row_count"],
                "fixed_qumond_lane_chi2_total": ngc6946_fixed["chi2_total_QUMOND_source_locked"],
                "delta_true_sign_split_label": ngc6946_fixed["delta_true_sign_split_label"],
                "all_fixed_qumond_residuals_negative": ngc6946_fixed["all_QUMOND_residuals_negative"],
                "guardrail": ngc6946_fixed["guardrail"],
            },
        },
        "executed_live_parity_stack": {
            "pilot_object_materialized": pilot["pilot_object_materialized"],
            "source_policy_lock_closed": policy_lock["policy_lock_closed"],
            "lawful_window_replay_rescue_seen_within_1sigma_box": lawful_window[
                "rescue_seen_within_1sigma_box"
            ],
            "promotion_target_identified": True,
            "headline_live_delta_aic_total": outward_shell["headline_live_parity_score"][
                "delta_aic_total"
            ],
            "hardening_companion_delta_aic_total": outward_shell["hardening_companion"][
                "delta_aic_total"
            ],
            "historical_control_stays_fenced": pilot["historical_same_convention_control"]["verdict"],
            "remaining_open_front": outward_shell["remaining_open_front"],
        },
        "present_full_head_reading": {
            "full_head_case_count": nonterminal_boundary["full_head"]["case_count"],
            "full_head_public_delta_aic_total": nonterminal_boundary["full_head"][
                "public_delta_aic_total"
            ],
            "structured_pair_fraction_of_full_head_public_delta_aic_total": nonterminal_boundary[
                "concentration_surface"
            ]["structured_pair_fraction_of_full_head_public_delta_aic_total"],
            "pocket_fraction_of_full_head_public_delta_aic_total": nonterminal_boundary[
                "concentration_surface"
            ]["pocket_fraction_of_full_head_public_delta_aic_total"],
            "boundary_class": nonterminal_boundary["boundary_surface"]["boundary_class"],
            "terminal_full_head_closure_not_admissible_now": nonterminal_boundary[
                "consistency_checks"
            ]["terminal_full_head_closure_is_not_admissible_now"],
        },
        "selected_next_court": {
            "selected_scope": next_scope["selected_scope"],
            "selected_scope_contains": next_scope["selected_scope_contains"],
            "rotation_fixed_public_qumond_crosscheck_count_with_zero_public_gap": next_scope[
                "rotation_fixed_public_qumond_crosscheck_count_with_zero_public_gap"
            ],
            "same_kernel_macs1206_secondary_deltasigma": next_scope["macs1206_secondary_deltasigma"],
            "next_honest_continuation": next_scope["next_honest_continuation"],
        },
        "structural_reading": {
            "the_packet_now_has_one_single_reviewer_facing_front_surface": True,
            "the_front_starts_from_named_witnesses_not_anonymous_rotation_rhetoric": True,
            "the_front_keeps_executed_parity_distinct_from_fixed_public_companion_support": True,
            "the_front_now_sits_above_one_explicit_local_route_split_beside_one_much_larger_same_sign_hardening_body": True,
            "the_front_ends_at_one_selected_next_cross_observable_court_instead_of_reader_improvisation": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the packet can now open with one single reviewer-facing front rather than forcing the reader to assemble it manually",
            "NGC0247 now carries the executed live parity stack while NGC6946 remains a second named public companion witness",
            "the front is now stabilized by one explicit local NGC0247 route split that remains visible beside the much larger ten-witness same-sign hardening body",
            "the present full head is already concentrated but still explicitly nonterminal",
            "the next honest gain is therefore the selected no-makeup cross-observable court rather than more same-head rhetoric",
        ],
        "not_supported_now": [
            "NGC6946 is already an executed matched-nuisance parity witness",
            "two named witnesses alone already close the whole no-makeup court",
            "the present full head already authorizes terminal whole-head closure language",
            "the selected cross-observable court is already executed or already closed",
            "Whole-family MOND_QUMOND closure",
        ],
    }

    output["verdict"] = (
        "CURRENT_REVIEWER_FACING_MASTER_FRONT_CLOSED__TWO_NAMED_WITNESSES_ONE_EXECUTED_LIVE_PARITY_STACK_ONE_CONCENTRATED_BUT_NONTERMINAL_HEAD_READING_AND_ONE_SELECTED_NEXT_COURT_NOW_FORM_ONE_SINGLE_PACKET_SURFACE"
        if all(consistency_checks.values())
        else "CURRENT_REVIEWER_FACING_MASTER_FRONT_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
