# Current Full-Head All-Quality-`1` Complement vs Mixed Heptad Note

Date: `2026-06-09`

Status: `packet-contained quality-flag counterexample`

Purpose:

After the packet had already shown that one seven-case `O7`-reinforced heptad
outweighs the other seven full-head cases combined, one sharper question
remained:

- could someone still argue that the losing seven-case half is scientifically
  privileged because it is the cleaner quality-`1` side?

No.

Machine-readable companion:

- `CURRENT_FULL_HEAD_ALL_QUALITY1_COMPLEMENT_VS_MIXED_HEPTAD_V1.json`

Reproduction script:

- `REPRODUCE_CURRENT_FULL_HEAD_ALL_QUALITY1_COMPLEMENT_VS_MIXED_HEPTAD_V1.py`

It should be read after:

- `CURRENT_FULL_HEAD_COUNT_BALANCED_BURDEN_ASYMMETRIC_SPLIT_NOTE_20260609.md`

## Short verdict

The current full head contains:

- one all-quality-`1` seven-case complement
- one mixed seven-case `O7`-reinforced heptad

Yet the all-quality-`1` half still loses by public burden.

The all-quality-`1` complement carries:

- `50%` of full-head case count
- `46.29065061884979%` of full-head public burden

The mixed heptad carries:

- `50%` of full-head case count
- `53.70934938115022%` of full-head public burden

So aggregating the quality-`1` side does not overturn the dominant heptad.

## 1. The all-quality-`1` complement

The all-quality-`1` half is:

- the protected clean-anchor quartet:
  `NGC5055`, `NGC3198`, `NGC7331`, `NGC2841`
- plus the localized quality-`1` continuation pocket:
  `NGC2903`, `NGC6674`, `NGC5033`

This is a real quality-`1` half of the current head.

It is not an artifact of dropping cases.

## 2. The mixed heptad

The mixed dominant heptad contains:

- `4` quality-`1` cases:
  `UGC09133`, `UGC06786`, `UGC02487`, `UGC03205`
- `3` quality-`2` cases:
  `UGC02953`, `UGC06787`, `UGC05253`

So the winning heptad is not one pure quality-`1` block.

## 3. Meaning

This gives the packet one especially sharp anti-reduction sentence:

- even one entire all-quality-`1` half of the current full head does not
  control the burden ordering

That is stronger than merely saying:

- quality `1` alone does not settle the split

Now the packet can say:

- even after aggregating one whole seven-case half that is all quality `1`,
  quality label alone still fails to order the current head.

## 4. What this does not authorize

This note does **not** authorize the claims that:

- quality flags are irrelevant
- the current full head is already globally terminally settled
- whole-family `MOND/QUMOND` closure already exists

## Best outward-safe reading

One mature outward-safe sentence is:

> The current full head contains one all-quality-`1` seven-case half and one
> mixed seven-case `O7`-reinforced heptad. Yet the all-quality-`1` half still
> carries less public burden than the mixed heptad. So quality label alone
> cannot rank the present full-head halves.
