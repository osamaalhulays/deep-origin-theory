# Recovered Dated QUMOND Fairness And Sentinel Family Note

Date: `2026-06-06`

This note records one deep-repo recovery that materially narrows two older
criticisms:

- "matched-nuisance / best-dressed comparator fairness was not yet a real
  doctrine,"
- and "the solved-problem / witness surface still rested on too little broader
  multi-galaxy pressure."

The older pre-`Rank 9` record was stronger than that.

## Short verdict

The older public-facing benchmark culture had already preserved:

- identical deterministic data partitions,
- identical nuisance-prior treatment,
- a locked fixed `QUMOND` baseline,
- an obs-only official model-selection comparator,
- a locked nuisance-prior width,
- a six-case sentinel core,
- and a recurring named multiseed pressure panel broader than one or two named
  galaxies alone.

That does **not** mean the current packet has already executed every later
comparator lane in final public form.

It **does** mean the fair criticism is now narrower:

- later execution completeness still remains,
- but comparator-fairness doctrine and broader family stress were already
  materially present in the older record.

## 1. Historical fairness doctrine was already real

The older benchmark surfaces already preserved a reviewer-hard fairness grammar.

Across the recovered pre-`Rank 9` surfaces, the record already fixed:

- identical deterministic `k`-fold partitions for both sides,
- identical baryonic nuisance-prior treatment,
- fixed `a0 = 1.2 x 10^-10 m/s^2`,
- locked `simple nu(y)` baseline,
- transparent `k_free` versus `k_total` counting,
- and one official obs-only `AIC/BIC` comparator for both sides.

The same historical line also later sealed:

- nuisance-prior width = `0.1 dex`,
- multiseed split-variance nomenclature,
- and production benchmarking under audit-clean review rules.

So the older record did not merely hope for comparator fairness.
It had already begun to formalize it.

## 2. Broader family pressure was already visible

The same older layer also preserved a wider multi-galaxy stress memory than a
cold current-packet reading may infer.

The recovered record now makes visible:

- one fixed six-case sentinel core:
  - `NGC6946`
  - `NGC5055`
  - `NGC0247`
  - `NGC5585`
  - `UGC00128`
  - `NGC2998`
- one broader galaxy benchmark layer preserved as `875 = 175 x 5` seeded report
  rows,
- and one recurring named multiseed pressure panel around:
  - `NGC0247`
  - `NGC6946`
  - `UGC11914`

That does not give the current packet a full whole-family verdict.

But it does defeat the weaker reading that the visible line rests only on one
galaxy, one anecdote, or one frozen cosmetic lane with no broader historical
pressure family behind it.

## 3. What this recovery does and does not do

This recovery **does** support the following fair readings:

- comparator fairness was already a governed historical object,
- broader multi-galaxy stress was already materially present,
- and the current packet's three-lane comparator grammar did not appear from
  nowhere.

This recovery does **not** support the stronger claims that:

- all current front-door comparator lanes have already been fully executed,
- the broader `MOND/QUMOND` family verdict is already closed,
- or the original current-production fitted-`Y` closure artifact is already
  publicly preserved for the named present spear.

Those later debts remain real.

## 4. Best fair reading now

The fairest public reading is now:

- the current packet already carries one strong bounded spear,
- one second named witness,
- one explicit three-lane comparator grammar,
- and one recovered older fairness-and-sentinel culture behind them.

So the remaining deduction should no longer say:

- "fair comparator doctrine absent,"
- or "broader family pressure absent."

It should now say something narrower:

- later matched-nuisance / best-dressed execution is still incomplete,
- and broader whole-family closure remains later-stage work.

## 5. Primary recovered older surfaces

See especially:

- `01_A_PreRank9/.../QCT_LINEAGE_AND_APEX_20260218_20260228/QUMOND_COMPARISON_PLAN.md`
- `01_A_PreRank9/.../QCT_LINEAGE_AND_APEX_20260218_20260228/STATS_FINAL_SIGNOFF.md`
- `01_A_PreRank9/.../QCT_LINEAGE_AND_APEX_20260218_20260228/PLAN_PROGRESS_REPORT.md`
- `01_A_PreRank9/.../QCT_LINEAGE_AND_APEX_20260218_20260228/QUMOND_BENCHMARK_HONESTY_NOTE.md`
- `01_A_PreRank9/.../MOND_AND_DARK_MATTER_KEY_RESULTS_NOTE.md`
- `01_A_PreRank9/.../WHAT_HAS_ALREADY_BEEN_ACHIEVED_BEFORE_RANK9.md`
