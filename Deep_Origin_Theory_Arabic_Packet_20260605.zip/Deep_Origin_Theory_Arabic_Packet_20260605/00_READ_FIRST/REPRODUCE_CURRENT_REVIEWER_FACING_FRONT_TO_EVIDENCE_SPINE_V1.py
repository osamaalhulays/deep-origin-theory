#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

MASTER_FRONT_PATH = HERE / "CURRENT_REVIEWER_FACING_MASTER_FRONT_V1.json"
FULL_HEAD_BOUNDARY_PATH = HERE / "CURRENT_FULL_HEAD_CONCENTRATED_BUT_NONTERMINAL_BOUNDARY_V1.json"
FULL_HEAD_ESCALATION_PATH = (
    HERE / "CURRENT_FULL_HEAD_SAME_OBSERVABLE_CEILING_AND_CROSS_OBSERVABLE_ESCALATION_V1.json"
)
COURT_STATE_ASCENT_PATH = (
    HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_STATE_AND_ASCENT_SYNTHESIS_V1.json"
)
COURT_LAUNCH_FRONT_PATH = HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LAUNCH_FRONT_V1.json"
COURT_LANE_BOARD_PATH = (
    HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_STATUS_BOARD_V1.json"
)
COURT_LANE_LADDER_PATH = (
    HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_PROGRESSION_LADDER_V1.json"
)
PARITY_PROMOTION_PATH = HERE / "NGC0247_EXECUTED_PARITY_WITNESS_PROMOTION_BOUNDARY_V1.json"
MATCHED_PARTITION_PATH = HERE / "NAMED_EXECUTED_MATCHED_NUISANCE_COURT_MORPHOLOGY_PARTITION_V1.json"
HUBBLE_FLOW_CLOSURE_PATH = HERE / "HUBBLE_FLOW_SENSITIVE_BODY_FULL_CLOSURE_V1.json"
O7_REINFLATION_PATH = HERE / "O7_REINFLATION_MICROFRONT_AFTER_NEAR_NEUTRAL_PERSISTENCE_V1.json"
EMPIRICAL_TENSION_PATH = (
    HERE / "CURRENT_REVIEWER_FACING_ROUTE_SPLIT_AND_FULL_BODY_EMPIRICAL_TENSION_V1.json"
)
POCKET_BOUNDARY_PATH = (
    HERE / "CURRENT_REVIEWER_FACING_NARROW_QUALITY1_CONTINUATION_POCKET_BOUNDARY_V1.json"
)


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    master_front = load_json(MASTER_FRONT_PATH)
    full_head_boundary = load_json(FULL_HEAD_BOUNDARY_PATH)
    full_head_escalation = load_json(FULL_HEAD_ESCALATION_PATH)
    court_state_ascent = load_json(COURT_STATE_ASCENT_PATH)
    court_launch_front = load_json(COURT_LAUNCH_FRONT_PATH)
    court_lane_board = load_json(COURT_LANE_BOARD_PATH)
    court_lane_ladder = load_json(COURT_LANE_LADDER_PATH)
    parity_promotion = load_json(PARITY_PROMOTION_PATH)
    matched_partition = load_json(MATCHED_PARTITION_PATH)
    hubble_flow_closure = load_json(HUBBLE_FLOW_CLOSURE_PATH)
    o7_reinflation = load_json(O7_REINFLATION_PATH)
    empirical_tension = load_json(EMPIRICAL_TENSION_PATH)
    pocket_boundary = load_json(POCKET_BOUNDARY_PATH)

    selected_scope = court_state_ascent["governing_court"]["selected_scope"]

    packet_front_entry = {
        "step_role": "name_the_live_front_before_opening_deeper_evidence",
        "primary_surface": "CURRENT_REVIEWER_FACING_MASTER_FRONT_V1.json",
        "question_answered": "what_is_the_single_packet_front_the_reviewer_should_start_from",
        "what_the_reviewer_learns": [
            "NGC0247 is the executed live parity witness",
            "NGC6946 is the fixed-public companion witness",
            "the present full head is concentrated but nonterminal",
            "the next honest gain is the selected no-makeup cross-observable court",
        ],
        "handoff_condition": (
            "once_the_reader_accepts_that_the_front_honestly_ends_at_one_selected_court_the_next_"
            "question_is_why_that_court_is_the_right_descent_target"
        ),
    }

    full_head_to_court_reason = {
        "step_role": "show_why_the_packet_must_leave_same_observable_rhetoric_and_enter_the_selected_court",
        "primary_surfaces": [
            "CURRENT_FULL_HEAD_CONCENTRATED_BUT_NONTERMINAL_BOUNDARY_V1.json",
            "CURRENT_FULL_HEAD_SAME_OBSERVABLE_CEILING_AND_CROSS_OBSERVABLE_ESCALATION_V1.json",
        ],
        "question_answered": "why_is_the_selected_cross_observable_court_the_next_honest_move",
        "what_the_reviewer_learns": [
            "the present full head is already strongly concentrated",
            "that concentration is still explicitly nonterminal",
            "the next highest-leverage move is therefore cross-observable escalation not more same-head rhetoric",
        ],
        "key_numeric_anchors": {
            "structured_pair_fraction_of_full_head_public_delta_aic_total": (
                full_head_boundary["concentration_surface"][
                    "structured_pair_fraction_of_full_head_public_delta_aic_total"
                ]
            ),
            "pocket_fraction_of_full_head_public_delta_aic_total": (
                full_head_boundary["concentration_surface"][
                    "pocket_fraction_of_full_head_public_delta_aic_total"
                ]
            ),
            "rotation_fixed_public_qumond_crosscheck_count_with_zero_public_gap": (
                full_head_escalation["selected_next_scope"][
                    "rotation_fixed_public_qumond_crosscheck_count_with_zero_public_gap"
                ]
            ),
        },
        "handoff_condition": (
            "once_the_reader_accepts_that_cross_observable_escalation_is_required_the_next_"
            "question_is_how_the_selected_court_should_be_read_as_one_object"
        ),
    }

    court_object_entry = {
        "step_role": "enter_the_selected_court_as_one_present_state_plus_governed_ascent_object",
        "primary_surfaces": [
            "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_STATE_AND_ASCENT_SYNTHESIS_V1.json",
            "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LAUNCH_FRONT_V1.json",
            "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_STATUS_BOARD_V1.json",
            "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_PROGRESSION_LADDER_V1.json",
        ],
        "question_answered": "how_should_the_selected_court_be_read_before_descending_into_lane_evidence",
        "what_the_reviewer_learns": [
            "the court is already packet-facing and launchable",
            "the court has one lane state board and one lane ascent ladder",
            "lane distinctions remain preserved at both state and ascent levels",
        ],
        "court_lanes": court_state_ascent["governing_court"]["court_lanes"],
        "handoff_condition": (
            "once_the_reader_accepts_the_selected_court_as_one_object_the_next_question_is_which_"
            "exact_evidence_bundle_to_open_for_each_live_side"
        ),
    }

    rotation_evidence_bundle = {
        "step_role": "open_the_rotation_evidence_without_collapsing_matched_nuisance_and_best_dressed",
        "subbundles": {
            "matched_nuisance_parity_evidence": {
                "primary_surfaces": [
                    "NGC0247_EXECUTED_PARITY_WITNESS_PROMOTION_BOUNDARY_V1.json",
                    "NAMED_EXECUTED_MATCHED_NUISANCE_COURT_MORPHOLOGY_PARTITION_V1.json",
                    "CURRENT_REVIEWER_FACING_ROUTE_SPLIT_AND_FULL_BODY_EMPIRICAL_TENSION_V1.json",
                ],
                "claims_tested": [
                    "NGC0247 is a real packet-contained executed parity witness",
                    "NGC0247 is the only named pro-QCT route-split witness",
                    "NGC6946 is the only named same-sign softening witness",
                    "the ten-witness hardening body remains visible beside both exceptions",
                    "the local NGC0247 route split must still be carried beside the much larger ten-witness same-sign hardening body",
                ],
                "key_numeric_anchors": {
                    "ngc0247_public_delta_aic_total": parity_promotion[
                        "live_matched_nuisance_witness"
                    ]["public_delta_aic_total"],
                    "ngc0247_faithful_delta_aic_total": parity_promotion[
                        "live_matched_nuisance_witness"
                    ]["faithful_delta_aic_total"],
                    "ngc0247_component_aware_delta_aic_total": parity_promotion[
                        "live_matched_nuisance_witness"
                    ]["component_aware_delta_aic_total"],
                    "ngc0247_release_side_delta_aic_total": empirical_tension[
                        "local_route_split_witness"
                    ]["release_side_best_dressed_return"]["option2_minimal_delta_aic_total"],
                    "named_executed_witness_count": matched_partition[
                        "named_executed_witness_count"
                    ],
                    "ten_witness_public_delta_aic_total": empirical_tension[
                        "ten_witness_hardening_body"
                    ]["combined_burden"]["public_delta_aic_total"],
                },
            },
            "best_dressed_hardening_evidence": {
                "primary_surfaces": [
                    "HUBBLE_FLOW_SENSITIVE_BODY_FULL_CLOSURE_V1.json",
                    "O7_REINFLATION_MICROFRONT_AFTER_NEAR_NEUTRAL_PERSISTENCE_V1.json",
                    "CURRENT_REVIEWER_FACING_NARROW_QUALITY1_CONTINUATION_POCKET_BOUNDARY_V1.json",
                ],
                "claims_tested": [
                    "the ten-witness Hubble-flow-sensitive body is already closed as a governed block",
                    "the body remains anti-QCT under component-aware replay",
                    "the live frontier has narrowed to one exact D72 reinflation opening batch",
                    "the current three-case nonoverlap remains one narrow continuation pocket rather than one silently absorbed fresh exact O7 block",
                ],
                "key_numeric_anchors": {
                    "ten_witness_public_delta_aic_total": hubble_flow_closure[
                        "combined_burden"
                    ]["public_delta_aic_total"],
                    "ten_witness_faithful_delta_aic_total": hubble_flow_closure[
                        "combined_burden"
                    ]["faithful_delta_aic_total"],
                    "ten_witness_component_aware_delta_aic_total": hubble_flow_closure[
                        "combined_burden"
                    ]["component_aware_delta_aic_total"],
                    "current_three_case_pocket_public_delta_aic_total": pocket_boundary[
                        "current_pocket"
                    ]["public_delta_aic_total"],
                    "current_three_case_pocket_fraction_of_body_public_delta_aic_total": (
                        pocket_boundary["current_pocket"][
                            "fraction_of_hubble_flow_sensitive_body_public_delta_aic_total"
                        ]
                    ),
                    "selected_next_batch": [
                        case["case_id"]
                        for case in o7_reinflation["reinflation_microfront"]["selected_next_batch"]
                    ],
                },
            },
        },
        "handoff_condition": (
            "once_the_reader_accepts_that_the_rotation_side_has_two_distinct_live_evidence_bundles_"
            "the_next_question_is_how_the_north_rail_is_supported_without_false_closure"
        ),
    }

    north_evidence_bundle = {
        "step_role": "open_the_same_kernel_north_rail_evidence_under_the_preserved_authority_gate",
        "primary_surfaces": [
            "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LAUNCH_FRONT_V1.json",
            "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_PROGRESSION_LADDER_V1.json",
        ],
        "deeper_shelf_c_anchor": [
            "03_C_Cluster/Deep_Origin_Theory_C_Cluster_Dossier_20260605.zip",
            "AUTHORITY_GATED_FRONTS_NOTE__MACS1206_AND_L2_20260606.md",
        ],
        "question_answered": "how_is_the_north_rail_real_and_launchable_without_being_falsely_promoted_to_north_closure",
        "what_the_reviewer_learns": [
            "the MACS1206 rail is same-kernel only and uses no new knobs",
            "the rail already carries a visible bounded runtime package candidate",
            "the next honest north move is Route A then Route B then Route C under an openly preserved authority gate",
        ],
        "key_numeric_anchors": {
            "shared_overlap_mid_bin_count": court_launch_front["north_rail"][
                "shared_overlap_mid_bin_count"
            ],
            "best_visible_member_pte": court_launch_front["north_rail"][
                "best_visible_member_pte"
            ],
            "route_a_priority": court_lane_ladder["lane_progression_ladder"][
                "same_kernel_macs1206_secondary_deltasigma_rail"
            ]["route_progression_order"]["route_a"]["priority"],
        },
    }

    consistency_checks = {
        "master_front_still_selects_the_same_court": (
            master_front["selected_next_court"]["selected_scope"] == selected_scope
        ),
        "full_head_escalation_still_points_to_the_same_court": (
            full_head_escalation["selected_next_scope"]["selected_scope"] == selected_scope
        ),
        "court_object_still_carries_the_same_four_lanes": (
            court_state_ascent["governing_court"]["court_lanes"]
            == court_lane_board["board_sequence"]
            == court_lane_ladder["ladder_sequence"]
        ),
        "matched_nuisance_evidence_still_has_ngc0247_as_the_only_named_route_split_witness": (
            parity_promotion["witness"] == "SPARC_NGC0247"
            and matched_partition["structural_partition"]["only_named_pro_qct_route_split_witness"]
            == "SPARC_NGC0247"
        ),
        "best_dressed_evidence_still_has_a_closed_ten_witness_body_and_live_d72_frontier": (
            hubble_flow_closure["uniform_direction"][
                "hubble_flow_sensitive_body_is_now_closed_as_a_governed_block"
            ]
            and o7_reinflation["current_reading"][
                "o7_live_wound_is_now_reinflation_growth_question"
            ]
            and not o7_reinflation["current_reading"]["d72_batch_already_completed"]
        ),
        "latest_rotation_tension_digest_is_now_inside_the_rotation_descent": (
            "CURRENT_REVIEWER_FACING_ROUTE_SPLIT_AND_FULL_BODY_EMPIRICAL_TENSION_V1.json"
            in rotation_evidence_bundle["subbundles"]["matched_nuisance_parity_evidence"][
                "primary_surfaces"
            ]
            and empirical_tension["structural_reading"][
                "the_packet_now_carries_one_compressed_surface_linking_the_local_ngc0247_route_split_to_the_much_larger_ten_witness_same_sign_body"
            ]
        ),
        "latest_three_case_pocket_boundary_digest_is_now_inside_the_rotation_descent": (
            "CURRENT_REVIEWER_FACING_NARROW_QUALITY1_CONTINUATION_POCKET_BOUNDARY_V1.json"
            in rotation_evidence_bundle["subbundles"]["best_dressed_hardening_evidence"][
                "primary_surfaces"
            ]
            and pocket_boundary["boundary_reading"][
                "the_packet_does_not_yet_authorize_renaming_this_pocket_as_one_fresh_exact_three_witness_o7_block"
            ]
        ),
        "north_evidence_still_remains_same_kernel_and_authority_gated": (
            court_launch_front["north_rail"]["same_kernel_only"]
            and court_launch_front["north_rail"]["no_new_knobs"]
            and court_lane_ladder["lane_progression_ladder"][
                "same_kernel_macs1206_secondary_deltasigma_rail"
            ]["route_progression_order"]["route_a"]["priority"]
            == "first"
        ),
        "front_to_court_handoff_remains_nonterminal": (
            full_head_boundary["structural_reading"][
                "that_concentration_is_real_but_not_yet_terminal"
            ]
            and full_head_escalation["structural_reading"][
                "the_next_honest_gain_is_not_more_same_head_rhetoric_but_cross_observable_escalation"
            ]
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "packet_contained_reviewer_facing_front_to_evidence_spine",
        "surface": "current_reviewer_facing_front_to_evidence_spine",
        "spine_sequence": [
            "packet_front_entry",
            "full_head_to_court_reason",
            "court_object_entry",
            "rotation_evidence_bundle",
            "north_evidence_bundle",
        ],
        "reviewer_facing_front_to_evidence_spine": {
            "packet_front_entry": packet_front_entry,
            "full_head_to_court_reason": full_head_to_court_reason,
            "court_object_entry": court_object_entry,
            "rotation_evidence_bundle": rotation_evidence_bundle,
            "north_evidence_bundle": north_evidence_bundle,
        },
        "structural_reading": {
            "the_packet_now_has_one_short_front_to_evidence_descent_route": True,
            "the_selected_court_now_has_one_reader_facing_evidence_spine_from_front_selection_to_lane_specific_support": True,
            "rotation_and_north_evidence_no_longer_need_to_be_discovered_by_reader_improvisation": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the packet now has one reviewer-facing front-to-evidence spine instead of one loose collection of front-door and deep-evidence notes",
            "the reader can now descend from the packet front into the selected court and then into exact rotation and north evidence bundles without collapsing claim boundaries",
            "the rotation side now has one explicit split between matched-nuisance and best-dressed evidence bundles inside the same court-level reading",
            "the rotation descent now also carries the packet-contained NGC0247 route-split versus ten-witness body tension digest and the packet-contained three-case pocket boundary digest",
            "the north rail now has one explicit evidence descent under the preserved same-kernel and authority-gated grammar",
        ],
        "not_supported_now": [
            "one single evidence bundle already settles the whole selected court",
            "rotation and north evidence may be merged into one undifferentiated proof block",
            "the selected court is already fully executed",
            "the north rail is already authority-closed",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_continuation": [
            "use_the_spine_as_the_default_reviewer_entry_before_opening_deeper_axis_specific_surfaces",
            "keep_rotation_and_north_evidence_descents_distinct_below_the_same_selected_court",
        ],
    }

    output["verdict"] = (
        "CURRENT_REVIEWER_FACING_FRONT_TO_EVIDENCE_SPINE_CLOSED__THE_PACKET_NOW_HAS_ONE_SHORT_REVIEWER_FACING_DESCENT_FROM_FRONT_SELECTION_TO_SELECTED_COURT_OBJECT_AND_THEN_TO_EXACT_ROTATION_AND_NORTH_EVIDENCE_BUNDLES"
        if all(consistency_checks.values())
        else "CURRENT_REVIEWER_FACING_FRONT_TO_EVIDENCE_SPINE_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
