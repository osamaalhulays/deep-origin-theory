# Comparator Fairness And Claim-Boundary Crosswalk

Date: `2026-06-06`

This crosswalk exists to stop one recurring blur:

- moving between fixed-comparator pressure,
- current bounded reconstruction,
- historical fitted strength,
- and future fairness-complete execution

as if they already belonged to one collapsed scientific score.

They do not.

## Crosswalk

| Lane | Object class | Nuisance grammar | Main purpose | What it may support now | What it may not support now | Authority ceiling |
| --- | --- | --- | --- | --- | --- | --- |
| `A` | fixed source-locked comparator | none | raw differential pressure | bounded named witness language; visible overshoot; reviewer-auditable strict stress | whole-family `MOND/QUMOND` defeat; fairness-complete verdict | bounded witness ceiling |
| `B` | current bounded reconstructed comparator | one recovered bounded nuisance on the visible current route | present row-level visibility for the named current line | current bounded improvement language for the same named case | equivalence with historical best-fit lane; broad comparative victory | bounded reconstructed current ceiling |
| `C` | historical fitted benchmark replay | historical fitted nuisance from preserved benchmark replay | preserve honesty about a strong historical fitted lane | historical-lane numerical strength in its own narrower grammar | present public fairness standard; universal comparator verdict | historical replay ceiling |
| `D` | matched-nuisance parity comparator | symmetric lawful nuisance freedoms for both sides | fairness parity | later rule-bound statement about what survives under equal nuisance budget | silent theory rescue; post-hoc beautification | later parity-execution ceiling |
| `E` | best-dressed adversarial comparator | literature-faithful best-form adversary under declared rules | strongest later external stress | later statement that a witness survives even under the opponent's best lawful practical presentation | hidden rescue; unauditable cosmetics; automatic total closure | later adversarial-execution ceiling |

## Governing rules

### 1. Cross-lane collapse is forbidden

The packet should not move between these lanes as if they were one
undifferentiated comparator result.

### 2. Stronger later lanes do not erase stricter earlier lanes

If later parity or adversarial lanes are executed,
they should extend the suite.
They should not rewrite what the strict lane originally proved.

### 3. Historical fitted strength is a preserved honesty lane

The fitted replay lane remains valuable because it prevents selective memory.

But it is not the same thing as:

- the fixed public comparator lane,
- the current bounded reconstructed lane,
- or a future matched-nuisance fairness lane.

### 4. Comparator fairness is allowed; theory rescue is not

The lawful expansion rule is:

- nuisance parity allowed
- theory rescue forbidden

That keeps later fairness work coherent with the packet's current
anti-drift discipline.

## Best short outward-safe reading

The packet's comparator culture is strongest when read through a governed
crosswalk:

- fixed pressure,
- bounded current reconstruction,
- preserved historical fitted replay,
- later matched-nuisance parity,
- and later best-dressed adversarial execution

are related lanes,
not interchangeable slogans.
