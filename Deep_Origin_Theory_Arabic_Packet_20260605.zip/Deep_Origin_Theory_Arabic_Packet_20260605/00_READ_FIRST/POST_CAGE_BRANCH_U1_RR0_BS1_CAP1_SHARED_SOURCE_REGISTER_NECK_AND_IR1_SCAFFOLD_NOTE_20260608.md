# Post-Cage Branch U1 RR0+BS1 CAP1 Shared-Source Register Neck And IR1 Scaffold Note

Date: `2026-06-08`

Status: `next exact attack after CAP1 compression`

## Purpose

This note attacks the next layer under the compressed authority burden
`CAP1`.

After:

- `RR0 + BS1` survival,
- post-divergence tooth classification,
- and coefficient-burden compression to
  `CAP1 = {A_Q, M_Q, J_lin, W_src, w_lin}`,

the next exact question is:

- should the route now freeze five heads separately,
  or is there one sharper shared neck beneath them first

## Short verdict

The shared neck comes first.

The exact next internal tooth is best read as:

`source_quality_shared_source_register_binding_for_CAP1_absent`

not yet:

- `A_Q` freeze alone
- `M_Q` freeze alone
- `J_lin` freeze alone
- `W_src` freeze alone
- or `w_lin` freeze alone

The minimum admissible next scaffold is therefore:

`I_src^(IR1)[g,ψ] = (I_amp[g,ψ], I_mix[g,ψ], I_geo[g,ψ])`

with:

1. `I_amp` = source-amplitude register
2. `I_mix` = bounded source-mixture register
3. `I_geo` = geometry-response moderation register

So the best current sovereign reading is:

`CAP1 does not yet ask for five unrelated coefficient miracles; it first asks for one shared source register neck, and the smallest admissible scaffold for that neck is IR1.`

## 1. Why the shared neck comes before headwise freeze

The new `CAP1` note already fixed the decisive rule:

- all five live heads must be governed through one shared source-quality
  dependence class

That means the next honest blocker is not:

- "find five formulas somehow"

It is first:

- "bind the five heads to one lawful same-source register"

This follows the same discipline that appeared elsewhere in the repo:

1. shared same-source binding neck precedes mode-specific authority details
2. completed same-source compare does not end the problem;
   it promotes the remaining tooth upward into coefficient authority

So the next `U1` move should not skip directly to headwise freeze.

It should first land the shared register neck.

## 2. The minimum scaffold `IR1`

The register should be kept as small as the live surface allows.

The minimum admissible scaffold is:

`I_src^(IR1)[g,ψ] = (I_amp[g,ψ], I_mix[g,ψ], I_geo[g,ψ])`

with the following exact roles.

### A. `I_amp`

`I_amp[g,ψ]`

is the source-amplitude register.

Its role is to carry the common source-strength content that later feeds:

- `J_lin`
- `W_src`
- and the carrier-side mass / activity burden indirectly

It must remain:

- source-governed
- non-empirical
- and owned by the same metric/matter route already admitted in `U1`

### B. `I_mix`

`I_mix[g,ψ]`

is the bounded source-mixture register.

Its role is to govern:

- the linear-versus-quadratic interaction partition
- and the south readout balance

The first clean bounded discipline is:

- `0 <= I_mix <= 1`

with the first admissible live identification:

- `w_lin = I_mix`
- `w_quad = 1 - I_mix`

under:

- `w_res = 0`
- `RR0`

So the south-weight head is no longer floating separately in the first live
register scaffold.

### C. `I_geo`

`I_geo[g,ψ]`

is the geometry-response moderation register.

Its role is to carry the part of the dependence class that can lawfully
moderate:

- `A_Q`
- `M_Q`
- and the interaction response environment

without importing:

- one second carrier
- one empirical fit
- or one non-variational patch

It is not yet one final formula.

It is one typed placeholder for the common geometric/source environment
dependence that the current line already needs.

## 3. First headwise binding contract above `IR1`

Once `IR1` is admitted,
the five live heads should be read first only as:

`A_Q = A_Q[I_src^(IR1)]`

`M_Q = M_Q[I_src^(IR1)]`

`J_lin = J_lin[I_src^(IR1)]`

`W_src = W_src[I_src^(IR1)]`

`w_lin = w_lin[I_src^(IR1)]`

with the first live simplification:

- `w_lin = I_mix`

admissible at scaffold grade.

This means the next strike is no longer trying to produce:

- five isolated authority objects

It is trying to produce:

- one shared-source register,
- then one headwise image of that register.

## 4. The induced common coefficient image

The scaffold naturally defines one induced coefficient image:

`V_CAP1^(IR1) = Image(I_src^(IR1) -> (A_Q, M_Q, J_lin, W_src, w_lin))`

This is useful because it turns the live burden into:

- one common source-governed image problem

rather than:

- five disconnected coefficient emergencies

This note does **not** claim that `V_CAP1^(IR1)` is already numerically
materialized.

It claims something prior:

- the next lawful attack should aim at one common image space.

## 5. Why this is better than widening now

This is another real survival gain for `U1`.

If the current record had shown that:

- no shared register could even be typed,
  or
- the south weight needed independent carrierhood,
  or
- the parent heads had no common dependence class at all,

then `U2` pressure would spike sharply.

But the current live record still permits a cleaner reading:

1. one same-carrier parent ledger exists
2. one same-carrier interaction ledger exists
3. one bounded south readout exists
4. one residual-free first live surface exists
5. and now one minimum shared-source register scaffold can be typed beneath
   the five live heads

That keeps `U1-first` honest another step deeper.

## 6. Exact pass criteria for the `IR1` strike

The `IR1` strike counts as progress only if it can show:

1. the three slots `I_amp`, `I_mix`, and `I_geo` are all source-governed
2. no slot requires direct `Q` dependence at register-definition grade
3. no slot requires empirical calibration, halo fit, or baryonic tuning
4. `I_mix` can lawfully own the first live south balance
5. the induced image `V_CAP1^(IR1)` does not hide one second carrier
6. `RR1` and `T_S` remain unopened

If any of these fail,
the register scaffold is not one clean `U1` gain.

## 7. Exact revocation conditions

This scaffold should be revoked immediately if later lawful work shows:

1. the south balance cannot be carried by `I_mix` without reopening residual
   or transport-sector pressure
2. `A_Q`, `M_Q`, `J_lin`, and `W_src` cannot share one same-source register
   without importing one hidden second carrier
3. one of the three slots can only be defined by observational borrowing
4. the register neck itself requires `Q`-feedback or external patchwork at
   its definition layer

If any of those appears,
`IR1` is not the right minimum scaffold.

## 8. What this changes

The live line now has one more precise constructive compression.

It no longer says only:

- the unresolved tooth compresses to `CAP1`

It now also says:

- the next exact internal neck under `CAP1` is shared-source register
  binding,
- and the smallest admissible scaffold for that neck is
  `I_src^(IR1) = (I_amp, I_mix, I_geo)`

This is the first real typing of `I_src`,
not just one name.

## Bottom line

The next honest freeze mission is now sharply ordered:

1. land the shared-source register neck
2. type the minimum scaffold
   `I_src^(IR1) = (I_amp, I_mix, I_geo)`
3. use it to generate the common image
   `V_CAP1^(IR1)`
4. only then attack stronger headwise authority freeze

That is the cleanest current route from `CAP1` toward true coefficient
authority without premature widening.
