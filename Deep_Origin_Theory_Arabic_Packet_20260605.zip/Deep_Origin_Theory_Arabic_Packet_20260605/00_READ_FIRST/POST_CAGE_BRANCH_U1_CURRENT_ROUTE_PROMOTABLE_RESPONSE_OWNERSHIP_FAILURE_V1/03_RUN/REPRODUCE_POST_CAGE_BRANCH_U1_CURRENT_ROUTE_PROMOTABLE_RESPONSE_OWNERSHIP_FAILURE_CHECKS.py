from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


SCRIPT_PATH = Path(__file__).resolve()
OBJECT_ROOT = SCRIPT_PATH.parents[1]
ROOT = SCRIPT_PATH.parents[4]
OUTPUTS = OBJECT_ROOT / "04_OUTPUTS"

NOTE_CHECKS = [
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_SINGLE_CARRIER_OWNERSHIP_TEST_NOTE_20260608.md",
        "fragments": [
            "one promotable source-governed evaluator / value authority",
            "If the final authority step requires one second hidden carrier or one external",
        ],
        "meaning": "the ownership test explicitly requires promotable authority and treats failure there as real U1 ownership failure",
    },
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_MINIMUM_ACTION_WORKSHEET_NOTE_20260608.md",
        "fragments": [
            "one future `Q`-owned jump to promotable response authority",
            "If the last step requires one second carrier or one non-variational patch,",
        ],
        "meaning": "the minimum U1 worksheet already types the future authority step as Q-owned",
    },
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_NO_REGRESSION_ADMISSION_FILTER_NOTE_20260608.md",
        "fragments": [
            "4. missing promotable authority",
            "without a new lawful source-governed step.",
        ],
        "meaning": "the route forbids inflating bounded probes into authority without a new lawful source-governed step",
    },
    {
        "path": ROOT
        / "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/POST_CAGE_BRANCH_U1_BOUNDED_PROBE_VERSUS_PROMOTABLE_AUTHORITY_NOTE_20260608.md",
        "fragments": [
            "bounded nontrivial probe: present",
            "promotable true-closure-grade authority: absent",
        ],
        "meaning": "the current route is explicitly preserved as probe-present but authority-absent",
    },
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_RR0_BS1_EARLIEST_UNRESOLVED_TOOTH_CLASSIFICATION_NOTE_20260608.md",
        "fragments": [
            "not one source-quality coefficient law with promotable authority.",
            "it is still later than the currently visible coefficient-authority wound.",
        ],
        "meaning": "the current first wound is still the coefficient/authority freeze, not companion necessity",
    },
    {
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_VERSUS_U2_PIVOT_DISCIPLINE_NOTE_20260608.md",
        "fragments": [
            "U1 still deserves the next clean strike, but U2 already has exact trigger classes",
            "open `U2` immediately once one trigger class fires cleanly",
        ],
        "meaning": "U2 is typed but not yet forced; it opens only once a trigger fires cleanly",
    },
]

FORM_C_STATUS_PATH = (
    ROOT
    / "artifacts/debt_board_20260530/L2_FORM_C_CURRENT_REPO_NO_GO_V1/04_OUTPUTS/status_summary.json"
)
FORM_C_VERDICT_PATH = (
    ROOT
    / "artifacts/debt_board_20260530/L2_FORM_C_CURRENT_REPO_NO_GO_V1/04_OUTPUTS/verdict.json"
)

SEARCH_ROOTS = [
    ROOT / "artifacts/debt_board_20260530",
    ROOT / "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST",
]


def relative(path: Path) -> str:
    return str(path.relative_to(ROOT))


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "path": relative(item["path"]),
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def load_form_c_inputs() -> dict:
    status = json.loads(FORM_C_STATUS_PATH.read_text(encoding="utf-8"))
    verdict = json.loads(FORM_C_VERDICT_PATH.read_text(encoding="utf-8"))
    return {
        "status_path": relative(FORM_C_STATUS_PATH),
        "verdict_path": relative(FORM_C_VERDICT_PATH),
        "status": status,
        "verdict": verdict,
        "passed": (
            status["verdict"] == "FORM_C_CURRENT_REPO_VISIBLE_ROUTE_NO_GO_MATERIALIZED"
            and status["callable_form_c_present"] is False
            and status["evaluator_grade_bundle_present"] is False
            and status["all_note_checks_pass"] is True
        ),
    }


def collect_form_d_visible_paths() -> list[str]:
    hits: list[str] = []
    for root in SEARCH_ROOTS:
        for path in sorted(root.rglob("*")):
            name = path.name
            if name.startswith("L2_FORM_D_") or name.startswith("FORM_D_"):
                hits.append(relative(path))
    return hits


def build_report(status: dict, note_checks: list[dict], form_d_paths: list[str]) -> str:
    lines = [
        "# Post-Cage Branch U1 Current-Route Promotable Response Ownership Failure Report",
        "",
        f"Generated at: `{status['generated_at_utc']}`",
        "",
        f"Verdict: `{status['verdict']}`",
        "",
        "## Summary",
        "",
        f"- form-c no-go confirmed: `{str(status['form_c_no_go_confirmed']).lower()}`",
        f"- reviewer-visible form-d object count: `{status['reviewer_visible_form_d_object_count']}`",
        f"- note checks passed: `{str(status['all_note_checks_pass']).lower()}`",
        f"- u2 already forced: `{str(status['u2_already_forced']).lower()}`",
        "",
        "## Reviewer-visible Form D paths",
        "",
    ]
    if not form_d_paths:
        lines.append("- none")
    else:
        for path in form_d_paths:
            lines.append(f"- `{path}`")
    lines.extend(
        [
            "",
            "## Note checks",
            "",
        ]
    )
    for check in note_checks:
        lines.append(f"- `{check['path']}` -> `{str(check['passed']).lower()}`")
    lines.extend(
        [
        "",
        "## Reading",
        "",
        "- the current route preserves real gains below the authority step,",
        "- but the same route still lacks one Q-owned promotable authority surface,",
        "- the narrowed same-route pre-external-intake form-c absence is already confirmed,",
        "- the later admitted external Form C authoring package exists separately but does not by itself satisfy same-route U1 ownership closure,",
        "- and no reviewer-visible form-d reopening is presently materialized,",
        "- so the current route fails exactly at promotable response ownership, not yet at forced U2.",
            "",
            "## Next exact move",
            "",
            "- materialize one real authority-grade Form D reopening, or",
            "- adjudicate the typed U1->U2 trigger classes the moment unavoidable companionhood or independent south-carrierhood becomes visible",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    OUTPUTS.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    form_c_inputs = load_form_c_inputs()
    form_d_paths = collect_form_d_visible_paths()

    status = {
        "object_kind": "post_cage_branch_u1_current_route_promotable_response_ownership_failure_status",
        "generated_at_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "scope": "current_repo_visible_frozen_u1_route_only",
        "form_c_no_go_confirmed": form_c_inputs["passed"],
        "reviewer_visible_form_d_object_count": len(form_d_paths),
        "all_note_checks_pass": all(check["passed"] for check in note_checks),
        "u2_already_forced": False,
        "later_external_form_c_not_same_route_closure": True,
        "verdict": "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_MATERIALIZED",
    }

    verdict = {
        "verdict": status["verdict"],
        "scope": status["scope"],
        "why": [
            "the ownership test already requires the same carrier Q to own the jump to promotable authority",
            "the current route preserves rule/operator/probe but still records authority absence",
            "the narrowed Form C current-route no-go is already confirmed",
            "the later admitted external Form C intake is authoring-side and does not by itself close the same-route U1 authority tooth",
            "no reviewer-visible Form D reopening object is presently materialized",
            "the first visible wound is still coefficient/authority freeze rather than forced companionhood",
        ],
        "next_exact_move": "REAL_FORM_D_REOPENING_OR_TYPED_U1_TO_U2_TRIGGER_ADJUDICATION",
        "ceiling": [
            "not a permanent impossibility theorem for U1",
            "not an immediate U2-forcing verdict",
            "not a full-program failure verdict",
        ],
    }

    report = build_report(status, note_checks, form_d_paths)

    (OUTPUTS / "note_checks.json").write_text(
        json.dumps(note_checks, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "form_c_route_inputs.json").write_text(
        json.dumps(form_c_inputs, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "form_d_visible_paths.json").write_text(
        json.dumps(form_d_paths, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "status_summary.json").write_text(
        json.dumps(status, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "verdict.json").write_text(
        json.dumps(verdict, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_REPORT.md").write_text(
        report,
        encoding="utf-8",
    )

    if not form_c_inputs["passed"]:
        raise SystemExit("form c route inputs are not in the expected closed state")
    if form_d_paths:
        raise SystemExit("unexpected reviewer-visible form d object found")
    if not all(check["passed"] for check in note_checks):
        raise SystemExit("required note evidence check failed")


if __name__ == "__main__":
    main()
