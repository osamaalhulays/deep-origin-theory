# U1 Versus U2 Boundary

Date: `2026-06-10`

## Present boundary

This object records:

- one stronger current-route failure verdict inside `U1`

not:

- one already-forced `U2` split.

## Why

The current route already fails at:

- promotable response-authority ownership

but the current record still does **not** yet prove:

1. one second transport-bearing companion is unavoidable,
2. one independent south carrier is unavoidable,
3. or one external exchange-current patch is unavoidable.

## Exact consequence

So the fair next order remains:

1. accept the present scoped `U1` failure verdict,
2. reopen `U1` only by one real authority-grade reopening,
3. or pivot to `U2` only when one typed trigger class fires cleanly.
