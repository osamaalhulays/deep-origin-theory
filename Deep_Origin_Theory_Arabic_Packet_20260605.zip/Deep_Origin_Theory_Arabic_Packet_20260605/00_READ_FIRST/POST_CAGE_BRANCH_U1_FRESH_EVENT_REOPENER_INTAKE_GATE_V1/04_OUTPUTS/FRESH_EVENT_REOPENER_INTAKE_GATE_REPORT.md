# Post-Cage Branch U1 Fresh Event Reopener Intake Gate Report

Generated at: `2026-06-12T15:30:04.735198+00:00`

Verdict: `POST_CAGE_BRANCH_U1_FRESH_EVENT_REOPENER_INTAKE_GATE_MATERIALIZED`

## Summary

- event-layer exhaustion confirmed: `True`
- crossing gate result: `reject_current_repo_visible_witnesses`
- Form D gate result: `reject_current_repo_visible_formd_candidates`
- U2 not fired confirmed: `True`
- current route intake result: `reject_local_replay`

## Intake outcomes

- `REJECT_LOCAL_REPLAY`
- `ROUTE_CROSSING_GATE`
- `ROUTE_FORMD_GATE`
- `ROUTE_U2_ADJUDICATION`

## Reading

- the present route no longer accepts duplicate local event replay as progress,
- any future reopening candidate must first clear freshness,
- and only then may it be routed to crossing, Form D, or U2 adjudication.

## Bottom line

- the current route now reads: reject local replay until one genuinely fresh arrival-grade event candidate appears.
