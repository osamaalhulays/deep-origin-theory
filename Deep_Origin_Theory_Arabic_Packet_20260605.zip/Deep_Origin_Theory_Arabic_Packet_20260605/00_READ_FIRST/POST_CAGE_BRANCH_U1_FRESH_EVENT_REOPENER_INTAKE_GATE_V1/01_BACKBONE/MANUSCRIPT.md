# Post-Cage Branch U1 Fresh Event Reopener Intake Gate

Date: `2026-06-11`

Status: `reviewer-facing intake-gate object`

## Purpose

This object does **not** claim:

- that one fresh reopening candidate already exists,
- that current same-route crossing already landed,
- that one real `Form D` engine already arrived,
- that `U2` is already forced,
- or that true `L0` crossing already happened.

It claims something narrower and operationally decisive:

1. the current local repo-visible event layer is already exhausted under
   present materials,
2. future spend is therefore no longer allowed to reopen by duplicate local
   replay,
3. and any future reopening candidate must now pass one fail-fast intake gate
   before it is even routed to the crossing gate, the `Form D` gate, or typed
   `U2` adjudication.

## Short verdict

The present route no longer permits one flat phrase like:

- "a fresh event may show up later."

It now fixes one exact future intake grammar.

Any future event candidate must first be judged as one of:

1. `REJECT_LOCAL_REPLAY`
   if it is only one replay of the scanned current local event layer,
2. `ROUTE_CROSSING_GATE`
   if it is one genuinely fresh same-route crossing-grade candidate,
3. `ROUTE_FORMD_GATE`
   if it is one genuinely fresh reviewer-visible `Form D` engine candidate,
4. `ROUTE_U2_ADJUDICATION`
   if it is one genuinely fresh fired-`U2` trigger candidate.

On the **current repo-visible route**,
the intake gate already reads:

- `CURRENT_ROUTE_INTAKE_RESULT = reject_local_replay`

because no fresh arrival-grade event candidate is presently visible.

## 1. Why freshness now belongs above all later gates

The current route already fixes:

- current event-layer exhaustion,
- crossing candidate rejection on present materials,
- `Form D` candidate rejection on present materials,
- and typed `U2` as present but not fired.

So the next honest question is no longer:

- "which current local thing should we reinterpret?"

It is:

- "is the future candidate genuinely beyond the scanned current local event
  layer at all?"

That freshness test must now happen first.

## 2. `REJECT_LOCAL_REPLAY` rule

Reject one candidate immediately if it is only:

1. restatement of current local route language,
2. duplicate local re-scan of already-seen materials,
3. same crossing claim already rejected by the current crossing gate,
4. same `Form D` naming already rejected by the current `Form D` gate,
5. same typed-`U2` rhetoric without fired trigger evidence,
6. symbolic operator grammar only,
7. placeholder or template authority pack only,
8. prose that launders crossing, supersession, and widening into one blended
   reopening cloud.

Those are not fresh reopeners.

They are below-line local replay.

## 3. `ROUTE_CROSSING_GATE` rule

Route one candidate to the crossing gate only if:

1. it is genuinely beyond the scanned current local event layer,
2. it presents one same-route `Q`-owned authority-step candidate rather than
   one engine-grade supersession candidate,
3. and it is reviewer-visible enough to deserve crossing-grade gate review.

This gate does **not** itself admit crossing.

It routes freshness-qualified candidates to the crossing gate only.

## 4. `ROUTE_FORMD_GATE` rule

Route one candidate to the `Form D` gate only if:

1. it is genuinely beyond the scanned current local event layer,
2. it presents one reviewer-visible engine-grade supersession candidate,
3. it rises above note-only, grammar-only, and placeholder-only status,
4. and it is not really same-route crossing or fired `U2`.

This gate does **not** itself admit `Form D`.

It routes freshness-qualified candidates to the `Form D` gate only.

## 5. `ROUTE_U2_ADJUDICATION` rule

Route one candidate to typed `U2` adjudication only if:

1. it is genuinely beyond the scanned current local event layer,
2. it carries one real forced-trigger claim at architecture level,
3. and it is not merely one attempt to rename crossing or `Form D`.

This gate does **not** itself admit widening.

It routes freshness-qualified candidates to typed `U2` adjudication only.

## 6. Why the current route already routes to `REJECT_LOCAL_REPLAY`

The current route already reads:

- crossing gate = reject current repo-visible witnesses
- `Form D` gate = reject current repo-visible `Form D` candidates
- typed `U2` = present but not fired
- event layer = exhausted under present materials

So the present route contains no fresh arrival-grade candidate.

That is why the current intake result is already:

- reject local replay

without claiming future impossibility.

## 7. What this changes operationally

This gate means:

- no duplicate local rescans count as progress,
- no renamed old candidates count as fresh arrival,
- and no later event claim can skip directly to crossing, `Form D`, or `U2`
  without first clearing freshness.

That is the missing operational lock above the current watch-only state.

## 8. What should supersede this object

This gate should be refreshed immediately if:

1. one fresh candidate clears the freshness test and routes to one later gate,
2. the current event-layer exhaustion verdict is no longer true,
3. or the route gains one new above-line class beyond crossing / `Form D` /
   fired `U2`.

Until then,
the current intake result remains:

- reject local replay.

## Bottom line

The post-cage event layer now carries one final local governance lock:

- not only watch-only / wait-only,
- but one exact fresh-event intake gate above that state.
