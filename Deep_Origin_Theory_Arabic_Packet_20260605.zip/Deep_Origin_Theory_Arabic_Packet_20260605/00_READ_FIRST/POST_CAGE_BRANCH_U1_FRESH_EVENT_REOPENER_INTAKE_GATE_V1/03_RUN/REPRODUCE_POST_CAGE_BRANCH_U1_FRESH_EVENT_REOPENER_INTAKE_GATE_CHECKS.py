from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[4]
OBJECT_ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = OBJECT_ROOT / "04_OUTPUTS"
OUTPUTS.mkdir(parents=True, exist_ok=True)


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


event_layer_verdict = read_json(
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EVENT_LAYER_INTAKE_GATED_EXHAUSTION_AND_WATCH_ONLY_STATE_V1/04_OUTPUTS/verdict.json"
)
crossing_verdict = read_json(
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_GRADE_WITNESS_DECISION_GATE_V1/04_OUTPUTS/verdict.json"
)
formd_verdict = read_json(
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_FORMD_GRADE_ENGINE_DECISION_GATE_V1/04_OUTPUTS/verdict.json"
)
u2_report = read_text(
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_V1/04_OUTPUTS/TYPED_U2_TRIGGER_ADJUDICATION_REPORT.md"
)

checks = [
    {
        "name": "event_layer_exhaustion_materialized",
        "passed": event_layer_verdict["materialized"] is True
        and event_layer_verdict["current_route_state"]
        == "intake_gated_exhausted_watch_only_wait_only",
    },
    {
        "name": "crossing_gate_rejects_current_visible_candidates",
        "passed": crossing_verdict["current_route_gate_result"]
        == "reject_current_repo_visible_witnesses",
    },
    {
        "name": "formd_gate_rejects_current_visible_candidates",
        "passed": formd_verdict["current_route_gate_result"]
        == "reject_current_repo_visible_formd_candidates",
    },
    {
        "name": "u2_not_fired",
        "passed": "strong-field trigger forced now: `false`" in u2_report
        and "south-substrate trigger forced now: `false`" in u2_report
        and "ledger-honesty trigger forced now: `false`" in u2_report,
    },
]

materialized = all(item["passed"] for item in checks)
generated_at = datetime.now(timezone.utc).isoformat()

verdict = {
    "object": "POST_CAGE_BRANCH_U1_FRESH_EVENT_REOPENER_INTAKE_GATE_V1",
    "generated_at": generated_at,
    "materialized": materialized,
    "current_route_intake_result": "reject_local_replay" if materialized else "gate_unstable",
    "outcomes": [
        "REJECT_LOCAL_REPLAY",
        "ROUTE_CROSSING_GATE",
        "ROUTE_FORMD_GATE",
        "ROUTE_U2_ADJUDICATION",
    ],
}

status_summary = {
    "verdict": (
        "POST_CAGE_BRANCH_U1_FRESH_EVENT_REOPENER_INTAKE_GATE_MATERIALIZED"
        if materialized
        else "POST_CAGE_BRANCH_U1_FRESH_EVENT_REOPENER_INTAKE_GATE_NOT_MATERIALIZED"
    ),
    "current_route_intake_result": verdict["current_route_intake_result"],
    "crossing_gate_result": crossing_verdict["current_route_gate_result"],
    "formd_gate_result": formd_verdict["current_route_gate_result"],
}

report_lines = [
    "# Post-Cage Branch U1 Fresh Event Reopener Intake Gate Report",
    "",
    f"Generated at: `{generated_at}`",
    "",
    f"Verdict: `{status_summary['verdict']}`",
    "",
    "## Summary",
    "",
    f"- event-layer exhaustion confirmed: `{checks[0]['passed']}`",
    f"- crossing gate result: `{crossing_verdict['current_route_gate_result']}`",
    f"- Form D gate result: `{formd_verdict['current_route_gate_result']}`",
    f"- U2 not fired confirmed: `{checks[3]['passed']}`",
    f"- current route intake result: `{verdict['current_route_intake_result']}`",
    "",
    "## Intake outcomes",
    "",
    "- `REJECT_LOCAL_REPLAY`",
    "- `ROUTE_CROSSING_GATE`",
    "- `ROUTE_FORMD_GATE`",
    "- `ROUTE_U2_ADJUDICATION`",
    "",
    "## Reading",
    "",
    "- the present route no longer accepts duplicate local event replay as progress,",
    "- any future reopening candidate must first clear freshness,",
    "- and only then may it be routed to crossing, Form D, or U2 adjudication.",
    "",
    "## Bottom line",
    "",
    "- the current route now reads: reject local replay until one genuinely fresh arrival-grade event candidate appears.",
]

(OUTPUTS / "checks.json").write_text(json.dumps(checks, indent=2), encoding="utf-8")
(OUTPUTS / "verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")
(OUTPUTS / "status_summary.json").write_text(json.dumps(status_summary, indent=2), encoding="utf-8")
(OUTPUTS / "FRESH_EVENT_REOPENER_INTAKE_GATE_REPORT.md").write_text(
    "\n".join(report_lines) + "\n",
    encoding="utf-8",
)
