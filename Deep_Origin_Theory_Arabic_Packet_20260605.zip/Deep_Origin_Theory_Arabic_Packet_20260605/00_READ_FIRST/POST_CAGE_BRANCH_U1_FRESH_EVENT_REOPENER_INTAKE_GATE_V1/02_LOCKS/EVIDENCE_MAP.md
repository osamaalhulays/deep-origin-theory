# Evidence Map

1. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EVENT_LAYER_INTAKE_GATED_EXHAUSTION_AND_WATCH_ONLY_STATE_V1/04_OUTPUTS/CURRENT_ROUTE_EVENT_LAYER_INTAKE_GATED_EXHAUSTION_AND_WATCH_ONLY_STATE_REPORT.md`
   - fixes the present event layer as exhausted / watch-only under current
     materials
2. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_GRADE_WITNESS_DECISION_GATE_V1/04_OUTPUTS/verdict.json`
   - fixes current crossing candidates as rejected on the present route
3. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_FORMD_GRADE_ENGINE_DECISION_GATE_V1/04_OUTPUTS/verdict.json`
   - fixes current `Form D` candidates as rejected on the present route
4. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_V1/04_OUTPUTS/TYPED_U2_TRIGGER_ADJUDICATION_REPORT.md`
   - fixes typed `U2` as present but not fired
