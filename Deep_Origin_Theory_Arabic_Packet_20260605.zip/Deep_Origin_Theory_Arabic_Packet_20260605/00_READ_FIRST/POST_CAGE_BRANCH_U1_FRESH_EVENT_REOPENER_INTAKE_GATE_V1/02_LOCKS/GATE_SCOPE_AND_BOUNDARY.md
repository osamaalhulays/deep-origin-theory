# Gate Scope And Boundary

- This gate governs only future reopening candidates above the current local
  repo-visible event layer.
- It does not itself decide crossing admission, `Form D` admission, or `U2`
  widening truth.
- It decides only whether the candidate is fresh enough and of which exact
  class it should be routed next.

## Kill conditions

This object must be refreshed if any of the following happen:

1. current local event-layer exhaustion no longer holds,
2. one current route candidate is no longer local replay,
3. a fresh candidate clears this gate,
4. one new exact above-line event class appears beyond crossing / `Form D` /
   fired `U2`,
5. or the downstream crossing / `Form D` / `U2` gates change their class
   grammar materially.
