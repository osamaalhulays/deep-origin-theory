# Gate Test Matrix

1. the current event-layer exhaustion / watch-only state is materialized.
2. current crossing gate result still reads:
   `reject_current_repo_visible_witnesses`.
3. current `Form D` gate result still reads:
   `reject_current_repo_visible_formd_candidates`.
4. current typed `U2` state still reads:
   not fired.
5. current route therefore contains no fresh arrival-grade event candidate and
   must read:
   `reject_local_replay`.

## Pass condition

- all five checks pass.

## Failure meaning

- the present route no longer supports one exact fresh-event intake gate.
