# Post-Cage Branch U1 BS1 Bounded South Readout Family Note

Date: `2026-06-08`

Purpose:

This note freezes the first exact admissible family for the bounded south
readout `B_S[...]`.

## Short verdict

The first recommended family is:

`BS1 = bounded_convex_ledger_readout`

acting on the first narrowed interaction-ledger pieces:

- `X_lin = J_lin[g,ψ] Q`
- `X_quad = W_src[g,ψ] Q^2`
- `X_res = R_res[g,ψ,Q]`

through bounded same-carrier readout faces:

- `Y_lin = B_lin[X_lin]`
- `Y_quad = B_quad[X_quad]`
- `Y_res = B_res[X_res]`

with:

- `|Y_lin| <= 1`
- `|Y_quad| <= 1`
- `|Y_res| <= 1`

and with:

`P_S^(1)[Q] = w_lin[g,ψ] Y_lin + w_quad[g,ψ] Y_quad + w_res[g,ψ] Y_res`

subject to:

- `w_lin >= 0`
- `w_quad >= 0`
- `w_res >= 0`
- `w_lin + w_quad + w_res = 1`

This keeps south bounded by construction and preserves the same-carrier rule.

## Why `BS1` is primary

`BS1` is the clean first family because it:

1. uses only already-owned ledger pieces
2. carries no independent south dynamics
3. carries no independent south transport tensor
4. keeps weighting explicit and bounded
5. avoids importing lane-local fitted authority

## Conditional family `BS2`

One later conditional family is also admissible:

`BS2 = component_weight_modulated_bounded_ledger_readout`

This may borrow grammar pressure from the Kreib source-channel weight policy
and its `f_gas / f_disk / f_bulge` component weights,
but only as bounded no-claim readout grammar.

It may **not** reopen the fenced public gas lane,
and it may **not** promote Kreib diagnostic constants into parent-law
authority.

## What breaks it

Reject immediately if the readout family needs:

- one primitive south field
- one hidden fit parameter
- one reopened public gas-support claim
- one imported diagnostic constant treated as law
- one independent south transport tensor
- or one independent south equation of motion

That would no longer be clean `U1`.

## Bottom line

The live line now has its first exact bounded south-readout family:

- `BS1` as the recommended safe family
- `BS2` as one conditional component-weighted side family

with one strict safety law:

- no public gas-authority reopening
- no diagnostic-to-law inflation
- no independent south dynamics
- no independent south transport
