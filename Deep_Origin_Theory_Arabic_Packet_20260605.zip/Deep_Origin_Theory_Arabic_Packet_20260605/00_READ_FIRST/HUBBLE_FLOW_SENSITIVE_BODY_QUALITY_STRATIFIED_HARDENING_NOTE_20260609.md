# Hubble-Flow-Sensitive Body Quality-Stratified Hardening Note

Date: `2026-06-09`

Status: `packet-contained body-internal stress test`

Purpose:

After the packet had already shown that the ten-witness
Hubble-flow-sensitive body is uniformly same-sign hardening,
one fair reviewer question still remained:

- is that hardening body merely a `quality-2` artifact?

This note answers that question directly.

Machine-readable companion:

- `HUBBLE_FLOW_SENSITIVE_BODY_QUALITY_STRATIFIED_HARDENING_V1.json`

Reproduction script:

- `REPRODUCE_HUBBLE_FLOW_SENSITIVE_BODY_QUALITY_STRATIFIED_HARDENING_V1.py`

It should be read after:

- `HUBBLE_FLOW_SENSITIVE_BODY_FULL_CLOSURE_NOTE_20260609.md`
- `NAMED_EXECUTED_MATCHED_NUISANCE_COURT_MORPHOLOGY_PARTITION_NOTE_20260609.md`

## Short verdict

The ten-witness Hubble-flow-sensitive hardening body is not a `quality-2`
artifact.

Inside that body:

- the `quality-1` subgroup has `7` members
- the `quality-2` subgroup has `3` members
- all `7/7` quality-`1` members harden further away from `QCT`
- all `3/3` quality-`2` members also harden further away from `QCT`

And the `quality-1` subgroup carries the larger share of the body's burden:

- public burden = `76333.1958648939`
- component-aware burden = `57972.45670655153`
- public share of body burden = `61.09148906899099%`
- component-aware share of body burden = `62.48371932110307%`

The `quality-2` subgroup carries:

- public burden = `48615.78971096982`
- component-aware burden = `34807.64239195408`
- public share of body burden = `38.90851093100902%`
- component-aware share of body burden = `37.51628067889693%`

So the hardening body cannot be dismissed as a low-quality tail effect.

## 1. The `quality-1` subgroup still hardens uniformly

The `quality-1` members inside the Hubble-flow-sensitive body are:

- `UGC09133`
- `UGC06786`
- `NGC2903`
- `NGC6674`
- `NGC5033`
- `UGC02487`
- `UGC03205`

Together they carry:

- public `Delta AIC_total = +76333.1958648939`
- faithful `Delta AIC_total = +52970.44465779079`
- component-aware `Delta AIC_total = +57972.45670655153`
- component-aware shift = `+5002.012048760745`

All seven harden further away from `QCT` under component-aware parity.

So even before looking at any `quality-2` members,
the body already carries one large, explicit, same-sign hardening
quality-`1` block.

## 2. The `quality-2` subgroup also hardens, but it is not the whole story

The `quality-2` members inside the Hubble-flow-sensitive body are:

- `UGC02953`
- `UGC06787`
- `UGC05253`

Together they carry:

- public `Delta AIC_total = +48615.78971096982`
- faithful `Delta AIC_total = +33288.395708140335`
- component-aware `Delta AIC_total = +34807.64239195408`
- component-aware shift = `+1519.2466838137452`

All three also harden further away from `QCT`.

So the correct reading is not:

- "`quality-2` hardens while `quality-1` softens."

The correct reading is:

- both stratified subgroups harden,
- and the larger subgroup is the `quality-1` subgroup.

## 3. Why this is stronger than a simple quality argument

This note does not say that quality flags are irrelevant.

It says something narrower and more important:

- inside the ten-witness Hubble-flow-sensitive body,
  the direction of component-aware movement is not explained away by
  isolating `quality-2` cases.

That is because:

- the `quality-1` subgroup itself is already uniformly hardening,
- and it carries the majority of the body's burden.

## 4. Why quality flag alone still does not settle the whole head

The packet already separately preserves that the protected clean-anchor
minority is:

- all quality `1`
- and external to the Hubble-flow-sensitive body

So quality flag alone is still not the law of the whole head.

It does not determine court membership by itself.

What this note closes is narrower:

- the Hubble-flow-sensitive hardening body is not a mere `quality-2`
  contamination story.

## 5. What this does not authorize

This note does **not** authorize the claims that:

- whole-family `MOND/QUMOND` closure already exists
- quality flag alone explains the entire giant-spiral head
- the protected clean-anchor minority disappears
- every later witness inside or outside the body must harden

## Best outward-safe reading

One mature outward-safe sentence is:

> The ten-witness Hubble-flow-sensitive body is not a `quality-2` artifact.
> Its `quality-1` subgroup already carries the larger share of the body's
> burden and itself hardens uniformly away from `QCT`, while the `quality-2`
> subgroup hardens in the same direction. So the present body-level pattern
> cannot be dismissed as a low-quality tail effect.
