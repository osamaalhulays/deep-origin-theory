#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

REMAINDER_LOCALIZATION_PATH = HERE / "HUBBLE_FLOW_SENSITIVE_BODY_CURRENT_O7_REMAINDER_LOCALIZATION_V1.json"
FULL_HEAD_BOUNDARY_PATH = HERE / "CURRENT_FULL_HEAD_CONCENTRATED_BUT_NONTERMINAL_BOUNDARY_V1.json"
LANE_STATUS_BOARD_PATH = HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_STATUS_BOARD_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def subtotal(catalog, case_ids, key):
    return sum(catalog[case_id][key] for case_id in case_ids)


def main():
    remainder_localization = load_json(REMAINDER_LOCALIZATION_PATH)
    full_head_boundary = load_json(FULL_HEAD_BOUNDARY_PATH)
    lane_status_board = load_json(LANE_STATUS_BOARD_PATH)

    pocket = remainder_localization["current_o7_nonintersecting_remainder"]
    catalog = remainder_localization["remainder_case_catalog"]
    localization = remainder_localization["localization_structure"]
    board_pocket = lane_status_board["lane_status_board"]["best_dressed_adversarial_hardening_court"][
        "current_nonoverlap_remainder"
    ]

    reopening_cases = localization["reopening_triad_cases"]
    reserve_cases = localization["reserve_triplet_cases"]
    pocket_public_total = pocket["public_delta_aic_total"]

    reopening_public_total = subtotal(catalog, reopening_cases, "public_delta_aic_total")
    reserve_public_total = subtotal(catalog, reserve_cases, "public_delta_aic_total")

    pocket_segments = {
        "residual_quality1_reopening_triad": {
            "case_count": len(reopening_cases),
            "cases": reopening_cases,
            "public_delta_aic_total": reopening_public_total,
            "share_of_pocket_public_delta_aic_total": reopening_public_total / pocket_public_total,
        },
        "quality1_reserve_triplet": {
            "case_count": len(reserve_cases),
            "cases": reserve_cases,
            "public_delta_aic_total": reserve_public_total,
            "share_of_pocket_public_delta_aic_total": reserve_public_total / pocket_public_total,
        },
    }

    consistency_checks = {
        "pocket_case_ids_match_the_expected_three_witness_triad": pocket["cases"]
        == ["SPARC_NGC2903", "SPARC_NGC6674", "SPARC_NGC5033"],
        "all_three_pocket_cases_are_quality1": remainder_localization["consistency_checks"][
            "remainder_has_no_quality2_member"
        ]
        and localization["all_cases_are_quality1"],
        "all_three_pocket_cases_keep_exact_qumond_protection": localization[
            "all_cases_have_exact_qumond_protection"
        ],
        "reopening_and_reserve_segments_recombine_to_the_pocket_public_total": abs(
            reopening_public_total + reserve_public_total - pocket_public_total
        )
        < 1e-9,
        "packet_lane_board_and_localization_surface_share_the_same_three_case_pocket": (
            board_pocket["case_count"] == pocket["case_count"] and board_pocket["cases"] == pocket["cases"]
        ),
        "pocket_stays_below_twelve_percent_of_full_head_public_burden": full_head_boundary[
            "consistency_checks"
        ]["pocket_public_burden_stays_below_twelve_percent"],
        "pocket_stays_below_one_fifth_of_body_public_burden": pocket[
            "fraction_of_body_public_delta_aic_total"
        ]
        < 0.2,
        "pocket_remains_disjoint_from_the_current_layered_o7_overlap": remainder_localization[
            "consistency_checks"
        ]["remainder_is_disjoint_from_current_o7_overlap"],
    }

    output = {
        "date": "2026-06-09",
        "status": "packet_contained_reviewer_facing_pocket_boundary_surface",
        "surface": "current_reviewer_facing_narrow_quality1_continuation_pocket_boundary",
        "synthesis_inputs": {
            "remainder_localization_surface": "HUBBLE_FLOW_SENSITIVE_BODY_CURRENT_O7_REMAINDER_LOCALIZATION_V1.json",
            "full_head_boundary_surface": "CURRENT_FULL_HEAD_CONCENTRATED_BUT_NONTERMINAL_BOUNDARY_V1.json",
            "court_lane_board_surface": "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_STATUS_BOARD_V1.json",
        },
        "current_pocket": {
            "case_count": pocket["case_count"],
            "cases": pocket["cases"],
            "public_delta_aic_total": pocket["public_delta_aic_total"],
            "faithful_delta_aic_total": pocket["faithful_delta_aic_total"],
            "component_aware_delta_aic_total": pocket["component_aware_delta_aic_total"],
            "fraction_of_hubble_flow_sensitive_body_public_delta_aic_total": pocket[
                "fraction_of_body_public_delta_aic_total"
            ],
            "fraction_of_full_head_public_delta_aic_total": full_head_boundary[
                "concentration_surface"
            ]["pocket_fraction_of_full_head_public_delta_aic_total"],
            "all_cases_are_quality1": localization["all_cases_are_quality1"],
            "all_cases_have_exact_qumond_protection": localization[
                "all_cases_have_exact_qumond_protection"
            ],
        },
        "pocket_segments": pocket_segments,
        "boundary_reading": {
            "the_current_three_case_object_is_one_narrow_quality1_continuation_pocket": remainder_localization[
                "structural_reading"
            ][
                "the_current_o7_nonoverlap_is_a_narrow_quality1_continuation_pocket_not_a_bodywide_counterpattern"
            ],
            "the_pocket_remains_split_between_reopening_and_reserve_not_one_uniform_later_block": remainder_localization[
                "structural_reading"
            ][
                "the_current_nonoverlap_is_split_only_between_reopening_and_reserve_quality1_segments"
            ],
            "the_pocket_lives_below_primary_core_and_below_quality2": remainder_localization[
                "structural_reading"
            ]["the_current_nonoverlap_lives_entirely_below_the_primary_core_and_below_quality2"],
            "the_packet_does_not_yet_authorize_renaming_this_pocket_as_one_fresh_exact_three_witness_o7_block": True,
            "any_later_absorption_would_need_a_genuinely_new_materialized_bridge_not_mere_naming_pressure": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the packet now carries one reviewer-facing boundary surface for the current three-case continuation pocket instead of leaving it as a scattered remainder fact",
            "the current pocket is explicitly split across two reopening cases and one reserve case rather than one uniform later block",
            "the current pocket is explicitly bounded as narrow on both the body scale and the full-head scale",
            "the packet now openly forbids silent renaming of the present three-case pocket into exact layered O7 overlap",
        ],
        "not_supported_now": [
            "the present three cases already form one fresh exact three-witness O7 block",
            "the current pocket is bodywide or majority-sized",
            "the present three-case pocket may be absorbed into O7 overlap by naming alone",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_continuation": [
            "keep the present three-case pocket separate in outward wording unless later exact materialized evidence removes the current disjointness",
            "if a later stronger bridge lands, promote it as one new object instead of retroactively renaming the current pocket",
        ],
    }

    output["verdict"] = (
        "CURRENT_REVIEWER_FACING_NARROW_QUALITY1_CONTINUATION_POCKET_BOUNDARY_CLOSED__THE_PRESENT_THREE_CASE_OBJECT_REMAINS_ONE_NARROW_QUALITY1_CONTINUATION_POCKET_SPLIT_BETWEEN_REOPENING_AND_RESERVE_RATHER_THAN_ONE_FRESH_EXACT_O7_BLOCK"
        if all(consistency_checks.values())
        else "CURRENT_REVIEWER_FACING_NARROW_QUALITY1_CONTINUATION_POCKET_BOUNDARY_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
