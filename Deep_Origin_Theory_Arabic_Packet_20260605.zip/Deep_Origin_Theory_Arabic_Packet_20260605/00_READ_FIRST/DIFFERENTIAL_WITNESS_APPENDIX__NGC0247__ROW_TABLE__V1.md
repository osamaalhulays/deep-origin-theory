# Differential Witness Appendix — NGC0247 Row-by-Row Oracle Surface

Date: `2026-06-04`

Status: `bounded public appendix`

## Purpose

This appendix publishes the preserved row-by-row local witness surface behind
the bounded `NGC0247` capsule.

It is meant to answer one narrow reviewer need directly:

- can the named differential witness be inspected row by row rather than only
  through summary wording?

## Scope rule

This appendix **does** publish:

- the `26` preserved local rows for `NGC0247`,
- the row-wise `delta_true` target,
- the corresponding source-side radius,
- and the paired `v_obs` / `v_bar` values used to make the witness legible.

This appendix does **not** claim:

- that the full exact public fixed-`QUMOND` comparator table is now closed,
- or that full `MOND/QUMOND` non-reducibility closure has been reached.

The explicit fixed-`QUMOND` row comparator now lives separately in:

- `FIXED_QUMOND_COMPARATOR_APPENDIX__NGC0247__SOURCE_LOCKED_V1.md`

## Provenance

This table is assembled from two preserved local sources:

- `epic30_oracle_points.ndjson` for the row-wise `delta_true` target
- the preserved `NGC0247` joined SPARC source-side radial case for
  `R`, `v_obs`, and `v_bar`

## Frozen summary

- row count = `26`
- negative rows = `13`
- positive rows = `13`
- `delta_true_min = -0.147828327514717`
- `delta_true_max = 0.25`

The sign pattern is not flat and not anonymous:

- row `1` = negative
- rows `2..5` = positive
- rows `6..17` = negative
- rows `18..26` = positive

That is the bounded reason this object now functions as a reviewer-readable
differential witness rather than only as part of aggregate benchmark harshness.

## Row-by-row table

| Row | r/r_max | R (kpc) | v_obs (km/s) | v_bar (km/s) | delta_true | sign |
| --- | ---: | ---: | ---: | ---: | ---: | :--: |
| 1 | 0.0743 | 1.08 | 34.6 | 22.4 | -0.009425 | - |
| 2 | 0.1107 | 1.61 | 47.0 | 29.9 | 0.020660 | + |
| 3 | 0.1479 | 2.15 | 59.1 | 35.0 | 0.181430 | + |
| 4 | 0.1857 | 2.70 | 64.4 | 38.8 | 0.139595 | + |
| 5 | 0.2215 | 3.22 | 67.4 | 42.4 | 0.045794 | + |
| 6 | 0.2593 | 3.77 | 69.8 | 45.6 | -0.030800 | - |
| 7 | 0.2964 | 4.31 | 71.3 | 48.4 | -0.101562 | - |
| 8 | 0.3336 | 4.85 | 73.2 | 50.7 | -0.136843 | - |
| 9 | 0.3700 | 5.38 | 75.1 | 52.3 | -0.147828 | - |
| 10 | 0.4072 | 5.92 | 78.5 | 53.9 | -0.122653 | - |
| 11 | 0.4443 | 6.46 | 81.4 | 55.4 | -0.107306 | - |
| 12 | 0.4807 | 6.99 | 83.5 | 56.9 | -0.108887 | - |
| 13 | 0.5179 | 7.53 | 87.1 | 58.5 | -0.083322 | - |
| 14 | 0.5550 | 8.07 | 90.7 | 59.9 | -0.049651 | - |
| 15 | 0.5928 | 8.62 | 93.1 | 61.2 | -0.042396 | - |
| 16 | 0.6286 | 9.14 | 95.9 | 62.6 | -0.028019 | - |
| 17 | 0.6664 | 9.69 | 98.4 | 63.8 | -0.014918 | - |
| 18 | 0.7036 | 10.23 | 101.0 | 64.7 | 0.009425 | + |
| 19 | 0.7400 | 10.76 | 103.0 | 65.3 | 0.030601 | + |
| 20 | 0.7772 | 11.30 | 104.0 | 65.5 | 0.042817 | + |
| 21 | 0.8143 | 11.84 | 105.0 | 65.3 | 0.069532 | + |
| 22 | 0.8514 | 12.38 | 105.0 | 64.8 | 0.086428 | + |
| 23 | 0.8879 | 12.91 | 105.0 | 63.9 | 0.118289 | + |
| 24 | 0.9271 | 13.48 | 106.0 | 62.6 | 0.186825 | + |
| 25 | 0.9635 | 14.01 | 108.0 | 61.2 | 0.250000 | + |
| 26 | 1.0000 | 14.54 | 107.0 | 59.9 | 0.250000 | + |

## Reviewer use rule

Use this appendix to inspect the bounded named witness directly.

Do not use it to claim that:

- the exact full fixed-`QUMOND` public comparator table is already finished,
- or that the whole anti-`MOND/QUMOND` question is already closed.
