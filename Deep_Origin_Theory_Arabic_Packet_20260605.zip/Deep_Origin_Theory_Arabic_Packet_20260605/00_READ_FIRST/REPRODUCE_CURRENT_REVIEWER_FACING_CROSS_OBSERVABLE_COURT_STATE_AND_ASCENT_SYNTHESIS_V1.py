#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

MASTER_FRONT_PATH = HERE / "CURRENT_REVIEWER_FACING_MASTER_FRONT_V1.json"
LAUNCH_FRONT_PATH = HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LAUNCH_FRONT_V1.json"
LANE_STATUS_BOARD_PATH = HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_STATUS_BOARD_V1.json"
LANE_PROGRESSION_LADDER_PATH = (
    HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_PROGRESSION_LADDER_V1.json"
)


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    master_front = load_json(MASTER_FRONT_PATH)
    launch_front = load_json(LAUNCH_FRONT_PATH)
    lane_status_board = load_json(LANE_STATUS_BOARD_PATH)
    lane_progression_ladder = load_json(LANE_PROGRESSION_LADDER_PATH)

    launch_rotation_side = launch_front["rotation_side"]
    board_lanes = lane_status_board["lane_status_board"]
    ladder_lanes = lane_progression_ladder["lane_progression_ladder"]

    lane_state_and_ascent = {
        "fixed_comparator_rotation_witness_court": {
            "current_state": board_lanes["fixed_comparator_rotation_witness_court"]["lane_status"],
            "current_role": board_lanes["fixed_comparator_rotation_witness_court"]["lane_role"],
            "current_visible_anchor": (
                board_lanes["fixed_comparator_rotation_witness_court"][
                    "rotation_fixed_public_qumond_crosscheck_count_with_zero_public_gap"
                ]
            ),
            "next_upgrade_stage": ladder_lanes["fixed_comparator_rotation_witness_court"][
                "next_upgrade_stage"
            ],
            "next_upgrade_object": ladder_lanes["fixed_comparator_rotation_witness_court"][
                "next_upgrade_object"
            ],
            "honest_reader_rule": (
                "treat_this_lane_as_one_frozen_reference_floor_that_advances_only_by_remaining_unchanged"
            ),
        },
        "matched_nuisance_parity_court": {
            "current_state": board_lanes["matched_nuisance_parity_court"]["lane_status"],
            "current_role": board_lanes["matched_nuisance_parity_court"]["lane_role"],
            "current_visible_anchor": {
                "named_executed_witness_count": board_lanes["matched_nuisance_parity_court"][
                    "named_executed_witness_count"
                ],
                "route_split_witness": board_lanes["matched_nuisance_parity_court"][
                    "route_split_witness"
                ],
                "same_sign_softening_witness": board_lanes["matched_nuisance_parity_court"][
                    "same_sign_softening_witness"
                ],
                "same_sign_hardening_body_witness_count": board_lanes[
                    "matched_nuisance_parity_court"
                ]["same_sign_hardening_body_witness_count"],
            },
            "next_upgrade_stage": ladder_lanes["matched_nuisance_parity_court"][
                "next_upgrade_stage"
            ],
            "next_upgrade_object": ladder_lanes["matched_nuisance_parity_court"][
                "next_upgrade_object"
            ],
            "honest_reader_rule": (
                "treat_this_lane_as_one_executed_named_parity_lane_that_may_expand_only_by_"
                "preserving_route_split_softening_and_hardening_as_distinct_structures"
            ),
        },
        "best_dressed_adversarial_hardening_court": {
            "current_state": board_lanes["best_dressed_adversarial_hardening_court"]["lane_status"],
            "current_role": board_lanes["best_dressed_adversarial_hardening_court"]["lane_role"],
            "current_visible_anchor": {
                "primary_front_block_members": board_lanes["best_dressed_adversarial_hardening_court"][
                    "primary_front_block"
                ]["members"],
                "layered_o7_overlap_case_count": board_lanes[
                    "best_dressed_adversarial_hardening_court"
                ]["layered_o7_convergence"]["overlap_case_count"],
                "current_nonoverlap_remainder_case_count": board_lanes[
                    "best_dressed_adversarial_hardening_court"
                ]["current_nonoverlap_remainder"]["case_count"],
            },
            "next_upgrade_stage": ladder_lanes["best_dressed_adversarial_hardening_court"][
                "next_upgrade_stage"
            ],
            "next_upgrade_object": ladder_lanes["best_dressed_adversarial_hardening_court"][
                "next_upgrade_object"
            ],
            "selected_next_batch": ladder_lanes["best_dressed_adversarial_hardening_court"][
                "selected_next_batch"
            ],
            "honest_reader_rule": (
                "treat_this_lane_as_one_materialized_hardening_lane_with_one_exact_live_"
                "reinflation_microfront_not_as_whole_court_closure"
            ),
        },
        "same_kernel_macs1206_secondary_deltasigma_rail": {
            "current_state": board_lanes["same_kernel_macs1206_secondary_deltasigma_rail"][
                "lane_status"
            ],
            "current_role": board_lanes["same_kernel_macs1206_secondary_deltasigma_rail"][
                "lane_role"
            ],
            "current_visible_anchor": {
                "same_kernel_only": board_lanes["same_kernel_macs1206_secondary_deltasigma_rail"][
                    "same_kernel_only"
                ],
                "no_new_knobs": board_lanes["same_kernel_macs1206_secondary_deltasigma_rail"][
                    "no_new_knobs"
                ],
                "shared_overlap_mid_bin_count": board_lanes[
                    "same_kernel_macs1206_secondary_deltasigma_rail"
                ]["shared_overlap_mid_bin_count"],
                "runtime_package_status": board_lanes[
                    "same_kernel_macs1206_secondary_deltasigma_rail"
                ]["runtime_package_status"],
            },
            "next_upgrade_stage": ladder_lanes["same_kernel_macs1206_secondary_deltasigma_rail"][
                "next_upgrade_stage"
            ],
            "next_upgrade_object": ladder_lanes[
                "same_kernel_macs1206_secondary_deltasigma_rail"
            ]["next_upgrade_object"],
            "route_progression_order": ladder_lanes[
                "same_kernel_macs1206_secondary_deltasigma_rail"
            ]["route_progression_order"],
            "honest_reader_rule": (
                "treat_this_lane_as_one_same_kernel_locked_north_rail_that_climbs_only_through_"
                "its_explicit_route_order_under_the_preserved_authority_gate"
            ),
        },
    }

    consistency_checks = {
        "master_front_already_ends_at_this_selected_court": (
            master_front["structural_reading"][
                "the_front_ends_at_one_selected_next_cross_observable_court_instead_of_reader_improvisation"
            ]
            and master_front["selected_next_court"]["selected_scope"]
            == launch_front["governing_court"]["selected_scope"]
        ),
        "launch_front_already_makes_the_court_packet_facing": launch_front["structural_reading"][
            "the_next_court_no_longer_needs_scope_debate_before_packet_facing_launch"
        ],
        "lane_board_already_freezes_every_current_lane_state": lane_status_board["structural_reading"][
            "each_lane_now_has_one_explicit_packet_side_state"
        ],
        "lane_ladder_already_freezes_every_next_upgrade_rule": lane_progression_ladder[
            "structural_reading"
        ]["each_lane_now_has_one_explicit_honest_next_upgrade_rule"],
        "launch_board_and_ladder_share_the_same_four_lane_order": (
            launch_front["governing_court"]["court_lanes"] == lane_status_board["board_sequence"]
            and lane_status_board["board_sequence"] == lane_progression_ladder["ladder_sequence"]
        ),
        "rotation_side_is_launchable_without_erasing_lane_distinctions": (
            launch_front["structural_reading"][
                "the_rotation_side_is_already_materially_populated_under_the_frozen_court_law"
            ]
            and launch_rotation_side["route_split_witness"] == "SPARC_NGC0247"
            and launch_rotation_side["same_sign_softening_witness"] == "SPARC_NGC6946"
        ),
        "north_side_is_launchable_but_not_north_closed": (
            launch_front["structural_reading"][
                "the_north_side_is_already_same_kernel_locked_but_not_authority_closed"
            ]
            and board_lanes["same_kernel_macs1206_secondary_deltasigma_rail"]["same_kernel_only"]
            and "final_north_ascent_closure_not_materialized"
            in board_lanes["same_kernel_macs1206_secondary_deltasigma_rail"]["not_closed_by_manifest"]
        ),
        "fixed_lane_is_carried_by_preservation_not_fake_expansion": (
            lane_state_and_ascent["fixed_comparator_rotation_witness_court"]["next_upgrade_stage"]
            == "floor_preservation_under_cross_observable_pressure"
        ),
        "best_dressed_lane_is_carried_by_exact_reinflation_batch": (
            lane_state_and_ascent["best_dressed_adversarial_hardening_court"][
                "next_upgrade_stage"
            ]
            == "O7_D72_nonshared_local_public_positive_spoiler_reinflation_opening_batch_materialization"
        ),
        "north_lane_is_carried_by_explicit_route_order": (
            lane_state_and_ascent["same_kernel_macs1206_secondary_deltasigma_rail"][
                "route_progression_order"
            ]["route_a"]["priority"]
            == "first"
            and lane_state_and_ascent["same_kernel_macs1206_secondary_deltasigma_rail"][
                "route_progression_order"
            ]["route_b"]["priority"]
            == "second"
            and lane_state_and_ascent["same_kernel_macs1206_secondary_deltasigma_rail"][
                "route_progression_order"
            ]["route_c"]["priority"]
            == "third"
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "packet_contained_reviewer_facing_cross_observable_court_state_and_ascent_synthesis",
        "surface": "current_reviewer_facing_cross_observable_court_state_and_ascent_synthesis",
        "synthesis_inputs": {
            "upstream_packet_front": "CURRENT_REVIEWER_FACING_MASTER_FRONT_V1.json",
            "court_launch_front": "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LAUNCH_FRONT_V1.json",
            "court_lane_status_board": "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_STATUS_BOARD_V1.json",
            "court_lane_progression_ladder": "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_PROGRESSION_LADDER_V1.json",
        },
        "governing_court": launch_front["governing_court"],
        "state_and_ascent_object": {
            "packet_front_now_lands_directly_inside_this_selected_court": True,
            "the_court_is_already_launchable_as_one_packet_side_object": True,
            "the_court_now_has_both_one_lane_state_board_and_one_lane_progression_ladder": True,
            "lane_distinction_remains_preserved_at_both_state_and_ascent_levels": True,
        },
        "lane_state_and_ascent": lane_state_and_ascent,
        "structural_reading": {
            "the_reader_no_longer_needs_to_assemble_the_selected_court_by_hand_from_multiple_scattered_surfaces": True,
            "the_selected_court_can_now_be_read_as_one_present_state_plus_one_governed_ascent_object": True,
            "the_packet_now_carries_one_court_level_reader_flow_from_front_selection_to_lane_by_lane_ascent": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the packet front now lands directly inside one selected cross-observable court rather than stopping at scope selection alone",
            "the selected court now has one launch front, one lane state board, and one lane progression ladder that agree on the same four-lane object",
            "a reviewer can now read each lane as one paired current-state plus next-ascent unit without collapsing the lanes into one fake uniform maturity class",
            "the north rail now reads as part of the same court-level ascent object while remaining explicitly authority-gated",
        ],
        "not_supported_now": [
            "the selected court is already fully executed",
            "all four lanes are already mature in the same sense",
            "lane distinctions may be erased now that the court has one synthesis surface",
            "the north rail is already authority-closed",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_continuation": [
            "use_this_court_level_state_and_ascent_object_as_the_reviewer_facing_entry_into_lane_specific_execution_without_erasing_claim_boundaries",
            "promote_only_lane_honest_upgrades_below_the_preserved_court_law",
        ],
    }

    output["verdict"] = (
        "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_STATE_AND_ASCENT_SYNTHESIS_CLOSED__THE_PACKET_FRONT_NOW_LANDS_DIRECTLY_INSIDE_ONE_SELECTED_COURT_WHOSE_FOUR_LANES_CAN_BE_READ_AS_ONE_PRESENT_STATE_PLUS_ONE_GOVERNED_ASCENT_OBJECT"
        if all(consistency_checks.values())
        else "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_STATE_AND_ASCENT_SYNTHESIS_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
