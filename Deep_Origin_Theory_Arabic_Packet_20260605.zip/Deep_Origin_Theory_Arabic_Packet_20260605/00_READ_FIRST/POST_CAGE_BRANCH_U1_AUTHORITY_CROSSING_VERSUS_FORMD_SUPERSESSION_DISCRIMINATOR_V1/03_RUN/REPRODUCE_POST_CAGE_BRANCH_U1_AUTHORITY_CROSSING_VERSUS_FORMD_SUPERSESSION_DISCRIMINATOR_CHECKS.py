#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"

LANDING_CRITERIA = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EXACT_VANISHING_LANDING_TEST_V1/02_LOCKS/LANDING_CRITERIA_AND_FAILURE_SIGNATURES.md"
ALLOWED_FORMS = "artifacts/debt_board_20260530/L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/02_LOCKS/ALLOWED_AUTHORING_FORMS.md"
TRIAD_MANUSCRIPT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_REOPENING_TRIAD_AFTER_FORMABC_NO_GO_V1/01_BACKBONE/MANUSCRIPT.md"
LANDING_REPORT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EXACT_VANISHING_LANDING_TEST_V1/04_OUTPUTS/EXACT_VANISHING_LANDING_TEST_REPORT.md"

NOTE_CHECKS = [
    {
        "key": "landing_requires_authority_crossing",
        "path": LANDING_CRITERIA,
        "fragments": [
            "5. one lawful `Q`-owned promotable response-authority surface is materially",
            "visible on the same route,",
            "The route is **not yet landed** if:",
            "3. but the promotable response-authority tooth is still not crossed.",
        ],
        "meaning": "same-route landing already requires internal authority crossing",
    },
    {
        "key": "landing_forbids_prior_formd",
        "path": LANDING_CRITERIA,
        "fragments": [
            "7. and no real `Form D` engine has already superseded the route before the",
            "landing claim is made.",
            "## Failure family C: superseded route",
            "1. one real reviewer-visible `Form D` engine appears first and lawfully",
            "changes the route order.",
        ],
        "meaning": "Form D is already fenced as prior supersession, not same-route landing",
    },
    {
        "key": "formd_is_operator_engine",
        "path": ALLOWED_FORMS,
        "fragments": [
            "4. `Form D`",
            "source-governed operator engine producing those outputs",
        ],
        "meaning": "Form D is explicitly one operator-engine class",
    },
    {
        "key": "triad_keeps_both_members_separate",
        "path": TRIAD_MANUSCRIPT,
        "fragments": [
            "1. one lawful `Q`-owned promotable response-authority crossing on the same",
            "2. one real reviewer-visible `Form D` operator engine that lawfully reopens",
            "the first class is landing-class reopening inside the preserved route,",
            "the second class is supersession-class reopening from above,",
        ],
        "meaning": "the triad already carries authority crossing and Form D as distinct above-line members",
    },
    {
        "key": "operational_report_distinguishes_recompute_vs_supersede",
        "path": LANDING_REPORT,
        "fragments": [
            "- if one real reviewer-visible Form D engine appears first, this landing test is superseded,",
            "- if one lawful Q-owned authority crossing appears first, the landing state must be recomputed,",
        ],
        "meaning": "the live landing-state report already distinguishes authority-crossing from Form D event consequences",
    },
]


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
if WORKSPACE_ROOT is None:
    raise RuntimeError("could not locate workspace root from discriminator runner")


def read_text(logical_relative_path: str) -> str:
    return (WORKSPACE_ROOT / logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": item["path"],
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def tf(value: bool) -> str:
    return str(value).lower()


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": (
            "POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_MATERIALIZED"
            if all_note_checks_pass
            else "POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_NOT_MATERIALIZED"
        ),
        "landing_requires_authority_crossing": note_check_map["landing_requires_authority_crossing"],
        "landing_forbids_prior_formd": note_check_map["landing_forbids_prior_formd"],
        "formd_is_operator_engine": note_check_map["formd_is_operator_engine"],
        "triad_keeps_both_members_separate": note_check_map["triad_keeps_both_members_separate"],
        "operational_report_distinguishes_recompute_vs_supersede": note_check_map["operational_report_distinguishes_recompute_vs_supersede"],
        "same_route_authority_crossing_landed": False,
        "reviewer_visible_formd_present": False,
        "all_note_checks_pass": all_note_checks_pass,
    }

    verdict = {
        "verdict": status_summary["verdict"],
        "landing_class_event": "lawful Q-owned promotable response-authority crossing inside the preserved current route",
        "supersession_class_event": "real reviewer-visible Form D operator engine reordering the route from above",
        "noncollapse_rule": "Form D may reopen the line but does not silently count as proof that the current route crossed its own authority tooth",
    }

    report_lines = [
        "# Authority Crossing Versus Form D Supersession Discriminator Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- landing requires same-route authority crossing: `{tf(status_summary['landing_requires_authority_crossing'])}`",
        f"- landing forbids prior `Form D` supersession: `{tf(status_summary['landing_forbids_prior_formd'])}`",
        f"- `Form D` remains one operator-engine class: `{tf(status_summary['formd_is_operator_engine'])}`",
        f"- reopening triad keeps both members separate: `{tf(status_summary['triad_keeps_both_members_separate'])}`",
        f"- live report distinguishes recompute vs supersede: `{tf(status_summary['operational_report_distinguishes_recompute_vs_supersede'])}`",
        f"- all note checks pass: `{tf(status_summary['all_note_checks_pass'])}`",
        "",
        "## Reading",
        "",
        "- authority crossing is one landing-class same-route event,",
        "- `Form D` is one engine-grade supersession-class event from above,",
        "- the two can both belong to the above-line reopening grammar,",
        "- but they do not have the same verdict consequence.",
        "",
        "## Non-collapse rule",
        "",
        "- do not treat `Form D` arrival as silent proof that the current route crossed its own authority tooth,",
        "- do not treat same-route authority crossing as automatic proof that one engine-grade `Form D` exists.",
        "",
        "## Ceiling",
        "",
        "- this report does not claim either class already landed,",
        "- it does not claim exact landing already happened,",
        "- it does not claim widening is already forced.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    (OUTPUT_ROOT / "AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
