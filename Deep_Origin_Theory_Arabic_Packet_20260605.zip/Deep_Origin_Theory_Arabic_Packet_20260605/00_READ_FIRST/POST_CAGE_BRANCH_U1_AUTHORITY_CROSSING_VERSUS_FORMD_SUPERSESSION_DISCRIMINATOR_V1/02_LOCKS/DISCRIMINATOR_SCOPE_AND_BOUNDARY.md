# Discriminator Scope And Boundary

Date: `2026-06-11`

Status: `scope lock`

## This object claims

- the current route already distinguishes authority crossing from `Form D`
  supersession,
- authority crossing is one landing-class same-route event,
- `Form D` is one engine-grade supersession-class event from above,
- and the two may not be silently merged into one flat reopening label.

## This object does not claim

- that authority crossing already happened,
- that `Form D` already happened,
- that exact landing already happened,
- that widening is already forced,
- or that one class is impossible in principle.

## This object fails if

1. the landing criteria no longer require one same-route authority surface
   for landing,
2. the landing criteria no longer forbid prior `Form D` supersession before
   same-route landing,
3. failure family `C` no longer classifies `Form D` as route supersession,
4. the allowed authoring forms no longer define `Form D` as one operator
   engine,
5. or the triad object no longer keeps authority crossing and `Form D` as
   separate above-line members.
