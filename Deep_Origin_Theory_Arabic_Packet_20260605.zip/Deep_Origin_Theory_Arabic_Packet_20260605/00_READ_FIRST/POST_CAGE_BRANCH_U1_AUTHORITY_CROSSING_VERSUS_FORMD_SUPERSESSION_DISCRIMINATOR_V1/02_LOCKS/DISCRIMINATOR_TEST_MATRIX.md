# Discriminator Test Matrix

Date: `2026-06-11`

Status: `test matrix`

## Required confirmations

1. same-route landing criteria still require one lawful `Q`-owned
   promotable response-authority surface on the same route.
2. same-route landing criteria still forbid prior `Form D` supersession.
3. failure family `C` still classifies `Form D` as route supersession rather
   than same-route landing.
4. the allowed authoring forms still define `Form D` as one source-governed
   operator engine.
5. the reopening triad still enumerates authority crossing and `Form D` as
   two separate above-line classes.
6. the landing-state report still distinguishes:
   recompute if authority crossing appears first,
   supersede if `Form D` appears first.

## Passing interpretation

If all six confirmations hold,
the present route now supports:

- authority crossing = landing-class same-route event
- `Form D` = supersession-class reopening from above

## Failing interpretation

If any confirmation fails,
the distinction must be recomputed before it is reused.
