# Evidence Map

Date: `2026-06-11`

Status: `evidence routing`

## Governing evidence surfaces

1. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EXACT_VANISHING_LANDING_TEST_V1/02_LOCKS/LANDING_CRITERIA_AND_FAILURE_SIGNATURES.md`
   - fixes authority crossing as a same-route landing requirement
   - fixes `Form D` as route supersession if it appears first

2. `artifacts/debt_board_20260530/L2_QCT_NUMERIC_KERNEL_AUTHORING_GATE_V1/02_LOCKS/ALLOWED_AUTHORING_FORMS.md`
   - fixes `Form D` as one source-governed operator engine

3. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_REOPENING_TRIAD_AFTER_FORMABC_NO_GO_V1/01_BACKBONE/MANUSCRIPT.md`
   - fixes authority crossing and `Form D` as separate above-line triad
     members

4. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EXACT_VANISHING_LANDING_TEST_V1/04_OUTPUTS/EXACT_VANISHING_LANDING_TEST_REPORT.md`
   - fixes the operational distinction:
     recompute on authority crossing,
     supersede on `Form D`
