# Authority Crossing Versus Form D Supersession Discriminator Report

Generated at: `2026-06-12T15:30:03.226594+00:00`

Verdict: `POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_MATERIALIZED`

## Summary

- landing requires same-route authority crossing: `true`
- landing forbids prior `Form D` supersession: `true`
- `Form D` remains one operator-engine class: `true`
- reopening triad keeps both members separate: `true`
- live report distinguishes recompute vs supersede: `true`
- all note checks pass: `true`

## Reading

- authority crossing is one landing-class same-route event,
- `Form D` is one engine-grade supersession-class event from above,
- the two can both belong to the above-line reopening grammar,
- but they do not have the same verdict consequence.

## Non-collapse rule

- do not treat `Form D` arrival as silent proof that the current route crossed its own authority tooth,
- do not treat same-route authority crossing as automatic proof that one engine-grade `Form D` exists.

## Ceiling

- this report does not claim either class already landed,
- it does not claim exact landing already happened,
- it does not claim widening is already forced.
