# Post-Cage Branch U1 Authority Crossing Versus Form D Supersession Discriminator

Date: `2026-06-11`

Status: `reviewer-facing class discriminator object`

## Purpose

This object does **not** claim:

- that one lawful same-route authority crossing already exists,
- that one reviewer-visible `Form D` engine already exists,
- that exact landing already happened,
- that widening is already forced,
- or that true `L0` crossing already exists.

It claims something narrower and operationally decisive:

1. the current frozen route already carries one reopening triad above the
   promotable response-authority tooth,
2. but the first two members of that triad are not one interchangeable
   event class,
3. and the route already contains enough material to discriminate them
   exactly.

## Short verdict

The first two above-line classes now have one cleaner exact reading:

1. one lawful `Q`-owned promotable response-authority crossing is one
   **landing-class same-route event** inside the preserved current route,
2. one real reviewer-visible `Form D` engine is one
   **engine-grade supersession event** that reorders the route from above,
3. so `Form D` may reopen the line,
   but it does **not** count as silent proof that the current route crossed
   its own authority tooth.

That distinction is now reviewer-visible rather than merely implied.

## 1. Why authority crossing is a landing-class event

The current landing criteria already fix that present same-route landing
requires:

1. typed `U2` triggers remain not yet fired,
2. the same-carrier ledger and closure gates remain intact,
3. one lawful `Q`-owned promotable response-authority surface becomes
   materially visible on the same route,
4. and no hidden widening import contaminates the claim.

So authority crossing is not one external replacement class.

It is one internal crossing event inside the preserved ownership map.

That is why the landing-state object says:

- if one lawful `Q`-owned authority crossing appears first,
  the landing state must be recomputed.

The route is still being judged as itself.

## 2. Why `Form D` is a supersession-class event

The same landing criteria also already fix:

- no real `Form D` engine may have superseded the route before a same-route
  landing claim is made.

And the failure-signature family is explicit:

- if one real reviewer-visible `Form D` engine appears first and lawfully
  changes the route order,
  the route is superseded rather than judged landed or widened.

So `Form D` is not the same thing as:

- current-route authority tooth crossed.

It is one higher engine-grade event that reorders the route from above.

## 3. Why the two classes cannot be silently merged

The current authoring gate already fixes:

- `Form D` = one source-governed operator engine producing the needed
  outputs.

That is stronger than:

- one presently judged same-route authority crossing.

The first class answers:

- did the current route cross its authority tooth while preserving its own
  landing map?

The second class answers:

- did one later engine arrive that lawfully replaces or reorders the route?

Those are not the same scientific event.

So one reader may not collapse them into:

- “somehow the route reopened.”

The reopening happened by different classes,
with different verdict consequences.

## 4. Relation to the reopening triad

The triad object remains correct.

It says the exact above-line classes are:

1. lawful same-route authority crossing,
2. real reviewer-visible `Form D`,
3. genuinely fired typed `U2` trigger.

This discriminator tightens only one thing:

- the first class is landing-class reopening inside the preserved route,
- the second class is supersession-class reopening from above,
- the third class is widening, not reopening on the same route.

So the triad is now internally typed more sharply than before.

## 5. What falls below the line after this discriminator

After this object,
the following shortcuts fall below the line:

- treating `Form D` arrival as if the current route already crossed its own
  authority tooth,
- treating one same-route authority crossing as if it automatically proves
  one engine-grade supersession,
- or writing “reopened” in one flat sense that launders the difference
  between landing-class and supersession-class events.

That is a genuine rigor gain.

## 6. What should supersede this object

This object should be superseded immediately if later lawful work shows:

1. one same-route authority crossing actually lands and a new landing-class
   verdict replaces the present distinction,
2. one real reviewer-visible `Form D` engine actually appears and a new
   supersession-class verdict replaces the present distinction,
3. or one fired typed `U2` trigger makes the whole comparison downstream to
   honest widening.

Until then,
this discriminator remains the cleanest exact grammar the current route
allows.

## Bottom line

The present route now carries one sharper bounded gain above the reopening
triad.

`Authority crossing` and `Form D` are no longer merely two names in one list.

They are now fixed as two distinct above-line classes:

- landing-class same-route crossing,
- versus engine-grade supersession from above.
