# Gate Test Matrix

Date: `2026-06-11`

Status: `test matrix`

## Required confirmations

1. the minimum crossing signature remains materialized.
2. the current-repo no-go remains materialized.
3. the route still distinguishes authority crossing from `Form D`.
4. the worksheet/admission filters still reject observational borrowing,
   hidden second carrierhood,
   and external authority patching.
5. the gate can therefore route future candidates into:
   `ADMIT`,
   `REJECT`,
   or
   `SUPERSEDE`.

## Passing interpretation

If all five confirmations hold,
the decision gate is materialized and current-route output is:

- `reject_current_repo_visible_witnesses`

## Failing interpretation

If any confirmation fails,
the gate must be recomputed before reuse.
