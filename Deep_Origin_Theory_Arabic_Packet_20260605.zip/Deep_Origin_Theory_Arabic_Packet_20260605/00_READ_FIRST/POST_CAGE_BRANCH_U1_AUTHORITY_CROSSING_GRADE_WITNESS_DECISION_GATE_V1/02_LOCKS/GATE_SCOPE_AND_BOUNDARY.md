# Gate Scope And Boundary

Date: `2026-06-11`

Status: `scope lock`

## This gate claims

- witness claims are now routed by one exact `admit / reject / supersede`
  grammar,
- same-route crossing-grade witnesses must satisfy the frozen minimum
  signature,
- below-line or regressive candidates are rejected,
- and `Form D` / fired `U2` events are routed to supersession rather than
  same-route crossing.

## This gate does not claim

- that one admitted witness already exists,
- that one superseding event already exists,
- that permanent impossibility is proven,
- or that whole-program closure is finished.

## This gate fails if

1. the minimum crossing signature is no longer frozen,
2. the current-repo no-go is no longer materialized,
3. the class discriminator no longer distinguishes same-route crossing from
   `Form D`,
4. or the rejection lines no longer fence off observational borrowing,
   hidden second carrierhood,
   and external authority patching.
