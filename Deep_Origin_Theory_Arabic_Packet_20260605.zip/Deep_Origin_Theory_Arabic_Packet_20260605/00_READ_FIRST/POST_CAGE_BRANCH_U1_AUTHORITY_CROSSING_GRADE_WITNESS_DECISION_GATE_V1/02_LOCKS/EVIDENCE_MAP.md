# Evidence Map

Date: `2026-06-11`

Status: `evidence routing`

## Core evidence surfaces

1. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_MINIMUM_SIGNATURE_V1/04_OUTPUTS/AUTHORITY_CROSSING_MINIMUM_SIGNATURE_REPORT.md`
   - freezes the minimum crossing signature

2. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_MINIMUM_SIGNATURE_CURRENT_REPO_NO_GO_V1/04_OUTPUTS/AUTHORITY_CROSSING_MINIMUM_SIGNATURE_CURRENT_REPO_NO_GO_REPORT.md`
   - fixes the present current-route result as no witness-grade materialization

3. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_V1/04_OUTPUTS/AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_REPORT.md`
   - fixes same-route crossing versus `Form D` supersession

4. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_QF1_IF1_FIRST_TYPED_WORKSHEET_NOTE_20260608.md`
   - provides immediate rejection lines for observational borrowing and
     hidden carrier leaks

5. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_NO_REGRESSION_ADMISSION_FILTER_NOTE_20260608.md`
   - provides rejection lines for hidden second carrierhood,
     separate south field,
     external authority patch,
     and bridge carrier leakage
