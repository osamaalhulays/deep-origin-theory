# Authority Crossing-Grade Witness Decision Gate Report

Generated at: `2026-06-12T15:30:02.958875+00:00`

Verdict: `POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_GRADE_WITNESS_DECISION_GATE_MATERIALIZED`

## Summary

- minimum crossing signature frozen: `true`
- current-repo no-go already materialized: `true`
- crossing remains distinct from `Form D`: `true`
- worksheet rejection lines present: `true`
- admission-filter rejection lines present: `true`
- current route gate result: `reject_current_repo_visible_witnesses`
- all note checks pass: `true`

## Gate grammar

- `ADMIT` if one same-route crossing-grade witness satisfies the frozen minimum signature.
- `REJECT` if the candidate stays below the line or violates branch honesty.
- `SUPERSEDE` if the real event is `Form D` or fired typed `U2` rather than same-route crossing.

## Current route result

- current repo-visible witness candidates are rejected at this stage.

## Ceiling

- this report does not claim permanent impossibility,
- it does not claim `Form D` is impossible,
- it does not claim `U2` is already forced.
