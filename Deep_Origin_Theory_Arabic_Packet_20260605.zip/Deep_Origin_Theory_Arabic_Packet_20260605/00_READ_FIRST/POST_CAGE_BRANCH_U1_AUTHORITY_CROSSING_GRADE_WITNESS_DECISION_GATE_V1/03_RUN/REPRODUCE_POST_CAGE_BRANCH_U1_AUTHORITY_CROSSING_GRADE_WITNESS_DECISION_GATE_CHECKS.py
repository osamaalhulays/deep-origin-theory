#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"

SIGNATURE_REPORT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_MINIMUM_SIGNATURE_V1/04_OUTPUTS/AUTHORITY_CROSSING_MINIMUM_SIGNATURE_REPORT.md"
CURRENT_NO_GO_REPORT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_MINIMUM_SIGNATURE_CURRENT_REPO_NO_GO_V1/04_OUTPUTS/AUTHORITY_CROSSING_MINIMUM_SIGNATURE_CURRENT_REPO_NO_GO_REPORT.md"
DISCRIMINATOR_REPORT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_V1/04_OUTPUTS/AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_REPORT.md"
WORKSHEET_NOTE = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_QF1_IF1_FIRST_TYPED_WORKSHEET_NOTE_20260608.md"
ADMISSION_FILTER = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_NO_REGRESSION_ADMISSION_FILTER_NOTE_20260608.md"

NOTE_CHECKS = [
    {
        "key": "signature_materialized",
        "path": SIGNATURE_REPORT,
        "fragments": [
            "Verdict: `POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_MINIMUM_SIGNATURE_MATERIALIZED`",
            "- and the event must remain same-route and non-`Form D` to count as authority crossing.",
        ],
        "meaning": "the minimum crossing signature is frozen",
    },
    {
        "key": "current_repo_no_go_materialized",
        "path": CURRENT_NO_GO_REPORT,
        "fragments": [
            "Verdict: `POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_MINIMUM_SIGNATURE_CURRENT_REPO_NO_GO_MATERIALIZED`",
            "- but the current repo-visible route still does not materialize a witness-grade surface satisfying it,",
        ],
        "meaning": "the current repo-visible route already fails the admit side of the gate",
    },
    {
        "key": "crossing_vs_formd_distinguished",
        "path": DISCRIMINATOR_REPORT,
        "fragments": [
            "- authority crossing is one landing-class same-route event,",
            "- `Form D` is one engine-grade supersession-class event from above,",
        ],
        "meaning": "same-route crossing remains distinct from Form D supersession",
    },
    {
        "key": "worksheet_rejection_lines_present",
        "path": WORKSHEET_NOTE,
        "fragments": [
            "5. transport closure needs one external patch",
            "6. the authority step is closed by observational borrowing",
        ],
        "meaning": "typed worksheet already supplies hard rejection lines against fake witnesses",
    },
    {
        "key": "admission_filter_rejection_lines_present",
        "path": ADMISSION_FILTER,
        "fragments": [
            "1. one hidden second transport-bearing field",
            "3. one external response-authority patch",
            "4. one bridge carrier not really owned by `Q`",
        ],
        "meaning": "no-regression filter already rejects hidden carrier and patch leakage",
    },
]


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
if WORKSPACE_ROOT is None:
    raise RuntimeError("could not locate workspace root from witness-decision gate runner")


def read_text(logical_relative_path: str) -> str:
    return (WORKSPACE_ROOT / logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": item["path"],
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def tf(value: bool) -> str:
    return str(value).lower()


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    gate_result = "reject_current_repo_visible_witnesses" if all_note_checks_pass else "gate_not_ready"

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": (
            "POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_GRADE_WITNESS_DECISION_GATE_MATERIALIZED"
            if all_note_checks_pass
            else "POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_GRADE_WITNESS_DECISION_GATE_NOT_MATERIALIZED"
        ),
        "signature_materialized": note_check_map["signature_materialized"],
        "current_repo_no_go_materialized": note_check_map["current_repo_no_go_materialized"],
        "crossing_vs_formd_distinguished": note_check_map["crossing_vs_formd_distinguished"],
        "worksheet_rejection_lines_present": note_check_map["worksheet_rejection_lines_present"],
        "admission_filter_rejection_lines_present": note_check_map["admission_filter_rejection_lines_present"],
        "current_route_gate_result": gate_result,
        "all_note_checks_pass": all_note_checks_pass,
    }

    verdict = {
        "verdict": status_summary["verdict"],
        "current_route_gate_result": gate_result,
        "admit_if": [
            "one Q-owned promotable evaluator/value authority becomes materially visible on the same route",
            "the ownership of the jump remains with Q",
            "no hidden widening import is needed",
            "no prior Form D supersession is doing the real work",
            "the witness is reviewer-visible enough to count as a crossing-grade package",
        ],
        "reject_if": [
            "bounded probe only",
            "symbolic operator grammar only",
            "placeholder/template authority pack only",
            "callable-free naming of future evaluator authority",
            "observational borrowing closes the authority step",
            "hidden second carrier or independent south carrier appears",
            "external response-authority patch appears",
            "bridge carrier is not really owned by Q",
        ],
        "supersede_if": [
            "a real reviewer-visible Form D engine appears first",
            "a typed U2 trigger fires first",
        ],
    }

    report_lines = [
        "# Authority Crossing-Grade Witness Decision Gate Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- minimum crossing signature frozen: `{tf(status_summary['signature_materialized'])}`",
        f"- current-repo no-go already materialized: `{tf(status_summary['current_repo_no_go_materialized'])}`",
        f"- crossing remains distinct from `Form D`: `{tf(status_summary['crossing_vs_formd_distinguished'])}`",
        f"- worksheet rejection lines present: `{tf(status_summary['worksheet_rejection_lines_present'])}`",
        f"- admission-filter rejection lines present: `{tf(status_summary['admission_filter_rejection_lines_present'])}`",
        f"- current route gate result: `{status_summary['current_route_gate_result']}`",
        f"- all note checks pass: `{tf(status_summary['all_note_checks_pass'])}`",
        "",
        "## Gate grammar",
        "",
        "- `ADMIT` if one same-route crossing-grade witness satisfies the frozen minimum signature.",
        "- `REJECT` if the candidate stays below the line or violates branch honesty.",
        "- `SUPERSEDE` if the real event is `Form D` or fired typed `U2` rather than same-route crossing.",
        "",
        "## Current route result",
        "",
        "- current repo-visible witness candidates are rejected at this stage.",
        "",
        "## Ceiling",
        "",
        "- this report does not claim permanent impossibility,",
        "- it does not claim `Form D` is impossible,",
        "- it does not claim `U2` is already forced.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    (OUTPUT_ROOT / "AUTHORITY_CROSSING_GRADE_WITNESS_DECISION_GATE_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
