# Post-Cage Branch U1 Authority Crossing-Grade Witness Decision Gate

Date: `2026-06-11`

Status: `reviewer-facing decision-gate object`

## Purpose

This object does **not** claim:

- that one same-route crossing-grade witness already exists,
- that `Form D` already exists,
- that `U2` is already forced,
- or that full closure already happened.

It claims something narrower and operationally decisive:

1. the minimum crossing signature is already frozen,
2. the current repo-visible route already has one scoped no-go against hidden
   crossing witnesses,
3. and any later claimed witness can now be routed through one exact
   `admit / reject / supersede` gate.

## Short verdict

The present route no longer needs one vague future judgment about authority
crossing witnesses.

It now has one exact gate with three possible outcomes:

1. `ADMIT`
   if one witness truly satisfies the same-route crossing-grade signature,
2. `REJECT`
   if the object remains below the line or violates branch honesty,
3. `SUPERSEDE`
   if the event is not same-route crossing at all,
   but one `Form D` supersession or one fired typed `U2` trigger.

On the **current repo-visible frozen route**,
the gate already reads:

- `CURRENT_ROUTE_GATE_RESULT = reject_current_repo_visible_witnesses`

because no witness-grade crossing surface is presently materialized.

## 1. `ADMIT` rule

Admit one candidate as same-route crossing-grade witness only if **all** of
the following hold:

1. bounded probe is no longer the top live object,
2. one `Q`-owned promotable evaluator / value authority becomes materially
   visible on the same route,
3. the ownership of the jump to that authority remains with `Q`,
4. the event survives without one hidden second carrier,
   one independent south carrier,
   one external patch,
   or one observational borrowing shortcut,
5. no prior `Form D` supersession is doing the real work,
6. and the witness is reviewer-visible enough to count as one crossing-grade
   package rather than one phrase.

## 2. `REJECT` rule

Reject one candidate immediately if it is any of the following:

1. bounded probe only,
2. symbolic operator grammar only,
3. placeholder/template row pack only,
4. callable-free naming of future evaluator authority,
5. observational borrowing that closes the authority step from data rather
   than from one lawful source-governed step,
6. one hidden second transport-bearing carrier,
7. one independent south carrier disguised as bookkeeping,
8. one external response-authority patch,
9. or one bridge carrier not really owned by `Q`.

Those are not crossing-grade witnesses.

They are below-line or regressive candidates.

## 3. `SUPERSEDE` rule

Do **not** admit or reject as same-route crossing if the real event is one of
the following:

1. one real reviewer-visible `Form D` engine appears first,
2. one typed `U2` trigger fires first.

In those cases,
the route is no longer waiting for same-route crossing judgment.

It is superseded by:

- engine-grade route replacement from above,
  or
- honest widening.

## 4. Why the current route already routes to `REJECT`

The current repo-visible no-go already fixes:

- no direct authority pack is visible,
- no callable evaluator family / emitted bundle is visible,
- no `Q`-owned promotable authority surface is visible,
- and same-route crossing remains non-`Form D`.

So the current route already fails the `ADMIT` side of this gate.

That is why the present output is not suspense.

It is one bounded gate result:

- reject current repo-visible witness candidates

without claiming permanent impossibility.

## 5. Exact operational meaning

This gate means:

- future witness claims no longer enter by mood,
- future witness claims no longer enter by naming,
- and future witness claims no longer enter by flattening `Form D`,
  widening,
  and same-route crossing into one blended hope.

They now enter by one exact decision gate only.

## 6. What should supersede this object

This gate should be refreshed immediately if:

1. one real crossing-grade witness appears and the result flips to `ADMIT`,
2. one real `Form D` engine appears and the result flips to `SUPERSEDE_FORMD`,
3. or one typed `U2` trigger fires and the result flips to
   `SUPERSEDE_U2`.

Until then,
the current gate remains:

- reject current repo-visible witness candidates.

## Bottom line

This cluster is now governed more tightly than before.

We no longer have:

- one live tooth,
- one signature,
- and one no-go only.

We now also have:

- one exact decision gate routing every claimed witness to:
  `admit`,
  `reject`,
  or
  `supersede`.
