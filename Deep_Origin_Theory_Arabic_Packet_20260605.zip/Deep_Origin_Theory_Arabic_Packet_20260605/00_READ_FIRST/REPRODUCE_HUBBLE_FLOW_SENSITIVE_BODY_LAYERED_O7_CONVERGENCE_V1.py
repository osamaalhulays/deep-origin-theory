#!/usr/bin/env python3
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent

HUBBLE_BODY_PATH = HERE / "HUBBLE_FLOW_SENSITIVE_BODY_FULL_CLOSURE_V1.json"
PRIMARY_CORE_PATH = HERE / "PRIMARY_PARITY_CORE_TRIAD_ORDER_AND_UNIFORM_COMPONENT_HARDENING_V1.json"
REOPENING_TRIAD_PATH = HERE / "RESIDUAL_QUALITY1_REOPENING_TRIAD_CLOSURE_V1.json"
RESERVE_NGC5033_PATH = HERE / "NGC5033_FIRST_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json"
RESERVE_UGC02487_PATH = HERE / "UGC02487_SECOND_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json"
RESERVE_UGC03205_PATH = HERE / "UGC03205_THIRD_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json"
QUALITY2_SIDECAR_PATH = HERE / "UGC05253_BOUNDED_QUALITY2_SIDECAR_ENTRY_V1.json"
O7_TAIL_NOTE_PATH = HERE / "BEST_DRESSED_ADVERSARIAL_COMPARATOR_O7_TAIL_STATUS_NOTE_20260608.md"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_text(path: Path):
    return path.read_text(encoding="utf-8")


def extract_backticked_tokens(text: str):
    return re.findall(r"`([^`]+)`", text)


def flexible_heading_regex(heading: str):
    return re.sub(r"\\ ", r"\\s+", re.escape(heading))


def extract_following_bullet_cases(text: str, heading: str):
    pattern = flexible_heading_regex(heading) + r"\s*\n\s*\n((?:- `[^`\n]+`\n)+)"
    match = re.search(pattern, text)
    if not match:
        raise ValueError(f"Could not locate bullet block after heading: {heading}")
    return extract_backticked_tokens(match.group(1))


def extract_inline_layer_cases(text: str, label: str):
    pattern = r"- " + re.escape(label) + r":\n  (.+)"
    match = re.search(pattern, text)
    if not match:
        raise ValueError(f"Could not locate inline layer: {label}")
    return extract_backticked_tokens(match.group(1))


def close_enough(left, right, tolerance=1e-9):
    return abs(left - right) <= tolerance


def load_hubble_member_catalog():
    members = {}

    primary_core = load_json(PRIMARY_CORE_PATH)
    for row in primary_core["ordered_core"]:
        members[row["case_id"]] = {
            "case_id": row["case_id"],
            "segment": "primary_parity_core",
            "public_delta_aic_total": row["public_delta_aic_total"],
            "faithful_delta_aic_total": row["faithful_delta_aic_total"],
            "component_aware_delta_aic_total": row["component_aware_delta_aic_total"],
            "component_aware_shift": row["component_aware_shift"],
            "quality_flag": row["quality_flag"],
        }

    reopening_triad = load_json(REOPENING_TRIAD_PATH)
    for row in reopening_triad["witnesses"]:
        members[row["case_id"]] = {
            "case_id": row["case_id"],
            "segment": "residual_quality1_reopening_triad",
            "public_delta_aic_total": row["public_delta_aic_total"],
            "faithful_delta_aic_total": row["faithful_delta_aic_total"],
            "component_aware_delta_aic_total": row["component_aware_delta_aic_total"],
            "component_aware_shift": row["component_aware_shift"],
            "quality_flag": 1,
        }

    for path, segment in (
        (RESERVE_NGC5033_PATH, "quality1_reserve_triplet"),
        (RESERVE_UGC02487_PATH, "quality1_reserve_triplet"),
        (RESERVE_UGC03205_PATH, "quality1_reserve_triplet"),
        (QUALITY2_SIDECAR_PATH, "bounded_quality2_sidecar"),
    ):
        row = load_json(path)["witness"]
        members[row["case_id"]] = {
            "case_id": row["case_id"],
            "segment": segment,
            "public_delta_aic_total": row["public_delta_aic_total"],
            "faithful_delta_aic_total": row["faithful_delta_aic_total"],
            "component_aware_delta_aic_total": row["component_aware_delta_aic_total"],
            "component_aware_shift": row["component_aware_shift"],
            "quality_flag": row["quality_flag"],
        }

    return members


def summarize_members(case_ids, member_catalog):
    ordered = [member_catalog[case_id] for case_id in case_ids]
    public_total = sum(row["public_delta_aic_total"] for row in ordered)
    faithful_total = sum(row["faithful_delta_aic_total"] for row in ordered)
    component_total = sum(row["component_aware_delta_aic_total"] for row in ordered)
    shift_total = sum(row["component_aware_shift"] for row in ordered)
    return {
        "case_count": len(ordered),
        "cases": case_ids,
        "public_delta_aic_total": public_total,
        "faithful_delta_aic_total": faithful_total,
        "component_aware_delta_aic_total": component_total,
        "component_aware_shift": shift_total,
    }


def segment_breakdown(case_ids, member_catalog):
    segment_map = {}
    for case_id in case_ids:
        segment = member_catalog[case_id]["segment"]
        segment_map.setdefault(segment, []).append(case_id)
    return [
        {"segment": segment, "cases": cases, "case_count": len(cases)}
        for segment, cases in sorted(segment_map.items())
    ]


def main():
    hubble_body = load_json(HUBBLE_BODY_PATH)
    member_catalog = load_hubble_member_catalog()
    o7_tail_note = load_text(O7_TAIL_NOTE_PATH)

    opening_band = extract_following_bullet_cases(
        o7_tail_note,
        "It then opened the largest branch, the nonshared local-public positive spoiler-retaining band, with:",
    )
    second_severe_triad = extract_following_bullet_cases(
        o7_tail_note,
        "It then materialized a second severe positive-spoiler-band triad:",
    )
    third_depth_triad = extract_following_bullet_cases(
        o7_tail_note,
        "Kreib then materialized a third depth triad:",
    )
    mixed_shift_persistence = extract_inline_layer_cases(
        o7_tail_note,
        "mixed-shift persistence",
    )

    body_cases = hubble_body["witnesses"]
    o7_layers = {
        "opening_positive_spoiler_band": opening_band,
        "second_severe_positive_spoiler_band_triad": second_severe_triad,
        "third_depth_triad": third_depth_triad,
        "mixed_shift_persistence_layer": mixed_shift_persistence,
    }

    case_to_o7_layer = {}
    for layer_name, cases in o7_layers.items():
        for case_id in cases:
            if case_id in body_cases:
                case_to_o7_layer[case_id] = layer_name

    intersecting_cases = [case_id for case_id in body_cases if case_id in case_to_o7_layer]
    remainder_cases = [case_id for case_id in body_cases if case_id not in case_to_o7_layer]

    intersecting_summary = summarize_members(intersecting_cases, member_catalog)
    remainder_summary = summarize_members(remainder_cases, member_catalog)
    full_body_summary = summarize_members(body_cases, member_catalog)

    intersecting_segments = segment_breakdown(intersecting_cases, member_catalog)
    remainder_segments = segment_breakdown(remainder_cases, member_catalog)

    consistency_checks = {
        "full_body_case_count_is_ten": len(body_cases) == 10,
        "member_catalog_matches_full_body_case_count": len(member_catalog) == len(body_cases),
        "opening_band_intersection_is_ugc09133_and_ugc06787": (
            set(opening_band) & set(body_cases)
        ) == {"SPARC_UGC09133", "SPARC_UGC06787"},
        "second_severe_intersection_is_ugc02953_and_ugc06786": (
            set(second_severe_triad) & set(body_cases)
        ) == {"SPARC_UGC02953", "SPARC_UGC06786"},
        "third_depth_intersection_is_ugc05253_and_ugc03205": (
            set(third_depth_triad) & set(body_cases)
        ) == {"SPARC_UGC05253", "SPARC_UGC03205"},
        "mixed_shift_intersection_is_ugc02487": (
            set(mixed_shift_persistence) & set(body_cases)
        ) == {"SPARC_UGC02487"},
        "intersection_case_count_is_seven": len(intersecting_cases) == 7,
        "intersection_and_remainder_exhaust_body": set(intersecting_cases) | set(remainder_cases)
        == set(body_cases),
        "intersection_and_remainder_are_disjoint": set(intersecting_cases).isdisjoint(
            set(remainder_cases)
        ),
        "intersection_spans_four_distinct_o7_layers": len(set(case_to_o7_layer.values())) == 4,
        "intersection_touches_all_four_current_body_segments": {
            row["segment"] for row in intersecting_segments
        }
        == {
            "primary_parity_core",
            "residual_quality1_reopening_triad",
            "quality1_reserve_triplet",
            "bounded_quality2_sidecar",
        },
        "full_body_public_total_matches_closure": close_enough(
            full_body_summary["public_delta_aic_total"],
            hubble_body["combined_burden"]["public_delta_aic_total"],
        ),
        "full_body_faithful_total_matches_closure": close_enough(
            full_body_summary["faithful_delta_aic_total"],
            hubble_body["combined_burden"]["faithful_delta_aic_total"],
        ),
        "full_body_component_total_matches_closure": close_enough(
            full_body_summary["component_aware_delta_aic_total"],
            hubble_body["combined_burden"]["component_aware_delta_aic_total"],
        ),
        "full_body_shift_total_matches_closure": close_enough(
            full_body_summary["component_aware_shift"],
            hubble_body["combined_burden"]["component_aware_shift"],
        ),
        "intersection_and_remainder_public_totals_recombine_exactly": close_enough(
            intersecting_summary["public_delta_aic_total"] + remainder_summary["public_delta_aic_total"],
            full_body_summary["public_delta_aic_total"],
        ),
        "intersection_and_remainder_component_totals_recombine_exactly": close_enough(
            intersecting_summary["component_aware_delta_aic_total"]
            + remainder_summary["component_aware_delta_aic_total"],
            full_body_summary["component_aware_delta_aic_total"],
        ),
        "intersection_and_remainder_shift_totals_recombine_exactly": close_enough(
            intersecting_summary["component_aware_shift"] + remainder_summary["component_aware_shift"],
            full_body_summary["component_aware_shift"],
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "bounded_packet_facing_cross_lane_reinforcement",
        "surface": "hubble_flow_sensitive_body_layered_o7_convergence",
        "full_hubble_flow_sensitive_body": {
            "case_count": len(body_cases),
            "cases": body_cases,
            "public_delta_aic_total": full_body_summary["public_delta_aic_total"],
            "faithful_delta_aic_total": full_body_summary["faithful_delta_aic_total"],
            "component_aware_delta_aic_total": full_body_summary["component_aware_delta_aic_total"],
            "component_aware_shift": full_body_summary["component_aware_shift"],
        },
        "o7_positive_spoiler_intersection": {
            **intersecting_summary,
            "fraction_of_body_case_count": intersecting_summary["case_count"] / len(body_cases),
            "fraction_of_body_public_delta_aic_total": intersecting_summary["public_delta_aic_total"]
            / full_body_summary["public_delta_aic_total"],
            "fraction_of_body_faithful_delta_aic_total": intersecting_summary["faithful_delta_aic_total"]
            / full_body_summary["faithful_delta_aic_total"],
            "fraction_of_body_component_aware_delta_aic_total": intersecting_summary[
                "component_aware_delta_aic_total"
            ]
            / full_body_summary["component_aware_delta_aic_total"],
            "fraction_of_body_component_aware_shift": intersecting_summary["component_aware_shift"]
            / full_body_summary["component_aware_shift"],
            "case_to_o7_layer": {case_id: case_to_o7_layer[case_id] for case_id in intersecting_cases},
            "distinct_o7_layer_count": len(set(case_to_o7_layer.values())),
            "layer_breakdown": [
                {
                    "layer": "opening_positive_spoiler_band",
                    "cases": [case_id for case_id in intersecting_cases if case_to_o7_layer[case_id] == "opening_positive_spoiler_band"],
                },
                {
                    "layer": "second_severe_positive_spoiler_band_triad",
                    "cases": [case_id for case_id in intersecting_cases if case_to_o7_layer[case_id] == "second_severe_positive_spoiler_band_triad"],
                },
                {
                    "layer": "third_depth_triad",
                    "cases": [case_id for case_id in intersecting_cases if case_to_o7_layer[case_id] == "third_depth_triad"],
                },
                {
                    "layer": "mixed_shift_persistence_layer",
                    "cases": [case_id for case_id in intersecting_cases if case_to_o7_layer[case_id] == "mixed_shift_persistence_layer"],
                },
            ],
            "segment_breakdown": intersecting_segments,
            "source_note": O7_TAIL_NOTE_PATH.name,
        },
        "current_nonintersecting_remainder": {
            **remainder_summary,
            "fraction_of_body_case_count": remainder_summary["case_count"] / len(body_cases),
            "fraction_of_body_public_delta_aic_total": remainder_summary["public_delta_aic_total"]
            / full_body_summary["public_delta_aic_total"],
            "fraction_of_body_component_aware_delta_aic_total": remainder_summary[
                "component_aware_delta_aic_total"
            ]
            / full_body_summary["component_aware_delta_aic_total"],
            "segment_breakdown": remainder_segments,
        },
        "structural_reading": {
            "most_of_the_current_hubble_flow_sensitive_body_is_already_independently_materialized_inside_layered_o7_positive_spoiler_space": True,
            "the_cross_lane_reinforcement_is_not_confined_to_the_primary_core": True,
            "the_intersection_touches_every_current_body_segment_from_primary_core_through_quality2_sidecar": True,
            "the_reinforcement_is_strong_but_not_total_because_a_three_witness_remainder_still_exists": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "seven of ten Hubble-flow-sensitive body members already materialize inside layered O7 positive-spoiler space",
            "that seven-witness subset spans four distinct internal O7 layers",
            "that subset already carries most of the body burden rather than a minor fringe share",
            "the cross-lane reinforcement extends beyond the primary core into reopening reserve and bounded quality2 continuation",
        ],
        "not_supported_now": [
            "The whole Hubble-flow-sensitive body is already exhausted inside O7 positive-spoiler space",
            "The three-witness remainder is irrelevant",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_frontier": [
            "test whether the current three-witness remainder later materializes inside the same O7 branch or stays structurally separate",
            "extend the cross-observable court without collapsing O6 body membership and O7 layer materialization into one identity claim",
        ],
    }

    output["verdict"] = (
        "HUBBLE_FLOW_SENSITIVE_BODY_LAYERED_O7_CONVERGENCE_CLOSED__SEVEN_OF_TEN_BODY_MEMBERS_ALREADY_SPAN_FOUR_DISTINCT_O7_POSITIVE_SPOILER_LAYERS_AND_CARRY_MOST_OF_THE_BODY_BURDEN"
        if all(consistency_checks.values())
        else "HUBBLE_FLOW_SENSITIVE_BODY_LAYERED_O7_CONVERGENCE_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
