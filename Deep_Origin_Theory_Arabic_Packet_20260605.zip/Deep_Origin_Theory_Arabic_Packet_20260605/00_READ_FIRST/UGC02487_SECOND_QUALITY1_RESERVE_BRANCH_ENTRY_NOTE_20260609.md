# `UGC02487` Second Quality-`1` Reserve Branch Entry Note

Date: `2026-06-09`

Status: `bounded packet-facing cross-archive refresh`

Purpose:

This note absorbs the second governed reserve witness after explicit reserve
entry at `NGC5033`.

It should be read after:

- `NGC5033_FIRST_QUALITY1_RESERVE_BRANCH_ENTRY_NOTE_20260609.md`

Machine-readable companion:

- `UGC02487_SECOND_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json`

Direct continuation now materialized in:

- `UGC03205_THIRD_QUALITY1_RESERVE_BRANCH_ENTRY_NOTE_20260609.md`

## Short verdict

`UGC02487` is no longer only the prepared next reserve witness.

It now closes as the second quality-`1` reserve branch entry witness.

It remains anti-`QCT` on public, faithful, and component-aware surfaces,
it preserves exact public-`QUMOND` codepath protection,
and component-aware replay still hardens further away from `QCT`.

## 1. Bounded reserve-second-entry surface

The bounded surface for `UGC02487` is:

- public `Delta AIC_total = +5395.448939562626`
- faithful matched-nuisance `Delta AIC_total = +4194.204085355166`
- component-aware matched-nuisance `Delta AIC_total = +4616.2697654791955`
- component-aware shift = `+422.0656801240293`
- faithful/public `QUMOND` absolute gap = `0.0`

So the second reserve entry is not a rescue for `QCT`.

It is another same-sign anti-`QCT` witness inside the reserve body.

## 2. Why `UGC02487` is the correct second reserve witness

### A. It is the heaviest remaining witness after `NGC5033`

- reserve-triplet burden share = `33.95509479828456%`
- remaining reserve-pair burden share = `52.2833064613493%`
- queue rank = `2`

### B. It still stands ahead of the last reserve witness

- public excess over `UGC03205` = `+471.25800793378676`

### C. It remains the calmer of the two remaining reserve witnesses under component-aware replay

- `UGC02487` component-aware shift = `+422.0656801240293`
- `UGC03205` component-aware shift = `+638.6767423112506`

### D. It remains source-lawful and quality-`1`

- distance flag = `1`
- distance error = `10.4 Mpc`
- inclination error = `5.0 deg`
- quality flag = `1`

## 3. What this does and does not change

This note means:

- the second reserve witness is now explicit at execution grade
- the bounded reserve queue now advances honestly to `UGC03205`

This note does **not** mean:

- that the reserve triplet is already closed
- that `UGC03205` can be skipped
- that bounded quality-`2` may already be entered
- that the whole `MOND/QUMOND` court is now closed

## 4. Next honest escalation

The direct continuation from this point is now materialized separately in:

- `UGC03205_THIRD_QUALITY1_RESERVE_BRANCH_ENTRY_NOTE_20260609.md`

## Best outward-safe reading

One mature outward-safe sentence is:

> After `NGC5033` opens the quality-`1` reserve body,
> `UGC02487` now closes as the second reserve witness.
> It remains anti-`QCT` on public, faithful, and component-aware surfaces,
> preserves exact public-`QUMOND` protection,
> and advances the bounded reserve queue honestly to `UGC03205`.
