#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORKSPACE_ROOT = HERE.parents[1]

START_HERE_PATH = HERE / "START_HERE_FIRST.md"
FAST_PATH_MAP_PATH = HERE / "FAST_PATH_AND_EVIDENCE_MAP.md"
KEY_QUESTIONS_PATH = HERE / "KEY_QUESTIONS_AND_SCOPE.md"
BASENAME_FREEZE_NOTE_PATH = HERE / "PACKET_BASENAME_FREEZE_AND_FRONT_DOOR_REVISION_SCOPE_NOTE_20260606.md"
PARKING_CORNER_PATH = HERE / "CURRENT_PACKET_PUBLICATION_PARKING_CORNER_V1.json"
FRONT_TO_EVIDENCE_PATH = HERE / "CURRENT_REVIEWER_FACING_FRONT_TO_EVIDENCE_SPINE_V1.json"
REVIEW_FACE_PATH = HERE / "CURRENT_REVIEWER_FACING_REVIEW_LAUNCH_PACKET_FACE_V1.json"
MASTER_FRONT_PATH = HERE / "CURRENT_REVIEWER_FACING_MASTER_FRONT_V1.json"
PRIMARY_ZIP_PATH = WORKSPACE_ROOT / "Deep_Origin_Theory_English_Packet_20260605.zip"
LATEST_ZIP_PATH = WORKSPACE_ROOT / "Deep_Origin_Theory_English_Packet_20260605__20260609_latest.zip"

PARKING_NOTE_NAME = "CURRENT_PACKET_PUBLICATION_PARKING_CORNER_NOTE_20260609.md"
CHECKLIST_NOTE_NAME = "CURRENT_PACKET_PUBLICATION_CLEANUP_CHECKLIST_NOTE_20260609.md"
TENSION_JSON_NAME = "CURRENT_REVIEWER_FACING_ROUTE_SPLIT_AND_FULL_BODY_EMPIRICAL_TENSION_V1.json"
POCKET_JSON_NAME = "CURRENT_REVIEWER_FACING_NARROW_QUALITY1_CONTINUATION_POCKET_BOUNDARY_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_text(path: Path):
    return path.read_text(encoding="utf-8")


def reading_state_branch(payload: dict) -> dict:
    return payload.get("what_follows_from_this_state") or payload.get(
        "what_belongs_after_this_corner", {}
    )


def maintenance_priorities(payload: dict) -> list:
    branch = reading_state_branch(payload)
    return branch.get("maintenance_priorities") or branch.get("cleanup_only_mode", [])


def future_revision_criteria(payload: dict) -> list:
    branch = reading_state_branch(payload)
    return branch.get("future_revision_criteria") or branch.get(
        "do_not_reopen_development_without", []
    )


def reading_state_rejects_scientific_finality(payload: dict) -> bool:
    options = {
        "this reading state means scientific finality",
        "this parking corner means scientific finality",
    }
    return any(option in payload["not_supported_now"] for option in options)


def reading_state_rejects_whole_family_closure(payload: dict) -> bool:
    options = {
        "this reading state means whole-family MOND_QUMOND closure",
        "this parking corner means whole-family MOND_QUMOND closure",
    }
    return any(option in payload["not_supported_now"] for option in options)


def reading_state_surface_is_closed(payload: dict) -> bool:
    verdict = payload["verdict"]
    return verdict.startswith("CURRENT_PACKET_PUBLICATION_READING_STATE_CLOSED__") or verdict.startswith(
        "CURRENT_PACKET_PUBLICATION_PARKING_CORNER_CLOSED__"
    )


def main():
    start_here = load_text(START_HERE_PATH)
    fast_path = load_text(FAST_PATH_MAP_PATH)
    key_questions = load_text(KEY_QUESTIONS_PATH)
    reading_state = load_json(PARKING_CORNER_PATH)
    front_to_evidence = load_json(FRONT_TO_EVIDENCE_PATH)
    review_face = load_json(REVIEW_FACE_PATH)
    master_front = load_json(MASTER_FRONT_PATH)

    front_door_surface_sync = {
        "start_here_exposes_reading_state_note": PARKING_NOTE_NAME in start_here,
        "start_here_exposes_cleanup_checklist": CHECKLIST_NOTE_NAME in start_here,
        "fast_path_exposes_reading_state_note": PARKING_NOTE_NAME in fast_path,
        "fast_path_exposes_cleanup_checklist": CHECKLIST_NOTE_NAME in fast_path,
        "key_questions_exposes_reading_state_note": PARKING_NOTE_NAME in key_questions,
    }

    reviewer_route_sync = {
        "front_to_evidence_carries_tension_digest": TENSION_JSON_NAME
        in front_to_evidence["reviewer_facing_front_to_evidence_spine"][
            "rotation_evidence_bundle"
        ]["subbundles"]["matched_nuisance_parity_evidence"]["primary_surfaces"],
        "front_to_evidence_carries_pocket_boundary_digest": POCKET_JSON_NAME
        in front_to_evidence["reviewer_facing_front_to_evidence_spine"][
            "rotation_evidence_bundle"
        ]["subbundles"]["best_dressed_hardening_evidence"]["primary_surfaces"],
        "review_face_carries_tension_digest": TENSION_JSON_NAME
        in review_face["launch_route"]["rotation_evidence_surfaces"][
            "matched_nuisance_parity_evidence"
        ]["primary_surfaces"],
        "review_face_carries_pocket_boundary_digest": POCKET_JSON_NAME
        in review_face["launch_route"]["rotation_evidence_surfaces"][
            "best_dressed_hardening_evidence"
        ]["primary_surfaces"],
        "master_front_carries_explicit_tension_reading": master_front["structural_reading"][
            "the_front_now_sits_above_one_explicit_local_route_split_beside_one_much_larger_same_sign_hardening_body"
        ],
    }

    artifact_readiness = {
        "basename_freeze_note_present": BASENAME_FREEZE_NOTE_PATH.exists(),
        "primary_zip_exists": PRIMARY_ZIP_PATH.exists() and PRIMARY_ZIP_PATH.stat().st_size > 0,
        "latest_zip_exists": LATEST_ZIP_PATH.exists() and LATEST_ZIP_PATH.stat().st_size > 0,
        "reading_state_surface_present": PARKING_CORNER_PATH.exists(),
    }

    maintenance_scope_discipline = {
        "reading_state_explicitly_rejects_scientific_finality": reading_state_rejects_scientific_finality(
            reading_state
        ),
        "reading_state_explicitly_rejects_whole_family_closure": reading_state_rejects_whole_family_closure(
            reading_state
        ),
        "future_revision_criteria_are_explicit": (len(future_revision_criteria(reading_state)) == 3),
        "maintenance_priorities_are_explicit": (len(maintenance_priorities(reading_state)) >= 5),
    }

    consistency_checks = {
        **front_door_surface_sync,
        **reviewer_route_sync,
        **artifact_readiness,
        **maintenance_scope_discipline,
        "reading_state_surface_itself_is_closed": reading_state_surface_is_closed(reading_state),
    }

    output = {
        "date": "2026-06-09",
        "status": "publication_facing_maintenance_checklist",
        "surface": "current_packet_publication_maintenance_checklist",
        "front_door_surface_sync": front_door_surface_sync,
        "reviewer_route_sync": reviewer_route_sync,
        "artifact_readiness": {
            **artifact_readiness,
            "primary_zip_path": str(PRIMARY_ZIP_PATH),
            "latest_zip_path": str(LATEST_ZIP_PATH),
        },
        "maintenance_scope_discipline": maintenance_scope_discipline,
        "remaining_maintenance_priorities": maintenance_priorities(reading_state),
        "future_revision_criteria": future_revision_criteria(reading_state),
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the packet now has one explicit publication-cleanup checklist rather than one implicit cleanup mood",
            "front-door notes and reviewer-route surfaces now expose the same reading-state and maintenance grammar",
            "the packet now has one stable bounded checklist to reuse on later update passes before republishing the zip",
            "publication cleanup remains explicitly separated from silent claim inflation",
        ],
        "not_supported_now": [
            "maintenance mode may drift back into widening by habit",
            "the packet should be republished without rechecking front-door route sync",
            "the packet should shift scope without one evidence-led reason",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_continuation": [
            "use this checklist on every later publication-cleanup pass before rebuilding the release zip",
            "keep future front-door revisions synchronized with the same reviewer-route surfaces instead of patching one layer alone",
        ],
    }

    output["verdict"] = (
        "CURRENT_PACKET_PUBLICATION_MAINTENANCE_CHECKLIST_CLOSED__THE_PACKET_NOW_HAS_ONE_EXPLICIT_MAINTENANCE_BASELINE_FOR_FRONT_DOOR_SYNC_REVIEWER_ROUTE_SYNC_ARTIFACT_READINESS_AND_SCOPE_DISCIPLINE"
        if all(consistency_checks.values())
        else "CURRENT_PACKET_PUBLICATION_CLEANUP_CHECKLIST_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
