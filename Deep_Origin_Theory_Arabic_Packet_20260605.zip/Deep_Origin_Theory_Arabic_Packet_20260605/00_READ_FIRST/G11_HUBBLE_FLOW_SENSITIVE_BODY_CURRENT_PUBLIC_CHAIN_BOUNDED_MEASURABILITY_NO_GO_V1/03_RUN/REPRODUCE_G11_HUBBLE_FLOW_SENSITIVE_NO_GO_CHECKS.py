#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"
PACKET_ROOT_NAME = "Deep_Origin_Theory_English_Packet_20260605"


def find_workspace_root() -> Path:
    for parent in THIS_FILE.parents:
        if (parent / PACKET_ROOT_NAME).exists() and (parent / "artifacts").exists():
            return parent
    raise RuntimeError("could not locate workspace root from G11 runner")


WORKSPACE_ROOT = find_workspace_root()
PACKET_ROOT = WORKSPACE_ROOT / PACKET_ROOT_NAME

CURRENT_G11_NOTE = (
    PACKET_ROOT
    / "00_READ_FIRST"
    / "CURRENT_G11_HUBBLE_FLOW_SENSITIVE_BODY_CLASSIFICATION_IS_EMPIRICAL_ONLY_UNTIL_ONE_QCT_INTERNAL_FAILURE_THEOREM_OR_BOUNDED_NO_GO_NOTE_20260612.md"
)
FORMC_SCHEMA = (
    PACKET_ROOT
    / "00_READ_FIRST"
    / "G4_FORM_C_SOURCE_GOVERNED_L2_EVALUATOR_V1"
    / "02_SCHEMA"
    / "INPUT_OUTPUT_SCHEMA.md"
)
FORMD_SCHEMA = (
    WORKSPACE_ROOT
    / "artifacts"
    / "debt_board_20260530"
    / "g4_external_intake"
    / "G4_L0_FIRST_CROSSING_ENGINE_V1"
    / "02_SCHEMA"
    / "AUTHOR_FREEZE_INPUT_TRIPLE_SCHEMA.md"
)
ANTI_QCT_PROTOCOL = (
    PACKET_ROOT
    / "00_READ_FIRST"
    / "ANTI_QCT_CASE_INVESTIGATION_PROTOCOL_AND_FIRST_PASS_TOPOLOGY_NOTE_20260608.md"
)
BODY_NOTE = (
    PACKET_ROOT
    / "00_READ_FIRST"
    / "NAMED_EXECUTED_MATCHED_NUISANCE_COURT_MORPHOLOGY_PARTITION_NOTE_20260609.md"
)
MANUSCRIPT_PATH = OBJECT_ROOT / "01_BACKBONE" / "MANUSCRIPT.md"
SCOPE_PATH = OBJECT_ROOT / "02_LOCKS" / "SCOPE_AND_BOUNDARY.md"
EVIDENCE_MAP_PATH = OBJECT_ROOT / "02_LOCKS" / "EVIDENCE_MAP.md"


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


NOTE_CHECKS = [
    {
        "key": "current_g11_wound_explicit",
        "path": CURRENT_G11_NOTE,
        "fragments": [
            "typed empirical classification is already present,",
            "internal source-side explanation is not yet present.",
        ],
    },
    {
        "key": "formc_schema_source_only",
        "path": FORMC_SCHEMA,
        "fragments": [
            "r_m,rho_b_kg_m3,gbar_m_s2",
            "m_inv_m1",
            "x_i = log10(gbar_i)",
        ],
    },
    {
        "key": "formd_schema_source_and_observed_only",
        "path": FORMD_SCHEMA,
        "fragments": [
            "r_m,rho_b_kg_m3,gbar_m_s2",
            "\"m_inv_m1\"",
            "benchmark_bin_id,x_i,log10_gobs_observed,sigma_log10_gobs",
        ],
    },
    {
        "key": "parity_layer_requires_external_sensitivity_coordinates",
        "path": ANTI_QCT_PROTOCOL,
        "fragments": [
            "distance uncertainty,",
            "inclination uncertainty,",
            "component-aware baryonic rematerialization from raw source",
        ],
    },
    {
        "key": "named_hubble_body_is_real",
        "path": BODY_NOTE,
        "fragments": [
            "The ten-witness Hubble-flow-sensitive body now carries:",
            "all ten remain anti-`QCT`",
            "all ten harden further away from `QCT` under component-aware parity",
        ],
    },
    {
        "key": "manuscript_measurability_no_go_written",
        "path": MANUSCRIPT_PATH,
        "fragments": [
            "Sigma_src",
            "Lambda_HFS",
            "not yet measurable",
            "G11_CLOSED_BY_BOUNDED_CURRENT_PUBLIC_CHAIN_MEASURABILITY_NO_GO",
        ],
    },
    {
        "key": "scope_lock_written",
        "path": SCOPE_PATH,
        "fragments": [
            "one bounded current-public-chain no-go for `G11`",
            "no claim that `QCT` can never explain the Hubble-flow-sensitive body",
            "no silent promotion from current-chain no-go to eternal theory no-go",
        ],
    },
    {
        "key": "evidence_map_written",
        "path": EVIDENCE_MAP_PATH,
        "fragments": [
            "CURRENT_G11_HUBBLE_FLOW_SENSITIVE_BODY_CLASSIFICATION_IS_EMPIRICAL_ONLY_UNTIL_ONE_QCT_INTERNAL_FAILURE_THEOREM_OR_BOUNDED_NO_GO_NOTE_20260612.md",
            "G4_FORM_C_SOURCE_GOVERNED_L2_EVALUATOR_V1/02_SCHEMA/INPUT_OUTPUT_SCHEMA.md",
            "AUTHOR_FREEZE_INPUT_TRIPLE_SCHEMA.md",
        ],
    },
]


ABSENCE_TOKENS = [
    "distance_uncertainty",
    "inclination_uncertainty",
    "hubble_flow",
    "peculiar_velocity",
    "flow_model",
    "distance_sigma",
    "inclination_sigma",
]


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": str(item["path"]),
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def collect_absence_scan() -> dict:
    source_chain_files = [FORMC_SCHEMA, FORMD_SCHEMA]
    results = []
    all_clear = True
    for path in source_chain_files:
        text = read_text(path)
        token_hits = {token: (token in text) for token in ABSENCE_TOKENS}
        clear = not any(token_hits.values())
        all_clear = all_clear and clear
        results.append(
            {
                "path": str(path),
                "token_hits": token_hits,
                "clear": clear,
            }
        )
    return {
        "all_clear": all_clear,
        "files": results,
    }


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def tf(value: bool) -> str:
    return str(value).lower()


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    absence_scan = collect_absence_scan()
    all_note_checks_pass = all(item["passed"] for item in note_checks)

    verdict = (
        "G11_CLOSED_BY_BOUNDED_CURRENT_PUBLIC_CHAIN_MEASURABILITY_NO_GO"
        if all_note_checks_pass and absence_scan["all_clear"]
        else "G11_NOT_YET_CLOSED_BY_BOUNDED_CURRENT_PUBLIC_CHAIN_MEASURABILITY_NO_GO"
    )

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": verdict,
        "named_hubble_body_is_real": True,
        "empirical_classification_already_present": True,
        "current_public_chain_internal_theorem_present": False,
        "bounded_no_go_materialized": verdict.startswith("G11_CLOSED"),
        "current_public_source_chain_omits_explicit_flow_parity_carriers": absence_scan["all_clear"],
        "all_note_checks_pass": all_note_checks_pass,
    }

    verdict_payload = {
        "verdict": verdict,
        "current_public_source_chain_state_layer": [
            "r_m",
            "rho_b(r)",
            "gbar(r)",
            "m_inv",
            "x_i bins",
            "optional observed rows",
            "Delta rows / prediction rows / first comparison stack",
        ],
        "required_hubble_sensitive_layer": [
            "distance uncertainty",
            "inclination uncertainty",
            "quality-aware masking grammar",
            "component-aware baryonic rematerialization",
            "matched-nuisance hardening sign across the named court",
        ],
        "closure_effect": [
            "G11 closes by bounded no-go on the current public chain",
            "the packet may preserve the Hubble-flow-sensitive body as a real empirical class",
            "the packet may not silently relabel that class as already internally source-derived",
        ],
        "ceiling": [
            "not an eternal no-go for all future QCT work",
            "not a denial of the empirical body",
            "not a reopening of blunt family defeat",
            "not cosmology completion",
        ],
    }

    report_lines = [
        "# G11 Current Public-Chain Bounded Measurability No-Go Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- named Hubble-flow-sensitive body already real: `{tf(status_summary['named_hubble_body_is_real'])}`",
        f"- empirical classification already present: `{tf(status_summary['empirical_classification_already_present'])}`",
        f"- current public-chain internal theorem already present: `{tf(status_summary['current_public_chain_internal_theorem_present'])}`",
        f"- explicit flow/parity carriers absent from current public source chain: `{tf(status_summary['current_public_source_chain_omits_explicit_flow_parity_carriers'])}`",
        f"- bounded no-go materialized: `{tf(status_summary['bounded_no_go_materialized'])}`",
        "",
        "## Reading",
        "",
        "- the present packet carries the empirical body honestly,",
        "- the present packet also carries lawful parity / flow sensitivity as an external lane grammar,",
        "- but those sensitivity coordinates are not public state variables of the current source-governed chain,",
        "- so the current chain cannot yet lawfully derive the Hubble-flow-sensitive class from inside itself.",
        "",
        "## Ceiling",
        "",
        "- this closes only the current-chain branch,",
        "- it does not say no future enriched public chain can ever derive that class,",
        "- and it does not promote empirical classification into internal explanation.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "absence_scan.json", absence_scan)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict_payload)
    (OUTPUT_ROOT / "G11_CURRENT_PUBLIC_CHAIN_BOUNDED_MEASURABILITY_NO_GO_REPORT.md").write_text(
        "\n".join(report_lines),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
