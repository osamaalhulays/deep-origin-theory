# Current `G6` / `D7` `PAYLOAD_B` Downstream-Use Boundary Note

Date: `2026-06-12`

Purpose:

Freeze the exact bounded downstream-use grammar for the first real Pavel
direct-author `PAYLOAD_B` landing so the empirical payload is not silently
misread as theory-side authoring or as one already normalized baryonic source
profile.

## Short verdict

The fair current reading is:

- the payload really closes `G6`
- and really closes `D7` at `PAYLOAD_B_admit`
- but it does **not** by itself authorize silent conversion into one theory-
  side source profile
- and it does **not** by itself fix one unique later rematerialization rule
  for every downstream use

## Exact landed shape

- `49` observed files
- `49` baryonic component files
- `49 / 49` matched galaxy pairs
- total observed rows = `1082`
- total baryonic rows = `4850`
- all baryonic files are oversampled relative to the observed rows

## What this payload is

This payload is:

- one lawful direct-author empirical `L2` payload
- one machine-readable observed-plus-components landing
- one bounded diagnostic-grade empirical input family

## What this payload is not

This payload is **not**:

- one direct `rho_b(r)` source-density profile pack
- one theory-side `Form A/B/C/D` authoring object
- one automatic `G4` crossing authorization
- one proof of `NGC4214` because that target is not in the landed set

## Exact downstream hygiene constraints

Any later downstream use must keep the following explicit:

1. `gbar` may be rematerialized from component curves only through one openly
   declared component rule
2. no silent conversion from circular-speed components to `rho_b(r)` may be
   claimed
3. negative gas-component rows must not be silently absolute-squared
4. duplicate radii must be normalized by one declared rule before strict-grid
   interpolation
5. optional bulge `nan` rows must be handled only by one declared bounded
   rule

## Exact visible flags in the landed payload

- negative `VHI` rows are visible
- negative `VH2` rows are visible
- `DDO210_vbaryons.dat` contains duplicate rounded radii
- some optional bulge rows appear as `nan`

These flags do **not** damage `G6` / `D7` closure.

They only constrain later rematerialization discipline.

## Safe present conclusion

The safe present conclusion is:

- `G6` / `D7` are closed at `PAYLOAD_B` grade
- later empirical use is lawful
  only if its normalization choices stay explicit
- and theory-side authoring remains distinct from this payload lane

## Read with

- `CURRENT_G6_L2_DIRECT_AUTHOR_PAYLOAD_ARRIVED_AND_CLASSIFIED_AS_PAYLOAD_B_NOTE_20260612.md`
- `CURRENT_D7_L2_PAYLOAD_B_ADMIT_BOUNDED_VERDICT_NOTE_20260612.md`
