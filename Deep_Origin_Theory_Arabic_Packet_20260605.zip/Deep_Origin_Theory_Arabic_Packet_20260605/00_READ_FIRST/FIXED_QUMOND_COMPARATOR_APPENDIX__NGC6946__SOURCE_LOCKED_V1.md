# Fixed-QUMOND Comparator Appendix — NGC6946 (Source-Locked Read)

Date: `2026-06-05`

Status: `bounded public appendix`

## Purpose

This appendix answers one reviewer request that remained open after the first
`NGC0247` spear:

- do we now have a **second** named row-readable fixed-`QUMOND` witness,
  rather than only one fully auditable galaxy plus a panel of remembered
  offender names?

Short answer:

- `yes, for NGC6946 in bounded holdout-spear form`

## Scope rule

This appendix **does** publish:

- one source-locked fixed-`QUMOND` row comparator for `NGC6946`,
- the per-row `v_obs ± sigma`,
- the preserved `v_bar`,
- the derived fixed-`QUMOND` velocity under the locked simple-`nu(y)` rule,
- the per-row fixed-`QUMOND` residual,
- the per-row obs-only `chi^2` contribution for that fixed comparator,
- and the paired oracle `delta_true` sign pattern.

This appendix does **not** claim:

- that the exact production benchmark table with fitted `Υ` has now been
  published for `NGC6946`,
- that one case-level `ΔAIC/ΔBIC` bridge is now public for this case,
- that one current public `v_QCT_current` row comparator is now closed here,
- or that full `MOND/QUMOND` non-reducibility has been finished.

## Provenance

This table is assembled from three preserved local sources:

- the preserved `NGC6946` joined SPARC source-side radial case for
  `R`, `v_obs`, `sigma_v`, and `v_bar`,
- `QUMOND_COMPARISON_PLAN.md` for the locked benchmark definition,
- and `epic30_oracle_points.ndjson` for the row-wise oracle `delta_true`.

## Fixed-comparator rule used here

The fixed source-locked comparator shown here uses the same public benchmark
definition already frozen in the packet:

- `a0 = 1.2 × 10^-10 m/s^2`
- simple `nu(y) = 0.5 + sqrt(0.25 + 1/y)`

with:

- `g_bar = v_bar^2 / R`
- `y = g_bar / a0`
- `v_QUMOND = v_bar * sqrt(nu(y))`

This makes the second named comparator explicit and inspectable without
pretending that the full fitted-`Υ` production benchmark table is already
public.

## Frozen summary

- row count = `58`
- all fixed-`QUMOND` row residuals are negative in this source-locked read
- source-locked fixed-`QUMOND` obs-only `chi^2_total = 31659.570`
- mean absolute fixed-`QUMOND` residual = `59.968 km/s`
- max absolute fixed-`QUMOND` residual = `82.922 km/s`
- oracle `delta_true` sign split = `29` negative / `29` positive
- oracle `delta_true_min = -0.25`
- oracle `delta_true_max = 0.25`

The bounded comparison point is therefore clear:

- the oracle witness changes sign across radius,
- while the explicit fixed-`QUMOND` residual remains one-sided and negative
  across all `58` preserved rows in this source-locked read.

That does **not** yet finish the whole anti-`MOND/QUMOND` question.
But it does make the second named witness materially easier to audit and
materially harder to dismiss as one-galaxy anecdote.

## Row-by-row fixed comparator table

| Row | r/r_max | R (kpc) | v_obs ± σ (km/s) | v_bar (km/s) | v_QUMOND (km/s) | residual_QUMOND (km/s) | χ² contrib. | delta_true | sign |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--: |
| 1 | 0.0093 | 0.19 | 153.0 ± 8.0 | 234.4 | 235.9 | -82.9 | 107.439 | -0.250000 | - |
| 2 | 0.0275 | 0.56 | 130.0 ± 9.0 | 179.8 | 185.1 | -55.1 | 37.528 | -0.250000 | - |
| 3 | 0.0461 | 0.94 | 128.0 ± 3.0 | 165.1 | 174.3 | -46.3 | 237.810 | -0.250000 | - |
| 4 | 0.0598 | 1.22 | 134.0 ± 3.0 | 162.8 | 174.5 | -40.5 | 182.033 | -0.231949 | - |
| 5 | 0.0779 | 1.59 | 129.0 ± 4.0 | 165.8 | 180.2 | -51.2 | 164.121 | -0.250000 | - |
| 6 | 0.0961 | 1.96 | 131.0 ± 7.0 | 168.0 | 184.9 | -53.9 | 59.388 | -0.250000 | - |
| 7 | 0.1147 | 2.34 | 138.0 ± 8.0 | 174.5 | 193.6 | -55.6 | 48.349 | -0.250000 | - |
| 8 | 0.1328 | 2.71 | 139.0 ± 5.0 | 185.2 | 206.0 | -67.0 | 179.384 | -0.250000 | - |
| 9 | 0.1466 | 2.99 | 143.0 ± 3.0 | 187.2 | 209.4 | -66.4 | 490.518 | -0.250000 | - |
| 10 | 0.1652 | 3.37 | 146.0 ± 2.0 | 191.5 | 215.6 | -69.6 | 1212.101 | -0.250000 | - |
| 11 | 0.1833 | 3.74 | 154.0 ± 2.0 | 193.6 | 219.7 | -65.7 | 1078.296 | -0.250000 | - |
| 12 | 0.2020 | 4.12 | 161.0 ± 1.0 | 195.9 | 223.7 | -62.7 | 3934.789 | -0.233858 | - |
| 13 | 0.2157 | 4.40 | 167.0 ± 2.0 | 198.8 | 227.8 | -60.8 | 925.551 | -0.199701 | - |
| 14 | 0.2338 | 4.77 | 173.0 ± 2.0 | 203.0 | 233.6 | -60.6 | 917.863 | -0.176770 | - |
| 15 | 0.2525 | 5.15 | 176.0 ± 4.0 | 207.2 | 239.2 | -63.2 | 249.829 | -0.181766 | - |
| 16 | 0.2706 | 5.52 | 178.0 ± 5.0 | 213.2 | 246.4 | -68.4 | 187.315 | -0.209322 | - |
| 17 | 0.2887 | 5.89 | 180.0 ± 3.0 | 213.4 | 248.3 | -68.3 | 517.947 | -0.193140 | - |
| 18 | 0.3025 | 6.17 | 179.0 ± 4.0 | 210.1 | 246.4 | -67.4 | 284.225 | -0.176740 | - |
| 19 | 0.3211 | 6.55 | 180.0 ± 5.0 | 209.3 | 247.3 | -67.3 | 181.393 | -0.161438 | - |
| 20 | 0.3392 | 6.92 | 181.0 ± 4.0 | 209.9 | 249.4 | -68.4 | 292.609 | -0.156978 | - |
| 21 | 0.3578 | 7.30 | 179.0 ± 4.0 | 207.2 | 248.4 | -69.4 | 301.225 | -0.153477 | - |
| 22 | 0.3716 | 7.58 | 179.0 ± 2.0 | 203.9 | 246.5 | -67.5 | 1138.940 | -0.125877 | - |
| 23 | 0.3897 | 7.95 | 179.0 ± 1.0 | 199.0 | 243.4 | -64.4 | 4148.807 | -0.082174 | - |
| 24 | 0.4083 | 8.33 | 178.0 ± 1.0 | 194.2 | 240.5 | -62.5 | 3904.261 | -0.047498 | - |
| 25 | 0.4265 | 8.70 | 177.0 ± 2.0 | 192.2 | 240.0 | -63.0 | 992.965 | -0.038617 | - |
| 26 | 0.4451 | 9.08 | 176.0 ± 2.0 | 190.6 | 239.9 | -63.9 | 1020.321 | -0.033042 | - |
| 27 | 0.4588 | 9.36 | 173.0 ± 3.0 | 189.0 | 239.4 | -66.4 | 489.982 | -0.049894 | - |
| 28 | 0.4770 | 9.73 | 172.0 ± 2.0 | 186.1 | 238.0 | -66.0 | 1090.142 | -0.031535 | - |
| 29 | 0.4951 | 10.10 | 172.0 ± 2.0 | 183.5 | 236.9 | -64.9 | 1052.212 | -0.003709 | - |
| 30 | 0.5137 | 10.48 | 170.0 ± 2.0 | 180.7 | 235.5 | -65.5 | 1074.074 | 0.003709 | + |
| 31 | 0.5275 | 10.76 | 171.0 ± 2.0 | 178.7 | 234.6 | -63.6 | 1012.294 | 0.038097 | + |
| 32 | 0.5456 | 11.13 | 174.0 ± 2.0 | 175.9 | 233.2 | -59.2 | 876.106 | 0.109653 | + |
| 33 | 0.5642 | 11.51 | 174.0 ± 2.0 | 173.3 | 232.0 | -58.0 | 841.646 | 0.142506 | + |
| 34 | 0.5824 | 11.88 | 175.0 ± 2.0 | 170.9 | 230.9 | -55.9 | 780.066 | 0.189308 | + |
| 35 | 0.6010 | 12.26 | 174.0 ± 2.0 | 168.6 | 229.8 | -55.8 | 779.593 | 0.208247 | + |
| 36 | 0.6147 | 12.54 | 173.0 ± 6.0 | 167.0 | 229.2 | -56.2 | 87.678 | 0.217251 | + |
| 37 | 0.6328 | 12.91 | 173.0 ± 6.0 | 164.9 | 228.3 | -55.3 | 85.052 | 0.247689 | + |
| 38 | 0.6515 | 13.29 | 173.0 ± 8.0 | 163.0 | 227.6 | -54.6 | 46.567 | 0.250000 | + |
| 39 | 0.6696 | 13.66 | 175.0 ± 9.0 | 161.2 | 227.0 | -52.0 | 33.365 | 0.250000 | + |
| 40 | 0.6877 | 14.03 | 174.0 ± 9.0 | 159.5 | 226.3 | -52.3 | 33.808 | 0.250000 | + |
| 41 | 0.7015 | 14.31 | 171.0 ± 9.0 | 158.2 | 225.9 | -54.9 | 37.179 | 0.250000 | + |
| 42 | 0.7201 | 14.69 | 167.0 ± 8.0 | 155.9 | 224.7 | -57.7 | 52.001 | 0.250000 | + |
| 43 | 0.7382 | 15.06 | 165.0 ± 7.0 | 153.5 | 223.3 | -58.3 | 69.484 | 0.250000 | + |
| 44 | 0.7569 | 15.44 | 163.0 ± 8.0 | 151.3 | 222.3 | -59.3 | 54.919 | 0.250000 | + |
| 45 | 0.7706 | 15.72 | 162.0 ± 8.0 | 150.0 | 221.7 | -59.7 | 55.658 | 0.250000 | + |
| 46 | 0.7887 | 16.09 | 161.0 ± 9.0 | 145.4 | 218.2 | -57.2 | 40.356 | 0.250000 | + |
| 47 | 0.8074 | 16.47 | 159.0 ± 10.0 | 143.5 | 217.3 | -58.3 | 33.982 | 0.250000 | + |
| 48 | 0.8255 | 16.84 | 158.0 ± 10.0 | 141.8 | 216.5 | -58.5 | 34.247 | 0.250000 | + |
| 49 | 0.8436 | 17.21 | 157.0 ± 10.0 | 140.2 | 215.8 | -58.8 | 34.523 | 0.250000 | + |
| 50 | 0.8578 | 17.50 | 157.0 ± 10.0 | 138.9 | 215.2 | -58.2 | 33.815 | 0.250000 | + |
| 51 | 0.8760 | 17.87 | 157.0 ± 9.0 | 137.3 | 214.4 | -57.4 | 40.732 | 0.250000 | + |
| 52 | 0.8941 | 18.24 | 160.0 ± 11.0 | 135.8 | 213.8 | -53.8 | 23.916 | 0.250000 | + |
| 53 | 0.9127 | 18.62 | 159.0 ± 12.0 | 134.3 | 213.2 | -54.2 | 20.365 | 0.250000 | + |
| 54 | 0.9265 | 18.90 | 160.0 ± 14.0 | 133.3 | 212.7 | -52.7 | 14.156 | 0.250000 | + |
| 55 | 0.9446 | 19.27 | 158.0 ± 16.0 | 132.0 | 212.2 | -54.2 | 11.472 | 0.250000 | + |
| 56 | 0.9632 | 19.65 | 155.0 ± 18.0 | 130.8 | 211.8 | -56.8 | 9.963 | 0.250000 | + |
| 57 | 0.9814 | 20.02 | 157.0 ± 19.0 | 129.2 | 210.9 | -53.9 | 8.059 | 0.250000 | + |
| 58 | 1.0000 | 20.40 | 154.0 ± 21.0 | 127.6 | 210.1 | -56.1 | 7.148 | 0.250000 | + |

## Use rule

Use this appendix to answer the narrower reviewer question:

- is there now a second named row-readable fixed-`QUMOND` witness beyond
  `NGC0247` itself?

Do **not** use it to claim:

- that `NGC6946` has already reached current replication parity with
  `NGC0247`,
- that a fitted-`Υ` production comparator has been published,
- or that the whole anti-`MOND/QUMOND` program question is finished.
