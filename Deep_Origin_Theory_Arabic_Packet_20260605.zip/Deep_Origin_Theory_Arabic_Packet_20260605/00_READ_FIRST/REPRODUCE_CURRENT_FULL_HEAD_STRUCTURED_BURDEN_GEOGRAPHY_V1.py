#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

THREE_BLOCK_PATH = HERE / "CURRENT_FULL_HEAD_THREE_BLOCK_BURDEN_HIERARCHY_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def close_enough(left, right, tolerance=1e-9):
    return abs(left - right) <= tolerance


def main():
    hierarchy = load_json(THREE_BLOCK_PATH)

    full_head = hierarchy["full_head"]
    heptad = hierarchy["three_block_ordering"]["dominant_o7_reinforced_heptad"]
    quartet = hierarchy["three_block_ordering"]["protected_clean_anchor_quartet"]
    pocket = hierarchy["three_block_ordering"]["localized_quality1_continuation_pocket"]

    structured_pair_case_count = heptad["case_count"] + quartet["case_count"]
    structured_pair_public_delta_aic_total = (
        heptad["public_delta_aic_total"] + quartet["public_delta_aic_total"]
    )
    structured_pair_cases = heptad["cases"] + quartet["cases"]

    consistency_checks = {
        "full_head_case_count_is_fourteen": full_head["case_count"] == 14,
        "structured_pair_and_pocket_recombine_to_full_head_case_count": (
            structured_pair_case_count + pocket["case_count"] == full_head["case_count"]
        ),
        "structured_pair_and_pocket_recombine_to_full_head_public_total": close_enough(
            structured_pair_public_delta_aic_total + pocket["public_delta_aic_total"],
            full_head["public_delta_aic_total"],
        ),
        "structured_pair_case_count_is_eleven": structured_pair_case_count == 11,
        "structured_pair_public_burden_exceeds_eighty_eight_percent": (
            structured_pair_public_delta_aic_total / full_head["public_delta_aic_total"] > 0.88
        ),
        "pocket_public_burden_stays_below_twelve_percent": (
            pocket["public_delta_aic_total"] / full_head["public_delta_aic_total"] < 0.12
        ),
        "structured_pair_public_burden_strictly_exceeds_pocket": (
            structured_pair_public_delta_aic_total > pocket["public_delta_aic_total"]
        ),
        "structured_pair_contains_all_named_middle_and_top_blocks": (
            heptad["case_count"] == 7 and quartet["case_count"] == 4
        ),
        "structured_pair_retains_four_o7_layers_plus_clean_anchor_internal_split": (
            heptad["distinct_o7_layer_count"] == 4
            and quartet["internal_lane_split"]["repeated_toward_qct_singleton"] == ["SPARC_NGC5055"]
            and quartet["internal_lane_split"]["o7_positive_dispersion_triad"]
            == ["SPARC_NGC2841", "SPARC_NGC3198", "SPARC_NGC7331"]
        ),
        "pocket_remains_exact_qumond_protected": pocket["all_cases_have_exact_qumond_protection"],
    }

    output = {
        "date": "2026-06-09",
        "status": "bounded_packet_facing_structured_burden_geography",
        "surface": "current_full_head_structured_burden_geography",
        "full_head": full_head,
        "structured_pair": {
            "case_count": structured_pair_case_count,
            "cases": structured_pair_cases,
            "public_delta_aic_total": structured_pair_public_delta_aic_total,
            "fraction_of_full_head_case_count": structured_pair_case_count / full_head["case_count"],
            "fraction_of_full_head_public_delta_aic_total": (
                structured_pair_public_delta_aic_total / full_head["public_delta_aic_total"]
            ),
            "internal_blocks": {
                "dominant_o7_reinforced_heptad": heptad["cases"],
                "protected_clean_anchor_quartet": quartet["cases"],
            },
        },
        "residual_narrow_pocket": {
            **pocket,
            "fraction_of_full_head_public_delta_aic_total": (
                pocket["public_delta_aic_total"] / full_head["public_delta_aic_total"]
            ),
        },
        "derived_ratios": {
            "structured_pair_to_pocket_public_burden_ratio": (
                structured_pair_public_delta_aic_total / pocket["public_delta_aic_total"]
            ),
            "structured_pair_to_pocket_case_count_ratio": (
                structured_pair_case_count / pocket["case_count"]
            ),
        },
        "structural_reading": {
            "the_current_full_head_is_not_a_diffuse_burden_field": True,
            "most_current_burden_is_already_concentrated_in_two_named_structured_blocks": True,
            "the_remaining_burden_is_real_but_narrow_and_exact_qumond_protected": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "eleven of the fourteen current full-head cases already carry more than eighty-eight percent of the total public burden",
            "that burden is concentrated in one dominant O7-reinforced heptad plus one protected clean-anchor quartet",
            "the residual three-case pocket is real but narrow in current total burden",
            "the current full head is therefore better read as structured burden geography than as a diffuse anti-QCT field",
        ],
        "not_supported_now": [
            "the current full-head burden is broadly and anonymously spread across many unrelated spoiler cases",
            "the narrow exact-QUMOND-protected pocket dominates the current scientific picture",
            "this concentration alone already proves whole-family MOND_QUMOND defeat",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_frontier": [
            "extend the cross-observable court while preserving the difference between present burden geography and final whole-family verdict",
            "test later whether the narrow pocket stays separate or gets absorbed without inflating current claims",
        ],
    }

    output["verdict"] = (
        "CURRENT_FULL_HEAD_STRUCTURED_BURDEN_GEOGRAPHY_CLOSED__MOST_CURRENT_BURDEN_ALREADY_CONCENTRATES_IN_ONE_O7_HEPTAD_PLUS_ONE_PROTECTED_QUARTET_WITH_ONLY_A_NARROW_RESIDUAL_POCKET"
        if all(consistency_checks.values())
        else "CURRENT_FULL_HEAD_STRUCTURED_BURDEN_GEOGRAPHY_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
