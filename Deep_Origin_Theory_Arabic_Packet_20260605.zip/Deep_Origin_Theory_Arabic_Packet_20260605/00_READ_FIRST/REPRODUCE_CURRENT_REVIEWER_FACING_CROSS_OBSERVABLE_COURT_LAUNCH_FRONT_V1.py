#!/usr/bin/env python3
import json
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent

SCOPE_SELECTION_PATH = HERE / "NO_MAKEUP_MOND_QUMOND_CROSS_OBSERVABLE_COURT_SCOPE_SELECTION_V1.json"
COURT_CHARTER_PATH = HERE / "NO_MAKEUP_MOND_QUMOND_CROSS_OBSERVABLE_COURT_DEEP_REASON_AND_EXECUTION_CHARTER_V1.json"
DOUBLE_LAUNCH_PATH = HERE / "NGC0247_FIRST_FULL_BODY_GROUNDED_NO_MAKEUP_COURT_DOUBLE_LAUNCH_V1.json"
NAMED_PARTITION_PATH = HERE / "NAMED_EXECUTED_MATCHED_NUISANCE_COURT_MORPHOLOGY_PARTITION_V1.json"
PRIMARY_PARITY_CORE_PATH = HERE / "PRIMARY_PARITY_CORE_TRIAD_ORDER_AND_UNIFORM_COMPONENT_HARDENING_V1.json"

CLUSTER_DOSSIER_ZIP_PATH = (
    HERE.parent / "03_C_Cluster" / "Deep_Origin_Theory_C_Cluster_Dossier_20260605.zip"
)
MACS1206_RUNTIME_PACKAGE_MANIFEST_PATH = (
    "Deep_Origin_Theory_C_Cluster_Dossier_20260605/"
    "MACS1206_CURRENT_VERSION_RUNTIME_PACKAGE_MANIFEST__V1.json"
)
MACS1206_SAME_KERNEL_CONTEXT_PATH = (
    "Deep_Origin_Theory_C_Cluster_Dossier_20260605/"
    "MACS1206_SOURCE_OBJECT__SAME_KERNEL_CONTEXT_V1.json"
)


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_json_from_zip(zip_path: Path, member: str):
    with zipfile.ZipFile(zip_path, "r") as archive:
        return json.loads(archive.read(member).decode("utf-8"))


def main():
    scope = load_json(SCOPE_SELECTION_PATH)
    charter = load_json(COURT_CHARTER_PATH)
    double_launch = load_json(DOUBLE_LAUNCH_PATH)
    partition = load_json(NAMED_PARTITION_PATH)
    primary_core = load_json(PRIMARY_PARITY_CORE_PATH)

    macs1206_manifest = load_json_from_zip(
        CLUSTER_DOSSIER_ZIP_PATH, MACS1206_RUNTIME_PACKAGE_MANIFEST_PATH
    )
    macs1206_same_kernel = load_json_from_zip(
        CLUSTER_DOSSIER_ZIP_PATH, MACS1206_SAME_KERNEL_CONTEXT_PATH
    )

    expected_lanes = {
        "fixed_comparator_rotation_witness_court",
        "matched_nuisance_parity_court",
        "best_dressed_adversarial_hardening_court",
        "same_kernel_macs1206_secondary_deltasigma_rail",
    }
    not_closed_by_manifest = set(macs1206_manifest["not_closed_by_this_manifest"])

    consistency_checks = {
        "selected_scope_is_the_no_makeup_cross_observable_court": (
            scope["selected_scope"] == "no_makeup_mond_qumond_cross_observable_court"
        ),
        "four_lanes_are_explicitly_frozen": set(scope["selected_scope_contains"]) == expected_lanes
        and set(charter["court_lanes"]) == expected_lanes,
        "court_law_forbids_rescue_collapse_and_drift": (
            charter["governing_law"]["theory_rescue_forbidden"]
            and charter["governing_law"]["lane_collapse_forbidden"]
            and charter["governing_law"]["cross_observable_drift_forbidden"]
            and charter["governing_law"]["full_body_burden_erasure_forbidden"]
        ),
        "rotation_fixed_public_crosscheck_mass_is_visible": (
            scope["rotation_fixed_public_qumond_crosscheck_count_with_zero_public_gap"] == 174
        ),
        "named_rotation_side_is_already_materially_partitioned": (
            partition["named_executed_witness_count"] == 12
            and partition["partitions"]["route_split"]["summary"]["witness_count"] == 1
            and partition["partitions"]["same_sign_softening"]["summary"]["witness_count"] == 1
            and partition["partitions"]["same_sign_hardening_hubble_flow_sensitive_body"]["summary"][
                "witness_count"
            ]
            == 10
        ),
        "ngc0247_remains_the_only_named_route_split_witness": (
            partition["structural_partition"]["only_named_pro_qct_route_split_witness"]
            == "SPARC_NGC0247"
        ),
        "ngc6946_remains_the_only_named_softening_witness": (
            partition["structural_partition"]["only_named_same_sign_softening_witness"]
            == "SPARC_NGC6946"
        ),
        "primary_parity_core_is_closed_as_a_front_block": primary_core["front_block_closure"][
            "primary_parity_core_is_now_closed_as_an_explicit_three_witness_front_block"
        ],
        "ngc0247_double_launch_is_already_compressed_under_shared_rules": (
            double_launch["witness"] == "SPARC_NGC0247"
            and double_launch["shared_launch_rules"]["lane_collapse_forbidden"]
            and double_launch["shared_launch_rules"]["cross_observable_drift_forbidden"]
        ),
        "macs1206_north_rail_is_same_kernel_locked": (
            scope["macs1206_secondary_deltasigma"]["same_kernel_only"]
            and scope["macs1206_secondary_deltasigma"]["no_new_knobs"]
        ),
        "macs1206_runtime_package_candidate_is_visible_but_not_north_closed": (
            macs1206_manifest["status"] == "bounded_runtime_package_candidate"
            and "final_north_ascent_closure_not_materialized" in not_closed_by_manifest
        ),
        "selected_scope_is_still_not_already_executed": (
            "Cross-observable court already executed" in scope["not_supported_now"]
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "packet_contained_reviewer_facing_cross_observable_court_launch_front",
        "surface": "current_reviewer_facing_cross_observable_court_launch_front",
        "governing_court": {
            "selected_scope": scope["selected_scope"],
            "court_lanes": scope["selected_scope_contains"],
            "deep_reason": charter["deep_reason"],
            "governing_law": charter["governing_law"],
            "hard_strike_conditions": charter["hard_strike_conditions"],
        },
        "rotation_side": {
            "fixed_public_qumond_crosscheck_count_with_zero_public_gap": scope[
                "rotation_fixed_public_qumond_crosscheck_count_with_zero_public_gap"
            ],
            "named_executed_witness_count": partition["named_executed_witness_count"],
            "route_split_witness": partition["structural_partition"][
                "only_named_pro_qct_route_split_witness"
            ],
            "same_sign_softening_witness": partition["structural_partition"][
                "only_named_same_sign_softening_witness"
            ],
            "same_sign_hardening_body_witness_count": partition["partitions"][
                "same_sign_hardening_hubble_flow_sensitive_body"
            ]["summary"]["witness_count"],
            "same_sign_hardening_body_public_absolute_burden": partition["partitions"][
                "same_sign_hardening_hubble_flow_sensitive_body"
            ]["summary"]["public_absolute_burden"],
            "primary_parity_core": {
                "members": [entry["case_id"] for entry in primary_core["ordered_core"]],
                "combined_public_delta_aic_total": primary_core["combined_burden"][
                    "public_delta_aic_total"
                ],
                "fraction_of_hubble_flow_sensitive_body": primary_core["combined_burden"][
                    "fraction_of_hubble_flow_sensitive_body"
                ],
                "fraction_of_giant_spiral_head_burden": primary_core["combined_burden"][
                    "fraction_of_giant_spiral_head_burden"
                ],
            },
            "ngc0247_double_launch": {
                "witness": double_launch["witness"],
                "launch_pair": double_launch["launch_pair"],
                "shared_launch_rules": double_launch["shared_launch_rules"],
            },
        },
        "north_rail": {
            "same_kernel_only": scope["macs1206_secondary_deltasigma"]["same_kernel_only"],
            "no_new_knobs": scope["macs1206_secondary_deltasigma"]["no_new_knobs"],
            "shared_overlap_mid_bin_count": scope["macs1206_secondary_deltasigma"][
                "shared_overlap_mid_bin_count"
            ],
            "best_visible_benchmark_member": scope["macs1206_secondary_deltasigma"][
                "best_visible_benchmark_member"
            ],
            "best_visible_member_pte": scope["macs1206_secondary_deltasigma"][
                "best_visible_member_pte"
            ],
            "current_version_runtime_package_status": macs1206_manifest["status"],
            "current_version_runtime_package_authority_read": macs1206_manifest["authority_read"],
            "same_kernel_context_profile_row_count": len(macs1206_same_kernel["profile_rows"]),
            "same_kernel_context_has_closure_annulus_zero_anchor": any(
                row["bin_role"] == "closure_annulus_zero_anchor"
                for row in macs1206_same_kernel["profile_rows"]
            ),
            "not_closed_by_manifest": macs1206_manifest["not_closed_by_this_manifest"],
        },
        "structural_reading": {
            "the_next_court_no_longer_needs_scope_debate_before_packet_facing_launch": True,
            "the_rotation_side_is_already_materially_populated_under_the_frozen_court_law": True,
            "the_north_side_is_already_same_kernel_locked_but_not_authority_closed": True,
            "the_honest_next_move_is_court_launch_not_final_court_victory_language": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the selected no-makeup cross-observable court now has one single reviewer-facing launch front",
            "the rotation side is no longer only a planned court but an already populated governed surface",
            "NGC0247 now carries the explicit double-launch bridge between matched-nuisance and best-dressed lanes",
            "the MACS1206 rail is already same-kernel locked with no new knobs while final north ascent remains explicitly open",
        ],
        "not_supported_now": [
            "the full cross-observable court is already executed",
            "the north rail is already authority-closed",
            "lane collapse between matched-nuisance and best-dressed routes is allowed",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_continuation": [
            "packet_facing_cross_observable_court_launch_under_preserved_lane_distinction_and_same_kernel_north_rail"
        ],
    }

    output["verdict"] = (
        "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LAUNCH_FRONT_CLOSED__THE_ROTATION_SIDE_IS_ALREADY_MATERIALLY_POPULATED_THE_NORTH_RAIL_IS_ALREADY_SAME_KERNEL_LOCKED_AND_THE_SELECTED_NEXT_COURT_NO_LONGER_NEEDS_SCOPE_DEBATE_BEFORE_REVIEWER_FACING_LAUNCH"
        if all(consistency_checks.values())
        else "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LAUNCH_FRONT_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
