# Ownership-Preserving Exact-Vanishing Attempt Test Matrix

Date: `2026-06-10`

Status: `gate matrix`

## Required gates

1. Prior trigger adjudication gate
   Passes only if typed `U2` classes are materialized and still `not yet
   fired`.

2. Same-carrier ledger gate
   Passes only if `T_Q^(0)` remains one same-carrier variational ledger
   admission with no forced `T_S`, no external exchange-current patch, and
   no hidden second transport-bearing companion.

3. Coefficient-law gate
   Passes only if `C_closure^(0)` remains one same-carrier coefficient-law
   sufficiency gate under the ownership map rather than one direct exact
   vanishing claim.

4. Shell-image gate
   Passes only if that same `C_closure^(0)` gate is still read through
   shell-typed `IR1` image sufficiency.

5. Verdict-order gate
   Passes only if the local upper split remains:
   `V_exact^(try)` first,
   `V_U2` only if a typed trigger fires.

## Immediate kill conditions

This attempt object fails immediately if the route requires:

1. one hidden second transport-bearing companion,
2. one independent south carrier,
3. one external exchange-current patch,
4. one widening verdict before the exact-attempt shell can even be posed,
5. one success claim without passing through the attempt shell.

## Allowed current outcome

The allowed current positive outcome is only:

- the attempt object is reviewer-visible and operationally ordered.

The object is still compatible with:

- later exact-attempt failure,
- later lawful widening,
- or later route reordering if a real new operator engine appears.
