from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


SCRIPT_PATH = Path(__file__).resolve()
OBJECT_ROOT = SCRIPT_PATH.parents[1]
ROOT = SCRIPT_PATH.parents[4]
OUTPUTS = OBJECT_ROOT / "04_OUTPUTS"

TYPED_U2_STATUS_PATH = (
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_V1/04_OUTPUTS/status_summary.json"
)
TYPED_U2_VERDICT_PATH = (
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_V1/04_OUTPUTS/verdict.json"
)
TYPED_U2_TRIGGER_MATRIX_PATH = (
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_V1/04_OUTPUTS/trigger_matrix.json"
)

NOTE_CHECKS = [
    {
        "key": "same_carrier_ledger_admission",
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_TQ_OWNERSHIP_FIRST_GATE_LOCALIZES_TO_SAME_CARRIER_VARIATIONAL_LEDGER_ADMISSION_NOTE_20260608.md",
        "fragments": [
            "`T_Q^(0) = same-carrier variational ledger admission`",
            "no `T_S`",
            "no external exchange-current patch",
            "no hidden second transport-bearing companion",
        ],
        "meaning": "the same-carrier ledger admission shell is already fixed",
    },
    {
        "key": "coefficient_law_gate",
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_EXACT_CLOSURE_TEST_FIRST_GATE_LOCALIZES_TO_SAME_CARRIER_COEFFICIENT_LAW_SUFFICIENCY_BEFORE_WIDENING_VERDICT_NOTE_20260608.md",
        "fragments": [
            "`C_closure^(0) = same-carrier coefficient-law sufficiency under the ownership map`",
            "This does **not** yet prove exact vanishing.",
            "widening remains one possible later verdict,",
        ],
        "meaning": "the first pre-vanishing gate is same-carrier coefficient-law sufficiency under ownership",
    },
    {
        "key": "shell_typed_ir1_image_gate",
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CCLOSURE_GATE_LOCALIZES_TO_SHELL_TYPED_IR1_IMAGE_SUFFICIENCY_BEFORE_EXACT_VANISHING_NOTE_20260608.md",
        "fragments": [
            "`C_closure^(0) = shell-typed IR1 image sufficiency test`",
            "lawful exact-vanishing attempt,",
            "This does **not** yet prove exact closure.",
        ],
        "meaning": "the closure-readiness gate is localized to shell-typed IR1 image sufficiency",
    },
    {
        "key": "final_verdict_order",
        "path": ROOT
        / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_FINAL_LOCAL_VERDICT_SPLITS_TO_OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT_BEFORE_TYPED_U2_TRIGGER_VERDICT_NOTE_20260608.md",
        "fragments": [
            "`C_closure^(0) -> V_exact^(try) -> V_U2^(only if typed trigger fires)`",
            "ownership-preserving exact-vanishing attempt",
            "that exact vanishing has been achieved",
            "only if that attempt forces one typed `U2` trigger",
        ],
        "meaning": "the local upper split now orders exact attempt before typed widening",
    },
]


def relative(path: Path) -> str:
    return str(path.relative_to(ROOT))


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": relative(item["path"]),
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def load_typed_u2_input() -> dict:
    status = json.loads(TYPED_U2_STATUS_PATH.read_text(encoding="utf-8"))
    verdict = json.loads(TYPED_U2_VERDICT_PATH.read_text(encoding="utf-8"))
    trigger_matrix = json.loads(TYPED_U2_TRIGGER_MATRIX_PATH.read_text(encoding="utf-8"))
    next_move = trigger_matrix["global_reading"]["next_honest_move"]
    return {
        "status_path": relative(TYPED_U2_STATUS_PATH),
        "verdict_path": relative(TYPED_U2_VERDICT_PATH),
        "trigger_matrix_path": relative(TYPED_U2_TRIGGER_MATRIX_PATH),
        "status": status,
        "verdict": verdict,
        "trigger_matrix": trigger_matrix,
        "passed": (
            status["verdict"]
            == "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_MATERIALIZED"
            and status["u2_currently_forced"] is False
            and status["all_note_checks_pass"] is True
            and next_move == "OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT"
        ),
    }


def note_passed(note_checks: list[dict], key: str) -> bool:
    for item in note_checks:
        if item["key"] == key:
            return item["passed"]
    raise KeyError(key)


def build_report(status: dict, note_checks: list[dict]) -> str:
    lines = [
        "# Post-Cage Branch U1 Current-Route Ownership-Preserving Exact-Vanishing Attempt Report",
        "",
        f"Generated at: `{status['generated_at_utc']}`",
        "",
        f"Verdict: `{status['verdict']}`",
        "",
        "## Summary",
        "",
        f"- typed U2 input confirmed: `{str(status['typed_u2_input_confirmed']).lower()}`",
        f"- same-carrier ledger admission visible: `{str(status['same_carrier_ledger_admission_visible']).lower()}`",
        f"- coefficient-law gate visible: `{str(status['coefficient_law_gate_visible']).lower()}`",
        f"- shell-typed IR1 image gate visible: `{str(status['shell_typed_ir1_image_gate_visible']).lower()}`",
        f"- ownership-preserving attempt now ordered: `{str(status['ownership_preserving_attempt_now_ordered']).lower()}`",
        f"- exact vanishing already achieved: `{str(status['exact_vanishing_already_achieved']).lower()}`",
        "",
        "## Note checks",
        "",
    ]
    for check in note_checks:
        lines.append(f"- `{check['path']}` -> `{str(check['passed']).lower()}`")
    lines.extend(
        [
            "",
            "## Reading",
            "",
            "- the same-carrier ledger is already admitted,",
            "- the first pre-vanishing gate is already typed as coefficient-law sufficiency under ownership,",
            "- the same gate is already sharpened to shell-typed IR1 image sufficiency,",
            "- typed U2 widening remains not yet fired,",
            "- so the next honest move is one ownership-preserving exact-vanishing attempt, not one present widening verdict.",
            "",
            "## Ceiling",
            "",
            "- this report does not prove exact vanishing,",
            "- it does not exclude later lawful widening,",
            "- it only materializes the next exact reviewer-visible attempt shell.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    OUTPUTS.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    typed_u2_input = load_typed_u2_input()

    status = {
        "object_kind": "post_cage_branch_u1_current_route_ownership_preserving_exact_vanishing_attempt_status",
        "generated_at_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "scope": "current_repo_visible_frozen_u1_route_only",
        "typed_u2_input_confirmed": typed_u2_input["passed"],
        "same_carrier_ledger_admission_visible": note_passed(
            note_checks, "same_carrier_ledger_admission"
        ),
        "coefficient_law_gate_visible": note_passed(
            note_checks, "coefficient_law_gate"
        ),
        "shell_typed_ir1_image_gate_visible": note_passed(
            note_checks, "shell_typed_ir1_image_gate"
        ),
        "ownership_preserving_attempt_now_ordered": note_passed(
            note_checks, "final_verdict_order"
        ),
        "typed_u2_currently_forced": False,
        "exact_vanishing_already_achieved": False,
        "all_note_checks_pass": all(check["passed"] for check in note_checks),
        "verdict": "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT_MATERIALIZED",
    }

    attempt_matrix = {
        "prior_trigger_adjudication": {
            "materialized": typed_u2_input["passed"],
            "current_trigger_state": "not_yet_fired",
            "required_next_move": "OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT",
        },
        "same_carrier_ledger_gate": {
            "passed": status["same_carrier_ledger_admission_visible"],
            "reading": "T_Q^(0) = same-carrier variational ledger admission",
        },
        "coefficient_law_gate": {
            "passed": status["coefficient_law_gate_visible"],
            "reading": "C_closure^(0) = same-carrier coefficient-law sufficiency under the ownership map",
        },
        "shell_typed_ir1_image_gate": {
            "passed": status["shell_typed_ir1_image_gate_visible"],
            "reading": "C_closure^(0) = shell-typed IR1 image sufficiency test",
        },
        "upper_verdict_order": {
            "passed": status["ownership_preserving_attempt_now_ordered"],
            "reading": "V_exact^(try) before V_U2^(only if typed trigger fires)",
        },
        "current_ceiling": {
            "exact_vanishing_already_achieved": False,
            "typed_u2_currently_forced": False,
        },
    }

    verdict = {
        "verdict": status["verdict"],
        "scope": status["scope"],
        "why": [
            "the typed U2 trigger adjudication object is already materialized and still reads not_yet_fired",
            "the same-carrier ledger is already admitted at T_Q^(0)",
            "the first pre-vanishing gate is already typed as coefficient-law sufficiency under the ownership map",
            "that gate is already sharpened to shell-typed IR1 image sufficiency",
            "the local upper split already orders exact attempt before any typed-trigger widening verdict",
        ],
        "allowed_current_reading": "next_honest_move_is_ownership_preserving_exact_vanishing_attempt",
        "ceiling": [
            "not proof of exact vanishing",
            "not exclusion of later lawful widening",
            "not a true L0 observed-row crossing",
        ],
    }

    report = build_report(status, note_checks)

    (OUTPUTS / "note_checks.json").write_text(
        json.dumps(note_checks, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "typed_u2_input.json").write_text(
        json.dumps(typed_u2_input, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "attempt_matrix.json").write_text(
        json.dumps(attempt_matrix, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "status_summary.json").write_text(
        json.dumps(status, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "verdict.json").write_text(
        json.dumps(verdict, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUTS / "OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT_REPORT.md").write_text(
        report,
        encoding="utf-8",
    )

    if not typed_u2_input["passed"]:
        raise SystemExit("typed U2 adjudication input is not in the expected state")
    if not all(check["passed"] for check in note_checks):
        raise SystemExit("required exact-attempt note evidence check failed")


if __name__ == "__main__":
    main()
