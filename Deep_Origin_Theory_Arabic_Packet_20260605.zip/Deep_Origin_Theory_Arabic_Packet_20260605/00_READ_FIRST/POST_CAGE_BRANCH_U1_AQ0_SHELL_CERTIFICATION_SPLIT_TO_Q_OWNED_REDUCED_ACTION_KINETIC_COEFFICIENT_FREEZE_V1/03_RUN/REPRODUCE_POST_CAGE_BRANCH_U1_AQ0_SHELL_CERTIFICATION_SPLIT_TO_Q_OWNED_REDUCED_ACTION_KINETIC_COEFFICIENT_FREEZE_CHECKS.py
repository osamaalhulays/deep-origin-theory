#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"
PACKET_PREFIX = "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"

AQ0_SPLIT_VERDICT_PATH = (
    "artifacts/debt_board_20260530/"
    + "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_POST_GATE_TARGET_SPLIT_TO_AQ0_VARIATIONAL_KINETIC_SHELL_CERTIFICATION_V1/04_OUTPUTS/verdict.json"
)
AQ_SHELL_VERDICT_PATH = (
    "artifacts/debt_board_20260530/"
    + "POST_CAGE_BRANCH_U1_AQ_VARIATIONAL_KINETIC_SHELL_V1/04_OUTPUTS/verdict.json"
)
REDUCED_ACTION_NOTE_PATH = (
    PACKET_PREFIX
    + "CURRENT_G1_REMAINING_BURDEN_SHARPENS_TO_Q_OWNED_REDUCED_ACTION_KINETIC_COEFFICIENT_FREEZE_NOTE_20260612.md"
)
REDUCED_ACTION_SOURCE_NOTE_PATH = (
    "artifacts/debt_board_20260530/"
    + "G1_PRESENT_MATERIALS_REMAINING_BURDEN_SHARPENS_FROM_AUTHORITY_GRADE_CERTIFICATION_OF_BQ_FREE_AQ0_VARIATIONAL_KINETIC_SHELL_TO_Q_OWNED_REDUCED_ACTION_KINETIC_COEFFICIENT_FREEZE_20260612.md"
)

NOTE_CHECKS = [
    {
        "key": "aq0_shell_split_materialized",
        "path": AQ0_SPLIT_VERDICT_PATH,
        "fragments": [
            "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_POST_GATE_TARGET_SPLIT_TO_AQ0_VARIATIONAL_KINETIC_SHELL_CERTIFICATION_MATERIALIZED",
            "\"next_exact_tooth\": \"reviewer_visible_authority_grade_certification_or_freeze_of_BQ_free_AQ0_shell\"",
        ],
        "meaning": "the broader A_Q^(0) shell-certification burden is already selected",
    },
    {
        "key": "aq_shell_materialized",
        "path": AQ_SHELL_VERDICT_PATH,
        "fragments": [
            "POST_CAGE_BRANCH_U1_AQ_VARIATIONAL_KINETIC_SHELL_MATERIALIZED",
            "\"positive_shell\": \"A_Q^(0)[I_geo^(0)] = B_Q-free same-carrier variational kinetic shell\"",
        ],
        "meaning": "the exact A_Q^(0) variational kinetic shell is already reviewer-visible",
    },
    {
        "key": "reduced_action_narrowing_present",
        "path": REDUCED_ACTION_NOTE_PATH,
        "fragments": [
            "one reviewer-visible lawful `Q`-owned reduced-action freeze for the",
            "single-`Q` kinetic coefficient carried by the already fixed",
            "with `C_Q_gradient` preserved as shadow pressure only rather than one",
        ],
        "meaning": "the remaining burden is already sharpened to one reduced-action kinetic-coefficient freeze",
    },
    {
        "key": "source_side_shadow_ceiling_present",
        "path": REDUCED_ACTION_SOURCE_NOTE_PATH,
        "fragments": [
            "coefficient-host prefill still does **not** count as full action",
            "`C_Q_gradient` remains real shadow pressure carried forward below",
        ],
        "meaning": "the host-skeleton prefill ceiling and gradient-shadow discipline remain explicit",
    },
]


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


def find_packet_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if parent.name == "00_READ_FIRST" and (parent / "START_HERE_FIRST.md").exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
SCRIPT_PACKET_ROOT = find_packet_root()
if SCRIPT_PACKET_ROOT is not None:
    PACKET_ROOT = SCRIPT_PACKET_ROOT
    RUNNING_FROM_PACKET = True
elif WORKSPACE_ROOT is not None:
    PACKET_ROOT = WORKSPACE_ROOT / "Deep_Origin_Theory_English_Packet_20260605" / "00_READ_FIRST"
    RUNNING_FROM_PACKET = False
else:
    raise RuntimeError("could not locate workspace or packet root from reduced-action split runner")


def candidate_paths(logical_relative_path: str) -> list[Path]:
    candidates: list[Path] = []

    def add(path: Path) -> None:
        if path not in candidates:
            candidates.append(path)

    if RUNNING_FROM_PACKET and logical_relative_path.startswith(PACKET_PREFIX):
        add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    if WORKSPACE_ROOT is not None:
        add(WORKSPACE_ROOT / logical_relative_path)
        if logical_relative_path.startswith(PACKET_PREFIX):
            add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    return candidates


def resolve_existing_path(logical_relative_path: str) -> Path:
    for candidate in candidate_paths(logical_relative_path):
        if candidate.exists():
            return candidate
    searched = "\n".join(str(path) for path in candidate_paths(logical_relative_path))
    raise FileNotFoundError(
        f"could not resolve reduced-action split surface: {logical_relative_path}\n{searched}"
    )


def read_text(logical_relative_path: str) -> str:
    return resolve_existing_path(logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": item["path"],
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    verdict_name = (
        "POST_CAGE_BRANCH_U1_AQ0_SHELL_CERTIFICATION_SPLIT_TO_Q_OWNED_REDUCED_ACTION_KINETIC_COEFFICIENT_FREEZE_MATERIALIZED"
        if all_note_checks_pass
        else "POST_CAGE_BRANCH_U1_AQ0_SHELL_CERTIFICATION_SPLIT_TO_Q_OWNED_REDUCED_ACTION_KINETIC_COEFFICIENT_FREEZE_NOT_MATERIALIZED"
    )

    selected_first_missing_witness_class = (
        "reviewer-visible lawful Q-owned reduced-action freeze for the single-Q kinetic coefficient carried by the already fixed B_Q-free A_Q^(0)[I_geo^(0)] shell"
        if all_note_checks_pass
        else None
    )

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": verdict_name,
        "aq0_shell_split_materialized": note_check_map["aq0_shell_split_materialized"],
        "aq_shell_materialized": note_check_map["aq_shell_materialized"],
        "reduced_action_narrowing_present": note_check_map["reduced_action_narrowing_present"],
        "source_side_shadow_ceiling_present": note_check_map["source_side_shadow_ceiling_present"],
        "all_note_checks_pass": all(note_check_map.values()),
        "selected_first_missing_witness_class": selected_first_missing_witness_class,
        "gradient_shadow_only": True,
        "full_g1_closed": False,
    }

    verdict = {
        "verdict": verdict_name,
        "selected_first_missing_witness_class": selected_first_missing_witness_class,
        "broader_shell_burden": "reviewer-visible authority-grade certification / freeze for the already fixed B_Q-free A_Q^(0)[I_geo^(0)] variational kinetic shell itself",
        "preserved_positive_shell": "A_Q^(0)[I_geo^(0)] = B_Q-free same-carrier variational kinetic shell",
        "gradient_status": "shadow pressure only, not coequal first-owner burden",
        "grade": "aq0_shell_certification_split_grade",
        "next_exact_tooth": "reviewer_visible_q_owned_reduced_action_freeze_of_single_q_kinetic_coefficient",
    }

    if all_note_checks_pass:
        reading_lines = [
            "- the broader A_Q^(0) shell-certification burden no longer remains one undivided witness class,",
            "- the first missing witness class is now selected on the single-Q kinetic coefficient carried by the already fixed shell,",
            "- and C_Q_gradient stays preserved as shadow pressure only rather than one coequal first-owner burden.",
        ]
    else:
        reading_lines = [
            "- the supporting route surfaces are present but do not yet pass the current reduced-action split check,",
            "- so no exact first missing witness class can yet be treated as verified inside the broader A_Q^(0) shell-certification burden,",
            "- and the route stays below this split until the missing check surfaces are repaired or strengthened.",
        ]

    report_lines = [
        "# Post-Cage Branch U1 A_Q^(0) Shell Certification Split To Q-Owned Reduced-Action Kinetic-Coefficient Freeze Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- broader A_Q^(0) shell split materialized: `{status_summary['aq0_shell_split_materialized']}`",
        f"- exact A_Q^(0) shell materialized: `{status_summary['aq_shell_materialized']}`",
        f"- reduced-action narrowing present: `{status_summary['reduced_action_narrowing_present']}`",
        f"- source-side shadow ceiling present: `{status_summary['source_side_shadow_ceiling_present']}`",
        f"- all note checks pass: `{status_summary['all_note_checks_pass']}`",
        "",
        "## Reading",
        "",
        *reading_lines,
        "",
        "## Ceiling",
        "",
        "- this report does not claim a landed reduced-action witness,",
        "- it does not claim final pairwise law,",
        "- it does not claim T_Q^(0) admission or exact transport closure,",
        "- and it does not claim full G1/G2 completion.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    write_json(
        OUTPUT_ROOT / "source_inputs.json",
        {
            "aq0_split_verdict_path": AQ0_SPLIT_VERDICT_PATH,
            "aq_shell_verdict_path": AQ_SHELL_VERDICT_PATH,
            "reduced_action_note_path": REDUCED_ACTION_NOTE_PATH,
            "reduced_action_source_note_path": REDUCED_ACTION_SOURCE_NOTE_PATH,
        },
    )
    (OUTPUT_ROOT / "AQ0_SHELL_CERTIFICATION_SPLIT_TO_Q_OWNED_REDUCED_ACTION_KINETIC_COEFFICIENT_FREEZE_REPORT.md").write_text(
        "\n".join(report_lines),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
