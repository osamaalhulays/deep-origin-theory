# Split Test Matrix

## Positive requirements

1. the broader `A_Q^(0)` shell-certification split is already materialized
2. the exact `A_Q^(0)[I_geo^(0)]` variational kinetic shell is already
   materialized
3. the remaining burden is already sharpened to one `Q`-owned
   reduced-action kinetic-coefficient freeze
4. host-skeleton prefill remains below full action ownership
5. `C_Q_gradient` remains shadow pressure only rather than one coequal
   first-owner burden

## Reject readings

- any generic certification-witness reading of the whole `A_Q^(0)` shell
- any coequal `{C_Q_kinetic, C_Q_gradient}` first-freeze reading
- any direct jump to `T_Q^(0)` or exact transport closure
