# Split Scope And Boundary

This object is valid only at:

- `A_Q^(0)` shell-certification split grade

It selects:

- the first missing witness class inside the already selected
  `A_Q^(0)` shell-certification burden

It does **not** select:

- a landed reduced-action witness,
- final public coefficient law,
- full action-ownership completion,
- `T_Q^(0)` admission,
- exact transport closure,
- or full `G1` completion.

The selected first missing witness class must remain:

- `Q`-owned,
- reduced-action grade,
- on the single-`Q` kinetic coefficient,
- carried by the already fixed `B_Q`-free `A_Q^(0)[I_geo^(0)]` shell,
- with `C_Q_gradient` preserved as shadow pressure only rather than one
  coequal first-owner burden.
