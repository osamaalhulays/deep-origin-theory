# Target Test Matrix

## Positive requirements

1. the pairwise-freeze decision gate is already materialized
2. the bound `C_Q_kinetic` freeze minimum signature is already materialized
3. the remaining shell burden is already localized to one `Q`-owned
   coefficient-law provenance / freeze
4. the remaining burden is already sharpened to one `I_geo`-mediated
   `A_Q`-first carrier-law freeze
5. the local `O_transport` tooth is already localized to one
   `I_geo`-mediated carrier-law freeze
6. `A_Q` is already localized as the real `T_Q` transport-ownership pivot
7. `M_Q` remains later co-carried rather than leading

## Reject readings

- any generic future-freeze reading with no exact target class
- any non-`Q` import
- any non-`I_geo` first neck
- any symmetric `{A_Q, M_Q}` first-freeze reading
- any `M_Q`-first reading
- any direct leap to final pairwise law or exact transport closure
