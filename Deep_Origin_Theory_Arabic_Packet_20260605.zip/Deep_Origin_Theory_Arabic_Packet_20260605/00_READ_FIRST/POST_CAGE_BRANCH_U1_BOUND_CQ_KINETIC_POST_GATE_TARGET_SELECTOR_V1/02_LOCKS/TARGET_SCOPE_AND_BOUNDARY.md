# Target Scope And Boundary

This object is valid only at:

- post-gate target-selection grade

It selects:

- the exact target class of the next lawful landed witness above the current
  bound `C_Q_kinetic` post-gate battlefield

It does **not** select:

- a landed witness,
- a final pairwise coefficient formula,
- exact `T_Q^(0)` ownership,
- exact transport closure,
- or full `G1` completion.

The selected target must remain:

- `Q`-owned,
- `I_geo`-mediated,
- `A_Q`-first,
- `B_Q`-free along `A_Q^(0)[I_geo^(0)]`,
- and `M_Q`-co-carried-later rather than leading.
