#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"
PACKET_PREFIX = "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"

DECISION_GATE_PATH = (
    PACKET_PREFIX
    + "CURRENT_G1_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_DECISION_GATE_MATERIALIZED_NOTE_20260612.md"
)
MIN_SIGNATURE_PATH = (
    PACKET_PREFIX
    + "CURRENT_G1_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_MINIMUM_SIGNATURE_MATERIALIZED_NOTE_20260612.md"
)
Q_OWNED_PROVENANCE_PATH = (
    PACKET_PREFIX
    + "CURRENT_G1_REMAINING_BURDEN_IS_Q_OWNED_COEFFICIENT_LAW_PROVENANCE_FOR_BQ_FREE_AQ0_SHELL_NOTE_20260612.md"
)
POST_GATE_TARGET_PATH = (
    PACKET_PREFIX
    + "CURRENT_G1_REMAINING_BURDEN_SHARPENS_TO_IGEO_MEDIATED_AQ_FIRST_CARRIER_LAW_FREEZE_NOTE_20260612.md"
)
OTRANSPORT_LOCALIZATION_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_OTRANSPORT_FIRST_LOCAL_TOOTH_LOCALIZES_TO_IGEO_MEDIATED_CARRIER_LAW_FREEZE_NOTE_20260608.md"
)
AQ_PIVOT_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_RR0_BS1_AQ_EXACT_TARGET_LOCALIZES_TO_TQ_TRANSPORT_OWNERSHIP_PIVOT_NOTE_20260608.md"
)

NOTE_CHECKS = [
    {
        "key": "decision_gate_materialized",
        "path": DECISION_GATE_PATH,
        "fragments": [
            "one missing reviewer-visible authority-grade pairwise-freeze object",
            "future claim will be routed by the now-materialized",
        ],
        "meaning": "the bound C_Q_kinetic freeze tooth is already governed by a materialized post-gate decision grammar",
    },
    {
        "key": "freeze_signature_materialized",
        "path": MIN_SIGNATURE_PATH,
        "fragments": [
            "one missing reviewer-visible authority-grade pairwise-freeze object",
            "bound `C_Q_kinetic`,",
            "`B_Q`-free corridor,",
        ],
        "meaning": "the lower bound C_Q_kinetic freeze tooth already has one frozen minimum signature",
    },
    {
        "key": "q_owned_provenance_localized",
        "path": Q_OWNED_PROVENANCE_PATH,
        "fragments": [
            "`B_Q`-free `A_Q^(0)[I_geo^(0)]`",
            "one lawful `Q`-owned coefficient-law provenance / freeze",
        ],
        "meaning": "the remaining shell burden is already localized to one Q-owned provenance/freeze",
    },
    {
        "key": "post_gate_target_localized",
        "path": POST_GATE_TARGET_PATH,
        "fragments": [
            "one lawful `Q`-owned `I_geo`-mediated `A_Q`-first carrier-law freeze",
            "with `M_Q` preserved as later co-carried rather than leading",
        ],
        "meaning": "the remaining burden is already sharpened to the exact post-gate target class",
    },
    {
        "key": "otransport_tooth_localized",
        "path": OTRANSPORT_LOCALIZATION_PATH,
        "fragments": [
            "`O_transport first local tooth = I_geo-mediated carrier-law freeze`",
            "`A_Q` first",
            "`M_Q` co-carried later inside the same carrier lane",
        ],
        "meaning": "the local O_transport battlefield already localizes to one I_geo-mediated carrier-law freeze with A_Q first",
    },
    {
        "key": "aq_transport_pivot_localized",
        "path": AQ_PIVOT_PATH,
        "fragments": [
            "`A_Q` should no longer be treated as one generic final coefficient unknown.",
            "`A_Q` = live transport-ownership pivot for the carrier side",
            "`M_Q` = co-carried mass face remaining inside the same later carrier lane",
        ],
        "meaning": "A_Q is already localized as the real T_Q transport-ownership pivot with M_Q later co-carried",
    },
]


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


def find_packet_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if parent.name == "00_READ_FIRST" and (parent / "START_HERE_FIRST.md").exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
SCRIPT_PACKET_ROOT = find_packet_root()
if SCRIPT_PACKET_ROOT is not None:
    PACKET_ROOT = SCRIPT_PACKET_ROOT
    RUNNING_FROM_PACKET = True
elif WORKSPACE_ROOT is not None:
    PACKET_ROOT = WORKSPACE_ROOT / "Deep_Origin_Theory_English_Packet_20260605" / "00_READ_FIRST"
    RUNNING_FROM_PACKET = False
else:
    raise RuntimeError("could not locate workspace or packet root from post-gate target selector runner")


def candidate_paths(logical_relative_path: str) -> list[Path]:
    candidates: list[Path] = []

    def add(path: Path) -> None:
        if path not in candidates:
            candidates.append(path)

    if RUNNING_FROM_PACKET and logical_relative_path.startswith(PACKET_PREFIX):
        add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    if WORKSPACE_ROOT is not None:
        add(WORKSPACE_ROOT / logical_relative_path)
        if logical_relative_path.startswith(PACKET_PREFIX):
            add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    return candidates


def resolve_existing_path(logical_relative_path: str) -> Path:
    for candidate in candidate_paths(logical_relative_path):
        if candidate.exists():
            return candidate
    searched = "\n".join(str(path) for path in candidate_paths(logical_relative_path))
    raise FileNotFoundError(
        f"could not resolve post-gate target selector surface: {logical_relative_path}\n{searched}"
    )


def read_text(logical_relative_path: str) -> str:
    return resolve_existing_path(logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": item["path"],
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    verdict_name = (
        "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_POST_GATE_TARGET_SELECTOR_MATERIALIZED"
        if all_note_checks_pass
        else "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_POST_GATE_TARGET_SELECTOR_NOT_MATERIALIZED"
    )

    selected_target = (
        "Q-owned I_geo-mediated A_Q-first carrier-law freeze for real T_Q ownership pivoting, "
        "with M_Q later co-carried rather than leading"
        if all_note_checks_pass
        else None
    )

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": verdict_name,
        "decision_gate_materialized": note_check_map["decision_gate_materialized"],
        "freeze_signature_materialized": note_check_map["freeze_signature_materialized"],
        "q_owned_provenance_localized": note_check_map["q_owned_provenance_localized"],
        "post_gate_target_localized": note_check_map["post_gate_target_localized"],
        "otransport_tooth_localized": note_check_map["otransport_tooth_localized"],
        "aq_transport_pivot_localized": note_check_map["aq_transport_pivot_localized"],
        "all_note_checks_pass": all_note_checks_pass,
        "selected_post_gate_target": selected_target,
        "full_g1_closed": False,
    }

    verdict = {
        "verdict": verdict_name,
        "selected_post_gate_target": selected_target,
        "prerequisite_tooth": "bound C_Q_kinetic authority-grade pairwise-freeze battlefield",
        "preserved_pair_order": "(I_amp^(0), I_geo^(0)) with I_geo^(0) > I_amp^(0)",
        "preserved_corridor": "B_Q-free A_Q^(0)[I_geo^(0)]",
        "aq_role": "real T_Q transport-ownership pivot",
        "mq_role": "later co-carried rather than leading",
        "grade": "post_gate_target_selection_grade",
        "next_exact_tooth": "reviewer_visible_landed_witness_of_selected_post_gate_target",
    }

    if all_note_checks_pass:
        reading_lines = [
            "- the post-gate battlefield no longer waits for one generic future freeze object,",
            "- the next exact missing target is now selected as one lawful `Q`-owned `I_geo`-mediated `A_Q`-first carrier-law freeze,",
            "- and `M_Q` remains preserved as later co-carried rather than leading.",
        ]
    else:
        reading_lines = [
            "- the supporting route surfaces are present but do not yet pass the current post-gate target-selector check,",
            "- so no exact selected target class can yet be treated as verified above the post-gate battlefield,",
            "- and the route stays below target selection until the missing check surfaces are repaired or strengthened.",
        ]

    report_lines = [
        "# Post-Cage Branch U1 Bound C_Q_kinetic Post-Gate Target Selector Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- decision gate materialized: `{status_summary['decision_gate_materialized']}`",
        f"- freeze signature materialized: `{status_summary['freeze_signature_materialized']}`",
        f"- `Q`-owned provenance localized: `{status_summary['q_owned_provenance_localized']}`",
        f"- post-gate target localized: `{status_summary['post_gate_target_localized']}`",
        f"- local `O_transport` tooth localized: `{status_summary['otransport_tooth_localized']}`",
        f"- `A_Q` transport pivot localized: `{status_summary['aq_transport_pivot_localized']}`",
        f"- all note checks pass: `{status_summary['all_note_checks_pass']}`",
        "",
        "## Reading",
        "",
        *reading_lines,
        "",
        "## Ceiling",
        "",
        "- this report does not claim a landed freeze witness,",
        "- it does not claim final pairwise coefficient law,",
        "- it does not claim exact `T_Q^(0)` ownership or transport closure,",
        "- and it does not claim full `G1/G2` completion.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    write_json(
        OUTPUT_ROOT / "source_inputs.json",
        {
            "decision_gate_path": DECISION_GATE_PATH,
            "min_signature_path": MIN_SIGNATURE_PATH,
            "q_owned_provenance_path": Q_OWNED_PROVENANCE_PATH,
            "post_gate_target_path": POST_GATE_TARGET_PATH,
            "otransport_localization_path": OTRANSPORT_LOCALIZATION_PATH,
            "aq_pivot_path": AQ_PIVOT_PATH,
        },
    )
    (OUTPUT_ROOT / "BOUND_CQ_KINETIC_POST_GATE_TARGET_SELECTOR_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
