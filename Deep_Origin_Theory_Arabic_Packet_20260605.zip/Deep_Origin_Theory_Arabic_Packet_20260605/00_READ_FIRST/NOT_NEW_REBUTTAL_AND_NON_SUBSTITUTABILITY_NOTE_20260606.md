# Not-New Rebuttal And Non-Substitutability Note

Date: `2026-06-06`

This note answers one cheap reviewer move:

- "this does not seem genuinely new."

The right answer is not insistence.
It is a substitution test.

## Core rule

Nearness in vocabulary is not the same as substitutability in scientific
architecture.

To say the packet is "not new" in a serious sense,
a reviewer should be able to identify prior work that already combines, in one
lawful chain:

- the same role-corrected parent / carrier / closure / observable /
  comparator split,
- the same source-governed bridge logic,
- the same law-bearing action-to-closure-to-observable spine,
- the same no-proxy / no-selected-line / no-premature-authority discipline,
- and the same bounded witness-plus-falsifier structure.

If that prior work is not named,
then "not new" usually means only:

- "some words sound adjacent to known traditions."

That is weaker than a real novelty objection.

## What does not count as a successful rebuttal

The following are not enough by themselves:

- saying the packet uses response language already found elsewhere,
- saying unification has been discussed before,
- saying scalar-tensor or matter-trace traditions exist,
- or saying galaxy-fit alternatives to dark matter already exist.

Those show adjacency.
They do not show substitutability.

## What a real rebuttal would need to show

A serious "not new" rebuttal would need to show prior work that already has:

1. one explicit role grammar separating parent, carrier, closure, observable,
   comparator, admissibility, and authority
2. one lawful bounded bridge under declared falsifiers
3. one source-governed law-bearing spine across layers
4. one repeated anti-category-error discipline in later observational and
   authority fronts
5. one bounded empirical witness culture connected to that same grammar

Without that,
the better reading is:

- adjacent language exists,
- but the packet's architecture is still distinctive.

## Strong outward-safe wording

Use wording of this type:

> The novelty claim is not that no neighboring vocabulary exists in the
> literature. The novelty claim is that the packet already presents a
> non-substitutable physical architecture: a role-corrected unification
> grammar with lawful bridge, spine, witness, admissibility, and authority
> layers that are not shown here to be matched by one prior unified program.

## What not to say

Do **not** say:

- everything here is unprecedented,
- nobody has ever thought about anything similar,
- the quantum/relativity problem is already fully solved here,
- or `MOND/QUMOND` are already finally defeated in all forms.

Those are broader and easier to attack.

## Narrow conclusion

The safest hard conclusion is:

- the packet's novelty survives not because nothing nearby exists,
- but because the visible architecture is not yet shown to be substitutable by
  any one prior framework named in the public record here.
