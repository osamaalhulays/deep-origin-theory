# Hubble-Flow-Sensitive Body Full Closure Note

Date: `2026-06-09`

Status: `bounded packet-facing cross-archive closure`

Purpose:

This note absorbs the full Hubble-flow-sensitive body after explicit closure
of:

- the primary parity core
- the full residual reopening branch

It should be read after:

- `PRIMARY_PARITY_CORE_TRIAD_ORDER_AND_UNIFORM_COMPONENT_HARDENING_NOTE_20260609.md`
- `RESIDUAL_REOPENING_BRANCH_FULL_CLOSURE_NOTE_20260609.md`

Machine-readable companion:

- `HUBBLE_FLOW_SENSITIVE_BODY_FULL_CLOSURE_V1.json`

Direct continuation now materialized in:

- `CLEAN_ANCHOR_MINORITY_VS_FULLY_CLOSED_HUBBLE_FLOW_SENSITIVE_BODY_CROSS_COURT_SYNTHESIS_NOTE_20260609.md`

## Short verdict

The full Hubble-flow-sensitive body now closes as an explicit ten-witness
governed matched-nuisance block.

All ten remain anti-`QCT` under the named component-aware surfaces.

## 1. Full body closure summary

The full Hubble-flow-sensitive body now carries combined burden:

- combined public `Delta AIC_total = +124948.98557586371`
- combined faithful `Delta AIC_total = +86258.84036593112`
- combined component-aware `Delta AIC_total = +92780.09909850561`
- combined component-aware shift = `+6521.258732574497`
- Hubble-flow-sensitive body share = `100%`
- giant-spiral head share = `65.54658179432487%`

The ten witnesses are:

- `UGC09133`
- `UGC02953`
- `UGC06787`
- `UGC06786`
- `NGC2903`
- `NGC6674`
- `NGC5033`
- `UGC02487`
- `UGC03205`
- `UGC05253`

## 2. Meaning

This does **not** settle the whole giant-spiral head.

It does close the full Hubble-flow-sensitive body itself as one explicit
governed court rather than one split front-plus-tail narrative.

It also does **not** erase the protected clean-anchor minority.

## 3. What this does not authorize

This note does **not** authorize the claims that:

- the whole giant-spiral head is already settled
- the clean-anchor minority disappears
- whole-family `MOND/QUMOND` closure is already complete

## 4. Next honest escalation

The next honest escalation is:

- `clean-anchor minority` versus the fully closed Hubble-flow-sensitive body
  as one explicit cross-court synthesis

## Best outward-safe reading

One mature outward-safe sentence is:

> The full Hubble-flow-sensitive body now closes as an explicit ten-witness
> governed matched-nuisance block, while the protected clean-anchor minority
> remains distinct and the next honest step moves to explicit cross-court
> synthesis rather than hidden body-level ambiguity.
