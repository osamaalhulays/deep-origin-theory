#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

COUNT_BALANCED_PATH = HERE / "CURRENT_FULL_HEAD_COUNT_BALANCED_BURDEN_ASYMMETRIC_SPLIT_V1.json"
HUBBLE_QUALITY_PATH = HERE / "HUBBLE_FLOW_SENSITIVE_BODY_QUALITY_STRATIFIED_HARDENING_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def close_enough(left, right, tolerance=1e-9):
    return abs(left - right) <= tolerance


def main():
    count_balanced = load_json(COUNT_BALANCED_PATH)
    hubble_quality = load_json(HUBBLE_QUALITY_PATH)

    full_head = count_balanced["full_head"]
    heptad = count_balanced["dominant_o7_reinforced_heptad"]
    complement = count_balanced["seven_case_complement"]

    hubble_quality1_cases = set(hubble_quality["quality1_subgroup"]["cases"])
    hubble_quality2_cases = set(hubble_quality["quality2_subgroup"]["cases"])

    heptad_quality1_cases = sorted(set(heptad["cases"]) & hubble_quality1_cases)
    heptad_quality2_cases = sorted(set(heptad["cases"]) & hubble_quality2_cases)

    complement_clean_anchor = complement["internal_split"]["protected_clean_anchor_quartet"]
    complement_pocket = complement["internal_split"]["localized_quality1_continuation_pocket"]

    consistency_checks = {
        "full_head_case_count_is_fourteen": full_head["case_count"] == 14,
        "heptad_case_count_is_seven": heptad["case_count"] == 7,
        "complement_case_count_is_seven": complement["case_count"] == 7,
        "counts_are_balanced": heptad["case_count"] == complement["case_count"],
        "complement_is_all_quality1_by_construction": (
            complement_clean_anchor["case_count"] + complement_pocket["case_count"]
            == complement["case_count"]
        ),
        "heptad_quality1_and_quality2_partition_the_heptad": (
            len(heptad_quality1_cases) + len(heptad_quality2_cases) == heptad["case_count"]
        ),
        "heptad_quality1_members_match_expected_set": heptad_quality1_cases
        == ["SPARC_UGC02487", "SPARC_UGC03205", "SPARC_UGC06786", "SPARC_UGC09133"],
        "heptad_quality2_members_match_expected_set": heptad_quality2_cases
        == ["SPARC_UGC02953", "SPARC_UGC05253", "SPARC_UGC06787"],
        "all_quality1_complement_public_burden_is_strictly_smaller_than_mixed_heptad": (
            complement["public_delta_aic_total"] < heptad["public_delta_aic_total"]
        ),
        "heptad_and_complement_public_totals_recombine_to_full_head": close_enough(
            heptad["public_delta_aic_total"] + complement["public_delta_aic_total"],
            full_head["public_delta_aic_total"],
        ),
        "complement_public_fraction_is_below_half": complement[
            "fraction_of_full_head_public_delta_aic_total"
        ]
        < 0.5,
        "heptad_public_fraction_is_above_half": heptad["fraction_of_full_head_public_delta_aic_total"]
        > 0.5,
    }

    output = {
        "date": "2026-06-09",
        "status": "bounded_packet_facing_quality_flag_counterexample",
        "surface": "current_full_head_all_quality1_complement_vs_mixed_heptad",
        "full_head": full_head,
        "all_quality1_complement": {
            **complement,
            "all_cases_are_quality1": True,
        },
        "mixed_o7_reinforced_heptad": {
            **heptad,
            "quality1_case_count": len(heptad_quality1_cases),
            "quality1_cases": heptad_quality1_cases,
            "quality2_case_count": len(heptad_quality2_cases),
            "quality2_cases": heptad_quality2_cases,
        },
        "structural_reading": {
            "an_all_quality1_half_of_the_current_full_head_still_does_not_outweigh_the_mixed_heptad": True,
            "quality1_mass_alone_does_not_control_current_full_head_burden": True,
            "quality_flag_alone_cannot_order_the_current_full_head_even_after_aggregating_one_entire_half": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the current full head contains one all-quality1 seven-case half and one mixed seven-case heptad",
            "the all-quality1 half still carries less public burden than the mixed heptad",
            "quality1 aggregation does not overturn the dominant reinforced heptad",
            "quality flag alone cannot rank the current full-head halves",
        ],
        "not_supported_now": [
            "an all-quality1 half of the head automatically carries the stronger current scientific position",
            "quality1 aggregation rescues the seven-case complement above the mixed heptad",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_frontier": [
            "extend the cross-observable court without reducing current structure to quality labels",
            "test whether later continuation changes the current all-quality1 complement versus mixed-heptad burden ordering",
        ],
    }

    output["verdict"] = (
        "CURRENT_FULL_HEAD_ALL_QUALITY1_COMPLEMENT_VS_MIXED_HEPTAD_CLOSED__AN_ALL_QUALITY1_HALF_OF_THE_HEAD_STILL_CARRIES_LESS_PUBLIC_BURDEN_THAN_THE_MIXED_O7_REINFORCED_HEPTAD"
        if all(consistency_checks.values())
        else "CURRENT_FULL_HEAD_ALL_QUALITY1_COMPLEMENT_VS_MIXED_HEPTAD_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
