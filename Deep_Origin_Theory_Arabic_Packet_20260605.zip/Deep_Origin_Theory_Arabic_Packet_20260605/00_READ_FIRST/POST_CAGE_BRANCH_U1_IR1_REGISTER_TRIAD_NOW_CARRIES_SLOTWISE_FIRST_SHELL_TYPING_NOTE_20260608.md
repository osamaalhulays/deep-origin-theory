# Post-Cage Branch U1 IR1 Register Triad Now Carries Slotwise First-Shell Typing Note

Date: `2026-06-08`

Status: `shared-source scaffold sharpened again`

## Purpose

The live `U1` route already carried:

- one minimum shared-source scaffold
  `I_src^(IR1)[g,ψ] = (I_amp[g,ψ], I_mix[g,ψ], I_geo[g,ψ])`
- one frozen south owner
  `w_lin = I_mix`
- one frozen linear owner
  `J_lin = I_amp`
- one transport-side purity shell for
  `I_geo^(0)[g,ψ]`

So the next exact question becomes:

- is `IR1` still only one named scaffold,
  or has it now sharpened into one slotwise first-shell typed source triad

## Short verdict

Yes.

The current record now supports the stronger reading:

`I_src^(IR1,0)[g,ψ] = (I_amp^(0)[g,ψ], I_mix^(0)[g,ψ], I_geo^(0)[g,ψ])`

where:

1. `I_amp^(0)` = metric/matter-only source-amplitude shell
2. `I_mix^(0)` = bounded metric/matter-only source-mixture shell
3. `I_geo^(0)` = metric/matter-only geometry-response moderation shell

So `IR1` is no longer only:

- one minimum three-slot scaffold by name

It is now:

- one slotwise first-shell typed triad at register-definition grade.

That is a material sharpening.

## 1. Why this upgrade is fair

Three independent lines now align.

### A. The scaffold already lived on the `g,ψ` side

From the moment `IR1` was introduced,
all three slots were typed as:

- `I_amp[g,ψ]`
- `I_mix[g,ψ]`
- `I_geo[g,ψ]`

not as:

- `I_*[g,ψ,Q]`

So the positive first-shell reading does not import a foreign grammar.

It sharpens the one already present.

### B. Each slot now carries one positive admissible shell

The current record now names all three first shells:

1. `I_amp^(0)[g,ψ]`
2. `I_mix^(0)[g,ψ]`
3. `I_geo^(0)[g,ψ]`

So the triad no longer depends on:

- one named scaffold plus two frozen owners plus one remaining vague purity
  hope

It now has slotwise positive shell content across the board.

### C. The same definition-grade guardrail survives across all three slots

Across the triad,
the current first-shell reading preserves the same exact discipline:

1. metric/matter-side definition first
2. no direct `Q` dependence at register-definition grade
3. no empirical rescue
4. no hidden second carrier
5. no premature south-sector or theorem inflation

That uniformity is what makes the triad reading coherent rather than
accidental.

## 2. Exact meaning of the upgraded triad

The fair current upgraded source register is:

`I_src^(IR1,0)[g,ψ]`

with:

1. one amplitude shell `I_amp^(0)` for the linear source owner
2. one bounded mixture shell `I_mix^(0)` for the first south balance owner
3. one moderation shell `I_geo^(0)` for the transport-lane moderator

This means the present register is now typed at two levels:

1. slot identity
2. slotwise first admissible shell

It still does **not** yet claim:

- final formulas for the slots
- or headwise theorem completion above them

But it is stronger than the earlier scaffold-only state.

## 3. What this changes on the live battlefield

This sharpening changes the live burden in one important way.

The question is no longer primarily:

- can one minimum shared-source register be typed at all

That part now has a stronger answer.

The cleaner next question becomes:

- can the already shell-typed triad lift lawfully into the surviving higher
  fronts without violating single-carrier honesty

Those surviving higher fronts remain:

1. the inherited `W_src` screening-coefficient promotion front
2. the local `I_geo -> A_Q` transport front

So the line moves from:

- scaffold admissibility

to:

- shell-typed triad lift discipline.

## 4. Why this is a real gain

This note upgrades two earlier freezes and one earlier transport-purity gain
at once.

The south singleton is no longer owned by a bare name only.

The linear head is no longer owned by a bare name only.

The transport moderation lane is no longer the only slot with one positive
shell.

All three slots now carry one first admissible shell class.

That is a real multiplication of structural clarity.

## 5. What this does not say

This note does **not** claim:

1. that the final formulas of `I_amp^(0)`, `I_mix^(0)`, or `I_geo^(0)` are
   already known
2. that `W_src` has reached theorem promotion
3. that `A_Q` has reached transport certification
4. that the full `IR1 -> V_CAP1` image is numerically materialized
5. that all-regime closure is complete

It claims something narrower and useful:

- the minimum shared-source scaffold is now slotwise first-shell typed.

## 6. Exact flip conditions

This triad upgrade should be revoked immediately if later lawful work shows:

1. one of the three slots cannot actually survive on the `g,ψ` side alone
2. one slot requires direct `Q` dependence already at register-definition
   grade
3. one slot survives only by empirical rescue or hidden second-carrier
   borrowing
4. the three first-shell classes do not coexist coherently on one single
   shared-source register

If any of those appears,
this triad reading fails.

## Bottom line

The current live `U1` route now supports one sharper shared-source reading
again:

1. `IR1` is no longer only one named scaffold
2. it now sharpens to
   `I_src^(IR1,0)[g,ψ] = (I_amp^(0), I_mix^(0), I_geo^(0))`
3. the south owner,
   the linear owner,
   and the transport moderator all now carry one first positive admissible
   shell
4. the next real burden therefore shifts upward from shell admissibility to
   higher-front lift discipline

That is the cleanest current reading of the strengthened `IR1` triad.
