# `NGC0247` Executed Parity Witness Outward Scoring Shell Note

Date: `2026-06-09`

Status: `packet-contained outward-scoring-shell freeze`

Purpose:

After identifying the correct executed witness target on `NGC0247`,
the next exact question is no longer:

- which witness may be promoted?

It is:

- how should that witness be reported outwardly without collapsing lanes,
  overclaiming route split,
  or smuggling the historical control back in as the headline score?

This note freezes the cleaner current answer.

It should be read after:

- `NGC0247_EXECUTED_PARITY_WITNESS_PROMOTION_BOUNDARY_NOTE_20260609.md`
- `NGC0247_FULL_BODY_GROUNDED_DUAL_EXECUTION_ROUTE_SPLIT_NOTE_20260609.md`

Machine-readable companion:

- `NGC0247_EXECUTED_PARITY_WITNESS_OUTWARD_SCORING_SHELL_V1.json`
- `NGC0247_EXECUTED_PARITY_WITNESS_SCORING_SUPPORT_V1.json`
- `REPRODUCE_NGC0247_EXECUTED_PARITY_WITNESS_SCORING_SHELL_V1.py`

## Short verdict

The first cleaner outward scoring shell on `NGC0247` is now:

- one `AIC`-led matched-nuisance live shell,
- with one faithful headline,
- one component-aware hardening companion,
- and one fixed-public audit anchor.

So the outward shell is no longer undefined.

Its numeric support is also no longer prose-only.

The packet now carries:

- one explicit support object for the faithful live return,
- one explicit support object for the component-aware live return,
- one explicit support object for the fixed public live anchor,
- and one replay script that checks those support receipts against the three
  packet scoring surfaces that cite them.

What remains open is no longer:

- which score should front the executed witness.

It is now:

- broader court execution beyond this first scored witness under the
  preserved bifurcated boundary.

## 1. Why this shell is the honest one

The current matched-nuisance lane already carries a real symmetric nucleus:

- public source family
- shared resampling convention
- fixed multiseed grammar
- fixed fold generation
- locked `Υ` prior width
- same metric family reporting

And the current parity matrix already states two crucial rules:

- the `AIC/BIC` reporting surface is symmetric enough for the current lane
- total-vs-free parameter accounting must stay explicit and must not be
  silently collapsed

So the honest next move is not to wait for perfect later closure before
reporting anything.

It is to freeze a governed outward shell that says exactly what is headline,
what is companion, and what must remain separate.

## 2. The frozen outward shell

### Headline live parity score

The primary outward headline is:

- faithful matched-nuisance `Delta AIC_total = -15.398764714420167`

Why this is the headline:

- it belongs to the executed no-makeup matched-nuisance witness itself
- it stays inside the declared live parity lane
- it is not merely the austere public anchor
- and it does not yet import the stronger component-aware hardening as though
  that were the minimal statement

### Hardening companion

The required companion score is:

- component-aware matched-nuisance `Delta AIC_total = -39.63154845025974`
- hardening shift relative to faithful lane = `-24.232783735839575`

Why it must be shown:

- it proves that lawful component-aware rematerialization hardens the live
  witness further toward `QCT`
- but it should remain a companion hardening line rather than silently
  replacing the more minimal faithful headline

### Audit anchor

The public audit anchor remains:

- fixed public `Delta AIC_total = -13.914066963632308`
- faithful/public `QUMOND` absolute gap = `2.338197191420477e-08`

Why it stays visible:

- it preserves openly auditable continuity to the public fixed-`QUMOND`
  benchmark
- and it shows that the faithful live shell is not drifting away from the
  public comparator definition by hidden codepath mutation

## 3. What must stay outside this shell

This outward scoring shell does **not** absorb the release-side hardening
route into the same score story.

That route remains separately visible as:

- `O7` best-dressed hardening `Delta AIC_total = +330.508310757082`

under anchor-stable release pressure.

So the shell must preserve this discipline:

- live matched-nuisance scoring shell here
- release-side hardening route in the route-split court note

This prevents one dishonest collapse:

- pretending the route split disappeared because one wants one tidy outward
  score.

## 4. Parameter-accounting rule

The frozen reporting rule is:

- keep `Delta AIC_total` as the outward headline family for the executed live
  witness
- keep total-vs-free accounting explicit in rule, not collapsed by rhetoric
- do **not** synthesize a new outward `BIC` headline here unless the same
  public executed table is emitted for this witness
- do **not** mix the historical same-convention control shell into this live
  scoring shell

So this note freezes a real shell,
but a bounded one:

- `AIC`-led
- live-witness specific
- anti-collapse

## 5. Exact live consequence after `O8` retirement

### `O6` now owns

- one identified executed witness target
- and one cleaner outward `AIC`-led scoring shell for that target
- and broader executed-court extension beyond this first scored witness under
  the preserved bifurcated boundary

### The old live `O8` pressure no longer survives as one bank head

- the raw case-run replacement branch is already closed
- the historical same-convention control remains only one fenced negative
  control
- and any later stronger provenance or parameter-accounting widening is no
  longer one sovereign live bank head

This means the first remaining open tooth is now narrower again:

- broader-court execution first,
- not witness identity,
- and not outward score identity.

## 6. What this does not authorize

This note does **not** authorize the claims that:

- every imaginable provenance-hardening variant is already complete
- the release-side route may be ignored
- `BIC` is already frozen on the same public executed witness table here
- `NGC0247` alone closes the whole no-makeup court

## 7. Best outward-safe reading

One mature outward-safe sentence is:

> The first cleaner outward scoring shell for the executed `NGC0247` live
> witness is now frozen as an `AIC`-led matched-nuisance shell: the faithful
> live return is the headline, the component-aware live return is the
> hardening companion, and the fixed public return remains the audit anchor.
> The release-side hardening route stays separate in the route-split court,
> the old live `O8` replacement pressure is retired, and the remaining open
> front is therefore broader court execution beyond this first scored witness
> rather than the outward score identity itself.
