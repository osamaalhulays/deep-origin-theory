# Current QCT Row Comparator Appendix For `NGC0247` (Phase-2 Reconstructed)

Date: `2026-06-05`

Status: `bounded reconstructed closure object`

## Purpose

This appendix closes the previously missing current row-level `QCT` comparator
for `NGC0247` at bounded Phase-2 scope.

It does so by freezing one reproducible reconstruction object built from:

- the preserved single-case source file,
- the preserved single-case `pred_one` current surface,
- the preserved Phase-2 forward-model rule,
- and the seed-`42` best-fit nuisance value recovered from the preserved
  Phase-2 benchmark path.

The result is not only a case-level score.

It is now a row-level public table with:

- `v_QCT_current`,
- `resid_QCT_current`,
- `chi2_QCT_obs_only_term`,
- `chi2_QCT_obs_model_term`,
- one side-by-side fixed-`QUMOND` comparator for continuity with the older
  witness surface,
- and one side-by-side Phase-2 benchmark-`QUMOND` replay surface so the stored
  `ΔAIC/ΔBIC` lane can be reconstructed from the same rows.

## Frozen reconstruction inputs

- source case file: `NGC0247_PHASE2_SOURCE_CASE_V1.json`
- current predictor surface: `NGC0247_PHASE2_PRED_ONE_V1.ndjson`
- reconstructed fitted nuisance:
  - `Upsilon_phase2_seed42 = 0.9254967104326863`
- reconstructed benchmark-`QUMOND` nuisance:
  - `Upsilon_qumond_phase2_seed42 = 0.5685897225673557`

## Verification against preserved Phase-2 lane

The reconstructed row table reproduces the preserved Phase-2 case metrics at
machine-level tolerance:

- reconstructed `QCT loglike_obs_only` =
  `-416.927456340074`
- preserved `QCT loglike_obs_only` =
  `-416.927455014586`
- absolute error =
  `1.325487801296e-06`

- reconstructed `QCT loglike_obs_model` =
  `-347.411314789366`
- preserved `QCT loglike_obs_model` =
  `-347.411313657104`
- absolute error =
  `1.132261957082e-06`

- reconstructed benchmark-`QUMOND` `loglike_obs_only` =
  `-268.481545250847`
- preserved benchmark-`QUMOND` `loglike_obs_only` =
  `-268.481545250847`
- absolute error =
  `0.000000000000e+00`

## Historical AIC/BIC convention note

The preserved Phase-2 single-case lane predates the later fairness hardening.

So in this specific lane:

- the stored `QCT` case-level `AIC/BIC` align with `loglike_obs_model`,
- while fixed-`QUMOND` stays `obs-only`,
- which is why the preserved Phase-2 totals differ from later obs-only
  comparison convention.

The row table keeps both `chi2_QCT_obs_only_term` and
`chi2_QCT_obs_model_term` visible so the reader can inspect this directly.

## Reconstructed totals

- row count = `26`
- `sum chi2_QCT_obs_only` = `358.894862305880`
- `sum chi2_QCT_obs_model` = `214.387742834650`
- `sum chi2_QUMOND_fixed` = `1160.320755644641`
- `sum chi2_QUMOND_phase2_benchmark` = `62.003040127427`
- `mean |resid_QCT_current|` = `6.791146479015 km/s`
- `max |resid_QCT_current|` = `11.760842186572 km/s`

Historical Phase-2 case totals reconstructed from the row object:

- reconstructed `ΔAIC_total` = `159.859539077038`
- preserved `ΔAIC_total` = `159.859536812514`
- reconstructed `ΔBIC_total` = `161.117635615059`
- preserved `ΔBIC_total` = `161.117633350535`

## Companion files

- row table:
  - `NGC0247_CURRENT_ROW_COMPARATOR__QCT_AND_FIXED_QUMOND__V1.csv`
- replay script:
  - `REPRODUCE_NGC0247_PHASE2_CURRENT_QCT_ROW_COMPARATOR_V1.py`

## Use rule

Use this appendix to support the narrower sentence:

> The `NGC0247` packet now includes a reconstructed current Phase-2 row-level
> `QCT` comparator, tied to preserved source rows and preserved current
> `delta_1d` predictions, and verified against the preserved case-level lane at
> machine-level tolerance.

Do **not** use this appendix to claim:

- whole-family `MOND/QUMOND` closure,
- that every historical stats lane used one identical fairness convention,
- or that the original stored best-fit nuisance object was itself preserved as a
  separate public file.
