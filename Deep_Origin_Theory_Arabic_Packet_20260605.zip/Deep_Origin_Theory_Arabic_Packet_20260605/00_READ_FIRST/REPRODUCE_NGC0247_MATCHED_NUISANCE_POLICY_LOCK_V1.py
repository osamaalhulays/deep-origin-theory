#!/usr/bin/env python3
import csv
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE_SUPPORT_PATH = HERE / "NGC0247_MATCHED_NUISANCE_SOURCE_SUPPORT_V1.json"
CURRENT_ROW_COMPARATOR_PATH = HERE / "NGC0247_CURRENT_ROW_COMPARATOR__QCT_AND_FIXED_QUMOND__V1.csv"


def load_rows(csv_path: Path):
    with csv_path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def main():
    support = json.loads(SOURCE_SUPPORT_PATH.read_text(encoding="utf-8"))
    rows = load_rows(CURRENT_ROW_COMPARATOR_PATH)

    keep_count = support["sfb_support"]["kill_flag_keep_count"]
    reject_count = support["sfb_support"]["kill_flag_reject_count"]
    row_count = len(rows)

    output = {
        "surface": "ngc0247_matched_nuisance_policy_lock",
        "case_id": support["case_id"],
        "source_geometry_metadata_visible": True,
        "distance_policy_visible": True,
        "inclination_policy_visible": True,
        "quality_mask_source_signals_visible": True,
        "source_policy": support["source_geometry_metadata"],
        "mask_family": {
            "current_rotation_row_count": row_count,
            "sfb_keep_count": keep_count,
            "sfb_reject_count": reject_count,
            "count_level_alignment_with_current_rotmod_rows": row_count == keep_count,
            "current_rotation_mask_rule": "keep current 26/26 packet row-comparator rows unless a later explicit source-visible rematerialized mask rule is declared symmetrically",
            "quality_flag_rule": "carry table1 quality_flag as source metadata only; do not infer semantic class here beyond exact integer visibility",
        },
        "exact_frozen_parity_items": [
            "adopted distance value and uncertainty are now source-visible inside packet support",
            "adopted inclination value and uncertainty are now source-visible inside packet support",
            "table1 quality flag is now source-visible inside packet support",
            "sfb kill-flag family is now source-visible inside packet support",
            "current rotmod row count is now exact against the packet row comparator",
        ],
        "remaining_execution_blockers": [
            "nuisance-shifted row rematerialization is not yet packet-contained",
            "QCT delta surface under distance/inclination perturbation is not yet recomputable from packet objects alone",
            "the executed matched-nuisance replay is therefore still above this policy lock",
        ],
        "count_level_alignment_with_current_rotmod_rows": row_count == keep_count,
        "policy_lock_closed": False,
    }

    output["policy_lock_closed"] = (
        output["source_geometry_metadata_visible"]
        and output["distance_policy_visible"]
        and output["inclination_policy_visible"]
        and output["quality_mask_source_signals_visible"]
        and row_count > 0
        and keep_count > 0
    )

    output["verdict"] = (
        "NGC0247_MATCHED_NUISANCE_SOURCE_POLICY_LOCK_CLOSED__NEXT_EXECUTION_TOOTH_IS_NUISANCE_SHIFTED_ROW_REMATERIALIZATION"
        if output["policy_lock_closed"]
        else "NGC0247_MATCHED_NUISANCE_SOURCE_POLICY_LOCK_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
