# Recovered Dated `k_star = 2` Body Snapshot And Narrow Negative-Crossing Branch

Date: `2026-06-06`

Status: `recovered dated narrowing`

Purpose:

This note freezes one older sequence that materially narrows how the harsh
galaxy benchmark should be read.

The recovered sequence does **not** promote final present-stage whole-family
closure.
It does show that the older record had already preserved:

- one body-good aggregate snapshot whose mean was dominated by the top two
  offenders,
- one later narrowed negative-crossing branch in the older external-response
  release line,
- and one later gated archive with negative fullset and holdout summaries.

That is stronger than reading the older benchmark history as one broad
anonymous failure wall.

## 1. Recovered body-good `k_star = 2` snapshot

One preserved historical console excerpt from the `2026-02-28` line records:

- `run_dir = /tmp/qct_pub_gemini_bet_20260228_044313`
- `global_mean_delta_aic = 37.23619577530098`
- `wins = 65`
- `sigma_min = 0.06549888104200363`
- `sigma_max = 0.4528455436229706`
- `k_star = 2`
- `trim1 = 9.59355461261113`
- `trim2 = -1.9893659173283358`
- `trim5 = -14.134037289125933`
- `trim10 = -27.06168709085843`

The worst named objects in that preserved snapshot begin with:

1. `UGC11914 = 3520.208982274221`
2. `UGC00128 = 1457.4586208550425`
3. `NGC6946 = 501.5375702715999`
4. `NGC6195 = 489.9885915154896`
5. `NGC5371 = 484.1556478202333`
6. `NGC0247 = 444.44438560835204`

Reviewer-safe meaning:

- the aggregate was still positive,
- but the body was not broadly broken,
- because removing only the top two offenders already drove the trimmed mean
  below zero.

So this preserved line supports:

- one sharp top-two tail diagnosis,

more than it supports:

- one diffuse many-object collapse diagnosis.

## 2. Recovered later narrowed negative-crossing branch

The older external-response release line preserved later narrowed negative
variants under historical naming.

The strongest visible recovered summaries are:

- one minimal narrowed variant:
  - `global_mean_delta_aic = -3.087485852362145`
  - `wins = 47`
  - `patched_cases = UGC11914 + NGC6195 + NGC5907`
- one robustness variant:
  - `global_mean_delta_aic = -18.286120143264593`
  - `wins = 49`
  - `patched_cases = UGC11914 + NGC6195 + NGC5907 + IC4202 + ESO079-G014`

These recovered values are preserved in the dated historical release layer,
not invented by later packet narration.

Reviewer-safe meaning:

- the older line did not stop at top-tail diagnosis alone,
- it also preserved a narrow negative-crossing branch with explicit case sets.

## 3. Recovered later gated negative summaries

The later archive also preserves a gated pass with negative aggregate summaries:

- fullset summary:
  - `global_mean_delta_aic = -18.262525833139946`
  - `wins = 64`
- holdout summary:
  - `global_mean_delta_aic = -29.42296836488205`
  - `wins = 13`

This matters because it shows the older line did not preserve only one
optimistic certificate surface.
It also preserved later gated negative summaries in explicit archive objects.

## 4. What this recovery changes

This recovery defeats the weaker reading that the older galaxy benchmark story
was only:

- one harsh aggregate,
- one named offender list,
- and no narrower lawful path beyond that.

The fairer reading is now:

- one older body-good snapshot already showed the mean was top-two dominated,
- one later narrowed historical branch preserved negative-crossing variants,
- and one later gated archive preserved negative fullset and holdout summaries.

## 5. What this recovery does **not** claim

This note does **not** claim:

- present-stage whole-family defeat of `MOND/QUMOND`,
- final current-production fitted-`Y` closure,
- or that the packet's current visible mainline has already absorbed every
  historical negative branch as a present public theorem.

Those later debts remain later.

## Reviewer-safe conclusion

Reviewer-safe conclusion:

- the harsh aggregate was real,
- the named offender tail was real,
- one preserved older line already showed a `k_star = 2` body-good structure,
- one later narrowed historical branch reached negative aggregate,
- and one later gated archive preserved negative fullset and holdout summaries.

So the older benchmark history should no longer be read as one broad
anonymous failure wall.

It should be read as one structured tail story that already carried narrower
historical negative-crossing routes.
