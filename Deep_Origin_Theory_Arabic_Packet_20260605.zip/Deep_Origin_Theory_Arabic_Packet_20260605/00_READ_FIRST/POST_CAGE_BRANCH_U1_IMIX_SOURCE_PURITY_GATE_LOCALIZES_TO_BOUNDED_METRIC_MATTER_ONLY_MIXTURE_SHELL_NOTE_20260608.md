# Post-Cage Branch U1 I_mix Source-Purity Gate Localizes To Bounded Metric/Matter-Only Mixture Shell Note

Date: `2026-06-08`

Status: `parallel shell-tightening after south-singleton freeze`

## Purpose

The live `U1` route already carries one real first south freeze:

`w_lin = I_mix`

`w_quad = 1 - I_mix`

`P_S^(IR1,1)[Q] = I_mix Y_lin + (1 - I_mix) Y_quad`

So the next exact question becomes:

- if this freeze is to remain honest,
  what is the first positive admissible class that `I_mix` should belong to

## Candidate readings

The positive side of the gate could in principle have been:

1. one vague mixture knob later stabilized by observational rescue
2. one bounded metric/matter-only source-mixture shell
3. one disguised proto-south carrier with hidden tensor pressure

## Short verdict

The current record best supports the second reading.

The first positive admissible class for the current `I_mix` gate is:

`I_mix^(0) = bounded metric/matter-only source-mixture shell`

meaning:

- `I_mix` must first be admissible as one bounded register built only from
  the already-owned metric/matter route

before it is allowed to bear any stronger south-side interpretive burden.

This is stronger than saying only:

- `0 <= I_mix <= 1`

because it supplies the positive mirror:

- yes, `I_mix` may first live as one bounded `g,ψ`-side mixture shell at
  register-definition grade.

That is a real gain.

## 1. Why the freeze now needs a positive shell, not only bounds

The existing singleton freeze already carries a clean negative contract:

1. `I_mix` remains source-governed
2. `I_mix` remains bounded: `0 <= I_mix <= 1`
3. `I_mix` does not borrow from observational fit, halo tuning, or baryonic
   calibration
4. `I_mix` does not reopen the fenced gas lane as public scientific
   authority
5. `I_mix` does not generate an independent south tensor or equation of
   motion

Those prohibitions are necessary,
but they still leave one possible fog:

- "bounded somehow"

The current record is already sharp enough to do better.

It can name the first clean shell class itself.

## 2. Why metric/matter-only is already repo-native

Three current lines align directly.

### A. The `IR1` scaffold already types `I_mix[g,ψ]`

The shared-source scaffold writes:

- `I_src^(IR1)[g,ψ] = (I_amp[g,ψ], I_mix[g,ψ], I_geo[g,ψ])`

It does not write:

- `I_mix[g,ψ,Q]`

That is already one exact repo-native clue:

- register-definition grade for `I_mix` stays on the metric/matter side.

### B. The south-singleton freeze already makes `I_mix` one lawful owner,
not one free repair knob

The freeze note does not treat `I_mix` as one late-fit nuisance.

It treats it as:

- one bounded source-mixture register

and explicitly rejects:

- observational borrowing
- gas-lane authority reopening
- independent south-carrier inflation

That already points toward one clean shell,
not one rescued parameter.

### C. The `BS1` and typed-worksheet contracts keep the south side as one
bounded projection, not one new carrier

The current live `BS1` surface and the typed `QF1/IF1` worksheet already
preserve:

- one bounded south readout
- no independent south field
- no separate south generator imported as present authority

So the first positive `I_mix` class should fit that same discipline:

- a bounded mixture shell on the `g,ψ` side,
  not one disguised south sector.

## 3. Exact meaning of the bounded metric/matter-only shell

The fair current positive class is:

`I_mix^(0)[g,ψ]`

with the following first-grade contract:

1. it is a functional of `g,ψ` only
2. it remains bounded: `0 <= I_mix^(0) <= 1`
3. it governs the first linear-versus-quadratic south balance
4. it does **not** depend directly on `Q` at register-definition grade
5. it does **not** borrow from observational fit, baryonic rescue, or
   public gas-lane reopening
6. it does **not** smuggle in one independent south tensor or equation of
   motion

This does **not** yet declare one final formula.

It declares the first lawful shell class.

## 4. Why direct `Q`-fed or south-carrier `I_mix` is too early

If `I_mix` already needed direct `Q` dependence at register-definition grade,
the singleton freeze would no longer sit cleanly on the same source-register
discipline that created it.

If `I_mix` already needed one independent south carrier,
then the present `BS1` and `RR0` survival line would be undermined from
inside.

So the first honest shell cannot be:

- `I_mix[g,ψ,Q]`

and cannot be:

- one proto-`T_S` or proto-south-sector owner.

If such pressure appears later,
that is a later flip condition,
not the first admissible shell.

## 5. Why this is a real gain

This note upgrades the south-singleton freeze from:

- one lawful owner name plus one bound

to:

- one lawful owner name plus one positive admissible shell class

So the live line now knows more exactly what the first south owner is allowed
to be before stronger south interpretation is attempted.

That removes one more layer of vagueness.

## 6. What this does not say

This note does **not** claim:

1. that the final functional form of `I_mix^(0)` is already known
2. that gas-sensitive object-level modeling is solved
3. that any public gas-lane authority is reopened
4. that an independent south tensor has become admissible
5. that south completion is already physically closed

It claims something narrower and useful:

- the first positive admissible shell for `I_mix` is now named.

## 7. Exact flip conditions

This shell reading should be revoked immediately if later lawful work shows:

1. `I_mix` cannot be typed meaningfully on the `g,ψ` side alone
2. direct `Q` dependence is required already at register-definition grade
3. boundedness survives only by importing one hidden south carrier
4. observational or gas-lane rescue is needed to keep the singleton freeze
   alive
5. the real first shell lies elsewhere than the bounded metric/matter route

If any of those appears,
this shell reading fails.

## Bottom line

The current live `U1` route now supports one sharper south reading again:

1. the south singleton is already frozen by `I_mix`
2. that freeze is no longer only negative plus bounded
3. its first positive admissible class is
   `I_mix^(0)[g,ψ]`
   as one bounded metric/matter-only source-mixture shell
4. only after that shell survives cleanly may stronger south interpretation
   be attempted without inflation

That is the cleanest current positive formulation of the live `I_mix` gate.
