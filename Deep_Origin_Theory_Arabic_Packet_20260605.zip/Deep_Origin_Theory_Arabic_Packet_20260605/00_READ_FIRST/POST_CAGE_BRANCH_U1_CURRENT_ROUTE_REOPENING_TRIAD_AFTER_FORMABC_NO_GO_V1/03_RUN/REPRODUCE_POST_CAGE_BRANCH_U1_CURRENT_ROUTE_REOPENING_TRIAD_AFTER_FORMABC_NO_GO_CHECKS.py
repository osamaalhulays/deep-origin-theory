#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"

FORM_A_REPORT = "artifacts/debt_board_20260530/L2_FORM_A_CURRENT_REPO_NO_GO_V1/04_OUTPUTS/FORM_A_CURRENT_REPO_NO_GO_REPORT.md"
FORM_B_REPORT = "artifacts/debt_board_20260530/L2_FORM_B_CURRENT_REPO_NO_GO_V1/04_OUTPUTS/FORM_B_CURRENT_REPO_NO_GO_REPORT.md"
FORM_C_REPORT = "artifacts/debt_board_20260530/L2_FORM_C_CURRENT_REPO_NO_GO_V1/04_OUTPUTS/FORM_C_CURRENT_REPO_NO_GO_REPORT.md"
AUTHORITY_REPORT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_V1/04_OUTPUTS/PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_REPORT.md"
U2_REPORT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_V1/04_OUTPUTS/TYPED_U2_TRIGGER_ADJUDICATION_REPORT.md"
LANDING_REPORT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EXACT_VANISHING_LANDING_TEST_V1/04_OUTPUTS/EXACT_VANISHING_LANDING_TEST_REPORT.md"

NOTE_CHECKS = [
    {
        "key": "form_a_no_go",
        "path": FORM_A_REPORT,
        "fragments": [
            "Verdict: `FORM_A_CURRENT_REPO_VISIBLE_ROUTE_NO_GO_MATERIALIZED`",
            "- but the repo-visible data-bearing surfaces still do not carry one populated `Form A` authority pack,",
            "- stop hidden-`Form A` hunting on the same frozen route",
        ],
        "meaning": "hidden Form A hunting is retired on the present frozen route",
    },
    {
        "key": "form_b_no_go",
        "path": FORM_B_REPORT,
        "fragments": [
            "Verdict: `FORM_B_CURRENT_REPO_VISIBLE_ROUTE_NO_GO_MATERIALIZED`",
            "- but the repo-visible data-bearing surfaces still do not carry one populated `Xi_QCT_L2(gbar_i)` authority pack,",
            "- stop hidden-`Form B` hunting on the same frozen route",
        ],
        "meaning": "hidden Form B hunting is retired on the present frozen route",
    },
    {
        "key": "form_c_no_go",
        "path": FORM_C_REPORT,
        "fragments": [
            "Verdict: `FORM_C_CURRENT_REPO_VISIBLE_ROUTE_NO_GO_MATERIALIZED`",
            "- and no evaluator-grade bundle directory is presently visible above the same route,",
            "- escalate to one stronger same-route `U1` failure verdict on promotable response ownership unless a real `Form D` engine lands first",
        ],
        "meaning": "hidden Form C hunting is retired and the route already escalates above it",
    },
    {
        "key": "authority_failure",
        "path": AUTHORITY_REPORT,
        "fragments": [
            "Verdict: `POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_MATERIALIZED`",
            "- but the same route still lacks one Q-owned promotable authority surface,",
            "- and no reviewer-visible form-d reopening is presently materialized,",
        ],
        "meaning": "the surviving wound is the authority tooth and reviewer-visible Form D is still absent",
    },
    {
        "key": "u2_not_yet_fired",
        "path": U2_REPORT,
        "fragments": [
            "Verdict: `POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_MATERIALIZED`",
            "- the current route therefore remains typed-but-not-fired on U2 triggers,",
            "- so widening is not yet presently earned.",
        ],
        "meaning": "typed U2 widening remains present but not yet fired",
    },
    {
        "key": "landing_supersession_rule",
        "path": LANDING_REPORT,
        "fragments": [
            "- promotable response-authority tooth crossed: `false`",
            "- reviewer-visible Form D engine present: `false`",
            "- if one real reviewer-visible Form D engine appears first, this landing test is superseded,",
            "- if one lawful Q-owned authority crossing appears first, the landing state must be recomputed,",
            "- if one typed U2 trigger fires first, widening becomes the honest verdict instead.",
        ],
        "meaning": "the current landing-state object already fixes the exact triad-like supersession grammar",
    },
]


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
if WORKSPACE_ROOT is None:
    raise RuntimeError("could not locate workspace root from reopening triad runner")


def read_text(logical_relative_path: str) -> str:
    return (WORKSPACE_ROOT / logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": item["path"],
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def tf(value: bool) -> str:
    return str(value).lower()


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": (
            "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_REOPENING_TRIAD_AFTER_FORMABC_NO_GO_MATERIALIZED"
            if all_note_checks_pass
            else "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_REOPENING_TRIAD_AFTER_FORMABC_NO_GO_NOT_MATERIALIZED"
        ),
        "form_a_no_go_confirmed": note_check_map["form_a_no_go"],
        "form_b_no_go_confirmed": note_check_map["form_b_no_go"],
        "form_c_no_go_confirmed": note_check_map["form_c_no_go"],
        "authority_failure_confirmed": note_check_map["authority_failure"],
        "u2_not_yet_fired_confirmed": note_check_map["u2_not_yet_fired"],
        "landing_supersession_rule_confirmed": note_check_map["landing_supersession_rule"],
        "hidden_abc_hunting_retired": (
            note_check_map["form_a_no_go"]
            and note_check_map["form_b_no_go"]
            and note_check_map["form_c_no_go"]
        ),
        "same_route_authority_crossing_landed": False,
        "reviewer_visible_form_d_present": False,
        "typed_u2_trigger_fired": False,
        "all_note_checks_pass": all_note_checks_pass,
    }

    reopening_modes = {
        "same_route_reopening": [
            "lawful Q-owned promotable response-authority crossing",
            "real reviewer-visible Form D operator engine reopening from above",
        ],
        "honest_widening": [
            "genuinely fired typed U2 trigger",
        ],
        "below_line": [
            "hidden Form A replay",
            "hidden Form B replay",
            "hidden Form C replay",
            "bounded-probe inflation into promotable authority",
            "naming Form D without one engine-grade object",
            "mood-based widening without one fired typed trigger",
        ],
    }

    verdict = {
        "verdict": status_summary["verdict"],
        "live_position": "blocked at the promotable response-authority tooth after Form A/B/C no-go",
        "exact_triad": [
            "lawful Q-owned promotable response-authority crossing",
            "real reviewer-visible Form D operator engine reopening from above",
            "genuinely fired typed U2 trigger",
        ],
        "same_route_only": reopening_modes["same_route_reopening"],
        "widening_only": reopening_modes["honest_widening"],
        "next_exact_read": "hold the current route exact until one triad member actually arrives",
    }

    report_lines = [
        "# Current-Route Reopening Triad After Form A/B/C No-Go Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- Form A no-go confirmed: `{tf(status_summary['form_a_no_go_confirmed'])}`",
        f"- Form B no-go confirmed: `{tf(status_summary['form_b_no_go_confirmed'])}`",
        f"- Form C no-go confirmed: `{tf(status_summary['form_c_no_go_confirmed'])}`",
        f"- authority-step failure confirmed: `{tf(status_summary['authority_failure_confirmed'])}`",
        f"- typed U2 not-yet-fired state confirmed: `{tf(status_summary['u2_not_yet_fired_confirmed'])}`",
        f"- landing supersession rule confirmed: `{tf(status_summary['landing_supersession_rule_confirmed'])}`",
        f"- hidden A/B/C hunting retired: `{tf(status_summary['hidden_abc_hunting_retired'])}`",
        f"- all note checks pass: `{tf(status_summary['all_note_checks_pass'])}`",
        "",
        "## Exact triad",
        "",
        "1. lawful `Q`-owned promotable response-authority crossing",
        "2. real reviewer-visible `Form D` operator engine reopening from above",
        "3. genuinely fired typed `U2` trigger",
        "",
        "## Reading",
        "",
        "- hidden `Form A/B/C` hunting is retired on the present frozen route,",
        "- the present blocker remains the promotable response-authority tooth,",
        "- same-route reopening still has only two lawful classes above that tooth,",
        "- and the third class is honest widening by one fired typed `U2` trigger, not silent same-route success.",
        "",
        "## Below-line moves",
        "",
        "- hidden `Form A` replay",
        "- hidden `Form B` replay",
        "- hidden `Form C` replay",
        "- bounded-probe inflation into promotable authority",
        "- naming `Form D` without one engine-grade object",
        "- mood-based widening without one fired typed trigger",
        "",
        "## Ceiling",
        "",
        "- this report does not claim one triad member already landed,",
        "- it does not claim exact landing already happened,",
        "- it does not claim widening is already forced,",
        "- it does not claim true `L0` crossing.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "reopening_modes.json", reopening_modes)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    (OUTPUT_ROOT / "CURRENT_ROUTE_REOPENING_TRIAD_AFTER_FORMABC_NO_GO_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
