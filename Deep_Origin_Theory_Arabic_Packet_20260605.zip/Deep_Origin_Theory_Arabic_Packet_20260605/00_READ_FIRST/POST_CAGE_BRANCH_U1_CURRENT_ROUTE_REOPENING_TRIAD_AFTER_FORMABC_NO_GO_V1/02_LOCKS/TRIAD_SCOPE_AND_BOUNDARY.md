# Triad Scope And Boundary

Date: `2026-06-11`

Status: `scope lock`

## This object claims

- current-route hidden `Form A` hunting is retired,
- current-route hidden `Form B` hunting is retired,
- current-route hidden `Form C` hunting is retired,
- the present route still sits at one promotable response-authority wound,
- typed `U2` triggers are present but not yet fired,
- and the only exact above-line classes now left are:
  lawful same-route authority crossing,
  real reviewer-visible `Form D` reopening,
  or genuinely fired typed `U2` trigger.

## This object does not claim

- that same-route authority crossing already exists,
- that `Form D` already exists,
- that typed `U2` trigger firing already exists,
- that exact landing already happened,
- that widening is already forced,
- or that true `L0` crossing already exists.

## This object fails if

1. one current-route `Form A/B/C` no-go object is no longer materialized,
2. the authority-failure verdict is no longer materialized,
3. typed `U2` trigger adjudication no longer reads `not yet fired`,
4. the landing-state object no longer preserves the exact supersession rule
   by authority crossing / `Form D` / fired typed `U2`,
5. or one triad member is already present and this object is not updated.

## Exact reading discipline

- the first two triad members are same-route reopening classes,
- the third triad member is not same-route reopening;
  it is honest widening supersession,
- nothing weaker may be promoted into one fourth live class by naming alone.
