# Clean-Anchor Minority Cross-Lane Dispersion Note

Date: `2026-06-09`

Status: `packet-contained internal court dispersion clarification`

Purpose:

After the packet had already shown that one protected clean-anchor minority
survives inside the current giant-spiral head, the next honest question was
whether that minority itself collapses to one simple later-program role.

It does not.

This note closes that point explicitly.

Machine-readable companion:

- `CLEAN_ANCHOR_MINORITY_CROSS_LANE_DISPERSION_V1.json`

Reproduction script:

- `REPRODUCE_CLEAN_ANCHOR_MINORITY_CROSS_LANE_DISPERSION_V1.py`

It should be read after:

- `CLEAN_ANCHOR_MINORITY_VS_FULLY_CLOSED_HUBBLE_FLOW_SENSITIVE_BODY_CROSS_COURT_SYNTHESIS_NOTE_20260609.md`
- `ANTI_QCT_CASE_INVESTIGATION_PROTOCOL_AND_FIRST_PASS_TOPOLOGY_NOTE_20260608.md`
- `BEST_DRESSED_ADVERSARIAL_COMPARATOR_O7_TAIL_STATUS_NOTE_20260608.md`

## Short verdict

The protected clean-anchor minority does not collapse to one uniform
cross-lane role.

Inside the current four-case clean-anchor minority:

- `NGC5055` remains repeated toward `QCT` across both currently cited programs
- `NGC3198` already materializes inside the `O7` second severe positive-spoiler triad
- `NGC2841` already materializes inside the `O7` third depth triad
- `NGC7331` already materializes inside the `O7` mixed-shift persistence layer

So the current clean-anchor minority is not one simple "`pro-QCT` block."

It is internally dispersed across lanes.

## 1. The split by count

The current clean-anchor minority still carries:

- `4` cases
- all quality `1`
- all non-Hubble-flow anchored
- all visibly multiseed stable

But those `4` cases now split by later-lane role as:

- repeated toward-`QCT` cross-program subset = `1/4` = `25%`
- materialized `O7` positive-spoiler subset = `3/4` = `75%`

## 2. The `1/4` repeated toward-`QCT` subset

The repeated toward-`QCT` subset is:

- `NGC5055`

This is not a speculative reinterpretation.

The packet already carries the explicit repeated role sentence:

- `NGC5055 = toward QCT in both programs`

So one member of the clean-anchor minority stays visibly pro-`QCT` across the
two currently cited governed program lines.

## 3. The `3/4` materialized `O7` positive-spoiler subset

The other three clean-anchor cases are not flat copies of one another.

They already occupy three distinct internal `O7` positive-spoiler layers:

- `NGC3198` = second severe positive-spoiler triad
- `NGC2841` = third depth triad
- `NGC7331` = mixed-shift persistence layer

So even the `O7` side does not catch these three inside one single narrow
band. The internal spread is already layered.

## 4. Meaning

This gives the packet one sharper and safer sentence:

- protected clean-anchor membership under the current `O6` full-head reading
  does not by itself predict one uniform later `O7` role

That matters because it blocks two bad simplifications at once:

- "`clean-anchor` means the whole minority is simply pro-`QCT` everywhere"
- "`O7` membership erases the minority as if it never existed"

Neither is fair.

The cleaner reading is:

- one protected clean-anchor minority still exists on the current full-head
  `O6` reading
- but that minority is internally cross-lane dispersed when read against the
  later `O7` topology

## 5. What this does not authorize

This note does **not** authorize the claims that:

- the later `O7` layers override the protected clean-anchor court
- the protected clean-anchor court overrides the later `O7` layers
- whole-family `MOND/QUMOND` closure already exists

## Best outward-safe reading

One mature outward-safe sentence is:

> The protected clean-anchor minority does not collapse to one simple later
> role. `NGC5055` remains repeated toward `QCT` across both currently cited
> programs, while `NGC3198`, `NGC2841`, and `NGC7331` already materialize
> across three distinct internal `O7` positive-spoiler layers. So court
> membership and lane identity should not be collapsed into one label.
