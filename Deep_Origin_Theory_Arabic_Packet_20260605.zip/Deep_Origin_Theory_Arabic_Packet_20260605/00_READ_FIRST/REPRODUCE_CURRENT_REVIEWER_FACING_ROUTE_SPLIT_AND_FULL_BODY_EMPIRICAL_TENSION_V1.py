#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

DUAL_ROUTE_SPLIT_PATH = HERE / "NGC0247_FULL_BODY_GROUNDED_DUAL_EXECUTION_ROUTE_SPLIT_V1.json"
HUBBLE_BODY_PATH = HERE / "HUBBLE_FLOW_SENSITIVE_BODY_FULL_CLOSURE_V1.json"
FULL_HEAD_BOUNDARY_PATH = HERE / "CURRENT_FULL_HEAD_CONCENTRATED_BUT_NONTERMINAL_BOUNDARY_V1.json"
LANE_STATUS_BOARD_PATH = HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_STATUS_BOARD_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    dual_route_split = load_json(DUAL_ROUTE_SPLIT_PATH)
    hubble_body = load_json(HUBBLE_BODY_PATH)
    full_head_boundary = load_json(FULL_HEAD_BOUNDARY_PATH)
    lane_status_board = load_json(LANE_STATUS_BOARD_PATH)

    matched_lane = lane_status_board["lane_status_board"]["matched_nuisance_parity_court"]
    route_split = dual_route_split["o6_matched_nuisance_execution_return"]
    release_side = dual_route_split["o7_best_dressed_hardening_execution_return"]
    full_body = hubble_body["combined_burden"]

    full_body_public = full_body["public_delta_aic_total"]
    release_anchor = release_side["option2_minimal_delta_aic_total"]
    live_public_abs = abs(route_split["public_delta_aic_total"])

    scale_contrast = {
        "full_body_public_over_ngc0247_release_anchor": full_body_public / release_anchor,
        "full_body_public_over_ngc0247_live_public_magnitude": full_body_public / live_public_abs,
        "full_body_fraction_of_giant_spiral_head_burden": dual_route_split["full_body_grounding"][
            "fully_closed_hubble_flow_sensitive_body_fraction_of_giant_spiral_head_burden"
        ],
        "local_route_split_release_minus_public_live_gap": release_side[
            "release_minus_public_live_gap"
        ],
        "local_route_split_release_minus_component_aware_gap": release_side[
            "release_minus_o6_component_aware_gap"
        ],
    }

    consistency_checks = {
        "ngc0247_release_side_remains_anchor_stable_and_anti_qct": release_side[
            "release_side_hardening_is_anchor_stable_and_anti_qct"
        ],
        "ngc0247_live_side_remains_pro_qct": route_split[
            "witness_is_pro_qct_on_public_faithful_and_component_aware_surfaces"
        ],
        "ngc0247_release_anchor_spread_is_zero": release_side["anchor_spread_abs"] == 0.0,
        "ten_witness_body_still_closes_as_a_governed_block": hubble_body["uniform_direction"][
            "hubble_flow_sensitive_body_is_now_closed_as_a_governed_block"
        ],
        "ten_witness_body_remains_anti_qct_under_component_aware_replay": hubble_body[
            "uniform_direction"
        ]["all_ten_remain_anti_qct_under_component_aware_replay"],
        "matched_and_best_dressed_rotation_lanes_remain_distinct_on_the_board": (
            lane_status_board["consistency_checks"]["matched_lane_is_named_and_executed"]
            and lane_status_board["consistency_checks"][
                "best_dressed_lane_has_materialized_body_and_live_edge"
            ]
        ),
        "full_head_boundary_still_forbids_terminal_single_slogan_language": (
            full_head_boundary["consistency_checks"]["terminal_full_head_closure_is_not_admissible_now"]
            and full_head_boundary["consistency_checks"]["terminal_qct_win_is_not_admissible_now"]
            and full_head_boundary["consistency_checks"]["terminal_qct_defeat_is_not_admissible_now"]
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "packet_contained_reviewer_facing_empirical_tension_surface",
        "surface": "current_reviewer_facing_route_split_and_full_body_empirical_tension",
        "synthesis_inputs": {
            "local_route_split_surface": "NGC0247_FULL_BODY_GROUNDED_DUAL_EXECUTION_ROUTE_SPLIT_V1.json",
            "full_body_surface": "HUBBLE_FLOW_SENSITIVE_BODY_FULL_CLOSURE_V1.json",
            "full_head_boundary_surface": "CURRENT_FULL_HEAD_CONCENTRATED_BUT_NONTERMINAL_BOUNDARY_V1.json",
            "court_lane_board_surface": "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_STATUS_BOARD_V1.json",
        },
        "rotation_side_context": {
            "route_split_witness": matched_lane["route_split_witness"],
            "same_sign_softening_witness": matched_lane["same_sign_softening_witness"],
            "same_sign_hardening_body_witness_count": matched_lane[
                "same_sign_hardening_body_witness_count"
            ],
        },
        "local_route_split_witness": {
            "witness": dual_route_split["witness"],
            "live_matched_nuisance_return": route_split,
            "release_side_best_dressed_return": release_side,
        },
        "ten_witness_hardening_body": {
            "witness_count": len(hubble_body["witnesses"]),
            "witnesses": hubble_body["witnesses"],
            "combined_burden": full_body,
        },
        "scale_contrast": scale_contrast,
        "structural_reading": {
            "the_packet_now_carries_one_compressed_surface_linking_the_local_ngc0247_route_split_to_the_much_larger_ten_witness_same_sign_body": True,
            "the_ngc0247_route_split_is_real_but_does_not_erase_the_larger_bodywide_anti_qct_burden": True,
            "the_larger_bodywide_anti_qct_burden_is_real_but_does_not_erase_the_local_ngc0247_route_split": True,
            "no_honest_reader_sentence_may_collapse_this_empirical_state_into_one_single_sided_rotation_slogan": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the packet now carries one reviewer-facing empirical tension surface in which NGC0247 stays an explicit route-split witness while the ten-witness Hubble-flow-sensitive body stays the much larger anti-QCT burden",
            "the rotation side can now be summarized honestly without erasing either the local route split or the larger same-sign hardening body",
            "the selected court can now carry both local exception structure and global burden structure on one packet-side surface",
            "the packet now openly forbids both one-sided pro-QCT spin and one-sided anti-QCT spin on the same live rotation court",
        ],
        "not_supported_now": [
            "NGC0247 alone outweighs the wider ten-witness body",
            "the ten-witness body makes the NGC0247 route split disappear by convenience",
            "one single rotation slogan already settles the whole selected court",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_continuation": [
            "carry this tension surface beside the split matched-nuisance versus best-dressed rotation descent so the reviewer can see both the local exception and the larger body burden at once",
            "continue to preserve route split, softening, and hardening as distinct morphologies instead of forcing one unified slogan",
        ],
    }

    output["verdict"] = (
        "CURRENT_REVIEWER_FACING_ROUTE_SPLIT_AND_FULL_BODY_EMPIRICAL_TENSION_CLOSED__THE_PACKET_NOW_CARRIES_ONE_HONEST_ROTATION_SIDE_SURFACE_IN_WHICH_NGC0247_STAYS_A_LOCAL_ROUTE_SPLIT_WITNESS_WHILE_THE_TEN_WITNESS_HUBBLE_FLOW_SENSITIVE_BODY_STAYS_THE_LARGER_ANTI_QCT_BURDEN"
        if all(consistency_checks.values())
        else "CURRENT_REVIEWER_FACING_ROUTE_SPLIT_AND_FULL_BODY_EMPIRICAL_TENSION_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
