# `(I_amp^(0), I_geo^(0))` Pair Order-Bearing Carrier Contract Test Matrix

Date: `2026-06-12`

Status: `bounded contract matrix`

## Positive target

The present object is materialized if the current route already supports all
of the following:

1. `(I_amp, I_geo) -> (A_Q, M_Q)` is the carrier-side image map,
2. `J_lin := I_amp` survives as the support-side source-amplitude binding,
3. `I_geo -> A_Q` survives as the transport-leading certification lane,
4. `A_Q` outranks `M_Q` inside the downstream carrier order,
5. `I_amp^(0)` survives as one positive source-amplitude shell,
6. the pair-order burden already rejects flat coequal rereading,
7. and one bounded carrier contract object can therefore bear the internal
   order `I_geo^(0) > I_amp^(0)` at current grade.

## Failure signatures

The object fails if the current route instead requires any of the following:

1. no stable carrier-side image map for the pair,
2. no stable support-side `I_amp` lane,
3. no stable transport-leading `I_geo` lane,
4. `I_amp^(0)` and `I_geo^(0)` remain flat and coequal,
5. one hidden second carrier to keep the order alive,
6. one forced leap straight to final pairwise law,
7. or one forced leap straight to exact transport closure.

## Honest next-tooth reading

If the object survives,
the honest next-tooth reading is:

- `(I_amp^(0), I_geo^(0)) -> carrier contract object -> pairwise law tooth`

not:

- `(I_amp^(0), I_geo^(0)) -> final pairwise law`

and not:

- `(I_amp^(0), I_geo^(0)) -> exact transport closure`.
