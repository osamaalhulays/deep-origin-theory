# `(I_amp^(0), I_geo^(0))` Pair Order-Bearing Carrier Contract Scope And Boundary

Date: `2026-06-12`

Status: `bounded scope card`

## This object does claim

1. one reviewer-visible carrier contract object now exists for the shell-typed
   pair `(I_amp^(0), I_geo^(0))`
2. that object freezes one noncoequal internal order at carrier-law grade
3. the order is:
   `I_geo^(0)` transport-leading,
   `I_amp^(0)` support amplitude

## This object does not claim

1. final pairwise coefficient law
2. final formula for how the pair enters the coefficient
3. full `A_Q` certification
4. `T_Q^(0)` closure
5. exact transport closure
6. full `G1/G2` completion

## Honest next-tooth reading

If this object survives,
the honest next-tooth reading is:

- bounded carrier contract object first,
- pairwise coefficient-law tooth above it later

not:

- direct jump from pair order to full transport closure.
