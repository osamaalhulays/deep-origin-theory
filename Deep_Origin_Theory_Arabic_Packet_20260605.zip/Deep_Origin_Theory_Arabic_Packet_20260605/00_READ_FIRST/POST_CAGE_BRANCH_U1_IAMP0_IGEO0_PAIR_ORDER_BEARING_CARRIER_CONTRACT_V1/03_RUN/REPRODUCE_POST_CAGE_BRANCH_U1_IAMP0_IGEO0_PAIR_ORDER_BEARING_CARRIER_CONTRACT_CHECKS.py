#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"
PACKET_PREFIX = "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"

PAIR_MAP_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_RR0_BS1_VCAP1_IR1_VERTICAL_IMAGE_DECOMPOSITION_AND_122_FREEZE_ORDER_NOTE_20260608.md"
)
JLIN_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_RR0_BS1_JLIN_REGISTER_BINDING_FREEZE_AND_ACTIVE_DYAD_NOTE_20260608.md"
)
AQ_PIVOT_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_RR0_BS1_AQ_EXACT_TARGET_LOCALIZES_TO_TQ_TRANSPORT_OWNERSHIP_PIVOT_NOTE_20260608.md"
)
IAMP_SHELL_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_IAMP_SOURCE_PURITY_GATE_LOCALIZES_TO_METRIC_MATTER_ONLY_AMPLITUDE_SHELL_NOTE_20260608.md"
)
PAIR_ORDER_PATH = (
    "artifacts/debt_board_20260530/"
    + "G1_PRESENT_MATERIALS_REMAINING_BURDEN_SHARPENS_FROM_TRANSPORT_LEADING_CARRIER_SUBBINDING_ON_SHELL_TYPED_IAMP0_IGEO0_PAIR_TO_LAWFUL_NONCOEQUAL_INTERNAL_ORDER_CONTRACT_ON_THAT_PAIR_20260612.md"
)

NOTE_CHECKS = [
    {
        "key": "carrier_side_image_map",
        "path": PAIR_MAP_PATH,
        "fragments": [
            "`(I_amp, I_geo) -> (A_Q, M_Q)`",
            "`V_Q^(2) = {A_Q, M_Q}`",
            "carrier dyad",
        ],
        "meaning": "the pair already has one stable carrier-side image map",
    },
    {
        "key": "support_binding",
        "path": JLIN_PATH,
        "fragments": [
            "`J_lin := I_amp`",
            "The linear head no longer remains live-open",
            "source-amplitude register I_amp",
        ],
        "meaning": "the support-side I_amp lane is already frozen at register-binding grade",
    },
    {
        "key": "transport_leading_lane",
        "path": AQ_PIVOT_PATH,
        "fragments": [
            "`A_Q` = live transport-ownership pivot for the carrier side",
            "`M_Q` = co-carried mass face remaining inside the same later carrier lane",
            "`A_Q` now localizes to the real `T_Q` transport-ownership pivot under the",
            "`I_geo` moderation lane",
        ],
        "meaning": "the transport-leading I_geo -> A_Q lane already outranks the companion mass face",
    },
    {
        "key": "positive_support_shell",
        "path": IAMP_SHELL_PATH,
        "fragments": [
            "`I_amp^(0)[g,ψ]`",
            "`I_amp^(0) = metric/matter-only source-amplitude shell`",
            "the first positive admissible shell for `I_amp` is now named",
        ],
        "meaning": "the support-side positive shell already exists",
    },
    {
        "key": "noncoequal_pair_order",
        "path": PAIR_ORDER_PATH,
        "fragments": [
            "one flat coequal doublet with no internal order",
            "`I_geo^(0)` as the transport-leading face",
            "`I_amp^(0)` as the support amplitude face",
        ],
        "meaning": "the pair-order burden already rejects flat coequality",
    },
]


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


def find_packet_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if parent.name == "00_READ_FIRST" and (parent / "START_HERE_FIRST.md").exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
SCRIPT_PACKET_ROOT = find_packet_root()
if SCRIPT_PACKET_ROOT is not None:
    PACKET_ROOT = SCRIPT_PACKET_ROOT
    RUNNING_FROM_PACKET = True
elif WORKSPACE_ROOT is not None:
    PACKET_ROOT = WORKSPACE_ROOT / "Deep_Origin_Theory_English_Packet_20260605" / "00_READ_FIRST"
    RUNNING_FROM_PACKET = False
else:
    raise RuntimeError("could not locate workspace or packet root from pair-order contract runner")


def candidate_paths(logical_relative_path: str) -> list[Path]:
    candidates: list[Path] = []

    def add(path: Path) -> None:
        if path not in candidates:
            candidates.append(path)

    if RUNNING_FROM_PACKET and logical_relative_path.startswith(PACKET_PREFIX):
        add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    if WORKSPACE_ROOT is not None:
        add(WORKSPACE_ROOT / logical_relative_path)
        if logical_relative_path.startswith(PACKET_PREFIX):
            add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    return candidates


def resolve_existing_path(logical_relative_path: str) -> Path:
    for candidate in candidate_paths(logical_relative_path):
        if candidate.exists():
            return candidate
    searched = "\n".join(str(path) for path in candidate_paths(logical_relative_path))
    raise FileNotFoundError(
        f"could not resolve pair-order contract surface: {logical_relative_path}\n{searched}"
    )


def read_text(logical_relative_path: str) -> str:
    return resolve_existing_path(logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": item["path"],
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    verdict_name = (
        "POST_CAGE_BRANCH_U1_IAMP0_IGEO0_PAIR_ORDER_BEARING_CARRIER_CONTRACT_MATERIALIZED"
        if all_note_checks_pass
        else "POST_CAGE_BRANCH_U1_IAMP0_IGEO0_PAIR_ORDER_BEARING_CARRIER_CONTRACT_NOT_MATERIALIZED"
    )

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": verdict_name,
        "carrier_side_image_map_confirmed": note_check_map["carrier_side_image_map"],
        "support_binding_confirmed": note_check_map["support_binding"],
        "transport_leading_lane_confirmed": note_check_map["transport_leading_lane"],
        "positive_support_shell_confirmed": note_check_map["positive_support_shell"],
        "noncoequal_pair_order_confirmed": note_check_map["noncoequal_pair_order"],
        "all_note_checks_pass": all_note_checks_pass,
        "flat_coequal_pair_required_now": False,
        "hidden_second_carrier_required_now": False,
        "final_pairwise_coefficient_law_already_claimed": False,
    }

    verdict = {
        "verdict": verdict_name,
        "contract_object": "IAMP0_IGEO0_PAIR_ORDER_BEARING_CARRIER_CONTRACT",
        "binding_pair": "(I_amp^(0), I_geo^(0))",
        "frozen_internal_order": "I_geo^(0) > I_amp^(0)",
        "grade": "carrier_law_grade",
        "next_exact_tooth": "pairwise_coefficient_law_tooth_above_object",
    }

    if all_note_checks_pass:
        reading_lines = [
            "- one bounded carrier contract object now holds the shell-typed pair,",
            "- the object's frozen internal order is `I_geo^(0) > I_amp^(0)`,",
            "- and the next exact tooth now sits above object absence.",
        ]
    else:
        reading_lines = [
            "- the supporting route surfaces are present but do not yet pass the current materialization check,",
            "- so the object cannot yet be treated as verified reviewer-visible closure,",
            "- and the route stays below pairwise-law ascent until the missing check surfaces are repaired or strengthened.",
        ]

    report_lines = [
        "# Post-Cage Branch U1 `(I_amp^(0), I_geo^(0))` Pair Order-Bearing Carrier Contract Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- carrier-side image map confirmed: `{status_summary['carrier_side_image_map_confirmed']}`",
        f"- support-side `I_amp` binding confirmed: `{status_summary['support_binding_confirmed']}`",
        f"- transport-leading `I_geo` lane confirmed: `{status_summary['transport_leading_lane_confirmed']}`",
        f"- positive `I_amp^(0)` shell confirmed: `{status_summary['positive_support_shell_confirmed']}`",
        f"- noncoequal pair order confirmed: `{status_summary['noncoequal_pair_order_confirmed']}`",
        f"- all note checks pass: `{status_summary['all_note_checks_pass']}`",
        "",
        "## Reading",
        "",
        *reading_lines,
        "",
        "## Ceiling",
        "",
        "- this report does not claim final pairwise coefficient law,",
        "- it does not claim full `A_Q` certification or `T_Q^(0)` closure,",
        "- it does not claim exact transport closure or full `G1/G2` completion.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    write_json(
        OUTPUT_ROOT / "source_inputs.json",
        {
            "pair_map_path": PAIR_MAP_PATH,
            "jlin_path": JLIN_PATH,
            "aq_pivot_path": AQ_PIVOT_PATH,
            "iamp_shell_path": IAMP_SHELL_PATH,
            "pair_order_path": PAIR_ORDER_PATH,
        },
    )
    (OUTPUT_ROOT / "IAMP0_IGEO0_PAIR_ORDER_BEARING_CARRIER_CONTRACT_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
