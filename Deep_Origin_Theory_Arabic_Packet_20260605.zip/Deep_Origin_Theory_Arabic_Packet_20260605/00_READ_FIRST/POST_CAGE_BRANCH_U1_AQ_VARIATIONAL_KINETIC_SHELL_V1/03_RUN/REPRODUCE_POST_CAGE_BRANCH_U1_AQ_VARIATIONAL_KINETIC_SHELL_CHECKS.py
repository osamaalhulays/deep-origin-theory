#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"
PACKET_PREFIX = "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"

AQ_SHELL_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_OTRANSPORT_IGEO_TO_AQ_ROUTE_LOCALIZES_TO_BQ_FREE_VARIATIONAL_KINETIC_SHELL_BEFORE_TQ_LIFT_NOTE_20260608.md"
)
BQ_NARROWING_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_FIRST_NARROWING_NO_MANDATORY_BQ_AND_PASSIVE_SOUTH_PROJECTION_NOTE_20260608.md"
)
TQ_GATE_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_TQ_OWNERSHIP_FIRST_GATE_LOCALIZES_TO_SAME_CARRIER_VARIATIONAL_LEDGER_ADMISSION_NOTE_20260608.md"
)

NOTE_CHECKS = [
    {
        "key": "aq_positive_shell",
        "path": AQ_SHELL_PATH,
        "fragments": [
            "`A_Q^(0)[I_geo^(0)] = B_Q-free same-carrier variational kinetic shell`",
            "`I_geo^(0) -> A_Q^(0) -> T_Q ownership`",
            "`A_Q^(0)` is the first variational kinetic shell",
        ],
        "meaning": "the exact positive A_Q shell is already localized cleanly",
    },
    {
        "key": "bq_nonmandatory",
        "path": BQ_NARROWING_PATH,
        "fragments": [
            "no mandatory primitive `B_Q` in the first narrowed strike",
            "`L_Q^(QF1a) = A_Q[g,ψ] g^{μν} ∇_μ Q ∇_ν Q + M_Q[g,ψ] Q^2`",
            "`B_Q` may remain one later recovery class",
        ],
        "meaning": "the first A_Q shell remains B_Q-free under the narrowed live grammar",
    },
    {
        "key": "tq_next_tooth",
        "path": TQ_GATE_PATH,
        "fragments": [
            "`T_Q^(0) = same-carrier variational ledger admission`",
            "`A_Q^(0) -> T_Q^(0) -> exact closure test`",
            "The first gate inside `T_Q ownership` is not yet:",
        ],
        "meaning": "the next exact tooth above A_Q is the T_Q ledger-admission shell",
    },
]


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


def find_packet_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if parent.name == "00_READ_FIRST" and (parent / "START_HERE_FIRST.md").exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
SCRIPT_PACKET_ROOT = find_packet_root()
if SCRIPT_PACKET_ROOT is not None:
    PACKET_ROOT = SCRIPT_PACKET_ROOT
    RUNNING_FROM_PACKET = True
elif WORKSPACE_ROOT is not None:
    PACKET_ROOT = WORKSPACE_ROOT / "Deep_Origin_Theory_English_Packet_20260605" / "00_READ_FIRST"
    RUNNING_FROM_PACKET = False
else:
    raise RuntimeError("could not locate workspace or packet root from A_Q shell runner")


def candidate_paths(logical_relative_path: str) -> list[Path]:
    candidates: list[Path] = []

    def add(path: Path) -> None:
        if path not in candidates:
            candidates.append(path)

    if RUNNING_FROM_PACKET and logical_relative_path.startswith(PACKET_PREFIX):
        add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    if WORKSPACE_ROOT is not None:
        add(WORKSPACE_ROOT / logical_relative_path)
        if logical_relative_path.startswith(PACKET_PREFIX):
            add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    return candidates


def resolve_existing_path(logical_relative_path: str) -> Path:
    for candidate in candidate_paths(logical_relative_path):
        if candidate.exists():
            return candidate
    searched = "\n".join(str(path) for path in candidate_paths(logical_relative_path))
    raise FileNotFoundError(
        f"could not resolve A_Q shell surface: {logical_relative_path}\n{searched}"
    )


def read_text(logical_relative_path: str) -> str:
    return resolve_existing_path(logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": item["path"],
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": (
            "POST_CAGE_BRANCH_U1_AQ_VARIATIONAL_KINETIC_SHELL_MATERIALIZED"
            if all_note_checks_pass
            else "POST_CAGE_BRANCH_U1_AQ_VARIATIONAL_KINETIC_SHELL_NOT_MATERIALIZED"
        ),
        "aq_positive_shell_confirmed": note_check_map["aq_positive_shell"],
        "bq_nonmandatory_preserved": note_check_map["bq_nonmandatory"],
        "next_exact_tooth_localized_to_tq0": note_check_map["tq_next_tooth"],
        "same_carrier_transport_reading_preserved": all_note_checks_pass,
        "mandatory_bq_required_now": False,
        "hidden_second_carrier_required_now": False,
        "external_patch_required_now": False,
        "all_note_checks_pass": all_note_checks_pass,
    }

    verdict = {
        "verdict": status_summary["verdict"],
        "positive_shell": "A_Q^(0)[I_geo^(0)] = B_Q-free same-carrier variational kinetic shell",
        "next_exact_tooth": "T_Q^(0) = same-carrier variational ledger admission",
        "live_chain": "I_geo^(0) -> A_Q^(0) -> T_Q^(0) -> exact closure test",
    }

    report_lines = [
        "# Post-Cage Branch U1 A_Q Variational Kinetic Shell Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- positive `A_Q` shell confirmed: `{status_summary['aq_positive_shell_confirmed']}`",
        f"- `B_Q`-nonmandatory discipline preserved: `{status_summary['bq_nonmandatory_preserved']}`",
        f"- next exact tooth localized to `T_Q^(0)`: `{status_summary['next_exact_tooth_localized_to_tq0']}`",
        f"- same-carrier transport reading preserved: `{status_summary['same_carrier_transport_reading_preserved']}`",
        f"- all note checks pass: `{status_summary['all_note_checks_pass']}`",
        "",
        "## Reading",
        "",
        "- the first positive `A_Q` shell is now reviewer-visible,",
        "- it is `B_Q`-free at first exact grade,",
        "- it remains same-carrier and variational,",
        "- and the next honest tooth above it is `T_Q^(0)`, not direct exact closure.",
        "",
        "## Ceiling",
        "",
        "- this report does not claim final `T_Q` ownership closure,",
        "- it does not claim exact divergence cancellation already achieved,",
        "- it does not claim full transport closure or full `G1/G2` completion.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    write_json(
        OUTPUT_ROOT / "source_inputs.json",
        {
            "aq_shell_path": AQ_SHELL_PATH,
            "bq_narrowing_path": BQ_NARROWING_PATH,
            "tq_gate_path": TQ_GATE_PATH,
        },
    )
    (OUTPUT_ROOT / "AQ_VARIATIONAL_KINETIC_SHELL_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
