#!/usr/bin/env python3
import csv
import json
import math
from pathlib import Path

KPC_IN_M = 3.085677581491367e+19
A0_MS2 = 1.2e-10
UPSILON_PHASE2_CURRENT_SEED42 = 0.9254967104326863
UPSILON_QUMOND_PHASE2_SEED42 = 0.5685897225673557
TARGET_LL_QCT_OBS_ONLY = -416.9274550145858
TARGET_LL_QCT_OBS_MODEL = -347.4113136571038
TARGET_LL_QUMOND_OBS_ONLY = -268.4815452508469
TARGET_DELTA_AIC_TOTAL = 159.85953681251374
TARGET_DELTA_BIC_TOTAL = 161.11763335053513

HERE = Path(__file__).resolve().parent
SOURCE_CASE = HERE / "NGC0247_PHASE2_SOURCE_CASE_V1.json"
PRED_ONE = HERE / "NGC0247_PHASE2_PRED_ONE_V1.ndjson"
CSV_PATH = HERE / "NGC0247_CURRENT_ROW_COMPARATOR__QCT_AND_FIXED_QUMOND__V1.csv"

def predict_qct(v_bar_ms, upsilon, delta_1d):
    return math.sqrt(upsilon) * v_bar_ms * math.sqrt(1.0 + delta_1d)

def sigma_qct(v_bar_ms, upsilon, delta_1d, sigma_delta_1d):
    return math.sqrt(upsilon) * v_bar_ms * (0.5 * sigma_delta_1d / math.sqrt(1.0 + delta_1d))

def predict_qumond(R_m, v_bar_ms):
    g_bar = (v_bar_ms ** 2) / R_m
    y = g_bar / A0_MS2
    nu = 0.5 + math.sqrt(0.25 + 1.0 / y)
    return v_bar_ms * math.sqrt(nu)

def predict_qumond_with_upsilon(R_m, v_bar_ms, upsilon):
    return predict_qumond(R_m, math.sqrt(upsilon) * v_bar_ms)

def gaussian_loglike(y_obs, y_model, sigma_obs, sigma_model=None):
    total = 0.0
    for i in range(len(y_obs)):
        var_eff = sigma_obs[i] ** 2
        if sigma_model is not None:
            var_eff += sigma_model[i] ** 2
        resid = y_obs[i] - y_model[i]
        total += -0.5 * (((resid ** 2) / var_eff) + math.log(2.0 * math.pi * var_eff))
    return total

case = json.loads(SOURCE_CASE.read_text(encoding="utf-8"))
pred = json.loads(PRED_ONE.read_text(encoding="utf-8").splitlines()[0])

R_grid_m = case["R_grid_m"]
v_obs_ms = case["v_obs_ms"]
sigma_v_ms = case["sigma_v_ms"]
v_bar_ms = case["v_bar_ms"]
delta_1d = pred["delta_1d"]
sigma_delta_1d = pred["sigma_delta_1d"]

rows = list(csv.DictReader(CSV_PATH.open("r", encoding="utf-8")))
if len(rows) != len(R_grid_m):
    raise SystemExit("row count mismatch")

v_qct = []
sigma_qct_vals = []
v_qumond_fixed = []
v_qumond_benchmark = []
for i in range(len(R_grid_m)):
    vq = predict_qct(v_bar_ms[i], UPSILON_PHASE2_CURRENT_SEED42, delta_1d[i])
    sq = sigma_qct(v_bar_ms[i], UPSILON_PHASE2_CURRENT_SEED42, delta_1d[i], sigma_delta_1d[i])
    vm_fixed = predict_qumond(R_grid_m[i], v_bar_ms[i])
    vm_bench = predict_qumond_with_upsilon(R_grid_m[i], v_bar_ms[i], UPSILON_QUMOND_PHASE2_SEED42)
    v_qct.append(vq)
    sigma_qct_vals.append(sq)
    v_qumond_fixed.append(vm_fixed)
    v_qumond_benchmark.append(vm_bench)

    csv_vq = float(rows[i]["v_QCT_current_km_s"]) * 1000.0
    csv_sq = float(rows[i]["sigma_model_QCT_km_s"]) * 1000.0
    csv_vm_fixed = float(rows[i]["v_QUMOND_fixed_km_s"]) * 1000.0
    csv_vm_bench = float(rows[i]["v_QUMOND_phase2_benchmark_km_s"]) * 1000.0
    if (
        abs(vq - csv_vq) > 1e-9
        or abs(sq - csv_sq) > 1e-9
        or abs(vm_fixed - csv_vm_fixed) > 1e-9
        or abs(vm_bench - csv_vm_bench) > 1e-9
    ):
        raise SystemExit(f"row {i+1} mismatch")

ll_qct_obs_only = gaussian_loglike(v_obs_ms, v_qct, sigma_v_ms, sigma_model=None)
ll_qct_obs_model = gaussian_loglike(v_obs_ms, v_qct, sigma_v_ms, sigma_model=sigma_qct_vals)
ll_qumond_obs_only = gaussian_loglike(v_obs_ms, v_qumond_benchmark, sigma_v_ms, sigma_model=None)
qct_aic_total_historic = 2.0 * 3 - 2.0 * ll_qct_obs_model
qct_bic_total_historic = 3.0 * math.log(len(rows)) - 2.0 * ll_qct_obs_model
qumond_aic_total = 2.0 * 2 - 2.0 * ll_qumond_obs_only
qumond_bic_total = 2.0 * math.log(len(rows)) - 2.0 * ll_qumond_obs_only

output = {
    "surface": "ngc0247_phase2_current_row_comparator",
    "row_count": len(rows),
    "upsilon_phase2_seed42": UPSILON_PHASE2_CURRENT_SEED42,
    "upsilon_qumond_phase2_seed42": UPSILON_QUMOND_PHASE2_SEED42,
    "ll_qct_obs_only": ll_qct_obs_only,
    "ll_qct_obs_model": ll_qct_obs_model,
    "ll_qumond_benchmark_obs_only": ll_qumond_obs_only,
    "delta_aic_total_historic": (qct_aic_total_historic - qumond_aic_total),
    "delta_bic_total_historic": (qct_bic_total_historic - qumond_bic_total),
    "ll_qct_obs_only_abs_error": abs(ll_qct_obs_only - TARGET_LL_QCT_OBS_ONLY),
    "ll_qct_obs_model_abs_error": abs(ll_qct_obs_model - TARGET_LL_QCT_OBS_MODEL),
    "ll_qumond_benchmark_obs_only_abs_error": abs(ll_qumond_obs_only - TARGET_LL_QUMOND_OBS_ONLY),
    "delta_aic_total_abs_error": abs((qct_aic_total_historic - qumond_aic_total) - TARGET_DELTA_AIC_TOTAL),
    "delta_bic_total_abs_error": abs((qct_bic_total_historic - qumond_bic_total) - TARGET_DELTA_BIC_TOTAL),
}

print(json.dumps(output, indent=2, sort_keys=True))
