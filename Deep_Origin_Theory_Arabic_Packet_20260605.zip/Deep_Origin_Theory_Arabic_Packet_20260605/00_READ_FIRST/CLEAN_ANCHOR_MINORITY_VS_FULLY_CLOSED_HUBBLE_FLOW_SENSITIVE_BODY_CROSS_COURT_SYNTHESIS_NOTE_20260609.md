# Clean-Anchor Minority vs Fully Closed Hubble-Flow-Sensitive Body Cross-Court Synthesis Note

Date: `2026-06-09`

Status: `bounded packet-facing cross-archive synthesis`

Purpose:

After fully closing the Hubble-flow-sensitive body itself,
the next honest task is to synthesize that closed majority-side court against
the protected clean-anchor minority rather than pretending either side alone
settles the whole giant-spiral head.

It should be read after:

- `HUBBLE_FLOW_SENSITIVE_BODY_FULL_CLOSURE_NOTE_20260609.md`

Machine-readable companion:

- `CLEAN_ANCHOR_MINORITY_VS_FULLY_CLOSED_HUBBLE_FLOW_SENSITIVE_BODY_CROSS_COURT_SYNTHESIS_V1.json`

Direct continuation now materialized in:

- `GLOBAL_CROSS_COURT_ADMISSIBLE_VERDICT_BOUNDARY_AFTER_FULL_BODY_CLEAN_ANCHOR_SYNTHESIS_NOTE_20260609.md`

## Short verdict

The giant-spiral head now reads as one governed bifurcated cross-court
structure:

- one protected clean-anchor minority court
- one fully closed Hubble-flow-sensitive body

## 1. Court A: protected clean-anchor minority

The protected clean-anchor minority court carries:

- `4` named witnesses
- total burden `65677.25633547574`
- giant-spiral head share `34.45341820567513%`
- all non-Hubble-flow anchored
- all quality `1`
- all visibly multiseed stable

## 2. Court B: fully closed Hubble-flow-sensitive body

The fully closed Hubble-flow-sensitive body court carries:

- `10` named witnesses
- public burden `124948.98557586371`
- faithful replay burden `86258.84036593112`
- component-aware replay burden `92780.09909850561`
- net component-aware shift `+6521.258732574497`
- giant-spiral head share `65.54658179432487%`
- lead over the clean-anchor minority `59271.72924038797`

## 3. What this now means

Supported now:

- the giant-spiral head is not empirically monolithic
- `QCT` retains one real protected clean-anchor minority court
- the fully closed Hubble-flow-sensitive body still dominates the head burden
- any fair full-head reading must carry both courts simultaneously

## 4. What this does not authorize

This note does **not** authorize the claims that:

- the clean-anchor minority may be erased
- the clean-anchor minority alone overturns the fully closed Hubble body
- the whole giant-spiral head is already globally settled

## 5. Next honest escalation

The next honest escalation is:

- one explicit global admissible verdict boundary for the current bifurcated
  full-head reading

## Best outward-safe reading

One mature outward-safe sentence is:

> The current full-head reading is no longer one single-side verdict but one
> governed bifurcated cross-court structure, with a protected clean-anchor
> minority and one fully closed Hubble-flow-sensitive body that still carries
> the larger burden share.
