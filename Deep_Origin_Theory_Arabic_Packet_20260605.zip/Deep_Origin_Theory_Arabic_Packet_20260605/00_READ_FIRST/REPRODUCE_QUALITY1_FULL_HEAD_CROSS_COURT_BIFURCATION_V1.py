#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

CLEAN_ANCHOR_SYNTHESIS_PATH = HERE / "CLEAN_ANCHOR_MINORITY_VS_FULLY_CLOSED_HUBBLE_FLOW_SENSITIVE_BODY_CROSS_COURT_SYNTHESIS_V1.json"
HUBBLE_QUALITY_SPLIT_PATH = HERE / "HUBBLE_FLOW_SENSITIVE_BODY_QUALITY_STRATIFIED_HARDENING_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def close_enough(left, right, tolerance=1e-9):
    return abs(left - right) <= tolerance


def main():
    clean_anchor = load_json(CLEAN_ANCHOR_SYNTHESIS_PATH)
    hubble_quality = load_json(HUBBLE_QUALITY_SPLIT_PATH)

    clean = clean_anchor["clean_anchor_minority_court"]
    body_q1 = hubble_quality["quality1_subgroup"]

    total_quality1_public_burden = clean["delta_aic_sum"] + body_q1["public_delta_aic_total"]
    clean_share = clean["delta_aic_sum"] / total_quality1_public_burden
    body_share = body_q1["public_delta_aic_total"] / total_quality1_public_burden

    consistency_checks = {
        "clean_anchor_court_is_all_quality1": clean["all_quality1"] is True,
        "hubble_quality1_subgroup_count_is_seven": body_q1["case_count"] == 7,
        "quality1_bifurcation_case_count_is_eleven": clean["case_count"] + body_q1["case_count"] == 11,
        "quality1_public_burden_recombines_exactly": close_enough(
            clean["delta_aic_sum"] + body_q1["public_delta_aic_total"],
            total_quality1_public_burden,
        ),
        "clean_anchor_and_hubble_quality1_are_disjoint_case_sets": set(clean["cases"]).isdisjoint(
            body_q1["cases"]
        ),
        "hubble_quality1_subgroup_still_uniformly_hardens": hubble_quality["consistency_checks"][
            "all_quality1_members_harden"
        ],
        "quality1_split_is_not_lopsided_to_one_side_only": (
            clean_share > 0.25 and body_share > 0.25
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "bounded_packet_facing_quality1_cross_court_bifurcation",
        "surface": "quality1_full_head_cross_court_bifurcation",
        "quality1_full_head_slice": {
            "case_count": clean["case_count"] + body_q1["case_count"],
            "public_delta_aic_total": total_quality1_public_burden,
        },
        "quality1_clean_anchor_court": {
            "case_count": clean["case_count"],
            "cases": clean["cases"],
            "public_delta_aic_total": clean["delta_aic_sum"],
            "fraction_of_quality1_full_head_public_burden": clean_share,
            "all_non_hubble_flow_anchored": clean["all_non_hubble_flow_anchored"],
            "all_visible_multiseed_stable": clean["all_visible_multiseed_stable"],
        },
        "quality1_hubble_flow_sensitive_subgroup": {
            "case_count": body_q1["case_count"],
            "cases": body_q1["cases"],
            "public_delta_aic_total": body_q1["public_delta_aic_total"],
            "component_aware_delta_aic_total": body_q1["component_aware_delta_aic_total"],
            "component_aware_shift": body_q1["component_aware_shift"],
            "fraction_of_quality1_full_head_public_burden": body_share,
            "all_component_aware_shifts_harden": hubble_quality["consistency_checks"][
                "all_quality1_members_harden"
            ],
        },
        "structural_reading": {
            "quality1_alone_does_not_settle_the_current_full_head": True,
            "quality1_itself_is_bifurcated_by_court_membership": True,
            "the_stronger_current_separator_is_hubble_flow_sensitive_body_membership_not_quality1_status_alone": True,
        },
        "consistency_checks": consistency_checks,
        "not_supported_now": [
            "Quality1 alone predicts one uniform current full-head verdict",
            "Quality1 alone reproduces the protected clean-anchor minority",
            "Quality1 alone reproduces the hardening body",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_frontier": [
            "test_whether_later_quality1_additions_follow_hubble_flow_sensitive_membership_more_than_raw_quality_flag",
            "extend_the_cross_observable_court_without_reducing_the_current_split_to_quality_labeling",
        ],
    }

    output["verdict"] = (
        "QUALITY1_FULL_HEAD_CROSS_COURT_BIFURCATION_CLOSED__QUALITY1_ALONE_DOES_NOT_SETTLE_THE_HEAD_BECAUSE_IT_SPLITS_BETWEEN_A_PROTECTED_CLEAN_ANCHOR_MINORITY_AND_A_LARGER_HUBBLE_FLOW_SENSITIVE_HARDENING_SUBGROUP"
        if all(consistency_checks.values())
        else "QUALITY1_FULL_HEAD_CROSS_COURT_BIFURCATION_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
