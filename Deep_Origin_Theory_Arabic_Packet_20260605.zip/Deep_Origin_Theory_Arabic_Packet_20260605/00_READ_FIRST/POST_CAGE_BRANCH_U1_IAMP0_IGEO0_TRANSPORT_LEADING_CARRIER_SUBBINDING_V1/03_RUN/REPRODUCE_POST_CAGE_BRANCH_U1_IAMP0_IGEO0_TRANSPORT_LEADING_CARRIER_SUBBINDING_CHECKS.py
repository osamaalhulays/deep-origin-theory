#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"
PACKET_PREFIX = "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"

VCAP1_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_RR0_BS1_VCAP1_IR1_VERTICAL_IMAGE_DECOMPOSITION_AND_122_FREEZE_ORDER_NOTE_20260608.md"
)
IMIX_OWNER_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_RR0_BS1_IR1_STEP1_SOUTH_SINGLETON_FREEZE_NOTE_20260608.md"
)
AQ_PIVOT_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_RR0_BS1_AQ_EXACT_TARGET_LOCALIZES_TO_TQ_TRANSPORT_OWNERSHIP_PIVOT_NOTE_20260608.md"
)
IAMP_SHELL_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_IAMP_SOURCE_PURITY_GATE_LOCALIZES_TO_METRIC_MATTER_ONLY_AMPLITUDE_SHELL_NOTE_20260608.md"
)
SHARPEN_PATH = (
    "artifacts/debt_board_20260530/"
    + "G1_PRESENT_MATERIALS_REMAINING_BURDEN_SHARPENS_FROM_SHARED_SOURCE_DEPENDENCE_BINDING_ON_SHELL_TYPED_IR1_REGISTER_TO_LAWFUL_TRANSPORT_LEADING_CARRIER_SUBBINDING_ON_SHELL_TYPED_IAMP0_IGEO0_PAIR_20260612.md"
)

NOTE_CHECKS = [
    {
        "key": "vertical_image_and_pair_map",
        "path": VCAP1_PATH,
        "fragments": [
            "`V_CAP1^(IR1) = V_S^(1) + V_int^(2) + V_Q^(2)`",
            "`(I_amp, I_geo) -> (A_Q, M_Q)`",
            "carrier dyad",
        ],
        "meaning": "the vertical image decomposition already isolates the carrier pair",
    },
    {
        "key": "south_singleton_owner",
        "path": IMIX_OWNER_PATH,
        "fragments": [
            "`w_lin = I_mix`",
            "singleton",
        ],
        "meaning": "the I_mix line is already isolated away from the first carrier-side burden",
    },
    {
        "key": "transport_pivot_order",
        "path": AQ_PIVOT_PATH,
        "fragments": [
            "`A_Q` = live transport-ownership pivot for the carrier side",
            "`M_Q` = co-carried mass face remaining inside the same later carrier lane",
        ],
        "meaning": "A_Q already leads the downstream carrier order",
    },
    {
        "key": "support_amplitude_face",
        "path": IAMP_SHELL_PATH,
        "fragments": [
            "`I_amp^(0)[g,ψ]`",
            "`I_amp^(0) = metric/matter-only source-amplitude shell`",
        ],
        "meaning": "the support-side amplitude face is already positively typed",
    },
    {
        "key": "bounded_subbinding_burden",
        "path": SHARPEN_PATH,
        "fragments": [
            "one reviewer-visible lawful transport-leading carrier subbinding carrying",
            "shell-typed `(I_amp^(0), I_geo^(0))` pair inside `I_src^(IR1,0)`",
            "`I_mix^(0)` remains live inside the broader shared-source architecture",
        ],
        "meaning": "the exact transport-leading subbinding burden is already sharply stated",
    },
]


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


def find_packet_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if parent.name == "00_READ_FIRST" and (parent / "START_HERE_FIRST.md").exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
SCRIPT_PACKET_ROOT = find_packet_root()
if SCRIPT_PACKET_ROOT is not None:
    PACKET_ROOT = SCRIPT_PACKET_ROOT
    RUNNING_FROM_PACKET = True
elif WORKSPACE_ROOT is not None:
    PACKET_ROOT = WORKSPACE_ROOT / "Deep_Origin_Theory_English_Packet_20260605" / "00_READ_FIRST"
    RUNNING_FROM_PACKET = False
else:
    raise RuntimeError("could not locate workspace or packet root from transport-leading subbinding runner")


def candidate_paths(logical_relative_path: str) -> list[Path]:
    candidates: list[Path] = []

    def add(path: Path) -> None:
        if path not in candidates:
            candidates.append(path)

    if RUNNING_FROM_PACKET and logical_relative_path.startswith(PACKET_PREFIX):
        add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    if WORKSPACE_ROOT is not None:
        add(WORKSPACE_ROOT / logical_relative_path)
        if logical_relative_path.startswith(PACKET_PREFIX):
            add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    return candidates


def resolve_existing_path(logical_relative_path: str) -> Path:
    for candidate in candidate_paths(logical_relative_path):
        if candidate.exists():
            return candidate
    searched = "\n".join(str(path) for path in candidate_paths(logical_relative_path))
    raise FileNotFoundError(
        f"could not resolve transport-leading subbinding surface: {logical_relative_path}\n{searched}"
    )


def read_text(logical_relative_path: str) -> str:
    return resolve_existing_path(logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": item["path"],
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    verdict_name = (
        "POST_CAGE_BRANCH_U1_IAMP0_IGEO0_TRANSPORT_LEADING_CARRIER_SUBBINDING_MATERIALIZED"
        if all_note_checks_pass
        else "POST_CAGE_BRANCH_U1_IAMP0_IGEO0_TRANSPORT_LEADING_CARRIER_SUBBINDING_NOT_MATERIALIZED"
    )

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": verdict_name,
        "vertical_image_and_pair_map_confirmed": note_check_map["vertical_image_and_pair_map"],
        "south_singleton_owner_confirmed": note_check_map["south_singleton_owner"],
        "transport_pivot_order_confirmed": note_check_map["transport_pivot_order"],
        "support_amplitude_face_confirmed": note_check_map["support_amplitude_face"],
        "bounded_subbinding_burden_confirmed": note_check_map["bounded_subbinding_burden"],
        "all_note_checks_pass": all_note_checks_pass,
        "final_pairwise_coefficient_law_already_claimed": False,
        "noncoequal_internal_order_contract_already_claimed_as_closed": False,
    }

    verdict = {
        "verdict": verdict_name,
        "object": "IAMP0_IGEO0_TRANSPORT_LEADING_CARRIER_SUBBINDING",
        "binding_pair": "(I_amp^(0), I_geo^(0))",
        "transport_leading_face": "I_geo^(0)",
        "support_amplitude_face": "I_amp^(0)",
        "excluded_first_competitor": "I_mix^(0)",
        "grade": "carrier_subbinding_grade",
        "next_exact_tooth": "noncoequal_internal_order_contract_on_shell_typed_iamp0_igeo0_pair",
    }

    if all_note_checks_pass:
        reading_lines = [
            "- one bounded transport-leading subbinding object now holds the shell-typed pair,",
            "- the object keeps `I_geo^(0)` as transport-leading and `I_amp^(0)` as support-side amplitude,",
            "- and the next exact tooth now sits above pair-level subbinding absence.",
        ]
    else:
        reading_lines = [
            "- the supporting route surfaces are present but do not yet pass the current materialization check,",
            "- so the object cannot yet be treated as verified reviewer-visible closure,",
            "- and the route stays below pair-order ascent until the missing check surfaces are repaired or strengthened.",
        ]

    report_lines = [
        "# Post-Cage Branch U1 `(I_amp^(0), I_geo^(0))` Transport-Leading Carrier Subbinding Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- vertical image and pair map confirmed: `{status_summary['vertical_image_and_pair_map_confirmed']}`",
        f"- south singleton owner confirmed: `{status_summary['south_singleton_owner_confirmed']}`",
        f"- transport pivot order confirmed: `{status_summary['transport_pivot_order_confirmed']}`",
        f"- support amplitude face confirmed: `{status_summary['support_amplitude_face_confirmed']}`",
        f"- bounded transport-leading burden confirmed: `{status_summary['bounded_subbinding_burden_confirmed']}`",
        f"- all note checks pass: `{status_summary['all_note_checks_pass']}`",
        "",
        "## Reading",
        "",
        *reading_lines,
        "",
        "## Ceiling",
        "",
        "- this report does not claim final pairwise coefficient law,",
        "- it does not claim full `A_Q` certification or `T_Q^(0)` closure,",
        "- it does not claim exact transport closure or full `G1/G2` completion.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    write_json(
        OUTPUT_ROOT / "source_inputs.json",
        {
            "vcap1_path": VCAP1_PATH,
            "imix_owner_path": IMIX_OWNER_PATH,
            "aq_pivot_path": AQ_PIVOT_PATH,
            "iamp_shell_path": IAMP_SHELL_PATH,
            "sharpen_path": SHARPEN_PATH,
        },
    )
    (OUTPUT_ROOT / "IAMP0_IGEO0_TRANSPORT_LEADING_CARRIER_SUBBINDING_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
