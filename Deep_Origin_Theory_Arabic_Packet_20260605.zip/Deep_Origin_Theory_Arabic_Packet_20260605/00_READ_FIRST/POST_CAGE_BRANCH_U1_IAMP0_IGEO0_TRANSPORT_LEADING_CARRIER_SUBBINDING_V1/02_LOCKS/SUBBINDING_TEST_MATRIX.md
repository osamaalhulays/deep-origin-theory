# `(I_amp^(0), I_geo^(0))` Transport-Leading Carrier Subbinding Test Matrix

Date: `2026-06-12`

Status: `test matrix`

1. Vertical image decomposition already isolates the carrier dyad.
2. Carrier-side image map `(I_amp, I_geo) -> (A_Q, M_Q)` is already explicit.
3. `I_mix -> w_lin` already isolates the south singleton owner.
4. `A_Q` already remains the transport-ownership pivot with `M_Q` later.
5. `I_amp^(0)` already remains the support amplitude face.
6. The bounded transport-leading subbinding burden is already stated as such.
7. No final pairwise coefficient law is silently claimed.

If all seven checks pass together,
the object may be treated as:

- `POST_CAGE_BRANCH_U1_IAMP0_IGEO0_TRANSPORT_LEADING_CARRIER_SUBBINDING_MATERIALIZED`.
