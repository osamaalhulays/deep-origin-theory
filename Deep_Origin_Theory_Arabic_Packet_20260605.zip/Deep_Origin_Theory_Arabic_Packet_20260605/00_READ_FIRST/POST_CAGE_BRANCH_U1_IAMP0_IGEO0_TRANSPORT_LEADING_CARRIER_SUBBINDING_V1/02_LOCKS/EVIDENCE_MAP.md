# `(I_amp^(0), I_geo^(0))` Transport-Leading Carrier Subbinding Evidence Map

Date: `2026-06-12`

Status: `evidence map`

## Governing source notes

1. `Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/POST_CAGE_BRANCH_U1_RR0_BS1_VCAP1_IR1_VERTICAL_IMAGE_DECOMPOSITION_AND_122_FREEZE_ORDER_NOTE_20260608.md`
   - fixes the vertical image decomposition and the carrier-side image map
     `(I_amp, I_geo) -> (A_Q, M_Q)`

2. `Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/POST_CAGE_BRANCH_U1_RR0_BS1_IR1_STEP1_SOUTH_SINGLETON_FREEZE_NOTE_20260608.md`
   - fixes the south singleton owner
     `I_mix -> w_lin`

3. `Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/POST_CAGE_BRANCH_U1_RR0_BS1_AQ_EXACT_TARGET_LOCALIZES_TO_TQ_TRANSPORT_OWNERSHIP_PIVOT_NOTE_20260608.md`
   - fixes `A_Q` as the transport-ownership pivot with `M_Q` later

4. `Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/POST_CAGE_BRANCH_U1_IAMP_SOURCE_PURITY_GATE_LOCALIZES_TO_METRIC_MATTER_ONLY_AMPLITUDE_SHELL_NOTE_20260608.md`
   - fixes `I_amp^(0)` as the positive source-amplitude shell

5. `artifacts/debt_board_20260530/G1_PRESENT_MATERIALS_REMAINING_BURDEN_SHARPENS_FROM_SHARED_SOURCE_DEPENDENCE_BINDING_ON_SHELL_TYPED_IR1_REGISTER_TO_LAWFUL_TRANSPORT_LEADING_CARRIER_SUBBINDING_ON_SHELL_TYPED_IAMP0_IGEO0_PAIR_20260612.md`
   - fixes the bounded transport-leading carrier-subbinding burden itself

## Supporting live-bank surfaces

1. `artifacts/debt_board_20260530/COSMIC_CLOSURE_GOAL_BANK_20260610.md`
   - preserves `G1` as the live theorem route

2. `artifacts/debt_board_20260530/EIGHT_GOAL_COMMAND_CARD_20260610.md`
   - preserves `G1` as the first execution order
