# `(I_amp^(0), I_geo^(0))` Transport-Leading Carrier Subbinding Scope And Boundary

Date: `2026-06-12`

Status: `scope lock`

This object is bounded to the following claim only:

1. one reviewer-visible transport-leading carrier-subbinding object exists on
   the shell-typed pair
   `(I_amp^(0), I_geo^(0))`,
2. that object carries the reduced-action kinetic burden below final pairwise
   law,
3. and `I_mix^(0)` no longer competes as one coequal first carrier-side
   burden.

This object does **not** claim:

1. final internal-order contract already known,
2. final pairwise coefficient law already known,
3. full `A_Q` certification already crossed,
4. `T_Q^(0)` already secured,
5. or full `G1` closure.

This object should be refreshed immediately if later lawful work shows:

1. the pair cannot lawfully carry the burden without `I_mix` at the same
   first-grade rank,
2. the transport-leading role no longer sits on `I_geo^(0)`,
3. or the current route already lands a stronger direct object above this
   grade.
