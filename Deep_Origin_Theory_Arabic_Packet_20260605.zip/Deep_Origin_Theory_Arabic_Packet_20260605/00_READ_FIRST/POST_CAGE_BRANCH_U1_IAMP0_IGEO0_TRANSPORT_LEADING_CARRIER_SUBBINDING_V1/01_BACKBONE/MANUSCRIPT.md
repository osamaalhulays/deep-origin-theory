# Post-Cage Branch U1 `(I_amp^(0), I_geo^(0))` Transport-Leading Carrier Subbinding

Date: `2026-06-12`

Status: `reviewer-facing bounded subbinding object`

## Purpose

This object does **not** claim:

- final pairwise coefficient law already known,
- full `A_Q` certification already crossed,
- real `T_Q^(0)` closure already secured,
- exact transport closure,
- or full `G1/G2` completion.

It claims something narrower and operationally decisive:

1. the shell-typed pair
   `(I_amp^(0), I_geo^(0))`
   inside `I_src^(IR1,0)` now carries one reviewer-visible transport-leading
   carrier-subbinding object,
2. that object freezes `I_geo^(0)` as the transport-leading face and
   `I_amp^(0)` as the support amplitude face beneath the single-`Q`
   reduced-action kinetic coefficient,
3. and the next exact tooth above that object is no longer generic
   pair-level carrier-subbinding absence.

## Short verdict

The current frozen `U1` route now already supports one sharper carrier
reading:

- the shell-typed `IR1` register already exists,
- the carrier-side image map already narrows the active pair to
  `(I_amp, I_geo) -> (A_Q, M_Q)`,
- `I_mix -> w_lin` already isolates the south singleton owner away from the
  first carrier-side burden,
- and `A_Q` already stands as the transport-ownership pivot with `M_Q`
  later in the same carrier lane.

So the live `G1` chain now reads more sharply as:

- `IR1` shared-source dependence object ->
  transport-leading carrier-subbinding object ->
  noncoequal internal-order contract tooth

That is another real bounded closure gain.

## 1. What this object closes

This object closes the ambiguity about whether the shell-typed pair is still
just one informal carveout beneath the register.

The route is no longer best read as:

- one full triad-level dependence burden with no reviewer-visible pair object,
- one pair-level slogan with `I_mix^(0)` still competing equally,
- or one forced jump straight from shared register dependence to final
  pairwise law.

It is now best read as:

1. one shell-typed carrier pair inside the shared register,
2. one lawful transport-leading carrier subbinding on that pair,
3. one reviewer-visible bounded object bearing that subbinding.

## 2. Why the object is carrier-subbinding grade

The current route already preserves:

- one vertical image decomposition,
- one carrier-side image map,
- one south singleton owner for `I_mix`,
- one support-side amplitude face,
- and one downstream carrier order with `A_Q` first and `M_Q` later.

So the next honest positive object is not:

- one empirical or external payload object,
- and not one final pairwise coefficient formula.

It is:

- one carrier-subbinding object sitting exactly at the grade where the pair
  burden already lives.

## 3. What subbinding the object bears

The present object freezes the following bounded reading only:

- `I_geo^(0)` = transport-leading face,
- `I_amp^(0)` = support amplitude face,
- `I_mix^(0)` = no longer one coequal first carrier-side burden,
- and the pair now carries one reviewer-visible subbinding beneath final
  pairwise law.

This does **not** yet claim:

- one final internal-order contract for the pair,
- one final pairwise coefficient formula,
- or one collapse of all later carrier pressure into this single object.

It claims something narrower:

- the pair no longer remains one undifferentiated subbinding wound at the
  current public grade.

## 4. Why this matters for `G1`

`G1` advances only when one live missing object actually becomes
reviewer-visible,
not when we rename the same burden.

This object moves the line from:

- one missing transport-leading carrier-subbinding object,

to:

- one materialized bounded transport-leading carrier-subbinding object on
  the shell-typed pair,
  with the next exact tooth now pushed above object absence.

That is real constructive progress.

## 5. What this does not claim

This object does **not** claim:

- that the noncoequal internal-order contract is already materialized,
- that the final pairwise coefficient law is already materialized,
- that `A_Q` or `T_Q^(0)` are already closed,
- or that the post-cage route is complete.

It claims something narrower and useful:

- the transport-leading carrier-subbinding object now exists,
- and it holds the shell-typed pair above flat carrier-level ambiguity at
  current bounded grade.

## Bottom line

The current post-cage `U1` route now carries one more exact carrier object:

- one lawful transport-leading carrier-subbinding object on the shell-typed
  `(I_amp^(0), I_geo^(0))` pair,
- with `I_geo^(0)` preserved as the transport-leading face and
  `I_amp^(0)` preserved as the support amplitude face,
- and with the next exact tooth now lifted above object absence.
