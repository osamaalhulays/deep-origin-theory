# `NGC0247` Phase-2 Raw Case-Run Replacement Closure Note

Date: `2026-06-09`

Status: `packet-contained replacement-branch closure`

Purpose:

The old `O8` pressure asked for one of two things:

- the directly preserved original current fitted-`Y` artifact,
- or one stronger current-production closure that makes that missing naked
  artifact non-controlling.

This note closes the second branch.

Machine-readable companion:

- `NGC0247_PHASE2_RAW_CASE_RUN_REPLACEMENT_CLOSURE_V1.json`

## Short verdict

The packet now carries one stronger current-production replacement capsule for
the named `NGC0247` Phase-2 lane.

So the packet no longer stops at:

- reconstructed rows,
- recovered nuisance values,
- and prose about one older raw case-run.

It now also contains the raw archived case-run metric body, the archived
external meta body, and the archived run-log discipline for that same named
lane.

The original standalone fitted-`Y` file is still not separately present as its
own naked artifact.

But that missing naked file no longer survives as one live closure-controlling
debt, because the replacement capsule is already stronger for audit and review
purposes.

## 1. What is packet-contained now

The replacement capsule now binds these packet-contained objects together:

1. `NGC0247_PHASE2_SOURCE_CASE_V1.json`
2. `NGC0247_PHASE2_PRED_ONE_V1.ndjson`
3. `NGC0247_PHASE2_CASE_RUN_MULTISEED_RESULTS_V1.ndjson`
4. `NGC0247_PHASE2_EXTERNAL_META_V2.json`
5. `NGC0247_PHASE2_RUN_BENCHMARK_STDERR_V1.log`
6. `CURRENT_QCT_ROW_COMPARATOR_APPENDIX__NGC0247__PHASE2_RECONSTRUCTED_V1.md`
7. `NGC0247_CURRENT_ROW_COMPARATOR__QCT_AND_FIXED_QUMOND__V1.csv`
8. `NGC0247_CURRENT_REPLICATION_CAPSULE_V1.md`
9. `NGC0247_EXECUTED_PARITY_WITNESS_OUTWARD_SCORING_SHELL_NOTE_20260609.md`

So the packet now contains, for the same named Phase-2 lane:

- the source body,
- the predictor body,
- the archived metric body,
- the archived external hash-and-prior body,
- the archived run-log boundary,
- the recovered nuisance-visible row body,
- and the frozen outward scoring shell.

## 2. Why this is stronger than one naked fitted-`Y` file

One standalone stored nuisance file would disclose one scalar object.

This replacement capsule discloses more:

- the exact same-case metric return,
- the exact manifest and artifact hash anchors,
- the exact prior-width disclosure `upsilon_sigma_dex_used = 0.1`,
- the exact stage boundary showing the sentinel early-exit line,
- the exact recovered row-level current comparator implied by the lane,
- and the exact outward scoring discipline that now governs promotion above
  the historical control.

So the replacement capsule is not weaker than the old debt target in review
value.

It is stronger.

## 3. The exact archived return now inside the packet

The copied raw metric body preserves:

- `case_id = NGC0247`
- `n_datapoints = 26`
- `cv_seed = 42`
- `cv_fold = 1`
- `delta_source = artifact_emulator`
- `training_manifest_hash = 989a28dc649a06e15ac4df5bfed717afe7f7b87b37e22cffca04d3e6a7f82aa4`
- `emulator_artifact_hash = ceca66e878ad1651ebd167d3c67a5cd04a7a2df925b8ac4943f21ed8e5cfc3fd`
- `QCT loglike_obs_only = -416.9274550145858`
- `QCT loglike_obs_model = -347.4113136571038`
- `QUMOND loglike_obs_only = -268.4815452508469`
- `Delta AIC_total = 159.85953681251374`
- `Delta BIC_total = 161.11763335053513`

The copied external meta body preserves:

- `v2_schema = true`
- `sigma_model_used = true`
- `upsilon_sigma_dex_used = 0.1`
- `created_utc = 2026-03-09T08:05:20Z`
- `n_cases = 1`
- `total_points = 26`

The copied run log preserves:

- `EARLY_EXIT stage=sentinel delta_key=delta_aic_free top_case=NGC0247 max_case=157.85953681251374 threshold=110.0`

So the packet no longer relies on a remembered raw lane.

It now carries that raw lane directly.

## 4. Cross-archive persistence

This same `NGC0247` Phase-2 raw return is not one fragile orphan.

Inside `PHASE2_ARCHIVE`, the exact `NGC0247` raw metric carrier with
`Delta AIC_total = 159.85953681251374` reappears in `199` archived
`multiseed_results.ndjson` files.

The same exact sentinel early-exit line reappears in `15` archived
`run_benchmark.stderr.log` files.

So the replacement capsule is not one improvised local reconstruction.

It is one packet digestion of a repeatedly preserved raw archive body.

## 5. Exact former-`O8` consequence

The packet still does **not** claim:

- that the original standalone fitted-`Y` file itself has suddenly been found.

It now does claim something narrower and stronger:

- the replacement branch of the old live `O8` pressure is closed.

Why:

- the raw case-run metric body is packet-contained,
- the raw external meta body is packet-contained,
- the raw run-log boundary is packet-contained,
- the recovered nuisance-visible row comparator is packet-contained,
- and the outward scoring shell is packet-contained.

So the missing naked fitted-`Y` file is now archival polish only.

It is no longer one live head in the closure bank.

The deeper `Apex` `obs-only` versus `obs+model` contradiction also remains
fenced below packet-clean public closure and therefore does not survive here
as one surviving live former-`O8` burden.

## 6. What this does not authorize

This note does **not** authorize the claims that:

- the whole `MOND/QUMOND` family verdict is finished,
- the release-side route split disappears,
- the historical same-convention control becomes the public headline,
- or the old naked fitted-`Y` file itself has now been recovered verbatim.

## 7. Best outward-safe reading

One exact outward-safe sentence is:

> The old `NGC0247` fitted-`Y` artifact debt no longer survives as one live
> packet debt, because the packet now contains a stronger raw Phase-2
> replacement capsule: source body, predictor body, archived metric body,
> archived external meta, archived run-log discipline, recovered nuisance-
> visible row comparator, and frozen outward scoring shell all now coexist on
> the same named lane. The original naked fitted-`Y` file is still not
> separately present, but it is no longer closure-controlling.
