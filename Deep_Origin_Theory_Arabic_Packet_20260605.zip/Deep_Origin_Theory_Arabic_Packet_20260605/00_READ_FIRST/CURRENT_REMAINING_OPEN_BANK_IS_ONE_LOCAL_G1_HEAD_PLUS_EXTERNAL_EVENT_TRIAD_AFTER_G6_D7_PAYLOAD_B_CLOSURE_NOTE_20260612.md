# Current Remaining Open Bank Is One Local `G1` Head Plus External Event Triad After `G6` / `D7` `PAYLOAD_B` Closure

Date: `2026-06-12`

Purpose:

State the exact current whole-bank reading after the empirical `L2` payload
lane is closed at `PAYLOAD_B` grade.

## Short verdict

The fair current reading is no longer:

- one local `G1` head plus one external-event quartet

It is now:

- one local `G1` head
- plus one external-event triad

More exactly:

- `G1` = fresh same-tooth witness-package owned
  or typed superseding-package owned
- `G5` = terminal carrier arrival-owned
- `G7` = real external dispatch-owned
- `G8` = broader independent replication-owned

## What this means

This does **not** mean the bank is closed.

It means something narrower:

- the empirical `G6` / `D7` lane is no longer one live open bank wound
- and the whole remaining open bank has compressed from one pentad to one
  tetrad

## Read with

- `CURRENT_G1_SAME_TOOTH_FREEZE_WITNESS_LOCAL_PACKET_EXHAUSTION_AND_WATCH_ONLY_NOTE_20260612.md`
- `CURRENT_G6_L2_DIRECT_AUTHOR_PAYLOAD_ARRIVED_AND_CLASSIFIED_AS_PAYLOAD_B_NOTE_20260612.md`
- `CURRENT_D7_L2_PAYLOAD_B_ADMIT_BOUNDED_VERDICT_NOTE_20260612.md`
- `CURRENT_NON_G1_REMAINING_OPEN_BANK_IS_ONE_EXTERNAL_EVENT_TRIAD_AFTER_G6_D7_PAYLOAD_B_CLOSURE_NOTE_20260612.md`
