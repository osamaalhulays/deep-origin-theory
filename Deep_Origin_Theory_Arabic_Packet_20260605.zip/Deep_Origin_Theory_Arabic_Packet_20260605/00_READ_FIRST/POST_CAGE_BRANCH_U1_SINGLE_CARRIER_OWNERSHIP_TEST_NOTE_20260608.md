# Post-Cage Branch U1 Single-Carrier Ownership Test Note

Date: `2026-06-08`

Purpose:

This note states one exact later refinement for the post-cage `U1` route:

- what the single carrier must actually own,
- and how to detect when a supposedly clean `U1` route has already become a
  disguised `U2` split.

## Short verdict

`U1` is not defined just by:

- one new action term,
- one response symbol,
- or one transport slogan.

It is defined by one stricter rule:

- the same carrier `Q` must own the response route, the south bounded regime,
  the transport role, and the jump to promotable source-governed authority.

## 1. What the single carrier must own

For `U1` to remain honest, `Q` must eventually own:

1. a real action contribution
2. a real field equation
3. a real stress-energy contribution
4. a lawful interaction route with matter/geometry
5. the source-to-total response route
6. the south bounded-regime realization
7. the jump from bounded probe to promotable response authority

If one of these is carried instead by a genuinely independent second sector,
the route is no longer clean `U1`.

## 2. The south-side test

The south side is the easiest place for fake `U1` survival to hide.

So the test is exact:

- if the south packet is one bounded regime or projected face of `Q`,
  `U1` remains alive
- if it needs one independently dynamical south carrier,
  the route has widened into `U2`

The same applies if the generator/basis substrate or coefficient law can no
longer be owned by `Q` itself.

## 3. The response-authority test

The later `L2` witness already gives:

- one source-to-total rule
- one nontrivial operator grammar
- one bounded nontrivial probe at `C0_NO_CLAIM_EXPORT`

But `U1` still owes one harder step:

- the same carrier must also own the jump to promotable source-governed
  evaluator / value authority

If that last step needs one hidden extra carrier or one external patch,
`U1` fails its ownership test.

## 4. The transport test

The deepest obstruction is still lawful total stress-energy transport
closure.

So `U1` survives only if `Q` can enter that ledger as a real carrier,
not as:

- one formal relabeling,
- one detached south packet,
- or one external exchange-current patch.

## Bottom line

The live question is now sharper than:

- "can we write a unified action?"

It is:

- "can one single carrier `Q` honestly own transport, south regime, and
  promotable response authority without hidden second-sector support?"

If yes, `U1` stays alive.

If no, the honest next line is `U2`.
