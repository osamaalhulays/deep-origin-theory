# Post-Cage Branch U1 RR0+BS1 VCAP1(IR1) Vertical Image Decomposition And 1-2-2 Freeze Order Note

Date: `2026-06-08`

Status: `next constructive compression after IR1 scaffold`

## Purpose

This note attacks the next exact question opened by the `IR1` scaffold note.

Once the shared-source register

`I_src^(IR1) = (I_amp, I_mix, I_geo)`

is admitted as the next internal neck,
the next question is:

- does the induced image
  `V_CAP1^(IR1) = Image(I_src^(IR1) -> (A_Q, M_Q, J_lin, W_src, w_lin))`
  still behave like five disconnected heads,
  or can it already be decomposed more sharply

## Short verdict

The image already admits one sharper structural decomposition.

At the present live `RR0 + BS1` surface,
the clean first topology is:

`V_CAP1^(IR1) = V_S^(1) + V_int^(2) + V_Q^(2)`

with exact head grouping:

1. `V_S^(1) = {w_lin}`
2. `V_int^(2) = {J_lin, W_src}`
3. `V_Q^(2) = {A_Q, M_Q}`

So the best current sovereign reading is:

`The vertical image problem is no longer five-head flat. It already decomposes into one south singleton, one interaction dyad, and one carrier dyad.`

This naturally induces the first exact freeze order:

`1-2-2`

namely:

1. south singleton first
2. interaction dyad second
3. carrier dyad third

That is a major live compression.

## 1. Why the south singleton separates first

Under:

- `RR0`
- `BS1`

the south side already simplifies to:

- `w_res = 0`
- `w_quad = 1 - w_lin`

and the `IR1` scaffold already typed the first admissible live reading:

- `w_lin = I_mix`

So the south-balance head is no longer a dyad or triad at first live grade.

It is one singleton.

That means the vertical image already contains one clean low-cost head:

`V_S^(1) = {w_lin}`

This is the easiest lawful freeze target in the current image.

## 2. Why the interaction dyad is the next exact block

The interaction side is already fixed at current live grade as:

`L_int^(IF1a,RR0) = J_lin[g,ψ] Q + W_src[g,ψ] Q^2`

These are not decorative names.

They are the explicit admitted interaction heads that already survive:

- worksheet grade
- bookkeeping grade
- and first divergence-audit grade

So the interaction image is already one clean dyad:

`V_int^(2) = {J_lin, W_src}`

It is still unresolved,
but it is structurally tighter than the carrier side because its two heads are
already explicit ledger heads on the admitted live surface.

## 3. Why the carrier dyad is the harder last block

The carrier side is:

`L_Q^(QF1a) = A_Q[g,ψ] g^{μν} ∇_μ Q ∇_ν Q + M_Q[g,ψ] Q^2`

So the carrier image is:

`V_Q^(2) = {A_Q, M_Q}`

This dyad is not merely another copy of the interaction dyad.

It is harder for two reasons:

1. it touches the geometry-response moderation side already isolated in
   `I_geo`
2. it sits closer to the strong-field / transport pressure frontier

So even though it is only two heads,
it is the right last target in the first freeze order.

## 4. Exact decomposition map

The clean first map is therefore:

`I_mix -> w_lin`

`(I_amp, I_mix, I_geo) -> (J_lin, W_src)`

`(I_amp, I_geo) -> (A_Q, M_Q)`

with the live derived head:

- `w_quad = 1 - w_lin`

This does **not** yet claim final formulas.

It claims something structurally stronger:

- the five-head image already has one exact topology

## 5. Why this is better than a flat five-head freeze

Without this decomposition,
the next freeze mission would still read like:

- freeze five unrelated heads somehow

That would be weak and noisy.

With the new decomposition,
the next mission becomes:

1. confirm the singleton south balance head
2. attack the interaction dyad as one block
3. attack the carrier dyad as one later block

So the image no longer reads as one flat burden.

It reads as one ordered triptych.

## 6. Exact `1-2-2` freeze order

The recommended first freeze order is now:

### Step 1. South singleton

Freeze:

- `w_lin = I_mix`

at the scaffold / bounded-readout grade.

This is the cleanest first win because:

- it already lives inside bounded convex grammar
- it already survives with `RR0`
- and its complement is derived automatically

### Step 2. Interaction dyad

Freeze the shared-source image of:

- `J_lin`
- `W_src`

next,
because these are the already-admitted explicit heads of the live
interaction ledger.

### Step 3. Carrier dyad

Freeze:

- `A_Q`
- `M_Q`

last in the first cycle,
because this is where geometry moderation and stronger transport pressure are
closest.

## 7. Why this is a big gain for `U1`

This is not cosmetic rewording.

If the image had refused decomposition,
then the route would still look like one foggy five-head unresolved burden.

Instead, the current record now says:

1. one shared-source register neck exists
2. one vertical image exists
3. that image already decomposes into
   `1 + 2 + 2`
4. and the corresponding freeze order is already readable

That is exactly the kind of structural gain that keeps `U1-first` alive with
discipline.

## 8. Exact revocation conditions

This decomposition should be revoked immediately if later lawful work shows:

1. `w_lin` cannot remain a singleton because south balance reopens residual
   or independent transport pressure
2. `J_lin` and `W_src` cannot be attacked as one dyad without hidden carrier
   splitting
3. `A_Q` and `M_Q` do not actually share the same carrier-side moderation
   route
4. the image order must be reversed because the carrier dyad becomes easier
   than the interaction dyad by lawful new evidence

If any of those appears,
the `1-2-2` order must be revised.

## 9. What this changes

The live line now gains one more major compression.

It no longer says only:

- `CAP1` is the right five-head burden
- `IR1` is the right shared-source scaffold

It now also says:

- the induced image `V_CAP1^(IR1)` already has one first exact topology
- and that topology already yields one first exact freeze order

That is a deeper constructive gain than naming `IR1` alone.

## Bottom line

The current live `U1` line now supports one stronger and cleaner reading:

- `CAP1` is the right burden
- `IR1` is the right shared-source neck
- `V_CAP1^(IR1)` decomposes as
  `V_S^(1) + V_int^(2) + V_Q^(2)`
- and the next freeze route is
  `1-2-2`

This is the clearest current path toward a real headwise authority program
without premature widening.
