#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

NGC0247_ROUTE_SPLIT_PATH = HERE / "NGC0247_FULL_BODY_GROUNDED_DUAL_EXECUTION_ROUTE_SPLIT_V1.json"
SHARED_SPEAR_BOUNDARY_PATH = HERE / "SHARED_SPEAR_DOUBLE_WITNESS_ROUTE_SPLIT_AND_SAME_SIGN_SOFTENING_V1.json"
PRIMARY_CORE_PATH = HERE / "PRIMARY_PARITY_CORE_TRIAD_ORDER_AND_UNIFORM_COMPONENT_HARDENING_V1.json"
RESIDUAL_TRIAD_PATH = HERE / "RESIDUAL_QUALITY1_REOPENING_TRIAD_CLOSURE_V1.json"
RESERVE_NGC5033_PATH = HERE / "NGC5033_FIRST_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json"
RESERVE_UGC02487_PATH = HERE / "UGC02487_SECOND_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json"
RESERVE_UGC03205_PATH = HERE / "UGC03205_THIRD_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json"
QUALITY2_SIDECAR_PATH = HERE / "UGC05253_BOUNDED_QUALITY2_SIDECAR_ENTRY_V1.json"
HUBBLE_BODY_PATH = HERE / "HUBBLE_FLOW_SENSITIVE_BODY_FULL_CLOSURE_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def summarize_members(members):
    public_total = sum(member["public_delta_aic_total"] for member in members)
    faithful_total = sum(member["faithful_delta_aic_total"] for member in members)
    component_total = sum(member["component_aware_delta_aic_total"] for member in members)
    component_shift_total = sum(member["component_aware_shift"] for member in members)
    public_abs_total = sum(abs(member["public_delta_aic_total"]) for member in members)
    component_abs_total = sum(abs(member["component_aware_delta_aic_total"]) for member in members)
    return {
        "witness_count": len(members),
        "public_delta_aic_total": public_total,
        "faithful_delta_aic_total": faithful_total,
        "component_aware_delta_aic_total": component_total,
        "component_aware_shift": component_shift_total,
        "public_absolute_burden": public_abs_total,
        "component_aware_absolute_burden": component_abs_total,
    }


def close_enough(left, right, tolerance=1e-9):
    return abs(left - right) <= tolerance


def extract_ngc0247_member():
    data = load_json(NGC0247_ROUTE_SPLIT_PATH)
    live = data["o6_matched_nuisance_execution_return"]
    release = data["o7_best_dressed_hardening_execution_return"]
    return {
        "case_id": "SPARC_NGC0247",
        "morphology": "route_split",
        "public_delta_aic_total": live["public_delta_aic_total"],
        "faithful_delta_aic_total": live["faithful_delta_aic_total"],
        "component_aware_delta_aic_total": live["component_aware_delta_aic_total"],
        "component_aware_shift": live["component_aware_delta_aic_total_shift"],
        "release_option2_minimal_delta_aic_total": release["option2_minimal_delta_aic_total"],
        "release_option1_robust_delta_aic_total": release["option1_robust_delta_aic_total"],
        "release_side_best_dressed_hardening_is_anti_qct": release[
            "release_side_hardening_is_anchor_stable_and_anti_qct"
        ],
        "public_and_live_matched_nuisance_lanes_are_pro_qct": live[
            "witness_is_pro_qct_on_public_faithful_and_component_aware_surfaces"
        ],
    }


def extract_ngc6946_member():
    data = load_json(SHARED_SPEAR_BOUNDARY_PATH)
    row = data["ngc6946"]
    return {
        "case_id": "SPARC_NGC6946",
        "morphology": "same_sign_softening",
        "public_delta_aic_total": row["public_live_delta_aic_total"],
        "faithful_delta_aic_total": row["o6_faithful_matched_nuisance_delta_aic_total"],
        "component_aware_delta_aic_total": row["o6_component_aware_matched_nuisance_delta_aic_total"],
        "component_aware_shift": row["o6_component_aware_softening_shift"],
        "release_option2_minimal_delta_aic_total": row["o7_option2_minimal_delta_aic_total"],
        "release_option1_robust_delta_aic_total": row["o7_option1_robust_delta_aic_total"],
        "release_side_best_dressed_hardening_is_anti_qct": row[
            "release_side_best_dressed_hardening_is_anti_qct"
        ],
        "matched_nuisance_lanes_remain_anti_qct_but_narrow_toward_qct": row[
            "live_matched_nuisance_lanes_remain_anti_qct_but_narrow_toward_qct"
        ],
    }


def extract_hubble_flow_sensitive_members():
    members = []

    core = load_json(PRIMARY_CORE_PATH)
    for row in core["ordered_core"]:
        members.append(
            {
                "case_id": row["case_id"],
                "morphology": "same_sign_hardening",
                "public_delta_aic_total": row["public_delta_aic_total"],
                "faithful_delta_aic_total": row["faithful_delta_aic_total"],
                "component_aware_delta_aic_total": row["component_aware_delta_aic_total"],
                "component_aware_shift": row["component_aware_shift"],
                "quality_flag": row["quality_flag"],
            }
        )

    residual = load_json(RESIDUAL_TRIAD_PATH)
    for row in residual["witnesses"]:
        members.append(
            {
                "case_id": row["case_id"],
                "morphology": "same_sign_hardening",
                "public_delta_aic_total": row["public_delta_aic_total"],
                "faithful_delta_aic_total": row["faithful_delta_aic_total"],
                "component_aware_delta_aic_total": row["component_aware_delta_aic_total"],
                "component_aware_shift": row["component_aware_shift"],
                "quality_flag": 1,
            }
        )

    for path in (RESERVE_NGC5033_PATH, RESERVE_UGC02487_PATH, RESERVE_UGC03205_PATH, QUALITY2_SIDECAR_PATH):
        row = load_json(path)["witness"]
        members.append(
            {
                "case_id": row["case_id"],
                "morphology": "same_sign_hardening",
                "public_delta_aic_total": row["public_delta_aic_total"],
                "faithful_delta_aic_total": row["faithful_delta_aic_total"],
                "component_aware_delta_aic_total": row["component_aware_delta_aic_total"],
                "component_aware_shift": row["component_aware_shift"],
                "quality_flag": row["quality_flag"],
            }
        )

    return members


def main():
    route_split = extract_ngc0247_member()
    softening = extract_ngc6946_member()
    hardening_members = extract_hubble_flow_sensitive_members()
    hubble_body = load_json(HUBBLE_BODY_PATH)

    route_split_summary = summarize_members([route_split])
    softening_summary = summarize_members([softening])
    hardening_summary = summarize_members(hardening_members)

    named_component_abs_total = (
        route_split_summary["component_aware_absolute_burden"]
        + softening_summary["component_aware_absolute_burden"]
        + hardening_summary["component_aware_absolute_burden"]
    )
    named_public_abs_total = (
        route_split_summary["public_absolute_burden"]
        + softening_summary["public_absolute_burden"]
        + hardening_summary["public_absolute_burden"]
    )

    hardening_case_ids = [member["case_id"] for member in hardening_members]
    hardening_quality_flags = {
        "quality1_count": sum(1 for member in hardening_members if member["quality_flag"] == 1),
        "quality2_count": sum(1 for member in hardening_members if member["quality_flag"] == 2),
    }

    consistency_checks = {
        "hubble_flow_sensitive_member_count_matches_closure": len(hardening_members)
        == len(hubble_body["witnesses"]),
        "hubble_flow_sensitive_case_ids_match_closure": hardening_case_ids == hubble_body["witnesses"],
        "hubble_flow_sensitive_public_total_matches_closure": close_enough(
            hardening_summary["public_delta_aic_total"],
            hubble_body["combined_burden"]["public_delta_aic_total"],
        ),
        "hubble_flow_sensitive_faithful_total_matches_closure": close_enough(
            hardening_summary["faithful_delta_aic_total"],
            hubble_body["combined_burden"]["faithful_delta_aic_total"],
        ),
        "hubble_flow_sensitive_component_total_matches_closure": close_enough(
            hardening_summary["component_aware_delta_aic_total"],
            hubble_body["combined_burden"]["component_aware_delta_aic_total"],
        ),
        "hubble_flow_sensitive_shift_total_matches_closure": close_enough(
            hardening_summary["component_aware_shift"],
            hubble_body["combined_burden"]["component_aware_shift"],
        ),
        "route_split_is_the_only_named_pro_qct_witness": route_split[
            "public_and_live_matched_nuisance_lanes_are_pro_qct"
        ],
        "softening_witness_is_outside_hubble_flow_sensitive_body": softening["case_id"]
        not in hardening_case_ids,
        "all_hubble_flow_sensitive_witnesses_harden": all(
            member["component_aware_shift"] > 0.0 for member in hardening_members
        ),
        "all_nonhardening_behavior_is_exhausted_by_ngc0247_and_ngc6946": (
            route_split["component_aware_shift"] < 0.0
            and softening["component_aware_shift"] < 0.0
            and all(member["component_aware_shift"] > 0.0 for member in hardening_members)
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "bounded_packet_facing_cross_archive_morphology_partition",
        "surface": "named_executed_matched_nuisance_court_morphology_partition",
        "named_executed_witness_count": 2 + len(hardening_members),
        "partitions": {
            "route_split": {
                "members": [route_split["case_id"]],
                "summary": route_split_summary,
                "witness": route_split,
            },
            "same_sign_softening": {
                "members": [softening["case_id"]],
                "summary": softening_summary,
                "witness": softening,
            },
            "same_sign_hardening_hubble_flow_sensitive_body": {
                "members": hardening_case_ids,
                "summary": {
                    **hardening_summary,
                    "fraction_of_named_executed_component_aware_absolute_burden": (
                        hardening_summary["component_aware_absolute_burden"] / named_component_abs_total
                    ),
                    "fraction_of_named_executed_public_absolute_burden": (
                        hardening_summary["public_absolute_burden"] / named_public_abs_total
                    ),
                },
                "quality_flag_counts": hardening_quality_flags,
            },
        },
        "named_executed_absolute_burden_totals": {
            "public_absolute_burden": named_public_abs_total,
            "component_aware_absolute_burden": named_component_abs_total,
        },
        "structural_partition": {
            "only_named_pro_qct_route_split_witness": route_split["case_id"],
            "only_named_same_sign_softening_witness": softening["case_id"],
            "uniform_same_sign_hardening_body": hardening_case_ids,
            "nonhardening_behavior_is_fully_outside_the_hubble_flow_sensitive_body": True,
        },
        "consistency_checks": consistency_checks,
        "not_supported_now": [
            "Whole-family MOND_QUMOND closure",
            "The named executed court is morphologically uniform",
            "NGC0247 or NGC6946 alone can overwrite the ten-witness hardening body",
            "The ten-witness hardening body erases the route-split and softening exceptions",
        ],
        "next_honest_frontier": [
            "test_whether_any_second_nonhardening_behavior_exists_beyond_NGC0247_and_NGC6946",
            "extend_the_no_makeup_court_without_collapsing_the_route_split_softening_and_hardening_partitions",
        ],
    }

    output["verdict"] = (
        "NAMED_EXECUTED_MATCHED_NUISANCE_COURT_PARTITION_CLOSED__NGC0247_IS_THE_ONLY_PRO_QCT_ROUTE_SPLIT_WITNESS_NGC6946_IS_THE_ONLY_SAME_SIGN_SOFTENING_WITNESS_AND_THE_TEN_WITNESS_HUBBLE_FLOW_SENSITIVE_BODY_IS_UNIFORMLY_SAME_SIGN_HARDENING"
        if all(consistency_checks.values())
        else "NAMED_EXECUTED_MATCHED_NUISANCE_COURT_PARTITION_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
