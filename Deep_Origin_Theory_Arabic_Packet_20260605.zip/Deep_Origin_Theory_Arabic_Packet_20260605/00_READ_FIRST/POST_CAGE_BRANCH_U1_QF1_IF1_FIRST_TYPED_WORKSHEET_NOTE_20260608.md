# Post-Cage Branch U1 QF1/IF1 First Typed Worksheet Note

Date: `2026-06-08`

Purpose:

This note gives the first typed worksheet for the recommended live `U1`
pairing:

- `QF1` for `S_Q`
- `IF1` for `S_int`

## Short verdict

The first admissible live pairing is now:

`S_U1^(1) = S_EH[g] + S_m[g,ψ] + S_Q^(QF1)[g,ψ,Q] + S_int^(IF1)[g,ψ,Q]`

This is still not a final theory claim.

It is one typed parent template under strict ownership and reduction rules.

## 1. The first `S_Q` template

The first `QF1` carrier template keeps:

- the final bulk carrier exactly `Q`
- one same-carrier kinetic slot
- one same-carrier masslike slot
- and one conditional same-carrier derivative/cross slot

It does **not** yet promote:

- `v`
- `Omega`
- or one observable object

into the primitive carrier sector.

## 2. The first `S_int` template

The first `IF1` interaction template keeps:

- one linear source slot
- one source-weighted field slot
- one residual same-carrier slot

This is the cleanest typed import from the Kreib source-channel grammar.

It remains:

- source-governed
- no-data
- no-fit
- and no lane-local rescue

## 3. The exact contracts

This typed pairing is admissible only if it preserves all of:

1. one reduced-surface shadow whose final bulk carrier remains exactly `Q`
2. one bounded south projection `South[Q] = P_S[Q]`
3. one transport ledger with `T_Q` and `T_int` still owned by the same route
4. one authority ladder that does not inflate bounded probe into promotable
   closure

## 4. What breaks it

Reject immediately if the pairing needs:

- one second carrier
- one separate south field
- one external transport patch
- or one observationally borrowed authority step

That would no longer be clean `U1`.

## Bottom line

The live line now has its first typed build strike:

- `S_EH + S_m + S_Q^(QF1) + S_int^(IF1)`

under one same-carrier ownership rule and one non-inflated reduction
discipline.
