#!/usr/bin/env python3
import json
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent

SCOPE_SELECTION_PATH = HERE / "NO_MAKEUP_MOND_QUMOND_CROSS_OBSERVABLE_COURT_SCOPE_SELECTION_V1.json"
COURT_CHARTER_PATH = HERE / "NO_MAKEUP_MOND_QUMOND_CROSS_OBSERVABLE_COURT_DEEP_REASON_AND_EXECUTION_CHARTER_V1.json"
LAUNCH_FRONT_PATH = HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LAUNCH_FRONT_V1.json"
MATCHED_PARTITION_PATH = HERE / "NAMED_EXECUTED_MATCHED_NUISANCE_COURT_MORPHOLOGY_PARTITION_V1.json"
PARITY_PROMOTION_PATH = HERE / "NGC0247_EXECUTED_PARITY_WITNESS_PROMOTION_BOUNDARY_V1.json"
PARITY_OUTWARD_SHELL_PATH = HERE / "NGC0247_EXECUTED_PARITY_WITNESS_OUTWARD_SCORING_SHELL_V1.json"
PRIMARY_PARITY_CORE_PATH = HERE / "PRIMARY_PARITY_CORE_TRIAD_ORDER_AND_UNIFORM_COMPONENT_HARDENING_V1.json"
LAYERED_O7_CONVERGENCE_PATH = HERE / "HUBBLE_FLOW_SENSITIVE_BODY_LAYERED_O7_CONVERGENCE_V1.json"
O7_REMAINDER_LOCALIZATION_PATH = HERE / "HUBBLE_FLOW_SENSITIVE_BODY_CURRENT_O7_REMAINDER_LOCALIZATION_V1.json"
O7_REINFLATION_MICROFRONT_PATH = HERE / "O7_REINFLATION_MICROFRONT_AFTER_NEAR_NEUTRAL_PERSISTENCE_V1.json"

CLUSTER_DOSSIER_ZIP_PATH = (
    HERE.parent / "03_C_Cluster" / "Deep_Origin_Theory_C_Cluster_Dossier_20260605.zip"
)
MACS1206_RUNTIME_PACKAGE_MANIFEST_PATH = (
    "Deep_Origin_Theory_C_Cluster_Dossier_20260605/"
    "MACS1206_CURRENT_VERSION_RUNTIME_PACKAGE_MANIFEST__V1.json"
)
MACS1206_SAME_KERNEL_CONTEXT_PATH = (
    "Deep_Origin_Theory_C_Cluster_Dossier_20260605/"
    "MACS1206_SOURCE_OBJECT__SAME_KERNEL_CONTEXT_V1.json"
)


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_json_from_zip(zip_path: Path, member: str):
    with zipfile.ZipFile(zip_path, "r") as archive:
        return json.loads(archive.read(member).decode("utf-8"))


def main():
    scope = load_json(SCOPE_SELECTION_PATH)
    charter = load_json(COURT_CHARTER_PATH)
    launch_front = load_json(LAUNCH_FRONT_PATH)
    matched_partition = load_json(MATCHED_PARTITION_PATH)
    parity_promotion = load_json(PARITY_PROMOTION_PATH)
    parity_outward = load_json(PARITY_OUTWARD_SHELL_PATH)
    primary_core = load_json(PRIMARY_PARITY_CORE_PATH)
    layered_o7 = load_json(LAYERED_O7_CONVERGENCE_PATH)
    o7_remainder = load_json(O7_REMAINDER_LOCALIZATION_PATH)
    o7_reinflation = load_json(O7_REINFLATION_MICROFRONT_PATH)

    macs1206_manifest = load_json_from_zip(
        CLUSTER_DOSSIER_ZIP_PATH, MACS1206_RUNTIME_PACKAGE_MANIFEST_PATH
    )
    macs1206_same_kernel = load_json_from_zip(
        CLUSTER_DOSSIER_ZIP_PATH, MACS1206_SAME_KERNEL_CONTEXT_PATH
    )

    expected_lanes = {
        "fixed_comparator_rotation_witness_court",
        "matched_nuisance_parity_court",
        "best_dressed_adversarial_hardening_court",
        "same_kernel_macs1206_secondary_deltasigma_rail",
    }

    fixed_lane = {
        "lane_status": "frozen_fixed_public_reference_floor",
        "lane_role": "reference_floor_for_cross_observable_pressure_without_lane_rescue",
        "rotation_fixed_public_qumond_crosscheck_count_with_zero_public_gap": scope[
            "rotation_fixed_public_qumond_crosscheck_count_with_zero_public_gap"
        ],
        "selected_scope_binding": scope["selected_scope"],
        "what_it_carries_now": [
            "one fixed-public comparator floor already frozen into the court",
            "one large visible rotation witness mass with zero public-gap drift",
            "one lawful baseline that later lanes must answer rather than cosmetically bypass",
        ],
        "what_it_does_not_carry_now": [
            "whole-court execution by itself",
            "whole-family MOND_QUMOND closure",
        ],
    }

    matched_lane = {
        "lane_status": "named_executed_parity_lane",
        "lane_role": "executed_live_rotation_lane_under_matched_nuisance_governance",
        "named_executed_witness_count": matched_partition["named_executed_witness_count"],
        "route_split_witness": matched_partition["structural_partition"][
            "only_named_pro_qct_route_split_witness"
        ],
        "route_split_public_delta_aic_total": parity_promotion["live_matched_nuisance_witness"][
            "public_delta_aic_total"
        ],
        "route_split_faithful_delta_aic_total": parity_outward["headline_live_parity_score"][
            "delta_aic_total"
        ],
        "route_split_component_aware_delta_aic_total": parity_outward["hardening_companion"][
            "delta_aic_total"
        ],
        "same_sign_softening_witness": matched_partition["structural_partition"][
            "only_named_same_sign_softening_witness"
        ],
        "same_sign_softening_public_delta_aic_total": matched_partition["partitions"][
            "same_sign_softening"
        ]["witness"]["public_delta_aic_total"],
        "same_sign_hardening_body_witness_count": matched_partition["partitions"][
            "same_sign_hardening_hubble_flow_sensitive_body"
        ]["summary"]["witness_count"],
        "same_sign_hardening_body_public_absolute_burden": matched_partition["partitions"][
            "same_sign_hardening_hubble_flow_sensitive_body"
        ]["summary"]["public_absolute_burden"],
        "what_it_carries_now": [
            "one named pro-QCT route-split witness",
            "one named same-sign softening witness",
            "one ten-witness same-sign hardening body",
        ],
        "what_it_does_not_carry_now": [
            "silent collapse into the best-dressed lane",
            "whole-court closure from one witness alone",
        ],
    }

    best_dressed_lane = {
        "lane_status": "materialized_hardening_lane_with_live_microfront",
        "lane_role": "adversarial_hardening_pressure_lane_with_materialized_body_layers_and_live_reinflation_edge",
        "primary_front_block": {
            "members": [entry["case_id"] for entry in primary_core["ordered_core"]],
            "combined_public_delta_aic_total": primary_core["combined_burden"][
                "public_delta_aic_total"
            ],
            "fraction_of_hubble_flow_sensitive_body": primary_core["combined_burden"][
                "fraction_of_hubble_flow_sensitive_body"
            ],
        },
        "layered_o7_convergence": {
            "overlap_case_count": layered_o7["o7_positive_spoiler_intersection"]["case_count"],
            "distinct_o7_layer_count": layered_o7["o7_positive_spoiler_intersection"][
                "distinct_o7_layer_count"
            ],
            "fraction_of_body_public_delta_aic_total": layered_o7["o7_positive_spoiler_intersection"][
                "fraction_of_body_public_delta_aic_total"
            ],
            "overlap_cases": layered_o7["o7_positive_spoiler_intersection"]["cases"],
        },
        "current_nonoverlap_remainder": {
            "case_count": o7_remainder["current_o7_nonintersecting_remainder"]["case_count"],
            "cases": o7_remainder["current_o7_nonintersecting_remainder"]["cases"],
            "all_cases_are_quality1": o7_remainder["localization_structure"]["all_cases_are_quality1"],
            "all_cases_have_exact_qumond_protection": o7_remainder["localization_structure"][
                "all_cases_have_exact_qumond_protection"
            ],
            "fraction_of_body_public_delta_aic_total": o7_remainder[
                "current_o7_nonintersecting_remainder"
            ]["fraction_of_body_public_delta_aic_total"],
        },
        "live_microfront": {
            "o7_live_wound_is_now_reinflation_growth_question": o7_reinflation["current_reading"][
                "o7_live_wound_is_now_reinflation_growth_question"
            ],
            "d72_batch_already_completed": o7_reinflation["current_reading"][
                "d72_batch_already_completed"
            ],
            "selected_next_batch": [
                case["case_id"] for case in o7_reinflation["reinflation_microfront"]["selected_next_batch"]
            ],
            "reserve_case_queue": [
                case["case_id"] for case in o7_reinflation["reinflation_microfront"]["reserve_cases"]
            ],
        },
        "what_it_carries_now": [
            "one explicit three-witness primary hardening front block",
            "one seven-of-ten layered O7 positive-spoiler overlap carrying most of the body burden",
            "one narrow three-witness quality1 continuation pocket rather than one bodywide counterpattern",
            "one live reinflation microfront beyond mere survival",
        ],
        "what_it_does_not_carry_now": [
            "whole-court execution by itself",
            "whole-family MOND_QUMOND closure",
        ],
    }

    north_lane = {
        "lane_status": "same_kernel_locked_authority_gated_rail",
        "lane_role": "north_cross_observable_rail_with_same_kernel_lock_and_explicit_authority_gate",
        "same_kernel_only": scope["macs1206_secondary_deltasigma"]["same_kernel_only"],
        "no_new_knobs": scope["macs1206_secondary_deltasigma"]["no_new_knobs"],
        "shared_overlap_mid_bin_count": scope["macs1206_secondary_deltasigma"][
            "shared_overlap_mid_bin_count"
        ],
        "best_visible_benchmark_member": scope["macs1206_secondary_deltasigma"][
            "best_visible_benchmark_member"
        ],
        "best_visible_member_pte": scope["macs1206_secondary_deltasigma"][
            "best_visible_member_pte"
        ],
        "runtime_package_status": macs1206_manifest["status"],
        "runtime_package_authority_read": macs1206_manifest["authority_read"],
        "same_kernel_context_profile_row_count": len(macs1206_same_kernel["profile_rows"]),
        "same_kernel_context_has_closure_annulus_zero_anchor": any(
            row["bin_role"] == "closure_annulus_zero_anchor"
            for row in macs1206_same_kernel["profile_rows"]
        ),
        "not_closed_by_manifest": macs1206_manifest["not_closed_by_this_manifest"],
        "what_it_carries_now": [
            "one same-kernel rail already frozen with no new knobs",
            "one visible current-version runtime package candidate",
            "one explicit authority gate above the rail rather than a hidden north ambiguity",
        ],
        "what_it_does_not_carry_now": [
            "final north ascent closure",
            "authority-closed court completion",
        ],
    }

    consistency_checks = {
        "launch_front_is_already_closed_before_boarding": launch_front["structural_reading"][
            "the_next_court_no_longer_needs_scope_debate_before_packet_facing_launch"
        ],
        "all_four_lanes_are_frozen_inside_one_court": set(scope["selected_scope_contains"])
        == expected_lanes
        and set(charter["court_lanes"]) == expected_lanes,
        "fixed_lane_keeps_the_large_public_reference_floor": (
            fixed_lane["rotation_fixed_public_qumond_crosscheck_count_with_zero_public_gap"] == 174
        ),
        "matched_lane_is_named_and_executed": (
            matched_lane["named_executed_witness_count"] == 12
            and matched_lane["route_split_witness"] == "SPARC_NGC0247"
            and matched_partition["partitions"]["route_split"]["witness"][
                "public_and_live_matched_nuisance_lanes_are_pro_qct"
            ]
        ),
        "best_dressed_lane_has_materialized_body_and_live_edge": (
            primary_core["front_block_closure"][
                "primary_parity_core_is_now_closed_as_an_explicit_three_witness_front_block"
            ]
            and layered_o7["o7_positive_spoiler_intersection"]["case_count"] == 7
            and o7_remainder["current_o7_nonintersecting_remainder"]["case_count"] == 3
            and not o7_reinflation["current_reading"]["d72_batch_already_completed"]
        ),
        "north_lane_is_locked_but_not_closed": (
            north_lane["same_kernel_only"]
            and north_lane["no_new_knobs"]
            and "final_north_ascent_closure_not_materialized" in north_lane["not_closed_by_manifest"]
        ),
        "lane_collapse_remains_forbidden": charter["governing_law"]["lane_collapse_forbidden"],
        "cross_observable_drift_remains_forbidden": charter["governing_law"][
            "cross_observable_drift_forbidden"
        ],
        "whole_court_execution_is_still_not_claimed": (
            "Cross-observable court already executed" in scope["not_supported_now"]
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "packet_contained_reviewer_facing_cross_observable_court_lane_status_board",
        "surface": "current_reviewer_facing_cross_observable_court_lane_status_board",
        "board_sequence": [
            "fixed_comparator_rotation_witness_court",
            "matched_nuisance_parity_court",
            "best_dressed_adversarial_hardening_court",
            "same_kernel_macs1206_secondary_deltasigma_rail",
        ],
        "lane_status_board": {
            "fixed_comparator_rotation_witness_court": fixed_lane,
            "matched_nuisance_parity_court": matched_lane,
            "best_dressed_adversarial_hardening_court": best_dressed_lane,
            "same_kernel_macs1206_secondary_deltasigma_rail": north_lane,
        },
        "structural_reading": {
            "each_lane_now_has_one_explicit_packet_side_state": True,
            "the_court_can_now_be_read_as_one_governed_board_rather_than_one_undifferentiated_promise": True,
            "execution_state_and_claim_boundary_are_now_tied_lane_by_lane": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the selected cross-observable court now has one explicit lane-by-lane board",
            "the fixed comparator lane is frozen as a reference floor rather than buried inside broader rhetoric",
            "the matched-nuisance lane is now visibly the executed named parity lane",
            "the best-dressed lane is now visibly a materialized hardening lane with one live reinflation edge",
            "the MACS1206 rail is now visibly a same-kernel locked north rail with an explicit authority gate above it",
        ],
        "not_supported_now": [
            "all four lanes are already executed in the same sense",
            "the north rail is already authority-closed",
            "matched-nuisance and best-dressed lanes may be silently collapsed",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_continuation": [
            "reviewer_facing_cross_observable_court_lane_progression_without_erasing_lane_distinctions",
            "later court execution only where each lane honestly upgrades its own state",
        ],
    }

    output["verdict"] = (
        "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_STATUS_BOARD_CLOSED__EACH_OF_THE_FOUR_LANES_NOW_HAS_ONE_EXPLICIT_PACKET_SIDE_STATE_SO_THE_NEXT_COURT_CAN_BE_READ_AS_ONE_GOVERNED_BOARD_RATHER_THAN_ONE_UNDIFFERENTIATED_PROMISE"
        if all(consistency_checks.values())
        else "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_STATUS_BOARD_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
