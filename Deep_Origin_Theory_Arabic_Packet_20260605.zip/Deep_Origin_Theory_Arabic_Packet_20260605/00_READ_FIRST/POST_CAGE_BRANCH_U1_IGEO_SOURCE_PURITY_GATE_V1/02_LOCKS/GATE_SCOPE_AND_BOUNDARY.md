# I_geo Source-Purity Gate Scope And Boundary

Date: `2026-06-11`

Status: `scope lock`

This object is scoped only to:

- the current frozen post-cage `U1` route,
- the exact live `G1` tooth
  `source-governed I_geo -> A_Q carrier-law certification`,
- the first internal gate inside that tooth,
- and the next exact tooth above that first gate.

It is **not** scoped to:

- full `T_Q` ownership,
- full transport closure,
- full `G1/G2` closure,
- whole-branch `U2` adjudication,
- or true `L0` observed-row crossing.

The object is valid only if all of the following remain true:

1. `U1` remains the live constructive owner,
2. no typed `U2` trigger has already forced widening,
3. the exact target remains
   `I_geo -> A_Q` carrier-law certification,
4. and the current route still preserves same-carrier discipline.

This object should be superseded immediately if later lawful work shows:

1. the first internal gate is not source-purity,
2. `I_geo` cannot be typed meaningfully on the `g,ψ` side alone,
3. direct `Q` dependence is required already at register-definition grade,
4. mandatory primitive `B_Q` must be reopened before `A_Q` can even stand,
5. or one genuine `U2` trigger fires before the gate survives.
