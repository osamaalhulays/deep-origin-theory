# I_geo Source-Purity Gate Test Matrix

Date: `2026-06-11`

Status: `bounded gate matrix`

## Positive target

The present object is materialized if the current route already supports all
of the following:

1. the first gate inside `I_geo -> A_Q` certification is
   `I_geo` source-purity,
2. the first positive admissible shell is
   `I_geo^(0)[g,ψ]`
   on the metric/matter-only route,
3. the gate excludes direct `Q` dependence at register-definition grade,
4. the gate excludes empirical borrowing,
5. the gate excludes hidden second-carrier leakage,
6. the gate excludes non-variational patching,
7. and the next exact tooth above that gate is
   `A_Q^(0)[I_geo^(0)]`
   rather than immediate `T_Q` lift.

## Failure signatures

The object fails if the current route instead requires any of the following:

1. direct `Q` dependence already at the shell-definition grade,
2. empirical calibration, halo rescue, or baryonic rescue at the gate,
3. one hidden second carrier inside the moderation lane,
4. one non-variational helper patch,
5. one immediate jump from `I_geo` straight to `T_Q` ownership,
6. or mandatory primitive `B_Q` reopening before `A_Q` can stand.

## Honest next-tooth reading

If the object survives,
the honest next-tooth reading is:

- `I_geo^(0) -> A_Q^(0) -> T_Q ownership`

not:

- `I_geo -> T_Q ownership`

and not:

- generic transport ambition with no internal gate structure.
