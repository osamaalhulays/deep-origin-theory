#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"
PACKET_PREFIX = "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"

TARGET_SPLIT_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_OTRANSPORT_IGEO_TO_AQ_TARGET_SPLITS_TO_SOURCE_PURITY_GATE_BEFORE_TRANSPORT_LIFT_NOTE_20260608.md"
)
IGEO_SHELL_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_IGEO_SOURCE_PURITY_GATE_LOCALIZES_TO_METRIC_MATTER_ONLY_REGISTER_SHELL_NOTE_20260608.md"
)
AQ_SHELL_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_OTRANSPORT_IGEO_TO_AQ_ROUTE_LOCALIZES_TO_BQ_FREE_VARIATIONAL_KINETIC_SHELL_BEFORE_TQ_LIFT_NOTE_20260608.md"
)

NOTE_CHECKS = [
    {
        "key": "target_split_gate_order",
        "path": TARGET_SPLIT_PATH,
        "fragments": [
            "`first gate inside I_geo -> A_Q certification = I_geo source-purity gate`",
            "Only after that gate survives cleanly does the route lawfully advance to:",
            "`A_Q -> T_Q` transport-lift inside the same certified lane",
        ],
        "meaning": "the exact target already splits first to source-purity before transport-lift",
    },
    {
        "key": "igeo_positive_shell",
        "path": IGEO_SHELL_PATH,
        "fragments": [
            "`I_geo^(0) = metric/matter-only register shell`",
            "`I_geo` may first be admitted only as one geometry-response moderation shell",
            "it does **not** yet depend directly on `Q`",
        ],
        "meaning": "the first positive admissible I_geo shell is metric/matter-only and Q-free at definition grade",
    },
    {
        "key": "aq_next_tooth",
        "path": AQ_SHELL_PATH,
        "fragments": [
            "`A_Q^(0)[I_geo^(0)] = B_Q-free same-carrier variational kinetic shell`",
            "`I_geo^(0) -> A_Q^(0) -> T_Q ownership`",
            "`B_Q` is not mandatory as a primitive first-strike bulk slot",
        ],
        "meaning": "the next exact tooth above the gate is the B_Q-free A_Q variational kinetic shell",
    },
]


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


def find_packet_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if parent.name == "00_READ_FIRST" and (parent / "START_HERE_FIRST.md").exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
SCRIPT_PACKET_ROOT = find_packet_root()
if SCRIPT_PACKET_ROOT is not None:
    PACKET_ROOT = SCRIPT_PACKET_ROOT
    RUNNING_FROM_PACKET = True
elif WORKSPACE_ROOT is not None:
    PACKET_ROOT = WORKSPACE_ROOT / "Deep_Origin_Theory_English_Packet_20260605" / "00_READ_FIRST"
    RUNNING_FROM_PACKET = False
else:
    raise RuntimeError("could not locate workspace or packet root from I_geo gate runner")


def candidate_paths(logical_relative_path: str) -> list[Path]:
    candidates: list[Path] = []

    def add(path: Path) -> None:
        if path not in candidates:
            candidates.append(path)

    if RUNNING_FROM_PACKET and logical_relative_path.startswith(PACKET_PREFIX):
        add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    if WORKSPACE_ROOT is not None:
        add(WORKSPACE_ROOT / logical_relative_path)
        if logical_relative_path.startswith(PACKET_PREFIX):
            add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    return candidates


def resolve_existing_path(logical_relative_path: str) -> Path:
    for candidate in candidate_paths(logical_relative_path):
        if candidate.exists():
            return candidate
    searched = "\n".join(str(path) for path in candidate_paths(logical_relative_path))
    raise FileNotFoundError(
        f"could not resolve I_geo source-purity surface: {logical_relative_path}\n{searched}"
    )


def read_text(logical_relative_path: str) -> str:
    return resolve_existing_path(logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": item["path"],
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": (
            "POST_CAGE_BRANCH_U1_IGEO_SOURCE_PURITY_GATE_MATERIALIZED"
            if all_note_checks_pass
            else "POST_CAGE_BRANCH_U1_IGEO_SOURCE_PURITY_GATE_NOT_MATERIALIZED"
        ),
        "igeo_target_split_confirmed": note_check_map["target_split_gate_order"],
        "igeo_source_purity_is_first_internal_gate": note_check_map["target_split_gate_order"],
        "metric_matter_only_positive_shell_confirmed": note_check_map["igeo_positive_shell"],
        "next_exact_tooth_localized_to_aq0": note_check_map["aq_next_tooth"],
        "u1_first_preserved": all_note_checks_pass,
        "direct_q_dependence_admitted_at_definition_grade": False,
        "empirical_borrowing_admitted": False,
        "hidden_second_carrier_admitted": False,
        "nonvariational_patch_admitted": False,
        "all_note_checks_pass": all_note_checks_pass,
    }

    verdict = {
        "verdict": status_summary["verdict"],
        "current_exact_target": "source-governed I_geo -> A_Q carrier-law certification",
        "first_internal_gate": "I_geo source-purity at register-definition grade",
        "positive_shell": "I_geo^(0)[g,ψ] = metric/matter-only register shell",
        "next_exact_tooth": "A_Q^(0)[I_geo^(0)] = B_Q-free same-carrier variational kinetic shell",
    }

    report_lines = [
        "# Post-Cage Branch U1 I_geo Source-Purity Gate Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- exact target split to source-purity confirmed: `{status_summary['igeo_target_split_confirmed']}`",
        f"- metric/matter-only positive shell confirmed: `{status_summary['metric_matter_only_positive_shell_confirmed']}`",
        f"- next exact tooth localized to `A_Q^(0)`: `{status_summary['next_exact_tooth_localized_to_aq0']}`",
        f"- `U1`-first discipline preserved: `{status_summary['u1_first_preserved']}`",
        f"- all note checks pass: `{status_summary['all_note_checks_pass']}`",
        "",
        "## Reading",
        "",
        "- the first internal gate inside the live `G1` tooth is now reviewer-visible,",
        "- the gate is source-purity of `I_geo` at register-definition grade,",
        "- the first positive admissible shell is `I_geo^(0)[g,ψ]` on the metric/matter-only route,",
        "- and the next honest tooth above that gate is `A_Q^(0)[I_geo^(0)]`, not direct `T_Q` lift.",
        "",
        "## Ceiling",
        "",
        "- this report does not claim full `I_geo -> A_Q` certification,",
        "- it does not claim real `T_Q` ownership already crossed,",
        "- it does not claim full transport closure or full `G1/G2` completion.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    write_json(
        OUTPUT_ROOT / "source_inputs.json",
        {
            "target_split_path": TARGET_SPLIT_PATH,
            "igeo_shell_path": IGEO_SHELL_PATH,
            "aq_shell_path": AQ_SHELL_PATH,
        },
    )
    (OUTPUT_ROOT / "IGEO_SOURCE_PURITY_GATE_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
