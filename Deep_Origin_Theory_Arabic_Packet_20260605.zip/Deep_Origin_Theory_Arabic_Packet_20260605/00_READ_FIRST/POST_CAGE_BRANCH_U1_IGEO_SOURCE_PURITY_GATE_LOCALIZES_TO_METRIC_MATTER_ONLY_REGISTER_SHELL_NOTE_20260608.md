# Post-Cage Branch U1 I_geo Source-Purity Gate Localizes To Metric/Matter-Only Register Shell Note

Date: `2026-06-08`

Status: `bounded packet-facing absorption`

## Purpose

The live `U1` route now already carries one exact gate order:

1. `O_transport` is the local execution owner
2. its next exact target is
   `I_geo -> A_Q` carrier-law certification
3. the first gate inside that target is
   `I_geo` source-purity at register-definition grade

So the next exact question becomes:

- if `I_geo` is to pass source-purity honestly,
  what is the first positive admissible class it should belong to

## Candidate readings

The positive side of the gate could in principle have been:

1. one vaguely source-governed but still mixed lane
2. one metric/matter-only register shell
3. one already carrier-fed lane with delayed purity excuses

## Short verdict

The current record best supports the second reading.

The first positive admissible class for the source-purity gate is:

`I_geo^(0) = metric/matter-only register shell`

meaning:

- `I_geo` must first be admissible as one register built only from the
  already-owned metric/matter route

before it is allowed to bear any later `A_Q -> T_Q` transport-lift claim.

This is stronger than saying only:

- "no direct `Q` dependence"

because it supplies the positive mirror:

- yes, `I_geo` may live on the `g,ψ` side alone at register-definition grade.

That is a real gain.

## 1. Why the gate needs a positive class, not only negative prohibitions

The current source-purity gate already carries four prohibitions:

1. no direct `Q` dependence
2. no empirical borrowing
3. no hidden second carrier
4. no non-variational patch

Those are necessary,
but not sufficient.

Without a positive admissible class,
the gate can still remain too foggy:

- "clean somehow"

The current record is already sharp enough to do better.

It can say what the first clean shell actually is.

## 2. Why metric/matter-only is already repo-native

Two current lines align directly.

### A. The `IR1` scaffold already types the register as `I_src^(IR1)[g,ψ]`

The register scaffold does not write:

- `I_src^(IR1)[g,ψ,Q]`

It writes:

- `I_src^(IR1)[g,ψ]`

and specifically:

- `I_geo[g,ψ]`

That is already one exact repo-native clue:

- register-definition grade stays on the metric/matter side.

### B. The first typed worksheet already enforces metric/matter-built source-governed structure

The typed `QF1/IF1` worksheet already states that the first-order operator
slot:

- `D[g,ψ]`

must be built only from already-owned metric/matter structures.

So the repo already preserves one lawful pattern:

- definition-grade source-governed scaffolds are allowed first on the
  `g,ψ` side before stronger carrier-lift claims are made.

That pattern fits `I_geo` exactly.

## 3. Exact meaning of the metric/matter-only register shell

The fair current positive class is:

- `I_geo` may first be admitted only as one geometry-response moderation shell
  defined on the already-owned metric/matter route

At this grade that means:

1. it is a functional of `g,ψ` only
2. it may use already-owned geometric/matter structures
3. it does **not** yet depend directly on `Q`
4. it does **not** yet smuggle a second carrier in disguised form

This does **not** yet declare one final formula.

It declares the first lawful shell class.

## 4. Why carrier-fed `I_geo` is too early

If `I_geo` already needed direct `Q` feedback at register-definition grade,
the gate would lose its purity before it began.

That would break the current order:

- register shell first
- headwise carrier-law lift second

So the route should not admit:

- one `I_geo[g,ψ,Q]` shell

at this gate.

If such dependence becomes unavoidable later,
that is a later flip condition,
not the first admissible shell.

## 5. Why this still preserves `U1-first`

This shell is the most conservative positive class available.

It preserves:

1. single-carrier honesty
2. source-governed discipline
3. no empirical rescue
4. no premature `U2` widening

So it is the right next subgate for the live `U1` attack.

## 6. Exact next-subgate wording

The fair current next subgate is:

- certify that `I_geo` first admits one metric/matter-only source-governed
  register shell
  `I_geo^(0)[g,ψ]`
  before any later `A_Q -> T_Q` carrier-law lift is claimed from it

This is narrower than:

- full `I_geo -> A_Q` certification

but stronger than:

- generic purity language with no positive shell.

## 7. What this does not say

This note does **not** claim:

- that the final functional form of `I_geo^(0)` is already known
- that `I_geo^(0)` already passes every authority test
- that `A_Q` is already transport-certified
- or that exact closure is near complete

It claims something narrower and useful:

- the positive admissible class for the next gate is now named.

## 8. Exact flip conditions

This shell reading should be revoked immediately if later lawful work shows:

1. `I_geo` cannot even be typed meaningfully on the `g,ψ` side alone
2. direct `Q` dependence is required already at register-definition grade
3. one hidden second carrier is unavoidable even before headwise lift
4. the real first positive shell lies elsewhere than the metric/matter route

If any of those appears,
this shell reading fails.

## Bottom line

The current live `U1` route now supports one sharper reading again:

1. `I_geo` source-purity is the first gate inside the current transport target
2. that gate is no longer only negative
3. its first positive admissible class is
   `I_geo^(0)[g,ψ]`
   as one metric/matter-only register shell
4. only after that shell survives cleanly may the route lawfully press toward
   `A_Q -> T_Q` transport-lift

That is the cleanest current positive formulation of the live `I_geo` gate.
