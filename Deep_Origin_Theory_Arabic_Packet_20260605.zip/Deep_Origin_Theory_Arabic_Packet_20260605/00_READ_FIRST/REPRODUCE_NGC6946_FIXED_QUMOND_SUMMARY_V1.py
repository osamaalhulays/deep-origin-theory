#!/usr/bin/env python3
import json
import math
from pathlib import Path


HERE = Path(__file__).resolve().parent
SOURCE_MD = HERE / "FIXED_QUMOND_COMPARATOR_APPENDIX__NGC6946__SOURCE_LOCKED_V1.md"
A0_MS2 = 1.2e-10
KPC_IN_M = 3.085677581491367e19


def parse_row(line: str):
    parts = [part.strip() for part in line.strip().strip("|").split("|")]
    if len(parts) != 10:
        return None
    if not parts[0].isdigit():
        return None

    v_obs_text, sigma_text = [part.strip() for part in parts[3].split("±")]
    return {
        "row_id": int(parts[0]),
        "r_kpc": float(parts[2]),
        "v_obs_km_s": float(v_obs_text),
        "sigma_km_s": float(sigma_text),
        "v_bar_km_s": float(parts[4]),
        "v_qumond_table_km_s": float(parts[5]),
        "residual_qumond_km_s": float(parts[6]),
        "chi2_contrib": float(parts[7]),
        "delta_true": float(parts[8]),
        "sign": parts[9],
    }


def recompute_qumond_km_s(r_kpc: float, v_bar_km_s: float) -> float:
    r_m = r_kpc * KPC_IN_M
    v_bar_ms = v_bar_km_s * 1000.0
    g_bar = (v_bar_ms ** 2) / r_m
    y = g_bar / A0_MS2
    nu = 0.5 + math.sqrt(0.25 + 1.0 / y)
    return (v_bar_ms * math.sqrt(nu)) / 1000.0


def main():
    text = SOURCE_MD.read_text(encoding="utf-8")
    rows = []
    in_table = False

    for line in text.splitlines():
        if line.startswith("| Row |"):
            in_table = True
            continue
        if in_table:
            if not line.startswith("|"):
                break
            row = parse_row(line)
            if row is not None:
                rows.append(row)

    if not rows:
        raise SystemExit("Could not parse NGC6946 markdown row table.")

    residuals = [row["residual_qumond_km_s"] for row in rows]
    chi2_total = sum(row["chi2_contrib"] for row in rows)
    delta_negative = sum(1 for row in rows if row["delta_true"] < 0)
    delta_positive = sum(1 for row in rows if row["delta_true"] > 0)
    max_v_qumond_recompute_error = 0.0
    max_residual_recompute_error = 0.0
    max_chi2_recompute_error = 0.0

    for row in rows:
        v_qumond_recomputed = recompute_qumond_km_s(row["r_kpc"], row["v_bar_km_s"])
        residual_recomputed = row["v_obs_km_s"] - v_qumond_recomputed
        chi2_recomputed = (residual_recomputed / row["sigma_km_s"]) ** 2

        max_v_qumond_recompute_error = max(
            max_v_qumond_recompute_error,
            abs(v_qumond_recomputed - row["v_qumond_table_km_s"]),
        )
        max_residual_recompute_error = max(
            max_residual_recompute_error,
            abs(residual_recomputed - row["residual_qumond_km_s"]),
        )
        max_chi2_recompute_error = max(
            max_chi2_recompute_error,
            abs(chi2_recomputed - row["chi2_contrib"]),
        )

    output = {
        "surface": "ngc6946_fixed_qumond_summary",
        "row_count": len(rows),
        "all_QUMOND_residuals_negative": all(value < 0 for value in residuals),
        "chi2_total_QUMOND_source_locked": round(chi2_total, 12),
        "mean_absolute_residual_km_s": round(
            sum(abs(value) for value in residuals) / len(residuals), 12
        ),
        "max_absolute_residual_km_s": round(max(abs(value) for value in residuals), 12),
        "max_v_QUMOND_recompute_error_km_s": round(max_v_qumond_recompute_error, 12),
        "max_residual_recompute_error_km_s": round(max_residual_recompute_error, 12),
        "max_chi2_recompute_error": round(max_chi2_recompute_error, 12),
        "delta_true_negative_rows": delta_negative,
        "delta_true_positive_rows": delta_positive,
        "delta_true_sign_split_label": f"{delta_negative} negative / {delta_positive} positive",
        "source_surface": str(SOURCE_MD),
        "guardrail": (
            "This bounded audit surface recomputes the published source-locked fixed-QUMOND lane "
            "directly from the row table, but it still does not claim parity with the fuller "
            "NGC0247 current-comparator lane."
        ),
    }

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
