#!/usr/bin/env python3
import csv
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
CURRENT_STACK_SCRIPT = HERE / "REPRODUCE_NGC0247_CURRENT_STACK_V1.py"
PHASE2_SCRIPT = HERE / "REPRODUCE_NGC0247_PHASE2_CURRENT_QCT_ROW_COMPARATOR_V1.py"
CSV_PATH = HERE / "NGC0247_CURRENT_ROW_COMPARATOR__QCT_AND_FIXED_QUMOND__V1.csv"

REQUIRED_COLUMNS = [
    "row_index",
    "R_kpc",
    "v_obs_km_s",
    "sigma_obs_km_s",
    "v_bar_km_s",
    "delta_1d_current",
    "sigma_delta_1d_current",
    "v_QUMOND_fixed_km_s",
    "v_QUMOND_phase2_benchmark_km_s",
    "fitted_upsilon_qumond_phase2_seed42",
    "fitted_upsilon_qct_phase2_seed42",
    "v_QCT_current_km_s",
    "sigma_model_QCT_km_s",
    "chi2_QUMOND_fixed_term",
    "chi2_QUMOND_phase2_benchmark_term",
    "chi2_QCT_obs_only_term",
    "chi2_QCT_obs_model_term",
]


def run_json_script(script_path: Path):
    output = subprocess.check_output(
        [sys.executable, str(script_path)],
        cwd=str(HERE),
        text=True,
    )
    return json.loads(output)


def load_rows(csv_path: Path):
    with csv_path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def as_float(row, key):
    return float(row[key])


def main():
    current_stack = run_json_script(CURRENT_STACK_SCRIPT)
    phase2 = run_json_script(PHASE2_SCRIPT)
    rows = load_rows(CSV_PATH)

    header = rows[0].keys() if rows else []
    missing_columns = [name for name in REQUIRED_COLUMNS if name not in header]

    qct_upsilons = sorted({as_float(row, "fitted_upsilon_qct_phase2_seed42") for row in rows})
    qumond_upsilons = sorted({as_float(row, "fitted_upsilon_qumond_phase2_seed42") for row in rows})

    readiness = {
        "surface": "ngc0247_parity_readiness_gate",
        "row_count": len(rows),
        "required_columns_present": len(missing_columns) == 0,
        "missing_columns": missing_columns,
        "row_surface_values": {
            "recovered_qct_upsilon_values": qct_upsilons,
            "recovered_qumond_upsilon_values": qumond_upsilons,
        },
        "verification": {
            "current_stack_verified": (
                current_stack["row_count"] == len(rows)
                and current_stack["max_v_QUMOND_recompute_error_km_s"] == 0.0
                and current_stack["max_residual_recompute_error_km_s"] == 0.0
                and current_stack["max_chi2_recompute_error"] == 0.0
                and current_stack["all_sigma_delta_1d_current_positive"] is True
            ),
            "phase2_row_comparator_verified": (
                phase2["row_count"] == len(rows)
                and phase2["ll_qct_obs_only_abs_error"] < 1e-5
                and phase2["ll_qct_obs_model_abs_error"] < 1e-5
                and phase2["ll_qumond_benchmark_obs_only_abs_error"] == 0.0
                and phase2["delta_aic_total_abs_error"] < 1e-5
                and phase2["delta_bic_total_abs_error"] < 1e-5
            ),
        },
        "historical_lane_recovered_nuisances": {
            "qct_phase2_seed42": phase2["upsilon_phase2_seed42"],
            "qumond_phase2_seed42": phase2["upsilon_qumond_phase2_seed42"],
        },
        "numeric_readiness_gate_closed": False,
        "remaining_blockers": [
            "same-convention scoring shell for formal parity verdict not yet frozen",
            "clean original fitted-Y production artifact not preserved as its own public file",
        ],
        "ownership_split": {
            "O6": [
                "named NGC0247 rowwise parity substrate",
                "recovered nuisance-visible numerical lane",
                "later executed reviewer-facing parity artifact",
            ],
            "O8": [
                "same-convention AIC/BIC and parameter-accounting shell",
                "original fitted-Y provenance artifact or stronger clean replacement",
            ],
        },
    }

    readiness["numeric_readiness_gate_closed"] = (
        readiness["required_columns_present"]
        and readiness["verification"]["current_stack_verified"]
        and readiness["verification"]["phase2_row_comparator_verified"]
        and len(qct_upsilons) == 1
        and len(qumond_upsilons) == 1
    )

    readiness["verdict"] = (
        "NGC0247_NUMERIC_PARITY_SUBSTRATE_READY__FORMAL_SCORE_SHELL_AND_PROVENANCE_CLEANUP_STILL_ABOVE_GATE"
        if readiness["numeric_readiness_gate_closed"]
        else "NGC0247_NUMERIC_PARITY_SUBSTRATE_NOT_YET_READY"
    )

    print(json.dumps(readiness, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
