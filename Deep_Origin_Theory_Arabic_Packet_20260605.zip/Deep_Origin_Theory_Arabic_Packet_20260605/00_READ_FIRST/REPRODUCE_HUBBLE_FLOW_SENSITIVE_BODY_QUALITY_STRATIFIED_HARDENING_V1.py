#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

PRIMARY_CORE_PATH = HERE / "PRIMARY_PARITY_CORE_TRIAD_ORDER_AND_UNIFORM_COMPONENT_HARDENING_V1.json"
RESIDUAL_TRIAD_PATH = HERE / "RESIDUAL_QUALITY1_REOPENING_TRIAD_CLOSURE_V1.json"
RESERVE_NGC5033_PATH = HERE / "NGC5033_FIRST_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json"
RESERVE_UGC02487_PATH = HERE / "UGC02487_SECOND_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json"
RESERVE_UGC03205_PATH = HERE / "UGC03205_THIRD_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json"
QUALITY2_SIDECAR_PATH = HERE / "UGC05253_BOUNDED_QUALITY2_SIDECAR_ENTRY_V1.json"
HUBBLE_BODY_PATH = HERE / "HUBBLE_FLOW_SENSITIVE_BODY_FULL_CLOSURE_V1.json"
CLEAN_ANCHOR_SYNTHESIS_PATH = HERE / "CLEAN_ANCHOR_MINORITY_VS_FULLY_CLOSED_HUBBLE_FLOW_SENSITIVE_BODY_CROSS_COURT_SYNTHESIS_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def close_enough(left, right, tolerance=1e-9):
    return abs(left - right) <= tolerance


def summarize_members(members):
    public_total = sum(member["public_delta_aic_total"] for member in members)
    faithful_total = sum(member["faithful_delta_aic_total"] for member in members)
    component_total = sum(member["component_aware_delta_aic_total"] for member in members)
    shift_total = sum(member["component_aware_shift"] for member in members)
    return {
        "case_count": len(members),
        "cases": [member["case_id"] for member in members],
        "public_delta_aic_total": public_total,
        "faithful_delta_aic_total": faithful_total,
        "component_aware_delta_aic_total": component_total,
        "component_aware_shift": shift_total,
    }


def collect_hubble_body_members():
    members = []

    core = load_json(PRIMARY_CORE_PATH)
    for row in core["ordered_core"]:
        members.append(
            {
                "case_id": row["case_id"],
                "quality_flag": row["quality_flag"],
                "public_delta_aic_total": row["public_delta_aic_total"],
                "faithful_delta_aic_total": row["faithful_delta_aic_total"],
                "component_aware_delta_aic_total": row["component_aware_delta_aic_total"],
                "component_aware_shift": row["component_aware_shift"],
            }
        )

    residual = load_json(RESIDUAL_TRIAD_PATH)
    for row in residual["witnesses"]:
        members.append(
            {
                "case_id": row["case_id"],
                "quality_flag": 1,
                "public_delta_aic_total": row["public_delta_aic_total"],
                "faithful_delta_aic_total": row["faithful_delta_aic_total"],
                "component_aware_delta_aic_total": row["component_aware_delta_aic_total"],
                "component_aware_shift": row["component_aware_shift"],
            }
        )

    for path in (
        RESERVE_NGC5033_PATH,
        RESERVE_UGC02487_PATH,
        RESERVE_UGC03205_PATH,
        QUALITY2_SIDECAR_PATH,
    ):
        row = load_json(path)["witness"]
        members.append(
            {
                "case_id": row["case_id"],
                "quality_flag": row["quality_flag"],
                "public_delta_aic_total": row["public_delta_aic_total"],
                "faithful_delta_aic_total": row["faithful_delta_aic_total"],
                "component_aware_delta_aic_total": row["component_aware_delta_aic_total"],
                "component_aware_shift": row["component_aware_shift"],
            }
        )

    return members


def main():
    members = collect_hubble_body_members()
    hubble_body = load_json(HUBBLE_BODY_PATH)
    clean_anchor = load_json(CLEAN_ANCHOR_SYNTHESIS_PATH)

    quality1_members = [member for member in members if member["quality_flag"] == 1]
    quality2_members = [member for member in members if member["quality_flag"] == 2]

    quality1_summary = summarize_members(quality1_members)
    quality2_summary = summarize_members(quality2_members)

    body_public_total = hubble_body["combined_burden"]["public_delta_aic_total"]
    body_component_total = hubble_body["combined_burden"]["component_aware_delta_aic_total"]

    quality1_summary["fraction_of_hubble_flow_sensitive_public_burden"] = (
        quality1_summary["public_delta_aic_total"] / body_public_total
    )
    quality1_summary["fraction_of_hubble_flow_sensitive_component_aware_burden"] = (
        quality1_summary["component_aware_delta_aic_total"] / body_component_total
    )
    quality2_summary["fraction_of_hubble_flow_sensitive_public_burden"] = (
        quality2_summary["public_delta_aic_total"] / body_public_total
    )
    quality2_summary["fraction_of_hubble_flow_sensitive_component_aware_burden"] = (
        quality2_summary["component_aware_delta_aic_total"] / body_component_total
    )

    consistency_checks = {
        "quality1_and_quality2_partition_the_hubble_flow_sensitive_body": (
            quality1_summary["case_count"] + quality2_summary["case_count"] == len(members)
        ),
        "quality1_public_total_plus_quality2_public_total_matches_body": close_enough(
            quality1_summary["public_delta_aic_total"] + quality2_summary["public_delta_aic_total"],
            body_public_total,
        ),
        "quality1_faithful_total_plus_quality2_faithful_total_matches_body": close_enough(
            quality1_summary["faithful_delta_aic_total"] + quality2_summary["faithful_delta_aic_total"],
            hubble_body["combined_burden"]["faithful_delta_aic_total"],
        ),
        "quality1_component_total_plus_quality2_component_total_matches_body": close_enough(
            quality1_summary["component_aware_delta_aic_total"] + quality2_summary["component_aware_delta_aic_total"],
            body_component_total,
        ),
        "quality1_shift_plus_quality2_shift_matches_body": close_enough(
            quality1_summary["component_aware_shift"] + quality2_summary["component_aware_shift"],
            hubble_body["combined_burden"]["component_aware_shift"],
        ),
        "all_quality1_members_harden": all(member["component_aware_shift"] > 0.0 for member in quality1_members),
        "all_quality2_members_harden": all(member["component_aware_shift"] > 0.0 for member in quality2_members),
        "quality1_subgroup_carries_majority_of_hubble_body_burden": (
            quality1_summary["public_delta_aic_total"] > quality2_summary["public_delta_aic_total"]
            and quality1_summary["component_aware_delta_aic_total"] > quality2_summary["component_aware_delta_aic_total"]
        ),
        "clean_anchor_minority_is_all_quality1_but_external_to_hubble_body": (
            clean_anchor["clean_anchor_minority_court"]["all_quality1"] is True
            and set(clean_anchor["clean_anchor_minority_court"]["cases"]).isdisjoint(
                quality1_summary["cases"] + quality2_summary["cases"]
            )
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "bounded_packet_facing_quality_stratified_body_reading",
        "surface": "hubble_flow_sensitive_body_quality_stratified_hardening",
        "quality1_subgroup": quality1_summary,
        "quality2_subgroup": quality2_summary,
        "structural_reading": {
            "the_hubble_flow_sensitive_body_is_not_a_quality2_only_hardening_artifact": True,
            "quality1_cases_inside_the_body_also_uniformly_harden": True,
            "quality_flag_alone_does_not_define_whole_head_court_membership": True,
        },
        "consistency_checks": consistency_checks,
        "not_supported_now": [
            "The hardening body is driven only by quality2 cases",
            "Quality1 inside the hardening body softens toward QCT",
            "Quality flag alone settles the full-head court split",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_frontier": [
            "test_whether_any_later_nonhardening_behavior_can_enter_the_hubble_flow_sensitive_body",
            "extend_the_no_makeup_court_without_reducing_it_to_a_quality_flag_explanation",
        ],
    }

    output["verdict"] = (
        "HUBBLE_FLOW_SENSITIVE_BODY_QUALITY_STRATIFIED_HARDENING_CLOSED__THE_TEN_WITNESS_HARDENING_BODY_IS_NOT_A_QUALITY2_ARTIFACT_BECAUSE_ITS_SEVEN_QUALITY1_MEMBERS_ALSO_UNIFORMLY_HARDEN"
        if all(consistency_checks.values())
        else "HUBBLE_FLOW_SENSITIVE_BODY_QUALITY_STRATIFIED_HARDENING_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
