# NGC0247 Canonical Tri-Comparator And Claim-Boundary Note

Date: `2026-06-06`

Status: `canonical comparison-discipline surface`

## Purpose

This note exists to close one smart remaining reviewer opening:

- the temptation to blur three different `NGC0247` comparison lanes into one
  rhetorical "QUMOND versus current theory" sentence.

The packet now carries enough material that this blurring is no longer
necessary.

It is therefore better to say the harder but cleaner thing:

- one target,
- three visible comparison lanes,
- three different lawful readings,
- and one explicit claim boundary.

## The three visible lanes

### Lane A — fixed source-locked comparator

This is the public fixed simple-`QUMOND` row comparator:

- no fitted nuisance,
- source-locked `v_bar`,
- frozen simple `nu(y)` rule,
- and one row-by-row fixed benchmark read.

This lane answers:

- what happens if the named case is inspected against the fixed public
  comparator without fitted rescue?

### Lane B — current bounded reconstructed comparator

This is the current bounded reconstructed row-level comparator for the present
Deep Origin Theory lane:

- tied to preserved source rows,
- tied to preserved current predictor surfaces,
- and tied to one recovered bounded nuisance value
  `Upsilon_phase2_seed42 = 0.9254967104326863`.

This lane answers:

- what does the currently exposed reconstructed row-level comparator look like
  for the same named case?

### Lane C — historical fitted benchmark replay

This is the preserved historical Phase-2 benchmark replay lane:

- fitted benchmark nuisance
  `Upsilon_qumond_phase2_seed42 = 0.5685897225673557`,
- historical single-case benchmark convention,
- and row-level replay carried only because the packet now preserves enough to
  reconstruct that historical lane visibly.

This lane answers:

- what did the historical fitted benchmark lane itself look like when replayed
  on the same rows?

## Canonical tri-comparator table

| Lane | Comparator object | Nuisance grammar | Frozen total(s) | Mean / max absolute residual | Residual sign read | Lawful present reading |
| --- | --- | --- | --- | --- | --- | --- |
| A | fixed source-locked simple-`QUMOND` | none | `chi2_total = 1160.321` | `16.883 / 22.100 km/s` | `26 negative / 0 positive` | fixed comparator overshoots the observed curve across all `26` preserved rows |
| B | current bounded reconstructed comparator (`v_QCT_current` row family) | recovered bounded `Upsilon_phase2_seed42 = 0.9254967104326863` | `chi2_obs_only = 358.895`; `chi2_obs_model = 214.388` | `6.791 / 11.761 km/s` | `17 negative / 9 positive` | present reconstructed row-level comparator materially narrows the fixed-comparator failure for the same named case |
| C | historical Phase-2 fitted benchmark replay | recovered benchmark `Upsilon_qumond_phase2_seed42 = 0.5685897225673557` | `chi2_obs_only = 62.003` | `3.231 / 6.881 km/s` | `20 negative / 6 positive` | historical fitted benchmark replay is numerically strong in its own narrower lane |

## What each lane proves

### What lane A proves

Lane A proves the strong bounded witness sentence:

- the fixed public comparator overshoots the named case in all `26` visible
  rows,
- while the paired correction target remains radius-resolved and sign-changing.

That is why `NGC0247` is already a real bounded differential witness rather
than a vague aggregate complaint.

### What lane B proves

Lane B proves that the packet no longer hides the present comparator behind
case-level language alone.

The packet now exposes:

- a visible current row-level comparator,
- visible residual structure,
- visible rowwise chi-squared terms,
- and a rerunnable bounded read for the same named case.

That is enough to support one bounded reviewer-safe sentence:

- the present reconstructed comparator materially improves the fixed
  source-locked benchmark for the named case.

### What lane C proves

Lane C proves something different and important:

- the packet is not erasing the historically strong fitted benchmark lane,
- and it is not pretending that every meaningful comparison already favors the
  current reconstructed comparator.

This is a strength, not a weakness in honesty.

It means the packet already preserves the uncomfortable lane as well, and so
does not survive by lane selection alone.

## What the tri-comparator does **not** prove

This tri-comparator note does **not** prove:

- whole-family `MOND/QUMOND` non-reducibility,
- that the original fitted-`Y` production object has been preserved as its own
  public artifact,
- that all historical lanes already obey one identical fairness convention,
- or that one single collapsed public score may be read across lanes A, B, and
  C without qualification.

## Why no single collapsed score is claimed here

One mature point must stay explicit:

- the three lanes are related,
- but they are not identical scientific objects.

In particular:

- lane A is a fixed source-locked public benchmark,
- lane B is a bounded reconstructed current comparator,
- and lane C is a historical fitted benchmark replay lane that predates later
  fairness hardening.

So the canonical present packet rule is:

- do not collapse A, B, and C into one slogan,
- do not silently move between "fixed benchmark failure" and "fitted benchmark
  strength" as if they were the same lane,
- and do not inflate a bounded named witness into a whole-family verdict.

## Best mature reading of `NGC0247`

The clean present reading is therefore:

1. against the fixed public source-locked comparator, the named case remains a
   strong bounded differential witness;
2. the packet now also exposes a current bounded reconstructed row-level
   comparator for the same case, making the witness inspectable rather than
   merely asserted;
3. the historical fitted benchmark replay remains numerically strong in its own
   lane and therefore blocks any dishonest claim that the packet has already
   closed the wider family question.

That is a more mature scientific surface than either of these two weaker
alternatives:

- "the whole `MOND/QUMOND` problem is finished,"
- or "the packet still only contains a suggestive narrative witness."

## Current-stage ceiling and later transfer

For the current admitted stage, this note should be read as marking one honest
ceiling:

- the packet now preserves a canonical three-lane comparison grammar for the
  named `NGC0247` case.

What remains is intentionally transferred to later fronts:

- directly preserved original fitted-`Y` closure artifact,
- broader current-production closure beyond the bounded reconstructed lane,
- and whole-family `MOND/QUMOND` verdict work.

## Golden reviewer-safe wording

One mature outward-safe sentence is:

> `NGC0247` should now be read through a canonical three-lane grammar: a fixed
> source-locked simple-`QUMOND` comparator that overshoots all `26` visible
> rows, a bounded reconstructed current row-level comparator that materially
> narrows that fixed-benchmark failure for the same named case, and a preserved
> historical fitted benchmark replay that remains strong in its own narrower
> lane. The result is a stronger bounded differential witness, not yet a
> whole-family closure claim.
