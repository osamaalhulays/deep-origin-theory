# Post-Cage Branch U1 Minimum Action Worksheet Note

Date: `2026-06-08`

Purpose:

This note states the smallest honest action worksheet for the post-cage `U1`
route.

It is not a final theory claim.

It is one disciplined worksheet for the next constructive strike.

## Short verdict

The minimum `U1` worksheet should start no larger than:

`S_U1 = S_EH[g] + S_m[g,ψ] + S_Q[g,Q] + S_int[g,ψ,Q]`

with one strict rule:

- the same carrier `Q` must own the response route, the south bounded regime,
  the transport role, and the future jump to promotable authority.

If one of those burdens is actually owned by a separate field architecture,
the route is already drifting into `U2`.

## 1. Minimum worksheet objects

The first honest `U1` worksheet needs only:

- one metric `g_{μν}`
- one matter sector `ψ`
- one real carrier `Q`
- one lawful interaction route between matter/geometry and `Q`

No separate south field appears at this stage.

## 2. What this worksheet must still own

The same worksheet must make room for:

1. total transport participation
2. one bounded south-regime realization from `Q`
3. one source-to-total response route
4. one bounded response probe
5. one future jump to promotable source-governed authority

So the real test is not whether the action looks elegant.

It is whether the same carrier still owns the whole route.

## 3. What breaks `U1`

The worksheet stops being honest `U1` if it quietly needs:

- one separate south field
- one separate transport-bearing companion
- one coefficient law not owned by `Q`
- or one response-authority patch not variationally owned by `Q`

At that point the route is no longer one-carrier-first.

It has widened into `U2`.

## Bottom line

The next constructive move is now clearer:

- not "invent the final action in one jump"
- but "write the smallest `U1` worksheet that proves the same carrier `Q`
  still owns transport, south regime, and response authority honestly"
