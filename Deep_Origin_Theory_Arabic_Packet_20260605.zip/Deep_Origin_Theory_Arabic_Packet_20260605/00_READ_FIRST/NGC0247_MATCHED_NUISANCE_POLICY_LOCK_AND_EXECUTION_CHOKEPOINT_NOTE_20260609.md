# `NGC0247` Matched-Nuisance Policy Lock And Execution Chokepoint Note

Date: `2026-06-09`

Status: `source-policy lock materialized`

Purpose:

This note closes one vagueness that was still sitting above the newly
materialized `NGC0247` parity-ready pilot object.

The open sentence used to be:

- freeze distance replay policy
- freeze inclination replay policy
- freeze quality masking rule

That sentence was directionally correct, but still too cloudy.

The packet now sharpens it into one cleaner truth:

- the source-policy layer is no longer vague,
- and the next real tooth is no longer policy naming,
- but nuisance-shifted row rematerialization.

## Short verdict

The `NGC0247` matched-nuisance source-policy lock is now closed at source
metadata level.

What is now packet-visible exactly:

- adopted distance = `3.70 +/- 0.19 Mpc`
- adopted inclination = `74.0 +/- 3.0 deg`
- table1 quality flag = `2`
- reference code = `Sa96,Ca90`
- `SFB` quality family = `34` rows total, `26` keep-flag rows, `8` reject-flag
  rows
- current packet row comparator = `26` rows

That means the source-policy ambiguity is no longer:

- "what distance/inclination/quality family would even count?"

It is now:

- "how do we lawfully rematerialize the shifted row object under those source
  variations?"

## What changed structurally

The hidden repository fact was not lack of metadata.

It was that part of the metadata was living inside the source-support
normalization machinery without being promoted into the visible support
surface.

That gap is now closed.

The `SPARC` vertical-support source layer now exports:

- distance,
- distance uncertainty,
- inclination,
- inclination uncertainty,
- quality flag,
- and reference code

for `NGC0247` directly into the visible support object.

So the packet now has a lawful source-policy anchor instead of one remembered
or implied policy.

## Why this matters

This is a real narrowing of the blocker.

Before this lock, one fair objection was:

- the future matched-nuisance replay is still underdeclared because its
  source-policy freedoms are not exact enough.

After this lock, that objection weakens.

The fair next objection is now tighter:

- the source-policy window is visible,
- but the nuisance-shifted row rematerialization is not yet packet-contained,
- especially on the `QCT` side where the current public delta surface remains
  attached to the adopted source state.

That is a better blocker because it is more technical and less rhetorical.

## Exact current ceiling

This note does **not** claim:

- that the matched-nuisance replay is already executed,
- that the nuisance-shifted `QCT` delta surface is already recomputable from
  packet objects alone,
- that one promotable same-convention scoring shell is already frozen,
- or that whole-family `MOND/QUMOND` fairness closure is finished.

It only claims:

- the source-policy lock is no longer vague,
- and the next exact tooth is nuisance-shifted row rematerialization.

## Best outward-safe reading

The packet may now say:

> The `NGC0247` fairness front no longer lacks an exact source-policy anchor.
> Its adopted distance and inclination windows, its table1 quality flag, and
> its visible photometric keep/reject family are now explicit. The remaining
> blocker is therefore not policy naming but lawful nuisance-shifted row
> rematerialization, especially for the current `QCT` delta surface.
