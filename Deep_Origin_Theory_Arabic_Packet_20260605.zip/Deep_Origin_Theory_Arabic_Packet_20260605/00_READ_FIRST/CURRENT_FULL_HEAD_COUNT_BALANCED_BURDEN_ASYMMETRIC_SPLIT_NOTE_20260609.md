# Current Full-Head Count-Balanced Burden-Asymmetric Split Note

Date: `2026-06-09`

Status: `packet-contained dominant-block clarification`

Purpose:

After the packet had already shown that the current full head closes as one
asymmetric two-court two-lane topology, one sharper question remained:

- is there already one single block inside that topology that dominates the
  rest of the head not only by structure but also by burden?

Yes.

Machine-readable companion:

- `CURRENT_FULL_HEAD_COUNT_BALANCED_BURDEN_ASYMMETRIC_SPLIT_V1.json`

Reproduction script:

- `REPRODUCE_CURRENT_FULL_HEAD_COUNT_BALANCED_BURDEN_ASYMMETRIC_SPLIT_V1.py`

It should be read after:

- `CURRENT_FULL_HEAD_ASYMMETRIC_TWO_COURT_TWO_LANE_TOPOLOGY_NOTE_20260609.md`

## Short verdict

The current full head may be split evenly by count into:

- one seven-case `O7`-reinforced heptad
- and one seven-case complement

But those two halves are not symmetric by burden.

The `O7`-reinforced heptad carries:

- `50%` of full-head case count
- `53.70934938115022%` of full-head public burden

The other seven cases together carry only:

- `50%` of full-head case count
- `46.29065061884979%` of full-head public burden

So one single heptad already outweighs the other seven current full-head cases
combined.

## 1. The dominant heptad

The dominant heptad is:

- `UGC09133`
- `UGC02953`
- `UGC06787`
- `UGC06786`
- `UGC02487`
- `UGC03205`
- `UGC05253`

This block is not only large.

It is also:

- already `O7`-materialized
- spread across `4` distinct internal `O7` layers
- the same block that already carries most of the Hubble-flow-sensitive
  court's burden

## 2. The seven-case complement is structurally weaker

The other seven current full-head cases are:

- the protected clean-anchor quartet:
  `NGC5055`, `NGC3198`, `NGC7331`, `NGC2841`
- plus the narrow localized quality-`1` continuation pocket:
  `NGC2903`, `NGC6674`, `NGC5033`

So the complement is not one rival reinforced block of the same type.

It is one quartet plus one narrow pocket.

## 3. Meaning

This gives the packet one especially sharp outward-safe sentence:

- the current full head is count-balanced, but not burden-balanced

That is stronger than saying only:

- the majority court is larger
- or the head is asymmetric in a loose verbal sense

Now the asymmetry is explicit at the dominant-block level.

## 4. What this does not authorize

This note does **not** authorize the claims that:

- the current head is already globally terminally settled
- the seven-case complement no longer matters
- whole-family `MOND/QUMOND` closure already exists

## Best outward-safe reading

One mature outward-safe sentence is:

> The current full head is evenly split by case count, seven versus seven, but
> not by burden. One single `O7`-reinforced heptad already carries the larger
> share of full-head public burden and outweighs the other seven cases
> combined, while those other seven do not form one rival reinforced block but
> a protected quartet plus a narrow localized pocket.
