#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"

PAIR_CONTRACT_VERDICT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_IAMP0_IGEO0_PAIR_ORDER_BEARING_CARRIER_CONTRACT_V1/04_OUTPUTS/verdict.json"
SELECTOR_VERDICT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_PAIRWISE_COEFFICIENT_CANDIDATE_OCCUPANT_SELECTOR_V1/04_OUTPUTS/verdict.json"
BINDING_VERDICT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_V1/04_OUTPUTS/verdict.json"
LIVE_BLOCKER_JSON = "artifacts/debt_board_20260530/G1_PRESENT_MATERIALS_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_MATERIALIZED_AND_NEXT_TOOTH_IS_ONE_AUTHORITY_GRADE_PAIRWISE_COEFFICIENT_FREEZE_20260612.json"
WORKSHEET_NOTE = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_QF1_IF1_FIRST_TYPED_WORKSHEET_NOTE_20260608.md"
KINETIC_FREEZE_NOTE = "artifacts/debt_board_20260530/G1_PRESENT_MATERIALS_REMAINING_BURDEN_SHARPENS_FROM_AUTHORITY_GRADE_CERTIFICATION_OF_BQ_FREE_AQ0_VARIATIONAL_KINETIC_SHELL_TO_Q_OWNED_REDUCED_ACTION_KINETIC_COEFFICIENT_FREEZE_20260612.md"


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
if WORKSPACE_ROOT is None:
    raise RuntimeError("could not locate workspace root from pairwise-freeze no-go runner")

ARTIFACT_ROOT = WORKSPACE_ROOT / "artifacts" / "debt_board_20260530"


def read_text(logical_relative_path: str) -> str:
    return (WORKSPACE_ROOT / logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def read_json(logical_relative_path: str) -> dict:
    return json.loads(read_text(logical_relative_path))


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def tf(value: bool) -> str:
    return str(value).lower()


def collect_note_checks() -> tuple[list[dict], list[str]]:
    results: list[dict] = []

    pair_contract = read_json(PAIR_CONTRACT_VERDICT)
    pair_contract_passed = (
        pair_contract.get("verdict")
        == "POST_CAGE_BRANCH_U1_IAMP0_IGEO0_PAIR_ORDER_BEARING_CARRIER_CONTRACT_MATERIALIZED"
        and pair_contract.get("binding_pair") == "(I_amp^(0), I_geo^(0))"
        and pair_contract.get("frozen_internal_order") == "I_geo^(0) > I_amp^(0)"
    )
    results.append(
        {
            "key": "pair_contract_materialized",
            "path": PAIR_CONTRACT_VERDICT,
            "meaning": "the reviewer-visible pair-order contract is already present",
            "checks": {
                "verdict": pair_contract.get("verdict"),
                "binding_pair": pair_contract.get("binding_pair"),
                "frozen_internal_order": pair_contract.get("frozen_internal_order"),
            },
            "passed": pair_contract_passed,
        }
    )

    selector = read_json(SELECTOR_VERDICT)
    selector_passed = (
        selector.get("verdict")
        == "POST_CAGE_BRANCH_U1_PAIRWISE_COEFFICIENT_CANDIDATE_OCCUPANT_SELECTOR_MATERIALIZED"
        and selector.get("selected_candidate_occupant") == "C_Q_kinetic"
    )
    results.append(
        {
            "key": "candidate_selector_materialized",
            "path": SELECTOR_VERDICT,
            "meaning": "the first lawful candidate occupant is already selected as C_Q_kinetic",
            "checks": {
                "verdict": selector.get("verdict"),
                "selected_candidate_occupant": selector.get("selected_candidate_occupant"),
            },
            "passed": selector_passed,
        }
    )

    binding = read_json(BINDING_VERDICT)
    binding_passed = (
        binding.get("verdict")
        == "POST_CAGE_BRANCH_U1_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_MATERIALIZED"
        and binding.get("bound_candidate_occupant") == "C_Q_kinetic"
        and binding.get("next_exact_tooth")
        == "authority_grade_pairwise_coefficient_freeze_for_bound_C_Q_kinetic"
    )
    results.append(
        {
            "key": "candidate_binding_materialized",
            "path": BINDING_VERDICT,
            "meaning": "the selected candidate is already bound at candidate grade and points to the freeze tooth above it",
            "checks": {
                "verdict": binding.get("verdict"),
                "bound_candidate_occupant": binding.get("bound_candidate_occupant"),
                "next_exact_tooth": binding.get("next_exact_tooth"),
            },
            "passed": binding_passed,
        }
    )

    live_blocker = read_json(LIVE_BLOCKER_JSON)
    live_blocker_passed = (
        live_blocker.get("new_blocker")
        == "one reviewer-visible authority-grade pairwise-coefficient freeze for the candidate-grade bound C_Q_kinetic occupant under the ordered shell-typed (I_amp^(0), I_geo^(0)) pair"
        and live_blocker.get("final_public_pairwise_formula_already_claimed") is False
    )
    results.append(
        {
            "key": "live_blocker_locked",
            "path": LIVE_BLOCKER_JSON,
            "meaning": "the live blocker is already frozen as one authority-grade pairwise freeze with final public pairwise formula still unclaimed",
            "checks": {
                "new_blocker": live_blocker.get("new_blocker"),
                "final_public_pairwise_formula_already_claimed": live_blocker.get(
                    "final_public_pairwise_formula_already_claimed"
                ),
            },
            "passed": live_blocker_passed,
        }
    )

    worksheet_text = read_text(WORKSHEET_NOTE)
    exact_coefficients_fragments = {
        "The exact coefficients remain open.": (
            "The exact coefficients remain open." in worksheet_text
        )
    }
    results.append(
        {
            "key": "exact_coefficients_remain_open",
            "path": WORKSHEET_NOTE,
            "meaning": "the current typed worksheet still admits that the exact coefficients remain open",
            "fragments": exact_coefficients_fragments,
            "passed": all(exact_coefficients_fragments.values()),
        }
    )

    kinetic_note_text = read_text(KINETIC_FREEZE_NOTE)
    kinetic_fragments = {
        "the single-`Q` kinetic": ("the single-`Q` kinetic" in kinetic_note_text),
        "coefficient is not yet materially frozen as a reduced action coefficient": (
            "coefficient is not yet materially frozen as a reduced action coefficient"
            in kinetic_note_text
        ),
    }
    results.append(
        {
            "key": "kinetic_coefficient_not_yet_materially_frozen",
            "path": KINETIC_FREEZE_NOTE,
            "meaning": "the reduced-action kinetic coefficient still remains below material freeze",
            "fragments": kinetic_fragments,
            "passed": all(kinetic_fragments.values()),
        }
    )

    visible_pairwise_package_siblings = sorted(
        path.name
        for path in ARTIFACT_ROOT.iterdir()
        if path.is_dir()
        and path.name != OBJECT_ROOT.name
        and ("PAIRWISE" in path.name or "CQ_KINETIC" in path.name)
    )
    expected_siblings = [
        "POST_CAGE_BRANCH_U1_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_V1",
        "POST_CAGE_BRANCH_U1_PAIRWISE_COEFFICIENT_CANDIDATE_OCCUPANT_SELECTOR_V1",
    ]
    sibling_scan_passed = visible_pairwise_package_siblings == expected_siblings
    results.append(
        {
            "key": "no_higher_grade_positive_pairwise_package_present",
            "path": "artifacts/debt_board_20260530",
            "meaning": "the repo-visible positive pairwise family still stops at selector plus candidate-grade binding",
            "visible_pairwise_package_siblings": visible_pairwise_package_siblings,
            "expected_pairwise_package_siblings": expected_siblings,
            "passed": sibling_scan_passed,
        }
    )

    return results, visible_pairwise_package_siblings


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks, visible_pairwise_package_siblings = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    verdict_name = (
        "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_CURRENT_REPO_NO_GO_MATERIALIZED"
        if all_note_checks_pass
        else "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_CURRENT_REPO_NO_GO_NOT_MATERIALIZED"
    )

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": verdict_name,
        "pair_contract_materialized": note_check_map["pair_contract_materialized"],
        "candidate_selector_materialized": note_check_map["candidate_selector_materialized"],
        "candidate_binding_materialized": note_check_map["candidate_binding_materialized"],
        "live_blocker_locked": note_check_map["live_blocker_locked"],
        "exact_coefficients_remain_open": note_check_map["exact_coefficients_remain_open"],
        "kinetic_coefficient_not_yet_materially_frozen": note_check_map[
            "kinetic_coefficient_not_yet_materially_frozen"
        ],
        "no_higher_grade_positive_pairwise_package_present": note_check_map[
            "no_higher_grade_positive_pairwise_package_present"
        ],
        "visible_pairwise_package_siblings": visible_pairwise_package_siblings,
        "authority_grade_pairwise_freeze_currently_materialized": False,
        "all_note_checks_pass": all_note_checks_pass,
    }

    verdict = {
        "verdict": verdict_name,
        "scope": "current_repo_visible_frozen_pairwise_route_only",
        "why": [
            "the pair-order contract is already materially present",
            "the first lawful candidate occupant is already selected as C_Q_kinetic",
            "that selected candidate is already bound at candidate grade",
            "the current record still says the exact coefficients remain open",
            "the current record still says the single-Q kinetic coefficient is not yet materially frozen at reduced-action grade",
            "the repo-visible positive pairwise family still stops below authority-grade freeze",
        ],
        "next_exact_move": "MATERIALIZE_ONE_REVIEWER_VISIBLE_AUTHORITY_GRADE_PAIRWISE_FREEZE_OBJECT_FOR_BOUND_C_Q_KINETIC_OR_ONE_STRONGER_LAWFUL_FREEZE_SURFACE_DISCHARGING_THE_SAME_TOOTH",
        "reopen_if": [
            "a reviewer-visible authority-grade pairwise-freeze object materializes for the bound C_Q_kinetic occupant",
            "a final public pairwise coefficient formula or stronger lawful pairwise-freeze surface appears and discharges the same tooth directly",
            "a new higher-grade positive pairwise package becomes materially visible above the present selector/binding family without hidden import",
        ],
        "ceiling": [
            "not a permanent impossibility theorem",
            "not a rejection of C_Q_kinetic as candidate-grade binding",
            "not a rejection of final pairwise law in principle",
            "not a G1 failure verdict",
        ],
    }

    source_inputs = {
        "pair_contract_verdict": PAIR_CONTRACT_VERDICT,
        "selector_verdict": SELECTOR_VERDICT,
        "binding_verdict": BINDING_VERDICT,
        "live_blocker_json": LIVE_BLOCKER_JSON,
        "worksheet_note": WORKSHEET_NOTE,
        "kinetic_freeze_note": KINETIC_FREEZE_NOTE,
        "visible_pairwise_package_siblings": visible_pairwise_package_siblings,
    }

    report_lines = [
        "# Bound `C_Q_kinetic` Authority-Grade Pairwise Freeze Current-Repo No-Go Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- pair-order contract already materialized: `{tf(status_summary['pair_contract_materialized'])}`",
        f"- candidate selector already materialized: `{tf(status_summary['candidate_selector_materialized'])}`",
        f"- candidate-grade binding already materialized: `{tf(status_summary['candidate_binding_materialized'])}`",
        f"- live blocker already frozen at authority-grade pairwise freeze: `{tf(status_summary['live_blocker_locked'])}`",
        f"- exact coefficients still remain open: `{tf(status_summary['exact_coefficients_remain_open'])}`",
        f"- kinetic coefficient still not materially frozen: `{tf(status_summary['kinetic_coefficient_not_yet_materially_frozen'])}`",
        f"- no higher-grade positive pairwise package presently visible: `{tf(status_summary['no_higher_grade_positive_pairwise_package_present'])}`",
        f"- all note checks pass: `{tf(status_summary['all_note_checks_pass'])}`",
        "",
        "## Visible Pairwise Package Siblings",
        "",
    ]

    for name in visible_pairwise_package_siblings:
        report_lines.append(f"- `{name}`")

    report_lines.extend(
        [
            "",
            "## Reading",
            "",
            "- the lower pairwise chain is now already real through candidate-grade binding,",
            "- but the current repo-visible route still does not materialize the higher-grade freeze object above that chain,",
            "- so hidden pairwise-freeze hunting on the current route is no longer the honest local move.",
            "",
            "## Ceiling",
            "",
            "- this report does not claim final pairwise law is impossible in principle,",
            "- it does not claim C_Q_kinetic was a wrong candidate,",
            "- it does not claim G1 is dead.",
            "",
        ]
    )

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    write_json(OUTPUT_ROOT / "source_inputs.json", source_inputs)
    (OUTPUT_ROOT / "BOUND_CQ_KINETIC_AUTHORITY_GRADE_PAIRWISE_FREEZE_CURRENT_REPO_NO_GO_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
