# Matched-Nuisance And Best-Dressed Comparator Protocol

Date: `2026-06-06`

This note defines how to extend the current comparator posture without
destroying its strict lane.

It answers one fairness question directly:

> how can the program compare itself seriously against `MOND/QUMOND` while
> remaining honest about nuisance handling, preprocessing culture, and rescue
> asymmetry?

## Core principle

The solution is not to abandon the austere lane.

The solution is to run multiple comparator lanes with explicit scope.

That lets the packet separate:

- raw theory pressure,
- lawful nuisance parity,
- and literature-faithful best-form adversary comparison.

## Comparator suite

### Lane A — Strict-Austere Comparator

Role:

- raw pressure lane
- silent-rescue blocker
- reviewer-auditable baseline

Properties:

- source-locked inputs
- no post-hoc row exclusion
- no hidden smoothing
- no silent geometry drift
- no theory-specific rescue knobs
- fixed comparator definition

### Lane B — Matched-Nuisance Parity Comparator

Role:

- symmetry lane
- fairness lane
- same-makeup-for-everyone lane

Rule:

Both the present theory and the comparator receive the same admissible
nuisance freedoms under one declared protocol.

Admissible parity items may include:

- the same `M/L` nuisance treatment or marginalization rule,
- the same distance uncertainty handling,
- the same inclination uncertainty handling,
- the same source-side masking/exclusion grammar,
- the same public auditable smoothing or interpolation rule if source
  documented,
- and the same information criterion and parameter-count accounting.

What remains forbidden:

- per-galaxy rescue knobs unique to one theory,
- tuning after seeing failure,
- source-unknown beautification,
- row deletion chosen after outcome inspection,
- and hidden widening of theory freedom under the label of nuisance handling.

### Lane C — Best-Dressed Adversarial Comparator

Role:

- strongest external stress lane
- literature-faithful opponent lane

Rule:

Allow the opposing framework to enter in its best publicly documented
practical form, but still under declared and auditable rules.

This may include:

- the best published nuisance handling standard for that comparator family,
- its standard source-side preprocessing culture,
- and its best lawful geometry treatment.

But it still may **not** include:

- unpublished rescue tricks,
- post-hoc galaxy-specific cosmetics,
- hidden hand edits,
- or non-auditable beautification.

## Packet-facing recommendation

The packet should say clearly:

1. the current strongest visible public result belongs to the
   `strict-austere lane`
2. that lane is scientifically legitimate and intentionally severe
3. later practical comparator symmetry should be reported through:
   - one matched-nuisance lane
   - one best-dressed adversarial lane
4. no later lane is allowed to mutate into theory rescue

## Best short outward-safe wording

> The current packet's strongest visible result against `QUMOND` belongs to a
> deliberately austere comparator lane. That lane is valuable because it
> blocks silent rescue. But the fairest completed comparison program should
> also distinguish matched-nuisance parity and literature-faithful
> best-dressed adversarial lanes, so that comparator fairness itself becomes a
> governed empirical object rather than an unspoken assumption.
