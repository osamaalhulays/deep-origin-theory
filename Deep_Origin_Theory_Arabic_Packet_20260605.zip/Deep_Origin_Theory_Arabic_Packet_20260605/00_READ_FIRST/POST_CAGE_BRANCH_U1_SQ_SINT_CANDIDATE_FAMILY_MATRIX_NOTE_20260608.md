# Post-Cage Branch U1 SQ/S_int Candidate Family Matrix Note

Date: `2026-06-08`

Purpose:

This note starts the first real constructive step for the post-cage `U1`
route.

Instead of jumping straight into one final formula,
it fixes the first admissible candidate families for:

- `S_Q`
- and `S_int`

## Short verdict

The cleanest first pairing is now:

- `S_Q`: one `Q`-bulk-exact carrier seed
- `S_int`: one source-governed interaction-ledger seed

Everything deeper should be judged against that pairing first.

## 1. Recommended `S_Q` family

The recommended first `S_Q` family is:

- one real single-carrier sector whose final bulk carrier remains exactly `Q`

This keeps the strongest Kreib-side gain:

- real `Q` prefill without importing old `v`, `Omega`, or other derived
  objects as the primitive carrier.

## 2. Recommended `S_int` family

The recommended first `S_int` family is:

- one source-governed interaction ledger between matter/geometry and `Q`

The cleanest Kreib-side seed here is the pattern:

- linear source term
- density-weighted field term
- residual slot

This is still only grammar seed,
not finished closure.

## 3. What gets rejected

Reject immediately if the candidate pairing needs:

- one second transport-bearing field
- one separate south field
- one observationally borrowed source patch
- or one lane-specific rescue device

At that point the route is no longer clean `U1`.

## Bottom line

The live build now has a real first pairing:

- `Q`-bulk-exact carrier seed
- plus source-governed interaction-ledger seed

That is the correct place to begin the next `U1` construction.
