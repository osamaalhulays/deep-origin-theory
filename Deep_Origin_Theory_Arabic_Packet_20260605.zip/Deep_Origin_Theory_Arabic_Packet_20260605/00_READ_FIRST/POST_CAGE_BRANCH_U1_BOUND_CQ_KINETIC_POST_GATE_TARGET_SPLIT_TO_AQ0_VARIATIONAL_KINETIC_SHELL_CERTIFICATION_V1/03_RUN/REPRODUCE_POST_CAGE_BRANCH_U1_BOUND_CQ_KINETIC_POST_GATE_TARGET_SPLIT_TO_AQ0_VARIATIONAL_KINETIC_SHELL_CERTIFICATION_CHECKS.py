#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"
PACKET_PREFIX = "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"

POST_GATE_SELECTOR_VERDICT_PATH = (
    "artifacts/debt_board_20260530/"
    + "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_POST_GATE_TARGET_SELECTOR_V1/04_OUTPUTS/verdict.json"
)
AQ_SHELL_VERDICT_PATH = (
    "artifacts/debt_board_20260530/"
    + "POST_CAGE_BRANCH_U1_AQ_VARIATIONAL_KINETIC_SHELL_V1/04_OUTPUTS/verdict.json"
)
POST_GATE_TARGET_NOTE_PATH = (
    PACKET_PREFIX
    + "CURRENT_G1_BOUND_CQ_KINETIC_POST_GATE_TARGET_LOCALIZES_TO_Q_OWNED_IGEO_MEDIATED_AQ_FIRST_CARRIER_LAW_FREEZE_NOTE_20260612.md"
)
SHELL_CERT_NOTE_PATH = (
    PACKET_PREFIX
    + "CURRENT_G1_REMAINING_BURDEN_SHARPENS_TO_AUTHORITY_GRADE_CERTIFICATION_OF_BQ_FREE_AQ0_VARIATIONAL_KINETIC_SHELL_NOTE_20260612.md"
)

NOTE_CHECKS = [
    {
        "key": "post_gate_selector_materialized",
        "path": POST_GATE_SELECTOR_VERDICT_PATH,
        "fragments": [
            "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_POST_GATE_TARGET_SELECTOR_MATERIALIZED",
            "\"selected_post_gate_target\": \"Q-owned I_geo-mediated A_Q-first carrier-law freeze for real T_Q ownership pivoting, with M_Q later co-carried rather than leading\"",
        ],
        "meaning": "the broader post-gate target has already been selected",
    },
    {
        "key": "aq_shell_materialized",
        "path": AQ_SHELL_VERDICT_PATH,
        "fragments": [
            "POST_CAGE_BRANCH_U1_AQ_VARIATIONAL_KINETIC_SHELL_MATERIALIZED",
            "\"positive_shell\": \"A_Q^(0)[I_geo^(0)] = B_Q-free same-carrier variational kinetic shell\"",
            "\"next_exact_tooth\": \"T_Q^(0) = same-carrier variational ledger admission\"",
        ],
        "meaning": "the exact A_Q variational kinetic shell is already reviewer-visible",
    },
    {
        "key": "post_gate_target_localized",
        "path": POST_GATE_TARGET_NOTE_PATH,
        "fragments": [
            "one lawful `Q`-owned `I_geo`-mediated `A_Q`-first carrier-law freeze",
            "with `M_Q` preserved as later co-carried rather than leading",
        ],
        "meaning": "the current post-gate target is already localized at the carrier-law level",
    },
    {
        "key": "shell_certification_sharpened",
        "path": SHELL_CERT_NOTE_PATH,
        "fragments": [
            "one reviewer-visible authority-grade certification / freeze for the already",
            "fixed `B_Q`-free `A_Q^(0)[I_geo^(0)]` variational kinetic shell itself,",
            "before later `T_Q^(0)` ledger admission and `C_closure^(0)` ascent",
        ],
        "meaning": "the remaining burden has already sharpened from the broad post-gate target to the A_Q shell certification tooth",
    },
]


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


def find_packet_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if parent.name == "00_READ_FIRST" and (parent / "START_HERE_FIRST.md").exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
SCRIPT_PACKET_ROOT = find_packet_root()
if SCRIPT_PACKET_ROOT is not None:
    PACKET_ROOT = SCRIPT_PACKET_ROOT
    RUNNING_FROM_PACKET = True
elif WORKSPACE_ROOT is not None:
    PACKET_ROOT = WORKSPACE_ROOT / "Deep_Origin_Theory_English_Packet_20260605" / "00_READ_FIRST"
    RUNNING_FROM_PACKET = False
else:
    raise RuntimeError("could not locate workspace or packet root from post-gate split runner")


def candidate_paths(logical_relative_path: str) -> list[Path]:
    candidates: list[Path] = []

    def add(path: Path) -> None:
        if path not in candidates:
            candidates.append(path)

    if RUNNING_FROM_PACKET and logical_relative_path.startswith(PACKET_PREFIX):
        add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    if WORKSPACE_ROOT is not None:
        add(WORKSPACE_ROOT / logical_relative_path)
        if logical_relative_path.startswith(PACKET_PREFIX):
            add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    return candidates


def resolve_existing_path(logical_relative_path: str) -> Path:
    for candidate in candidate_paths(logical_relative_path):
        if candidate.exists():
            return candidate
    searched = "\n".join(str(path) for path in candidate_paths(logical_relative_path))
    raise FileNotFoundError(
        f"could not resolve post-gate split surface: {logical_relative_path}\n{searched}"
    )


def read_text(logical_relative_path: str) -> str:
    return resolve_existing_path(logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": item["path"],
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    verdict_name = (
        "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_POST_GATE_TARGET_SPLIT_TO_AQ0_VARIATIONAL_KINETIC_SHELL_CERTIFICATION_MATERIALIZED"
        if all_note_checks_pass
        else "POST_CAGE_BRANCH_U1_BOUND_CQ_KINETIC_POST_GATE_TARGET_SPLIT_TO_AQ0_VARIATIONAL_KINETIC_SHELL_CERTIFICATION_NOT_MATERIALIZED"
    )

    selected_first_witness_class = (
        "reviewer-visible authority-grade certification / freeze for the already fixed "
        "B_Q-free A_Q^(0)[I_geo^(0)] variational kinetic shell itself"
        if all_note_checks_pass
        else None
    )

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": verdict_name,
        "post_gate_selector_materialized": note_check_map["post_gate_selector_materialized"],
        "aq_shell_materialized": note_check_map["aq_shell_materialized"],
        "post_gate_target_localized": note_check_map["post_gate_target_localized"],
        "shell_certification_sharpened": note_check_map["shell_certification_sharpened"],
        "all_note_checks_pass": all_note_checks_pass,
        "selected_first_missing_witness_class": selected_first_witness_class,
        "tq0_is_downstream": True,
        "full_g1_closed": False,
    }

    verdict = {
        "verdict": verdict_name,
        "selected_first_missing_witness_class": selected_first_witness_class,
        "broader_post_gate_target": "Q-owned I_geo-mediated A_Q-first carrier-law freeze for real T_Q ownership pivoting, with M_Q later co-carried rather than leading",
        "positive_shell": "A_Q^(0)[I_geo^(0)] = B_Q-free same-carrier variational kinetic shell",
        "next_downstream_tooth": "T_Q^(0) = same-carrier variational ledger admission",
        "grade": "post_gate_target_split_grade",
        "next_exact_tooth": "reviewer_visible_authority_grade_certification_or_freeze_of_BQ_free_AQ0_shell",
    }

    if all_note_checks_pass:
        reading_lines = [
            "- the broader post-gate target no longer remains one undivided future witness class,",
            "- the first missing witness class is now selected on the already fixed `B_Q`-free `A_Q^(0)[I_geo^(0)]` shell itself,",
            "- and `T_Q^(0)` remains downstream rather than the current first owner.",
        ]
    else:
        reading_lines = [
            "- the supporting route surfaces are present but do not yet pass the current post-gate split check,",
            "- so no exact first missing witness class can yet be treated as verified inside the broader post-gate target,",
            "- and the route stays below this split until the missing check surfaces are repaired or strengthened.",
        ]

    report_lines = [
        "# Post-Cage Branch U1 Bound C_Q_kinetic Post-Gate Target Split To A_Q^(0) Variational Kinetic Shell Certification Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- post-gate target selector materialized: `{status_summary['post_gate_selector_materialized']}`",
        f"- exact `A_Q^(0)` shell materialized: `{status_summary['aq_shell_materialized']}`",
        f"- broader post-gate target localized: `{status_summary['post_gate_target_localized']}`",
        f"- shell-certification sharpening present: `{status_summary['shell_certification_sharpened']}`",
        f"- all note checks pass: `{status_summary['all_note_checks_pass']}`",
        "",
        "## Reading",
        "",
        *reading_lines,
        "",
        "## Ceiling",
        "",
        "- this report does not claim a landed witness,",
        "- it does not claim final pairwise law,",
        "- it does not claim `T_Q^(0)` admission or exact transport closure,",
        "- and it does not claim full `G1/G2` completion.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    write_json(
        OUTPUT_ROOT / "source_inputs.json",
        {
            "post_gate_selector_verdict_path": POST_GATE_SELECTOR_VERDICT_PATH,
            "aq_shell_verdict_path": AQ_SHELL_VERDICT_PATH,
            "post_gate_target_note_path": POST_GATE_TARGET_NOTE_PATH,
            "shell_cert_note_path": SHELL_CERT_NOTE_PATH,
        },
    )
    (OUTPUT_ROOT / "BOUND_CQ_KINETIC_POST_GATE_TARGET_SPLIT_TO_AQ0_VARIATIONAL_KINETIC_SHELL_CERTIFICATION_REPORT.md").write_text(
        "\n".join(report_lines),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
