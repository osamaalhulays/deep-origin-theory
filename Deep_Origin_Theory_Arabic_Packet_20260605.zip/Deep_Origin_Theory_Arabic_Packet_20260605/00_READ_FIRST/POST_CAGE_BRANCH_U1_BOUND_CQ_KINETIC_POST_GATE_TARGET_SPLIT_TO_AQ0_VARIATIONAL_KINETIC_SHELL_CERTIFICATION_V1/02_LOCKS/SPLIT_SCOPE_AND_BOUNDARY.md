# Split Scope And Boundary

This object is valid only at:

- post-gate target-splitting grade

It selects:

- the first missing witness class inside the already selected post-gate
  target

It does **not** select:

- a landed witness,
- a final coefficient formula,
- final `T_Q^(0)` admission,
- `C_closure^(0)` ascent,
- exact transport closure,
- or full `G1` completion.

The selected first missing witness class must remain:

- reviewer-visible,
- authority-grade,
- on the already fixed `B_Q`-free `A_Q^(0)[I_geo^(0)]` variational kinetic
  shell,
- and strictly below later `T_Q^(0)` ledger admission and
  `C_closure^(0)` ascent.
