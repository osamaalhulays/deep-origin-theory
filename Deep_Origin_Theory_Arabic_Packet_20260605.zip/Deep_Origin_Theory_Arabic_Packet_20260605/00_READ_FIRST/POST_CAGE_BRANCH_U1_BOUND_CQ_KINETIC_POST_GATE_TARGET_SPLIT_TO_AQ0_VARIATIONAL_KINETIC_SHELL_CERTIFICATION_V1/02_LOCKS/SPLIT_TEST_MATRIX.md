# Split Test Matrix

## Positive requirements

1. the post-gate target selector is already materialized
2. the exact `A_Q^(0)[I_geo^(0)]` variational kinetic shell is already
   materialized
3. the current post-gate target is already localized to one lawful
   `Q`-owned `I_geo`-mediated `A_Q`-first carrier-law freeze
4. the remaining burden is already sharpened to authority-grade
   certification / freeze of the already fixed
   `B_Q`-free `A_Q^(0)[I_geo^(0)]`
   variational kinetic shell
5. `T_Q^(0)` remains downstream rather than the current first owner

## Reject readings

- any generic landed-witness reading of the whole post-gate target
- any first reading that starts at `T_Q^(0)` rather than `A_Q^(0)`
- any reopening of mandatory primitive `B_Q` at this first split
- any direct jump to `C_closure^(0)` or exact transport closure
