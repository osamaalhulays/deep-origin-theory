# Named Executed Matched-Nuisance Court Morphology Partition Note

Date: `2026-06-09`

Status: `packet-contained live-court partition closure`

Purpose:

After the packet had already materialized:

- the first full-body-grounded `NGC0247` route-split witness,
- the bounded `NGC6946` same-sign softening witness,
- the ten-witness Hubble-flow-sensitive body closure,
- and the cross-court full-head boundary,

one exact structural question still remained underexpressed:

- what is the current morphology of the whole named executed matched-nuisance
  court when all presently materialized witnesses are carried together?

This note closes that gap.

Machine-readable companion:

- `NAMED_EXECUTED_MATCHED_NUISANCE_COURT_MORPHOLOGY_PARTITION_V1.json`

Reproduction script:

- `REPRODUCE_NAMED_EXECUTED_MATCHED_NUISANCE_COURT_MORPHOLOGY_PARTITION_V1.py`

## Short verdict

The current named executed matched-nuisance court now splits cleanly into
three partitions:

- `NGC0247` alone = the only pro-`QCT` route-split witness
- `NGC6946` alone = the only same-sign softening witness
- the ten-witness Hubble-flow-sensitive body = one uniform same-sign
  hardening body

That ten-witness hardening body already carries:

- `10/12` named executed witnesses
- `124948.98557586373` public absolute burden out of
  `126129.45060796101`
- `92780.09909850561` component-aware absolute burden out of
  `93764.66263532615`
- `99.06408453663496%` of the current named executed public absolute burden
- `98.94996312134162%` of the current named executed component-aware
  absolute burden

So all currently named nonhardening behavior is now exhausted by the two
non-Hubble-flow shared spears:

- `NGC0247`
- `NGC6946`

## 1. The first partition: `NGC0247` remains the only named pro-`QCT` route split

`NGC0247` still returns:

- public `Delta AIC_total = -13.914066963632308`
- faithful matched-nuisance `Delta AIC_total = -15.398764714420167`
- component-aware matched-nuisance `Delta AIC_total = -39.63154845025974`

while its release-side best-dressed hardening return stays anti-`QCT`.

So `NGC0247` remains:

- the only current named executed witness whose public and live
  matched-nuisance surfaces are pro-`QCT`
- and the only named executed witness that must be carried as a route split
  rather than a same-sign continuation

## 2. The second partition: `NGC6946` remains the only same-sign softening witness

`NGC6946` still remains anti-`QCT` on public, faithful, and component-aware
surfaces,
but it softens materially under component-aware parity:

- public `Delta AIC_total = +1166.5509651336554`
- faithful matched-nuisance `Delta AIC_total = +1033.7327930524393`
- component-aware matched-nuisance `Delta AIC_total = +944.931988370284`
- component-aware shift = `-88.80080468215533`

So `NGC6946` remains:

- the only current named executed same-sign softening witness
- and the only named executed anti-`QCT` witness that moves toward `QCT`
  under component-aware parity

## 3. The third partition: the ten-witness Hubble-flow-sensitive body is uniformly same-sign hardening

The ten-witness Hubble-flow-sensitive body now carries:

- `UGC09133`
- `UGC02953`
- `UGC06787`
- `UGC06786`
- `NGC2903`
- `NGC6674`
- `NGC5033`
- `UGC02487`
- `UGC03205`
- `UGC05253`

Across that whole body:

- all ten remain anti-`QCT`
- all ten harden further away from `QCT` under component-aware parity
- combined component-aware shift = `+6521.258732574497`

So the currently materialized Hubble-flow-sensitive body is not morphologically
mixed.

It is one uniform same-sign hardening block.

## 4. Why this is a real narrowing

This means the current live court is no longer only:

- one first spear,
- one second spear,
- one third spear,
- one residual branch,
- and one whole-body block listed separately.

It now has one exact present morphology at named executed scale:

- one route-split exception,
- one same-sign softening exception,
- and one dominant ten-witness same-sign hardening body

That is stronger than either weaker reading:

- "the current executed court is still morphologically untyped"
- "the current court still behaves as one flat family"

## 5. What this does to the frontier

The next honest court question is now narrower than:

- just "find more witnesses"

It is now:

- test whether any second nonhardening behavior exists beyond `NGC0247` and
  `NGC6946`
- and extend the no-makeup court without collapsing the present three-part
  partition into one fake uniform verdict

## 6. What this does not authorize

This note does **not** authorize the claims that:

- whole-family `MOND/QUMOND` closure already exists
- the ten-witness hardening body erases the `NGC0247` route split
- the two exceptions erase the ten-witness hardening body
- the current named court already settles the whole cross-observable court

## Best outward-safe reading

One mature outward-safe sentence is:

> The current named executed matched-nuisance court is no longer
> morphologically untyped. It now splits into one pro-`QCT` route-split
> witness at `NGC0247`, one same-sign softening witness at `NGC6946`, and one
> ten-witness Hubble-flow-sensitive body that is uniformly same-sign
> hardening. So the next honest question is not whether the current court has
> any structure at all, but whether any second nonhardening behavior exists
> beyond those two present exceptions.
