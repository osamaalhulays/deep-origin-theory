# `NGC0247` Historical Phase-2 Same-Convention Control Note

Date: `2026-06-08`

Status: `bounded packet-facing control freeze`

Purpose:

This note freezes the smallest same-convention scoring shell that can be
placed above the preserved historical Phase-2 `NGC0247` row object.

Its job is not to create a celebratory parity artifact.

Its job is to stop one wrong promotion.

## Short verdict

Once the preserved historical Phase-2 lane is rescored under one explicit
same-convention `obs-only` shell for both models, it becomes **more**
anti-`QCT`, not less.

So that bounded historical lane must now be read as:

- one useful numerical control,

not as:

- the first reviewer-facing executed parity artifact.

## 1. The friendliest same-convention shell is still strongly anti-`QCT`

Using the friendliest explicit shell:

- `obs-only` likelihood for both models
- one fitted nuisance count on each side

the preserved historical Phase-2 row object yields:

- `Delta AIC = +296.89182217845337`
- `Delta BIC = +296.89182217845337`

against `QCT`.

That is already enough to close the control reading.

## 2. Extra `QCT`-side penalty only worsens the shell

If one adds one extra `QCT`-side penalty term while keeping the same
`obs-only` convention, the shell becomes:

- `Delta AIC = +298.89182217845337`

against `QCT`.

So the control does not depend on one fragile counting choice.

## 3. Why this matters

The mixed historical shell preserved in the bounded Phase-2 note was already
anti-`QCT`:

- historical mixed-shell `Delta AIC_total = +159.85953907703765`

But the friendliest same-convention shell is harsher still by:

- `+137.03228310141571`

That means the bookkeeping ambiguity is now gone.

The preserved historical Phase-2 lane is not waiting to become a good public
parity artifact after one small scoring cleanup.

It is a negative control.

## 4. Historical split at issuance, and current live consequence after `O8` retirement

At issuance, this surface helped localize one ambiguity under the old
`O6/O8` split.

Current live reading is narrower and cleaner:

- the old live `O8` replacement pressure is retired
- the preserved historical Phase-2 lane remains one fenced negative control
- and the broader live burden now sits above the first executed witness under
  `O6`, not on this control shell itself

### `O6` must not overpromote the bounded historical lane

`O6` should not emit its first reviewer-facing executed parity artifact from
this bounded historical Phase-2 shell.

The first reviewer-facing parity artifact must instead come from:

- one cleaner promotable shell above this control,
- or one different lawful matched-nuisance execution object.

## Claim ceiling

This note does **not** claim:

- whole-family `MOND/QUMOND` closure
- failure of every future matched-nuisance lane on `NGC0247`
- or that the named spear itself loses all value

It only claims:

- the preserved historical Phase-2 row object now has a frozen
  same-convention control shell,
- and that shell is strongly anti-`QCT`,
- so it must remain a control rather than a promoted outward parity artifact,
- even after the old live `O8` replacement pressure is retired.

## Best outward-safe reading

The packet may now say:

> The preserved historical Phase-2 `NGC0247` shell can be rescored under an
> explicit same-convention control, and that control is strongly anti-`QCT`.
> This sharpens bookkeeping honesty, but it also means that bounded
> historical shell should remain a control object rather than the first
> reviewer-facing matched-nuisance artifact.
