# Current `D7` `L2` `PAYLOAD_B` Admit Bounded Verdict Note

Date: `2026-06-12`

Purpose:

Freeze the exact bounded `D7` intake verdict after the first real `G6`
direct-author payload landing.

## Short verdict

The fair current reading is:

- `D7` has now really woken
- the landed payload survives channel and machine-readability checks
- same-source coherence survives
- the lawful intake verdict is `PAYLOAD_B_admit`
- `D7` is therefore closed at its bounded current scope

## Intake verification order

The landed payload survives the exact `D7` order:

1. the arrival channel is lawful:
   direct-author payload supplied to the user
2. the payload is genuinely machine-readable:
   paired `.dat` files inside two zip attachments
3. rowwise same-source coherence survives:
   the galaxy-name sets match exactly across the observed and baryonic zips
4. the required weaker component-curve class survives:
   `Vobs` + `sigma_Vobs` are direct,
   stars are direct,
   optional bulge is direct,
   and gas is supplied in one bounded split-form equivalent
   `VHI + VH2`

## Exact class freeze

The exact class freeze is:

- not `PAYLOAD_A`
- yes `PAYLOAD_B`

The reason the verdict stops at `PAYLOAD_B` is narrow:

- gas-component uncertainties are not supplied as one full uncertainty-bearing
  gas surface
- the payload is therefore not one full uncertainty-complete component pack

## Exact bounded verdict

The lawful bounded verdict is:

- `PAYLOAD_B_admit`

## Exact consequence

This verdict does **not** claim:

- `PAYLOAD_A_admit`
- `C2`
- direct promotion into theory-side authoring
- full closure

It claims something narrower:

- the weaker lawful empirical fallback has landed
- one diagnostic-only reopen may now exist above this payload
- and the stronger claim-capable branch reserved for `PAYLOAD_A` remains
  unopened

## Downstream-use boundary

This verdict also does **not** silently choose:

- one signed-square rule for negative gas-component rows
- one duplicate-radius compression rule
- one optional bulge `nan` normalization rule
- or one hidden conversion from component curves into `rho_b(r)`

Those are later downstream-use choices and must stay explicit if exercised.

## Redistribution boundary

This note records intake and verdict only.

It does **not** republish the raw direct-author payload inside the public
packet.

## Read with

- `CURRENT_G6_L2_DIRECT_AUTHOR_PAYLOAD_ARRIVED_AND_CLASSIFIED_AS_PAYLOAD_B_NOTE_20260612.md`
- `CURRENT_G6_L2_EMPIRICAL_PAYLOAD_ARRIVAL_GRAMMAR_NOTE_20260611.md`
- `CURRENT_D7_L2_POST_PAYLOAD_INTAKE_AND_BOUNDED_VERDICT_NOTE_20260611.md`
- `CURRENT_G6_D7_PAYLOAD_B_DOWNSTREAM_USE_BOUNDARY_NOTE_20260612.md`
