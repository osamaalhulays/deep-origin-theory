#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"
PACKET_PREFIX = "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"

CCLOSURE_GATE_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_EXACT_CLOSURE_TEST_FIRST_GATE_LOCALIZES_TO_SAME_CARRIER_COEFFICIENT_LAW_SUFFICIENCY_BEFORE_WIDENING_VERDICT_NOTE_20260608.md"
)
IR1_IMAGE_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_CCLOSURE_GATE_LOCALIZES_TO_SHELL_TYPED_IR1_IMAGE_SUFFICIENCY_BEFORE_EXACT_VANISHING_NOTE_20260608.md"
)
EXACT_ATTEMPT_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT_V1/01_BACKBONE/MANUSCRIPT.md"
)

NOTE_CHECKS = [
    {
        "key": "cclosure_gate",
        "path": CCLOSURE_GATE_PATH,
        "fragments": [
            "`C_closure^(0) = same-carrier coefficient-law sufficiency under the ownership map`",
            "`T_Q^(0) -> C_closure^(0) -> exact vanishing / widening verdict`",
            "The first gate inside the remaining exact-closure test is not yet:",
        ],
        "meaning": "the current route already fixes C_closure as the first honest gate above T_Q",
    },
    {
        "key": "ir1_image_sharpening",
        "path": IR1_IMAGE_PATH,
        "fragments": [
            "`C_closure^(0) = shell-typed IR1 image sufficiency test`",
            "`I_src^(IR1,0) -> A_Q^(0) -> T_Q^(0) -> C_closure^(0)[shell-typed IR1 image sufficiency] -> exact vanishing / widening verdict`",
            "It is now explicitly tied back to the same shared-source triad",
        ],
        "meaning": "the C_closure gate is already sharpened to shell-typed IR1 image sufficiency",
    },
    {
        "key": "next_tooth_exact_attempt",
        "path": EXACT_ATTEMPT_PATH,
        "fragments": [
            "`I_src^(IR1,0) -> A_Q^(0) -> T_Q^(0) -> C_closure^(0) -> V_exact^(try) -> V_U2^(only if typed trigger fires)`",
            "first one ownership-preserving exact-vanishing attempt",
            "only then one widening verdict if a typed `U2` trigger is actually forced",
        ],
        "meaning": "the next honest tooth above the sharpened closure gate is the exact-attempt shell",
    },
]


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


def find_packet_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if parent.name == "00_READ_FIRST" and (parent / "START_HERE_FIRST.md").exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
SCRIPT_PACKET_ROOT = find_packet_root()
if SCRIPT_PACKET_ROOT is not None:
    PACKET_ROOT = SCRIPT_PACKET_ROOT
    RUNNING_FROM_PACKET = True
elif WORKSPACE_ROOT is not None:
    PACKET_ROOT = WORKSPACE_ROOT / "Deep_Origin_Theory_English_Packet_20260605" / "00_READ_FIRST"
    RUNNING_FROM_PACKET = False
else:
    raise RuntimeError("could not locate workspace or packet root from C_closure gate runner")


def candidate_paths(logical_relative_path: str) -> list[Path]:
    candidates: list[Path] = []

    def add(path: Path) -> None:
        if path not in candidates:
            candidates.append(path)

    if RUNNING_FROM_PACKET and logical_relative_path.startswith(PACKET_PREFIX):
        add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    if WORKSPACE_ROOT is not None:
        add(WORKSPACE_ROOT / logical_relative_path)
        if logical_relative_path.startswith(PACKET_PREFIX):
            add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    return candidates


def resolve_existing_path(logical_relative_path: str) -> Path:
    for candidate in candidate_paths(logical_relative_path):
        if candidate.exists():
            return candidate
    searched = "\n".join(str(path) for path in candidate_paths(logical_relative_path))
    raise FileNotFoundError(
        f"could not resolve C_closure surface: {logical_relative_path}\n{searched}"
    )


def read_text(logical_relative_path: str) -> str:
    return resolve_existing_path(logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": item["path"],
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": (
            "POST_CAGE_BRANCH_U1_CCLOSURE_IR1_IMAGE_SUFFICIENCY_MATERIALIZED"
            if all_note_checks_pass
            else "POST_CAGE_BRANCH_U1_CCLOSURE_IR1_IMAGE_SUFFICIENCY_NOT_MATERIALIZED"
        ),
        "cclosure_gate_confirmed": note_check_map["cclosure_gate"],
        "ir1_image_sharpening_confirmed": note_check_map["ir1_image_sharpening"],
        "next_exact_tooth_localized_to_vexact_try": note_check_map["next_tooth_exact_attempt"],
        "exact_vanishing_already_landed": False,
        "forced_widening_already_required": False,
        "all_note_checks_pass": all_note_checks_pass,
    }

    verdict = {
        "verdict": status_summary["verdict"],
        "gate": "C_closure^(0) = shell-typed IR1 image sufficiency test",
        "next_exact_tooth": "V_exact^(try) = ownership-preserving exact-vanishing attempt",
        "live_chain": "I_src^(IR1,0) -> A_Q^(0) -> T_Q^(0) -> C_closure^(0)[shell-typed IR1 image sufficiency] -> V_exact^(try) -> V_U2^(only if typed trigger fires)",
    }

    report_lines = [
        "# Post-Cage Branch U1 C_closure IR1 Image Sufficiency Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- `C_closure^(0)` gate confirmed: `{status_summary['cclosure_gate_confirmed']}`",
        f"- shell-typed `IR1` image sharpening confirmed: `{status_summary['ir1_image_sharpening_confirmed']}`",
        f"- next exact tooth localized to `V_exact^(try)`: `{status_summary['next_exact_tooth_localized_to_vexact_try']}`",
        f"- all note checks pass: `{status_summary['all_note_checks_pass']}`",
        "",
        "## Reading",
        "",
        "- the closure-readiness gate is no longer generic coefficient wish-language,",
        "- it is now tied to shell-typed `IR1` image sufficiency,",
        "- and the next honest tooth above it is the exact-attempt shell, not direct landed success or forced widening.",
        "",
        "## Ceiling",
        "",
        "- this report does not claim exact vanishing already landed,",
        "- it does not claim widening already forced,",
        "- it does not claim full `G1/G2` completion.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    write_json(
        OUTPUT_ROOT / "source_inputs.json",
        {
            "cclosure_gate_path": CCLOSURE_GATE_PATH,
            "ir1_image_path": IR1_IMAGE_PATH,
            "exact_attempt_path": EXACT_ATTEMPT_PATH,
        },
    )
    (OUTPUT_ROOT / "CCLOSURE_IR1_IMAGE_SUFFICIENCY_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
