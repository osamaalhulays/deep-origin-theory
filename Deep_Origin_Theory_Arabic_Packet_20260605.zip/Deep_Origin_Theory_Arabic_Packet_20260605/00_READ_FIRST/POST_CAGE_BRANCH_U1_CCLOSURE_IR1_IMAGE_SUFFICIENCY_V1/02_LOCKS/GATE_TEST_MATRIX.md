# C_closure IR1 Image Sufficiency Test Matrix

Date: `2026-06-11`

Status: `bounded gate matrix`

## Positive target

The present object is materialized if the current route already supports all
of the following:

1. `C_closure^(0)` is the next honest gate above `T_Q^(0)`,
2. that gate is not generic coefficient wish-language,
3. that gate is localized to shell-typed `IR1` image sufficiency,
4. the gate remains same-carrier and ownership-preserving,
5. the next honest tooth above that gate is
   `V_exact^(try)`,
6. and widening remains downstream and trigger-bound.

## Failure signatures

The object fails if the current route instead requires any of the following:

1. direct landed exact vanishing without an attempt shell,
2. one fresh coefficient-law cloud from zero rather than the shell-typed
   `IR1` image,
3. one already-forced widening verdict before the exact-attempt shell can be
   posed honestly,
4. or one ownership-map break before the gate can stand.

## Honest next-tooth reading

If the object survives,
the honest next-tooth reading is:

- `I_src^(IR1,0) -> A_Q^(0) -> T_Q^(0) -> C_closure^(0)[shell-typed IR1 image sufficiency] -> V_exact^(try) -> V_U2^(only if typed trigger fires)`

not:

- `... -> C_closure^(0) -> exact success`

and not:

- `... -> C_closure^(0) -> forced widening`.
