# `NGC0247` Parity-Ready Pilot Object Materialization Note

Date: `2026-06-08`

Status: `packet-contained pilot-object freeze`

Purpose:

This note turns one already implied `O6` gain into one explicit packet object.

The packet had already accumulated:

- one named differential witness,
- one canonical tri-comparator grammar,
- one preserved Phase-2 case-lock lane,
- one numeric parity-readiness gate,
- and one fenced same-convention historical negative control.

What it did **not** yet carry as its own explicit object was:

- one machine-checkable `NGC0247` parity-ready pilot object that binds those
  pieces together in one reviewer-facing surface.

That missing middle object now exists.

## Short verdict

`NGC0247` is now materialized as one packet-contained parity-ready pilot
object.

This means:

- the source-side case body is present,
- the rowwise comparator body is present,
- the preserved multiseed case-level bridge is visible,
- the packet-contained readiness gate is closed,
- and the preserved historical same-convention shell is explicitly fenced as
  one negative control rather than the first scored parity artifact.

So the first reviewer-facing parity precursor is no longer missing.

What remains above it is no longer "find the object".

It is:

- freeze the replay policy,
- execute the lawful matched-nuisance replay,
- and freeze one promotable same-convention scoring shell above the fenced
  historical control.

## What is frozen together now

The pilot object is rebuilt directly from packet-contained surfaces:

1. `NGC0247_PHASE2_SOURCE_CASE_V1.json`
2. `NGC0247_PHASE2_PRED_ONE_V1.ndjson`
3. `NGC0247_CURRENT_REPLICATION_ROWS_V1.csv`
4. `NGC0247_CURRENT_ROW_COMPARATOR__QCT_AND_FIXED_QUMOND__V1.csv`
5. `REPRODUCE_NGC0247_CURRENT_STACK_V1.py`
6. `REPRODUCE_NGC0247_PHASE2_CURRENT_QCT_ROW_COMPARATOR_V1.py`
7. `NGC0247_PARITY_READINESS_GATE_V1.json`
8. `NGC0247_HISTORICAL_PHASE2_SAME_CONVENTION_CONTROL_V1.json`
9. `NGC0247_CANONICAL_TRI_COMPARATOR_AND_CLAIM_BOUNDARY_NOTE_20260606.md`
10. `NGC0247_MODEL_LOCK_CARD_V1.md`
11. `NGC0247_CURRENT_REPLICATION_CAPSULE_V1.md`
12. `CASE_LEVEL_BENCHMARK_APPENDIX__NGC0247__ARTIFACT_EMULATOR_V1.md`

The packet now also includes:

- `REPRODUCE_NGC0247_PARITY_READY_PILOT_OBJECT_V1.py`
- `NGC0247_PARITY_READY_PILOT_OBJECT_V1.json`

So the pilot object is not prose only.

It is one bounded rebuildable surface.

## Why this was the right issuance-stage `O6/O8` split, and how it reads now

At issuance, this new object sharpened one important discipline:

- `O6` owns the named lawful parity pilot object and the later executed replay,
- `O8` owns the promotable same-convention scoring shell and provenance
  cleanup above that object.

Current live reading is now narrower:

- the raw Phase-2 replacement branch is closed
- the old live `O8` replacement pressure is retired
- the historical same-convention shell remains fenced as control
- and the live burden above this object is now broader executed-court
  extension under `O6`

This prevents one bad move:

- trying to promote the preserved historical Phase-2 same-convention shell as
  the first reviewer-facing parity artifact.

The packet now has the cleaner route:

- promote the pilot object first,
- keep the historical shell fenced as control,
- and only then freeze the scorer above it.

## What was still open at issuance, and what remains live now

The issuance-stage open items were exact:

1. freeze distance replay policy
2. freeze inclination replay policy
3. freeze quality-flag aware masking rule
4. execute the lawful matched-nuisance parity replay itself
5. freeze one promotable same-convention scoring shell above the fenced
   historical control
6. recover the clean original fitted-`Y` artifact or replace it with one
   stronger clean current-production closure

The current live remainder is narrower than that old six-item list:

- the source-policy items and first executed witness are now packet-contained
- the replacement branch above the old fitted-`Y` pressure is now closed
- the surviving live burden is broader executed-court extension under the
  preserved bifurcated boundary

## Claim ceiling

This note does **not** claim:

- that the matched-nuisance replay is already executed,
- that the scoring shell is already frozen,
- that the fitted-`Y` provenance gap is already closed,
- or that whole-family `MOND/QUMOND` closure is finished.

It only claims:

- the first reviewer-facing parity precursor now exists as one explicit
  packet-contained object,
- and the wrong first promotion target has been fenced off.

## Best outward-safe reading

The packet may now say:

> `NGC0247` is no longer only a bounded witness and no longer only a
> parity-ready description in prose. It is now a packet-contained
> parity-ready pilot object with source rows, rowwise comparator surfaces,
> preserved multiseed bridge continuity, a closed numeric readiness gate, and
> an explicitly fenced historical same-convention negative control. What
> remains is the executed lawful replay and the promotable scoring shell
> above that object, not the discovery of the object itself.
