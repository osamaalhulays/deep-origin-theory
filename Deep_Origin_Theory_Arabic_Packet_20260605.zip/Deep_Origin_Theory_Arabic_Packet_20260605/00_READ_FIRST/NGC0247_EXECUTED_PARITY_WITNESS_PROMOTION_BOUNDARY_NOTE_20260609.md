# `NGC0247` Executed Parity Witness Promotion Boundary Note

Date: `2026-06-09`

Status: `packet-contained promotion-boundary freeze`

Purpose:

This note closes the next exact tooth above the already materialized
`NGC0247` parity-ready pilot object,
the source-policy lock,
the lawful matched-nuisance window replay,
and the first full-body-grounded dual execution return.

The missing sentence used to be:

- where exactly is the first reviewer-facing executed parity witness,
- and what exactly may be promoted from the packet without overclaim?

This note answers that in bounded form.

It should be read after:

- `NGC0247_PARITY_READY_PILOT_OBJECT_MATERIALIZATION_NOTE_20260608.md`
- `NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_AND_NO_RESCUE_NOTE_20260609.md`
- `NGC0247_FULL_BODY_GROUNDED_DUAL_EXECUTION_ROUTE_SPLIT_NOTE_20260609.md`

Machine-readable companion:

- `NGC0247_EXECUTED_PARITY_WITNESS_PROMOTION_BOUNDARY_V1.json`

Direct continuation now materialized in:

- `NGC0247_EXECUTED_PARITY_WITNESS_OUTWARD_SCORING_SHELL_NOTE_20260609.md`

## Short verdict

`NGC0247` no longer sits only as:

- one parity-ready pilot object,
- one policy-locked future replay target,
- or one historical control with bookkeeping cleanup.

It now carries one packet-contained executed parity witness stack.

That stack identifies the correct reviewer-facing promotion target:

- the live matched-nuisance witness under the frozen no-makeup court,

not:

- the preserved historical Phase-2 same-convention control shell.

So the remaining open tooth is no longer:

- "where is the executed witness?"

It is now:

- broader court execution beyond this first executed witness under the
  preserved bifurcated boundary.

## 1. What is now frozen together

The packet now carries, on one named witness:

1. one parity-ready pilot object
2. one explicit source-policy lock
3. one lawful visible `distance / inclination` replay with no rescue on the
   preserved Phase-2 lane
4. one first full-body-grounded `O6` matched-nuisance execution return
5. one first full-body-grounded `O7` hardening return establishing the
   route-split court reading

So the packet no longer lacks one named executed witness surface.

It already has one.

## 2. What the executed witness is

The correct promotion target is the live matched-nuisance witness,
not the historical control.

That live witness now visibly carries:

- fixed public live `Delta AIC_total = -13.914066963632308`
- faithful matched-nuisance `Delta AIC_total = -15.398764714420167`
- component-aware matched-nuisance `Delta AIC_total = -39.63154845025974`

So the live named witness remains pro-`QCT` on all three visible parity
surfaces.

At the same time,
the same named case also carries the harsher release-side route:

- `O7` hardening `Delta AIC_total = +330.508310757082`

under both declared release anchors with:

- anchor spread absolute gap = `0.0`

So the packet now identifies one honest executed witness sentence:

- `NGC0247` is a bounded live matched-nuisance pro-`QCT` witness inside one
  larger release-vs-live route-split court.

## 3. Why the historical control stays fenced below it

The preserved historical Phase-2 same-convention shell remains the wrong
promotion target.

Its friendliest explicit same-convention control still yields:

- `Delta AIC = +296.89182217845337`

against `QCT`,
and the extra-penalty variant yields:

- `Delta AIC = +298.89182217845337`

against `QCT`.

The lawful visible `distance / inclination` replay also does **not** rescue
that preserved Phase-2 lane:

- central equal-free `obs-only` replay `Delta AIC = +293.31161341697657`
- full lawful-window span < `1.0` `AIC` point
- no rescue anywhere inside the visible `±1 sigma` box

So the historical shell remains:

- one negative control,

not:

- the first reviewer-facing executed parity witness.

## 4. Exact live consequence after `O8` retirement

### `O6` now owns

- the packet-contained executed `NGC0247` live matched-nuisance witness stack
- the bounded route-split reading that keeps the live witness and the release
  witness visible simultaneously
- the claim that the reviewer-facing promotion target is no longer
  missing or misidentified
- and broader court execution beyond this first executed witness under the
  preserved bifurcated boundary

### The old live `O8` pressure no longer survives as one bank head

- the raw Phase-2 replacement branch is already closed
- the preserved historical same-convention shell remains only one fenced
  negative control
- and any later stronger provenance widening is no longer one sovereign live
  bank head

This matters because it stops two bad moves at once:

- promoting the historical control as the first outward parity artifact
- or pretending the broader-court execution is already finished

## 5. What this does not authorize

This note does **not** authorize the claims that:

- the promotable same-convention outward scoring shell is already frozen
- every imaginable later provenance polish is already complete
- `NGC0247` alone closes the whole no-makeup court
- whole-family `MOND/QUMOND` verdict work is already complete

## 6. Next honest continuation

The next honest continuation is:

- carry the court beyond this first executed witness without collapsing it
  into one-case closure under the preserved bifurcated boundary

## Best outward-safe reading

One mature outward-safe sentence is:

> `NGC0247` now has a packet-contained executed parity witness stack. The
> correct reviewer-facing promotion target is the live matched-nuisance
> witness under the frozen no-makeup court, while the preserved historical
> Phase-2 same-convention shell remains a fenced negative control. The old
> live `O8` replacement pressure is retired, and what remains open is the
> broader court beyond this first executed witness under the preserved
> bifurcated boundary.
