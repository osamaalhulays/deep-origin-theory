#!/usr/bin/env python3
import json
import math
import os
import zipfile
from pathlib import Path

A0_MS2 = 1.2e-10
GRID_POINTS = 31
OPTIONAL_EXTERNAL_ARCHIVE_DIRS = [
    Path(
        "/Users/imac/Desktop/QCT 2026/PHASE2_ARCHIVE/"
        "GATEPIPE_DEDUP_PRODTEST_FIX4_20260309_110507_FAIL_SENTINEL_20260309_080525/"
        "WORK/DEDUP_PRODTEST_FIX4_20260309_110507/sentinel/case_runs/NGC0247"
    ),
]

HERE = Path(__file__).resolve().parent
SOURCE_CASE_PATH = HERE / "NGC0247_PHASE2_SOURCE_CASE_V1.json"
PRED_ONE_PATH = HERE / "NGC0247_PHASE2_PRED_ONE_V1.ndjson"
SOURCE_SUPPORT_PATH = HERE / "NGC0247_MATCHED_NUISANCE_SOURCE_SUPPORT_V1.json"
COLD_REVIEW_MODE = os.environ.get("QCT_COLD_REVIEW", "1") != "0"
ALLOW_OPTIONAL_EXTERNAL_ARCHIVE = os.environ.get("QCT_ALLOW_OPTIONAL_EXTERNAL_ARCHIVE", "0") == "1"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_first_ndjson(path: Path):
    line = path.read_text(encoding="utf-8").splitlines()[0]
    return json.loads(line)


def linspace(start, stop, count):
    if count == 1:
        return [start]
    step = (stop - start) / (count - 1)
    return [start + index * step for index in range(count)]


def gaussian_loglike(y_obs, y_model, sigma_obs, sigma_model=None):
    total = 0.0
    for index in range(len(y_obs)):
        var_eff = sigma_obs[index] ** 2
        if sigma_model is not None:
            var_eff += sigma_model[index] ** 2
        resid = y_obs[index] - y_model[index]
        total += -0.5 * (((resid ** 2) / var_eff) + math.log(2.0 * math.pi * var_eff))
    return total


def predict_qumond(radius_m, v_bar_ms):
    g_bar = (v_bar_ms ** 2) / radius_m
    y_value = g_bar / A0_MS2
    nu_value = 0.5 + math.sqrt(0.25 + 1.0 / y_value)
    return v_bar_ms * math.sqrt(nu_value)


def optimize_positive_scalar(objective, lower=0.01, upper=3.0, coarse_points=181, refine_steps=64):
    coarse_grid = linspace(lower, upper, coarse_points)
    values = [objective(point) for point in coarse_grid]
    best_index = min(range(len(coarse_grid)), key=lambda idx: values[idx])

    left_index = max(0, best_index - 1)
    right_index = min(len(coarse_grid) - 1, best_index + 1)
    left = coarse_grid[left_index]
    right = coarse_grid[right_index]

    if left == right:
        return coarse_grid[best_index]

    phi = (1.0 + math.sqrt(5.0)) / 2.0
    inverse_phi = 1.0 / phi

    c_value = right - (right - left) * inverse_phi
    d_value = left + (right - left) * inverse_phi
    fc_value = objective(c_value)
    fd_value = objective(d_value)

    for _ in range(refine_steps):
        if fc_value <= fd_value:
            right = d_value
            d_value = c_value
            fd_value = fc_value
            c_value = right - (right - left) * inverse_phi
            fc_value = objective(c_value)
        else:
            left = c_value
            c_value = d_value
            fc_value = fd_value
            d_value = left + (right - left) * inverse_phi
            fd_value = objective(d_value)

    return c_value if fc_value <= fd_value else d_value


def inspect_optional_external_archive():
    if COLD_REVIEW_MODE and not ALLOW_OPTIONAL_EXTERNAL_ARCHIVE:
        return {
            "status": "skipped_optional_archive_not_bundled",
            "artifact_emulator_mode": "not_directly_inspected_here",
            "cold_review_mode": True,
            "skip_reason": "cold_review_default_external_archive_disabled",
        }

    for case_dir in OPTIONAL_EXTERNAL_ARCHIVE_DIRS:
        npz_path = case_dir / "emu_v2_out" / "external_model_v2.npz"
        meta_path = case_dir / "emu_v2_out" / "external_meta_v2.json"
        multiseed_path = case_dir / "multiseed_results.ndjson"
        if not (npz_path.exists() and meta_path.exists() and multiseed_path.exists()):
            continue

        with zipfile.ZipFile(npz_path) as handle:
            member_names = sorted(info.filename for info in handle.infolist())

        meta = load_json(meta_path)
        multiseed = load_first_ndjson(multiseed_path)
        has_features_hashes = "features_hashes.npy" in member_names
        has_delta_1d = "delta_1d.npy" in member_names
        has_sigma_delta_1d = "sigma_delta_1d.npy" in member_names

        if (not has_features_hashes) and has_delta_1d and has_sigma_delta_1d:
            emulator_mode = "V1_fixed_delta_surface"
        elif has_features_hashes:
            emulator_mode = "V2_features_hash_indexed_surface"
        else:
            emulator_mode = "unclassified_member_layout"

        return {
            "status": "verified_optional_archive",
            "case_dir": str(case_dir),
            "npz_path": str(npz_path),
            "meta_path": str(meta_path),
            "multiseed_path": str(multiseed_path),
            "npz_member_names": member_names,
            "meta_v2_schema_label": meta.get("v2_schema"),
            "has_features_hashes_member": has_features_hashes,
            "has_delta_1d_member": has_delta_1d,
            "has_sigma_delta_1d_member": has_sigma_delta_1d,
            "artifact_emulator_mode": emulator_mode,
            "artifact_hash_sha256": meta.get("artifact_hash_sha256"),
            "created_utc": meta.get("created_utc"),
            "multiseed_delta_aic_total": multiseed.get("delta_aic_total"),
            "multiseed_features_hash": multiseed.get("audit", {}).get("features_hash"),
        }

    return {
        "status": "skipped_optional_archive_not_bundled",
        "artifact_emulator_mode": "not_directly_inspected_here",
        "cold_review_mode": COLD_REVIEW_MODE,
    }


def transform_rows(case, support, distance_mpc, inclination_deg):
    source_geometry = support["source_geometry_metadata"]
    distance_ratio = distance_mpc / source_geometry["adopted_distance_mpc"]
    inclination_ratio = (
        math.sin(math.radians(source_geometry["adopted_inclination_deg"]))
        / math.sin(math.radians(inclination_deg))
    )
    sqrt_distance_ratio = math.sqrt(distance_ratio)

    return {
        "distance_ratio": distance_ratio,
        "inclination_ratio": inclination_ratio,
        "R_grid_m": [radius * distance_ratio for radius in case["R_grid_m"]],
        "v_bar_ms": [value * sqrt_distance_ratio for value in case["v_bar_ms"]],
        "v_obs_ms": [value * inclination_ratio for value in case["v_obs_ms"]],
        "sigma_v_ms": [value * inclination_ratio for value in case["sigma_v_ms"]],
    }


def evaluate_point(transformed, pred):
    delta_1d = pred["delta_1d"]
    sigma_delta_1d = pred["sigma_delta_1d"]

    qct_amplitude = []
    qct_sigma_amplitude = []
    for index, v_bar_ms in enumerate(transformed["v_bar_ms"]):
        delta_value = delta_1d[index]
        qct_amplitude.append(v_bar_ms * math.sqrt(1.0 + delta_value))
        qct_sigma_amplitude.append(
            v_bar_ms * (0.5 * sigma_delta_1d[index] / math.sqrt(1.0 + delta_value))
        )

    weights = [1.0 / (sigma ** 2) for sigma in transformed["sigma_v_ms"]]
    numerator = sum(
        qct_amplitude[index] * transformed["v_obs_ms"][index] * weights[index]
        for index in range(len(qct_amplitude))
    )
    denominator = sum((value ** 2) * weights[index] for index, value in enumerate(qct_amplitude))
    qct_obs_only_scale = max(0.0, numerator / denominator)
    qct_obs_only_model = [qct_obs_only_scale * value for value in qct_amplitude]
    ll_qct_obs_only = gaussian_loglike(
        transformed["v_obs_ms"],
        qct_obs_only_model,
        transformed["sigma_v_ms"],
    )

    def qct_obs_model_objective(scale):
        y_model = [scale * value for value in qct_amplitude]
        sigma_model = [scale * value for value in qct_sigma_amplitude]
        return -gaussian_loglike(
            transformed["v_obs_ms"],
            y_model,
            transformed["sigma_v_ms"],
            sigma_model=sigma_model,
        )

    qct_obs_model_scale = optimize_positive_scalar(qct_obs_model_objective)
    qct_obs_model = [qct_obs_model_scale * value for value in qct_amplitude]
    qct_sigma_model = [qct_obs_model_scale * value for value in qct_sigma_amplitude]
    ll_qct_obs_model = gaussian_loglike(
        transformed["v_obs_ms"],
        qct_obs_model,
        transformed["sigma_v_ms"],
        sigma_model=qct_sigma_model,
    )

    def qumond_objective(scale):
        y_model = [
            predict_qumond(transformed["R_grid_m"][index], scale * transformed["v_bar_ms"][index])
            for index in range(len(transformed["R_grid_m"]))
        ]
        return -gaussian_loglike(
            transformed["v_obs_ms"],
            y_model,
            transformed["sigma_v_ms"],
        )

    qumond_scale = optimize_positive_scalar(qumond_objective)
    qumond_model = [
        predict_qumond(transformed["R_grid_m"][index], qumond_scale * transformed["v_bar_ms"][index])
        for index in range(len(transformed["R_grid_m"]))
    ]
    ll_qumond_obs_only = gaussian_loglike(
        transformed["v_obs_ms"],
        qumond_model,
        transformed["sigma_v_ms"],
    )

    row_count = len(transformed["R_grid_m"])
    log_row_count = math.log(row_count)

    delta_aic_historical = (2.0 * 3 - 2.0 * ll_qct_obs_model) - (2.0 * 2 - 2.0 * ll_qumond_obs_only)
    delta_bic_historical = (3.0 * log_row_count - 2.0 * ll_qct_obs_model) - (
        2.0 * log_row_count - 2.0 * ll_qumond_obs_only
    )

    delta_aic_equal_free = (2.0 * 1 - 2.0 * ll_qct_obs_only) - (2.0 * 1 - 2.0 * ll_qumond_obs_only)
    delta_bic_equal_free = (1.0 * log_row_count - 2.0 * ll_qct_obs_only) - (
        1.0 * log_row_count - 2.0 * ll_qumond_obs_only
    )

    delta_aic_qct_extra = (2.0 * 2 - 2.0 * ll_qct_obs_only) - (2.0 * 1 - 2.0 * ll_qumond_obs_only)
    delta_bic_qct_extra = (2.0 * log_row_count - 2.0 * ll_qct_obs_only) - (
        1.0 * log_row_count - 2.0 * ll_qumond_obs_only
    )

    return {
        "upsilon_qct_obs_only": qct_obs_only_scale ** 2,
        "upsilon_qct_obs_model": qct_obs_model_scale ** 2,
        "upsilon_qumond_obs_only": qumond_scale ** 2,
        "ll_qct_obs_only": ll_qct_obs_only,
        "ll_qct_obs_model": ll_qct_obs_model,
        "ll_qumond_obs_only": ll_qumond_obs_only,
        "shells": {
            "historical_mixed": {
                "delta_aic": delta_aic_historical,
                "delta_bic": delta_bic_historical,
            },
            "equal_free_obs_only": {
                "delta_aic": delta_aic_equal_free,
                "delta_bic": delta_bic_equal_free,
            },
            "qct_extra_penalty_obs_only": {
                "delta_aic": delta_aic_qct_extra,
                "delta_bic": delta_bic_qct_extra,
            },
        },
    }


def summarize_point(distance_mpc, inclination_deg, transformed, evaluation):
    return {
        "distance_mpc": distance_mpc,
        "inclination_deg": inclination_deg,
        "distance_ratio": transformed["distance_ratio"],
        "inclination_ratio": transformed["inclination_ratio"],
        "upsilon_qct_obs_only": evaluation["upsilon_qct_obs_only"],
        "upsilon_qct_obs_model": evaluation["upsilon_qct_obs_model"],
        "upsilon_qumond_obs_only": evaluation["upsilon_qumond_obs_only"],
        "ll_qct_obs_only": evaluation["ll_qct_obs_only"],
        "ll_qct_obs_model": evaluation["ll_qct_obs_model"],
        "ll_qumond_obs_only": evaluation["ll_qumond_obs_only"],
        "shells": evaluation["shells"],
    }


def main():
    case = load_json(SOURCE_CASE_PATH)
    pred = load_first_ndjson(PRED_ONE_PATH)
    support = load_json(SOURCE_SUPPORT_PATH)
    source_geometry = support["source_geometry_metadata"]
    optional_archive = inspect_optional_external_archive()

    distance_grid = linspace(
        source_geometry["adopted_distance_range_mpc"][0],
        source_geometry["adopted_distance_range_mpc"][1],
        GRID_POINTS,
    )
    inclination_grid = linspace(
        source_geometry["adopted_inclination_range_deg"][0],
        source_geometry["adopted_inclination_range_deg"][1],
        GRID_POINTS,
    )

    central_transformed = transform_rows(
        case,
        support,
        source_geometry["adopted_distance_mpc"],
        source_geometry["adopted_inclination_deg"],
    )
    central_evaluation = evaluate_point(central_transformed, pred)
    central_summary = summarize_point(
        source_geometry["adopted_distance_mpc"],
        source_geometry["adopted_inclination_deg"],
        central_transformed,
        central_evaluation,
    )

    shell_best = {}
    shell_worst = {}
    shell_min_delta = {}
    shell_max_delta = {}

    for distance_mpc in distance_grid:
        for inclination_deg in inclination_grid:
            transformed = transform_rows(case, support, distance_mpc, inclination_deg)
            evaluation = evaluate_point(transformed, pred)
            point_summary = summarize_point(distance_mpc, inclination_deg, transformed, evaluation)

            for shell_name, shell_values in evaluation["shells"].items():
                delta_aic = shell_values["delta_aic"]
                if (shell_name not in shell_best) or (delta_aic < shell_best[shell_name]["shells"][shell_name]["delta_aic"]):
                    shell_best[shell_name] = point_summary
                if (shell_name not in shell_worst) or (delta_aic > shell_worst[shell_name]["shells"][shell_name]["delta_aic"]):
                    shell_worst[shell_name] = point_summary
                shell_min_delta[shell_name] = min(shell_min_delta.get(shell_name, delta_aic), delta_aic)
                shell_max_delta[shell_name] = max(shell_max_delta.get(shell_name, delta_aic), delta_aic)

    shell_summary = {}
    rescue_seen = False
    for shell_name in ("historical_mixed", "equal_free_obs_only", "qct_extra_penalty_obs_only"):
        best_point = shell_best[shell_name]
        worst_point = shell_worst[shell_name]
        delta_span = shell_max_delta[shell_name] - shell_min_delta[shell_name]
        rescue_seen = rescue_seen or (shell_min_delta[shell_name] <= 0.0)
        shell_summary[shell_name] = {
            "central": {
                "delta_aic": central_summary["shells"][shell_name]["delta_aic"],
                "delta_bic": central_summary["shells"][shell_name]["delta_bic"],
            },
            "best_point_for_qct": {
                "distance_mpc": best_point["distance_mpc"],
                "inclination_deg": best_point["inclination_deg"],
                "delta_aic": best_point["shells"][shell_name]["delta_aic"],
                "delta_bic": best_point["shells"][shell_name]["delta_bic"],
            },
            "worst_point_for_qct": {
                "distance_mpc": worst_point["distance_mpc"],
                "inclination_deg": worst_point["inclination_deg"],
                "delta_aic": worst_point["shells"][shell_name]["delta_aic"],
                "delta_bic": worst_point["shells"][shell_name]["delta_bic"],
            },
            "delta_aic_span_within_window": delta_span,
            "rescue_seen_within_window": shell_min_delta[shell_name] <= 0.0,
        }

    output = {
        "surface": "ngc0247_phase2_matched_nuisance_window_replay",
        "case_id": case["case_id"],
        "grid_points_per_axis": GRID_POINTS,
        "row_count": len(case["R_grid_m"]),
        "source_policy": {
            "adopted_distance_mpc": source_geometry["adopted_distance_mpc"],
            "adopted_distance_error_mpc": source_geometry["adopted_distance_error_mpc"],
            "adopted_distance_range_mpc": source_geometry["adopted_distance_range_mpc"],
            "adopted_inclination_deg": source_geometry["adopted_inclination_deg"],
            "adopted_inclination_error_deg": source_geometry["adopted_inclination_error_deg"],
            "adopted_inclination_range_deg": source_geometry["adopted_inclination_range_deg"],
        },
        "same_family_transform_law": {
            "distance_law": "R_prime = R * (D_prime / D); v_bar_prime = v_bar * sqrt(D_prime / D)",
            "inclination_law": "v_obs_prime = v_obs * sin(i) / sin(i_prime); sigma_v_prime = sigma_v * sin(i) / sin(i_prime)",
        },
        "optional_external_archive_check": optional_archive,
        "historical_delta_surface_replay_mode": (
            optional_archive["artifact_emulator_mode"]
            if optional_archive["status"] == "verified_optional_archive"
            else "packet_visible_delta_1d_replay_only"
        ),
        "central_point": central_summary,
        "shell_summary": shell_summary,
        "rescue_seen_within_1sigma_box": rescue_seen,
        "verdict": (
            "NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_CLOSED__LAWFUL_DI_BOX_DOES_NOT_RESCUE_QCT"
            if not rescue_seen
            else "NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_NOT_CLOSED"
        ),
    }

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
