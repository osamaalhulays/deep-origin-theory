from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[4]
OBJECT_ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = OBJECT_ROOT / "04_OUTPUTS"
OUTPUTS.mkdir(parents=True, exist_ok=True)


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


landing_report = read_text(
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EXACT_VANISHING_LANDING_TEST_V1/04_OUTPUTS/EXACT_VANISHING_LANDING_TEST_REPORT.md"
)
triad_report = read_text(
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_REOPENING_TRIAD_AFTER_FORMABC_NO_GO_V1/04_OUTPUTS/CURRENT_ROUTE_REOPENING_TRIAD_AFTER_FORMABC_NO_GO_REPORT.md"
)
crossing_verdict = read_json(
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_GRADE_WITNESS_DECISION_GATE_V1/04_OUTPUTS/verdict.json"
)
formd_verdict = read_json(
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_FORMD_GRADE_ENGINE_DECISION_GATE_V1/04_OUTPUTS/verdict.json"
)
u2_report = read_text(
    ROOT
    / "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_V1/04_OUTPUTS/TYPED_U2_TRIGGER_ADJUDICATION_REPORT.md"
)

checks = [
    {
        "name": "landing_still_unearned_prewidening",
        "passed": "promotable response-authority tooth crossed: `false`" in landing_report
        and "reviewer-visible Form D engine present: `false`" in landing_report
        and "hidden widening presently forced: `false`" in landing_report
        and "exact vanishing landed on current route: `false`" in landing_report,
    },
    {
        "name": "reopening_triad_still_exact",
        "passed": "lawful `Q`-owned promotable response-authority crossing" in triad_report
        and "real reviewer-visible `Form D` operator engine reopening from above" in triad_report
        and "genuinely fired typed `U2` trigger" in triad_report,
    },
    {
        "name": "crossing_gate_rejects_current_visible_candidates",
        "passed": crossing_verdict["current_route_gate_result"]
        == "reject_current_repo_visible_witnesses",
    },
    {
        "name": "formd_gate_rejects_current_visible_candidates",
        "passed": formd_verdict["current_route_gate_result"]
        == "reject_current_repo_visible_formd_candidates",
    },
    {
        "name": "u2_present_but_not_fired",
        "passed": "strong-field trigger forced now: `false`" in u2_report
        and "south-substrate trigger forced now: `false`" in u2_report
        and "ledger-honesty trigger forced now: `false`" in u2_report
        and "typed-but-not-fired on U2 triggers" in u2_report,
    },
]

materialized = all(item["passed"] for item in checks)
generated_at = datetime.now(timezone.utc).isoformat()

verdict = {
    "object": "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EVENT_LAYER_INTAKE_GATED_EXHAUSTION_AND_WATCH_ONLY_STATE_V1",
    "generated_at": generated_at,
    "materialized": materialized,
    "current_route_state": (
        "intake_gated_exhausted_watch_only_wait_only" if materialized else "state_unstable"
    ),
    "reopen_only_if": [
        "fresh crossing-grade witness survives the crossing gate",
        "fresh reviewer-visible Form D engine survives the Form D gate",
        "typed U2 trigger genuinely fires",
    ],
}

status_summary = {
    "verdict": (
        "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EVENT_LAYER_INTAKE_GATED_EXHAUSTION_AND_WATCH_ONLY_STATE_MATERIALIZED"
        if materialized
        else "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EVENT_LAYER_INTAKE_GATED_EXHAUSTION_AND_WATCH_ONLY_STATE_NOT_MATERIALIZED"
    ),
    "current_route_state": verdict["current_route_state"],
    "crossing_gate_result": crossing_verdict["current_route_gate_result"],
    "formd_gate_result": formd_verdict["current_route_gate_result"],
}

report_lines = [
    "# Post-Cage Branch U1 Current-Route Event-Layer Intake-Gated Exhaustion And Watch-Only State Report",
    "",
    f"Generated at: `{generated_at}`",
    "",
    f"Verdict: `{status_summary['verdict']}`",
    "",
    "## Summary",
    "",
    f"- landing still unearned pre-widening: `{checks[0]['passed']}`",
    f"- reopening triad still exact: `{checks[1]['passed']}`",
    f"- crossing gate result: `{crossing_verdict['current_route_gate_result']}`",
    f"- Form D gate result: `{formd_verdict['current_route_gate_result']}`",
    f"- U2 present but not fired: `{checks[4]['passed']}`",
    f"- current route state: `{verdict['current_route_state']}`",
    "",
    "## Reading",
    "",
    "- current repo-visible event classes are already adjudicated under present materials,",
    "- no local authority-work replay remains inside the same scanned event layer,",
    "- and future spend is now intake-gated watch-only / wait-only unless one fresh arrival-grade candidate appears.",
    "",
    "## Reopen only if",
    "",
    "- fresh crossing-grade witness survives the crossing gate",
    "- fresh reviewer-visible Form D engine survives the Form D gate",
    "- typed U2 trigger genuinely fires",
    "",
    "## Bottom line",
    "",
    "- the current local repo-visible event layer is now exhausted under present materials.",
]

(OUTPUTS / "checks.json").write_text(json.dumps(checks, indent=2), encoding="utf-8")
(OUTPUTS / "verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")
(OUTPUTS / "status_summary.json").write_text(json.dumps(status_summary, indent=2), encoding="utf-8")
(OUTPUTS / "CURRENT_ROUTE_EVENT_LAYER_INTAKE_GATED_EXHAUSTION_AND_WATCH_ONLY_STATE_REPORT.md").write_text(
    "\n".join(report_lines) + "\n",
    encoding="utf-8",
)
