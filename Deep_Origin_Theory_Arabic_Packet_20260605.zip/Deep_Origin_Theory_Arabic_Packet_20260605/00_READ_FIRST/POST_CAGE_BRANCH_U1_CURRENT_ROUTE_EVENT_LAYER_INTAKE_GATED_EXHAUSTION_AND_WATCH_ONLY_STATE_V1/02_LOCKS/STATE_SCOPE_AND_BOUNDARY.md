# State Scope And Boundary

- This object governs the current local repo-visible event layer only.
- It does not govern future fresh arrival-grade materials that do not yet
  exist on the scanned current route.
- It does not deny future same-route crossing, future `Form D`, or future
  fired `U2`.
- It does not close the broader theorem route or true `L0`.

## Kill conditions

This object must be refreshed if any of the following happen:

1. the crossing gate no longer reads
   `reject_current_repo_visible_witnesses`,
2. the `Form D` gate no longer reads
   `reject_current_repo_visible_formd_candidates`,
3. typed `U2` no longer reads not-fired,
4. exact landing becomes earned on the current route,
5. hidden widening becomes presently forced,
6. or one fresh arrival-grade candidate survives one of the three event gates.
