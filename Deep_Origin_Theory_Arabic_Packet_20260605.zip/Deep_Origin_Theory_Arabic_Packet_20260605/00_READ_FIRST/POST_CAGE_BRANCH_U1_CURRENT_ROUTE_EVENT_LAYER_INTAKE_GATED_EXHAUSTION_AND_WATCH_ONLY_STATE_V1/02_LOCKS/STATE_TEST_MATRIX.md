# State Test Matrix

1. exact landing test still reads:
   promotable tooth not crossed,
   reviewer-visible `Form D` absent,
   hidden widening not forced,
   exact landing not earned.
2. reopening triad remains materialized with only three exact above-line
   classes.
3. same-route crossing gate still reads:
   `reject_current_repo_visible_witnesses`.
4. `Form D` gate still reads:
   `reject_current_repo_visible_formd_candidates`.
5. typed `U2` trigger adjudication still reads:
   present but not fired.

## Pass condition

- all five checks pass.

## Failure meaning

- the current local event layer is no longer honestly exhausted under present
  materials.
