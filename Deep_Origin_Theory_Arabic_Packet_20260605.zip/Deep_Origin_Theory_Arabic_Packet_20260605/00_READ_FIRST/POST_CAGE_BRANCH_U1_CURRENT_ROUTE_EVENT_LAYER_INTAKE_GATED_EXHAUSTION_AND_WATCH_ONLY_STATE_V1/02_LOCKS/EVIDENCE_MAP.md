# Evidence Map

1. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EXACT_VANISHING_LANDING_TEST_V1/04_OUTPUTS/EXACT_VANISHING_LANDING_TEST_REPORT.md`
   - fixes exact landing not yet earned, no present `Form D`, and no hidden
     widening presently forced
2. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_REOPENING_TRIAD_AFTER_FORMABC_NO_GO_V1/04_OUTPUTS/CURRENT_ROUTE_REOPENING_TRIAD_AFTER_FORMABC_NO_GO_REPORT.md`
   - fixes the exact triad above the authority tooth
3. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_GRADE_WITNESS_DECISION_GATE_V1/04_OUTPUTS/verdict.json`
   - fixes current crossing gate result as reject on current repo-visible
     candidates
4. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_FORMD_GRADE_ENGINE_DECISION_GATE_V1/04_OUTPUTS/verdict.json`
   - fixes current `Form D` gate result as reject on current repo-visible
     candidates
5. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_V1/04_OUTPUTS/TYPED_U2_TRIGGER_ADJUDICATION_REPORT.md`
   - fixes typed `U2` triggers as present but not fired
