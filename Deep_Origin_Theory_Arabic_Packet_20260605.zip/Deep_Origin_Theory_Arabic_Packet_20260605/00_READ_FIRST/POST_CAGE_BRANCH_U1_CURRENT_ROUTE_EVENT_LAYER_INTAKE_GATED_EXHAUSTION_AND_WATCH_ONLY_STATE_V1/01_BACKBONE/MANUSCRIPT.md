# Post-Cage Branch U1 Current-Route Event-Layer Intake-Gated Exhaustion And Watch-Only State

Date: `2026-06-11`

Status: `reviewer-facing event-layer governance object`

## Purpose

This object does **not** claim:

- that true `L0` crossing already happened,
- that one same-route authority crossing already landed,
- that one real `Form D` engine already exists,
- that `U2` is already forced,
- or that the broader theorem route is complete.

It claims something narrower and operationally decisive:

1. the current repo-visible route already carries enough exact event-layer
   governance above the promotable response-authority tooth,
2. all presently visible event classes on that route are already adjudicated
   under current materials,
3. and the scanned current local event layer is therefore exhausted under
   present materials, with future spend now watch-only / wait-only unless one
   genuinely fresh arrival-grade candidate appears and survives the relevant
   intake gate.

## Short verdict

The current route is no longer best read as one open suspended event cloud.

It is now best read as one governed exhausted local event layer:

- same-route crossing candidates are already routed to
  `reject_current_repo_visible_witnesses`,
- `Form D` candidates are already routed to
  `reject_current_repo_visible_formd_candidates`,
- typed `U2` triggers are already adjudicated as present-but-not-fired,
- exact landing is already not earned,
- hidden widening is already not earned,
- and the current local repo-visible event layer is therefore exhausted under
  present materials.

So future spend inside this same scanned local event layer is now:

- intake-gated,
- watch-only / wait-only,
- and not one live authority-work replay under present materials.

## 1. Why the event layer is no longer one vague suspense cloud

The current route now already carries:

1. one landing-state test,
2. one exact reopening triad,
3. one crossing-grade witness gate,
4. one `Form D` minimum-signature + no-go + decision gate stack,
5. and one typed `U2` trigger adjudication.

That is already enough to stop reading the upper event layer as:

- "maybe a hidden crossing,"
- "maybe a hidden engine,"
- "maybe widening already forced somehow,"
- or "maybe one more local rescan will change the event class by mood."

The event classes are now governed, not merely named.

## 2. Present current-route event verdicts

Under present materials, the route already reads:

### A. Same-route crossing

- no same-route crossing-grade witness is presently materialized,
- and current repo-visible candidates already route to:
  `reject_current_repo_visible_witnesses`.

### B. `Form D`

- no reviewer-visible `Form D` engine is presently materialized,
- and current repo-visible candidates already route to:
  `reject_current_repo_visible_formd_candidates`.

### C. Typed `U2`

- typed widening trigger classes are present,
- but all three current trigger families remain not fired.

### D. Landing and widening

- exact landing is not yet earned on the current route,
- and hidden widening is not yet presently forced.

So the whole presently visible event layer is already read at bounded verdict
grade.

## 3. Why this now counts as local event-layer exhaustion

Local event-layer exhaustion here does **not** mean:

- no future event can ever happen.

It means something narrower:

- the scanned current local repo-visible event layer no longer contains one
  honest unresolved live spend inside its present materials.

The remaining openness is no longer:

- search harder inside the same visible local event layer.

It is only:

- wait for one genuinely fresh arrival-grade candidate,
- then route that candidate through the correct intake gate.

That is already stronger than saying only:

- not yet authorized.

It says:

- present local event spend is exhausted under current materials.

## 4. The future intake grammar after exhaustion

After this object, any future event candidate must enter only by one of three
gates:

1. same-route crossing gate,
2. `Form D` engine gate,
3. or fired typed `U2` trigger adjudication.

Fail-fast rejection therefore applies if the candidate is only:

- one restatement of current local route language,
- one repeated local scan of already-seen materials,
- one naming upgrade,
- one grammar-only upgrade,
- one placeholder upgrade,
- or one blended prose that launders crossing, supersession, and widening
  into one flat reopening.

## 5. Watch-only / wait-only meaning

Watch-only / wait-only does **not** mean:

- do nothing forever.

It means:

- no honest authority-work replay remains inside the same scanned local event
  layer under present materials,
- no duplicate local re-scan is first-order work,
- and future energy belongs either to genuinely fresh arrival-grade
  materialization or to another still-live goal.

That is the clean operational consequence of exhaustion.

## 6. What should reopen this state

This state should be reopened immediately if lawful later work shows:

1. one fresh same-route crossing-grade witness that survives the crossing
   gate,
2. one fresh reviewer-visible `Form D` engine that survives the `Form D`
   gate,
3. or one genuinely fired typed `U2` trigger that changes widening status.

Until one of those happens,
the present event-layer reading remains:

- intake-gated,
- exhausted under present materials,
- and watch-only / wait-only on the current local route.

## Bottom line

The current route now carries one stronger governed event-layer verdict.

Not only are crossing, `Form D`, and `U2` typed separately.

They are now collectively strong enough to support:

- one exact current local event-layer exhaustion reading,
- plus one intake-gated watch-only / wait-only state under present materials.
