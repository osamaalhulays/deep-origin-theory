#!/usr/bin/env python3
import json
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent

LANE_STATUS_BOARD_PATH = HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_STATUS_BOARD_V1.json"
COURT_CHARTER_PATH = (
    HERE / "NO_MAKEUP_MOND_QUMOND_CROSS_OBSERVABLE_COURT_DEEP_REASON_AND_EXECUTION_CHARTER_V1.json"
)
PARITY_PROMOTION_PATH = HERE / "NGC0247_EXECUTED_PARITY_WITNESS_PROMOTION_BOUNDARY_V1.json"
MATCHED_PARTITION_PATH = HERE / "NAMED_EXECUTED_MATCHED_NUISANCE_COURT_MORPHOLOGY_PARTITION_V1.json"
HUBBLE_FLOW_CLOSURE_PATH = HERE / "HUBBLE_FLOW_SENSITIVE_BODY_FULL_CLOSURE_V1.json"
O7_REINFLATION_MICROFRONT_PATH = HERE / "O7_REINFLATION_MICROFRONT_AFTER_NEAR_NEUTRAL_PERSISTENCE_V1.json"

CLUSTER_DOSSIER_ZIP_PATH = (
    HERE.parent / "03_C_Cluster" / "Deep_Origin_Theory_C_Cluster_Dossier_20260605.zip"
)
MACS1206_RUNTIME_PACKAGE_MANIFEST_PATH = (
    "Deep_Origin_Theory_C_Cluster_Dossier_20260605/"
    "MACS1206_CURRENT_VERSION_RUNTIME_PACKAGE_MANIFEST__V1.json"
)
MACS1206_STAGE2_GATE_NOTE_PATH = (
    "Deep_Origin_Theory_C_Cluster_Dossier_20260605/"
    "MACS1206_STAGE2_COMPLETE_AND_SAME_TARGET_AUTHORITY_ONLY_GATE_NOTE_20260606.md"
)
MACS1206_ROUTE_PRIORITY_NOTE_PATH = (
    "Deep_Origin_Theory_C_Cluster_Dossier_20260605/"
    "MACS1206_TERMINAL_ROUTE_PRIORITY_AND_FINISH_ORDER_NOTE_20260606.md"
)


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_json_from_zip(zip_path: Path, member: str):
    with zipfile.ZipFile(zip_path, "r") as archive:
        return json.loads(archive.read(member).decode("utf-8"))


def load_text_from_zip(zip_path: Path, member: str):
    with zipfile.ZipFile(zip_path, "r") as archive:
        return archive.read(member).decode("utf-8")


def main():
    board = load_json(LANE_STATUS_BOARD_PATH)
    charter = load_json(COURT_CHARTER_PATH)
    parity_promotion = load_json(PARITY_PROMOTION_PATH)
    matched_partition = load_json(MATCHED_PARTITION_PATH)
    hubble_flow_closure = load_json(HUBBLE_FLOW_CLOSURE_PATH)
    o7_reinflation = load_json(O7_REINFLATION_MICROFRONT_PATH)

    macs1206_manifest = load_json_from_zip(
        CLUSTER_DOSSIER_ZIP_PATH, MACS1206_RUNTIME_PACKAGE_MANIFEST_PATH
    )
    macs1206_stage2_note = load_text_from_zip(
        CLUSTER_DOSSIER_ZIP_PATH, MACS1206_STAGE2_GATE_NOTE_PATH
    )
    macs1206_route_note = load_text_from_zip(
        CLUSTER_DOSSIER_ZIP_PATH, MACS1206_ROUTE_PRIORITY_NOTE_PATH
    )

    lane_status_board = board["lane_status_board"]
    fixed_lane = lane_status_board["fixed_comparator_rotation_witness_court"]
    matched_lane = lane_status_board["matched_nuisance_parity_court"]
    best_dressed_lane = lane_status_board["best_dressed_adversarial_hardening_court"]
    north_lane = lane_status_board["same_kernel_macs1206_secondary_deltasigma_rail"]

    fixed_progression = {
        "current_state": fixed_lane["lane_status"],
        "current_state_object": (
            "174 fixed-public QUMOND crosschecks with zero public-gap drift already frozen "
            "as the reference floor"
        ),
        "next_upgrade_stage": "floor_preservation_under_cross_observable_pressure",
        "next_upgrade_object": (
            "preserve_the_fixed_public_reference_floor_unchanged_while_other_lanes_answer_it"
        ),
        "blocking_condition": (
            "this_lane_has_no_further_internal_execution_frontier_of_its_own_and_advances_only_"
            "by_remaining_frozen"
        ),
        "promotion_rule": (
            "the_lane_is_honestly_carried_only_if_the_174_case_floor_remains_unchanged_while_"
            "later_lanes_upgrade_without_comparator_cosmetics"
        ),
        "do_not_do": [
            "change_the_fixed_public_floor_to_relieve_pressure_on_later_lanes",
            "rebrand_floor_preservation_as_whole_court_execution",
            "use_comparator_cosmetics_as_theory_rescue",
        ],
    }

    matched_progression = {
        "current_state": matched_lane["lane_status"],
        "current_state_object": (
            "one executed named parity lane with NGC0247 as the only named pro-QCT route-split "
            "witness, NGC6946 as the only named same-sign softening witness, and one ten-witness "
            "same-sign hardening body"
        ),
        "next_upgrade_stage": "beyond_first_executed_witness_under_preserved_partition",
        "next_upgrade_object": parity_promotion["remaining_open_shells"][0],
        "blocking_condition": "one_case_closure_is_forbidden_under_the_preserved_bifurcated_boundary",
        "promotion_rule": (
            "broaden_the_lane_only_by_preserving_route_split_softening_and_hardening_as_distinct_"
            "named_morphologies"
        ),
        "next_frontier": matched_partition["next_honest_frontier"],
        "do_not_do": [
            "collapse_the_lane_into_ngc0247_alone",
            "erase_ngc6946_or_the_ten_witness_hardening_body_from_the_morphology",
            "silently_merge_matched_nuisance_and_best_dressed_into_one_rotation_lane",
        ],
    }

    best_dressed_progression = {
        "current_state": best_dressed_lane["lane_status"],
        "current_state_object": (
            "one fully closed ten-witness Hubble-flow-sensitive body plus one live reinflation "
            "microfront beyond mere survival"
        ),
        "next_upgrade_stage": o7_reinflation["basis"]["next_live_stage"],
        "next_upgrade_object": "execute_the_selected_d72_reinflation_opening_batch",
        "blocking_condition": "the_live_wound_is_now_reinflation_growth_not_branch_survival",
        "promotion_rule": (
            "upgrade_the_lane_by_materializing_the_selected_reinflation_batch_without_rebranding_"
            "it_as_full_court_or_whole_family_closure"
        ),
        "selected_next_batch": [
            case["case_id"] for case in o7_reinflation["reinflation_microfront"]["selected_next_batch"]
        ],
        "reserve_case_queue": [
            case["case_id"] for case in o7_reinflation["reinflation_microfront"]["reserve_cases"]
        ],
        "do_not_do": [
            "reopen_the_survival_question_that_the_near_neutral_persistence_probe_already_narrowed",
            "pretend_the_d72_batch_is_already_completed",
            "inflate_the_lane_into_whole_court_execution_or_whole_family_mond_qumond_closure",
        ],
    }

    north_progression = {
        "current_state": north_lane["lane_status"],
        "current_state_object": (
            "one same-kernel locked north rail with stage-2 complete, same-target local next move "
            "equal to none, and one explicit authority-only gate above the current lock"
        ),
        "next_upgrade_stage": "route_a_current_version_authority_carrier",
        "next_upgrade_object": (
            "absorb_one_route_a_authority_object_before_any_attempt_to_reopen_blind_same_target_"
            "numeric_farming"
        ),
        "blocking_condition": "same_target_live_blocker_is_authority_only_gate",
        "promotion_rule": (
            "take_route_a_first_then_route_b_second_if_needed_then_route_c_third_and_stop_at_one_"
            "bounded_finish_if_none_land"
        ),
        "route_progression_order": {
            "route_a": {
                "priority": "first",
                "status": "nearest_live_route",
                "finish_objects": [
                    "authoritative_multicomponent_full_completion",
                    "authoritative_BCG_fixed_setting_confirmation",
                    "source_acknowledged_current_version_complete_run_bundle",
                    "source_certified_current_version_bundle_clarification",
                ],
            },
            "route_b": {
                "priority": "second",
                "status": "real_and_source_touched_but_not_runtime_self_active",
                "finish_objects": [
                    "target_specific_joint_baryonic_covariance_carrier",
                    "equivalent_baryonic_input_file_set",
                ],
            },
            "route_c": {
                "priority": "third",
                "status": "fallback_legitimacy_route",
                "finish_objects": [
                    "external_independent_bounded_reproduction_adjudication_packet"
                ],
            },
            "if_none_land": "bounded_finish_at_highest_honest_ceiling",
        },
        "do_not_do": [
            "pretend_route_b_self_activates_inside_runtime",
            "reopen_same_target_blind_local_numeric_pursuit_as_if_stage2_were_not_complete",
            "promote_the_rail_into_authority_closed_north_ascent_before_one_route_actually_lands",
        ],
    }

    consistency_checks = {
        "board_already_freezes_the_four_lane_states": board["structural_reading"][
            "each_lane_now_has_one_explicit_packet_side_state"
        ],
        "governing_law_still_forbids_theory_rescue": charter["governing_law"][
            "theory_rescue_forbidden"
        ],
        "governing_law_still_forbids_lane_collapse": charter["governing_law"][
            "lane_collapse_forbidden"
        ],
        "governing_law_still_forbids_cross_observable_drift": charter["governing_law"][
            "cross_observable_drift_forbidden"
        ],
        "fixed_lane_still_carries_the_174_case_floor": (
            fixed_lane["rotation_fixed_public_qumond_crosscheck_count_with_zero_public_gap"] == 174
        ),
        "matched_lane_still_requires_broader_court_extension": (
            parity_promotion["remaining_open_shells"][0]
            == "carry the court beyond the first executed witness without collapsing it into one-case closure under the preserved bifurcated boundary"
            and matched_partition["next_honest_frontier"][1]
            == "extend_the_no_makeup_court_without_collapsing_the_route_split_softening_and_hardening_partitions"
        ),
        "best_dressed_lane_is_at_the_d72_reinflation_edge": (
            hubble_flow_closure["uniform_direction"][
                "hubble_flow_sensitive_body_is_now_closed_as_a_governed_block"
            ]
            and o7_reinflation["current_reading"]["o7_live_wound_is_now_reinflation_growth_question"]
            and not o7_reinflation["current_reading"]["d72_batch_already_completed"]
        ),
        "north_lane_stage2_gate_is_explicit": (
            "stage-2 same-target bounded prediction and freeze = `complete`" in macs1206_stage2_note
            and "same-target local next move = `none`" in macs1206_stage2_note
            and "same-target live blocker = `authority_only_gate`" in macs1206_stage2_note
        ),
        "north_lane_finish_order_is_explicit": (
            "Route A current-version authority carrier = `nearest_live_route`" in macs1206_route_note
            and "Route B public-cluster baryonic carrier = `real_and_source_touched_but_not_runtime_self_active`" in macs1206_route_note
            and "Route C independent replication = `fallback_legitimacy_route`" in macs1206_route_note
            and "1. `Route A first`" in macs1206_route_note
            and "2. `Route B second, source-touched, but not self-active`" in macs1206_route_note
            and "3. `Route C third`" in macs1206_route_note
            and "4. `bounded finish if none land`" in macs1206_route_note
        ),
        "north_manifest_still_refuses_false_closure": (
            macs1206_manifest["status"] == "bounded_runtime_package_candidate"
            and "final_north_ascent_closure_not_materialized"
            in macs1206_manifest["not_closed_by_this_manifest"]
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "packet_contained_reviewer_facing_cross_observable_court_lane_progression_ladder",
        "surface": "current_reviewer_facing_cross_observable_court_lane_progression_ladder",
        "ladder_sequence": [
            "fixed_comparator_rotation_witness_court",
            "matched_nuisance_parity_court",
            "best_dressed_adversarial_hardening_court",
            "same_kernel_macs1206_secondary_deltasigma_rail",
        ],
        "governing_law": charter["governing_law"],
        "lane_progression_ladder": {
            "fixed_comparator_rotation_witness_court": fixed_progression,
            "matched_nuisance_parity_court": matched_progression,
            "best_dressed_adversarial_hardening_court": best_dressed_progression,
            "same_kernel_macs1206_secondary_deltasigma_rail": north_progression,
        },
        "structural_reading": {
            "each_lane_now_has_one_explicit_honest_next_upgrade_rule": True,
            "lane_progression_is_not_uniform_across_the_four_lanes": True,
            "the_selected_court_can_now_be_read_as_one_state_board_plus_one_next_upgrade_ladder": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the selected cross-observable court now has one exact lane-by-lane progression ladder",
            "the fixed comparator lane is now visibly a preservation duty rather than a fake expansion lane",
            "the matched-nuisance lane is now visibly governed by broader extension without one-case collapse",
            "the best-dressed lane is now visibly governed by one exact D72 reinflation opening batch",
            "the MACS1206 rail is now visibly governed by one explicit route order instead of one vague north wait state",
        ],
        "not_supported_now": [
            "all four lanes upgrade by the same kind of move",
            "the matched-nuisance lane may be collapsed into NGC0247 alone",
            "the best-dressed lane is already whole-court closure",
            "the north rail is already authority-closed",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_continuation": [
            "execute_lane_specific_upgrades_without_erasing_lane_distinctions",
            "carry_the_selected_cross_observable_court_forward_only_by_lane_honest_promotions",
        ],
    }

    output["verdict"] = (
        "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_PROGRESSION_LADDER_CLOSED__EACH_LANE_NOW_HAS_ONE_EXPLICIT_HONEST_NEXT_UPGRADE_RULE_SO_THE_SELECTED_COURT_CAN_BE_READ_AS_ONE_STATE_BOARD_PLUS_ONE_GOVERNED_ASCENT_LADDER"
        if all(consistency_checks.values())
        else "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_PROGRESSION_LADDER_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
