# Post-Cage Branch U1 RR0+BS1 IR1 Step-1 South Singleton Freeze Note

Date: `2026-06-08`

Status: `first live freeze after 1-2-2 decomposition`

## Purpose

This note executes the first exact freeze move opened by the
`V_CAP1^(IR1)` decomposition note.

Once the image was compressed into:

- one south singleton
- one interaction dyad
- one carrier dyad

the first exact question became:

- can the south singleton be frozen now without reopening residual or hidden
  transport pressure

## Short verdict

Yes.

At the present live `RR0 + BS1` surface,
the first exact singleton freeze is:

`w_lin := I_mix`

with:

`w_quad := 1 - I_mix`

`w_res := 0`

So the first live south readout freezes as:

`P_S^(IR1,1)[Q] = I_mix Y_lin + (1 - I_mix) Y_quad`

with:

- `0 <= I_mix <= 1`
- `Y_res = 0`

This is the best current sovereign reading:

`The first step of the 1-2-2 program is now live-freezable: the south balance is no longer one free convex-weight pair but one bounded singleton register I_mix.`

## 1. Why this freeze is lawful now

Three earlier gains already prepared it:

1. `RR0` froze the residual face to zero first
2. `BS1` froze the south readout as one bounded convex ledger readout
3. `IR1` froze the shared-source scaffold with `I_mix` as the bounded
   source-mixture register

So the current live surface already contains everything needed for the first
singleton freeze:

- no live residual weight
- one bounded mixture slot
- one derived complement

This means the first south balance no longer needs independent free weights.

## 2. Exact frozen south form

The old current-grade south form was:

`P_S^(1,0)[Q] = w_lin Y_lin + w_quad Y_quad`

subject to:

- `w_lin >= 0`
- `w_quad >= 0`
- `w_lin + w_quad = 1`

The first exact singleton freeze replaces that pair by:

`w_lin = I_mix`

`w_quad = 1 - I_mix`

with:

- `0 <= I_mix <= 1`

So the frozen first live form is:

`P_S^(IR1,1)[Q] = I_mix Y_lin + (1 - I_mix) Y_quad`

This is a real tightening,
not just renaming.

## 3. What this removes

This freeze removes one important ambiguity.

The south side no longer carries:

- one free two-weight balance at first live grade

It now carries:

- one single bounded source-mixture register

That means the south-balance burden is no longer:

- `w_lin`
- plus `w_quad`

It is now:

- one head only

This is the first true headwise authority reduction after the structural
decomposition.

## 4. Why this is good news for `U1`

This is a strong survival gain.

If the south singleton had refused freezing,
then even the easiest head in the `1-2-2` order would have reopened:

- residual pressure
- south transport suspicion
- or hidden `U2` drift

But none of those is currently forced.

So the first freeze move lands cleanly.

That means the route has moved from:

- image topology only

to:

- one actual frozen head

## 5. Exact freeze contract

This first freeze is admissible only under the following contract:

1. `I_mix` remains source-governed
2. `I_mix` remains bounded: `0 <= I_mix <= 1`
3. `I_mix` does not borrow from observational fit, halo tuning, baryonic
   calibration, or lane-local rescue
4. `I_mix` does not reopen the fenced gas lane as public scientific authority
5. `I_mix` does not generate an independent south tensor or equation of
   motion

If any of these fail,
the freeze is not clean.

## 6. What remains unfrozen on purpose

This note does **not** yet freeze:

1. the interaction dyad `{J_lin, W_src}`
2. the carrier dyad `{A_Q, M_Q}`
3. the final internal form of `I_mix[g,ψ]`

It freezes only the first exact live identity:

- the south singleton is owned by `I_mix`

That order discipline matters.

## 7. Exact next target

After this singleton freeze,
the next exact live target is now sharper:

- attack the interaction dyad
  `{J_lin, W_src}`

as one shared-source image block above the already-frozen south singleton.

So the live freeze route becomes:

1. south singleton: frozen
2. interaction dyad: next
3. carrier dyad: later

## Bottom line

The first step of the `1-2-2` program is now no longer just planned.

It is frozen at current live grade:

`w_lin = I_mix`

`w_quad = 1 - I_mix`

`P_S^(IR1,1)[Q] = I_mix Y_lin + (1 - I_mix) Y_quad`

That is the first actual headwise freeze inside the post-cage `U1` authority
program.
