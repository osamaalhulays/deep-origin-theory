# Intermediate-Variable Dimensional Register

Date: `2026-06-06`

Status: `reviewer-facing dimensional register`

Purpose:

This note closes one small but recurring deduction route:

- the major PDE symbols were dimension-audited,
- but some intermediate working variables had not yet been gathered into one
  explicit table.

Only symbols whose present public dimensional status is already explicit on the
current reviewer-facing path are included below.

## A. Galaxy PDE and local closure variables

| Symbol | Role | Dimension / unit | Public anchor |
| --- | --- | --- | --- |
| `phi(R,z)` | galaxy-scale closure field | dimensionless | `SPEC-205_PHENOMENOLOGICAL_CLOSURE_CORRIGENDUM.md` |
| `∂_R phi`, `∂_z phi` | field gradients | `m^-1` | implied by `phi` dimensionless and spatial derivatives in `SPEC-205` |
| `∇^2 phi` | Laplacian term | `m^-2` | `SPEC-205_PHENOMENOLOGICAL_CLOSURE_CORRIGENDUM.md` |
| `rho_b(R,z)` | baryonic mass density | `kg m^-3` | `SPEC-205_PHENOMENOLOGICAL_CLOSURE_CORRIGENDUM.md` |
| `kappa = 8πG/c^2` | fixed source-coupling constant | `m kg^-1` | `SPEC-205_PHENOMENOLOGICAL_CLOSURE_CORRIGENDUM.md` |
| `kappa rho_b` | source term scale | `m^-2` | `SPEC-205_PHENOMENOLOGICAL_CLOSURE_CORRIGENDUM.md` |
| `m_inv^2` | inverse-length mass term | `m^-2` | `SPEC-205_PHENOMENOLOGICAL_CLOSURE_CORRIGENDUM.md`, `SPEC-204_TG4_ACTIONCONSISTENT.md` |
| `m_eff^2` | effective screening mass term | `m^-2` | `SPEC-205_PHENOMENOLOGICAL_CLOSURE_CORRIGENDUM.md` |
| `beta` | fixed source convention | dimensionless, frozen to `1` | `SPEC-205_PHENOMENOLOGICAL_CLOSURE_CORRIGENDUM.md` |
| `beta_alpha` | fixed screening convention | dimensionless, frozen to `1` | `SPEC-205_PHENOMENOLOGICAL_CLOSURE_CORRIGENDUM.md` |
| `Delta(r)` | rowwise response lift with `Delta(r) := -phi_compare(r)` on the locked compare path | dimensionless | `action_vs_epic_reestablishment_phi_radial_extraction_rule_lock_v1_status.json` |
| `epsilon_1au` | Solar/local deviation audit quantity | dimensionless acceptance metric | `SPEC-204_TG4_ACTIONCONSISTENT.md`, `SOLAR_LOCAL_SAFETY_PINNING_NOTE.md` |

## B. Velocity-side forward-model variables

| Symbol | Role | Dimension / unit | Public anchor |
| --- | --- | --- | --- |
| `v_bar` / `V_bar(r)` | baryonic circular-speed input | velocity, stored in `m s^-1` or `km s^-1` according to table | `NGC0247_MODEL_LOCK_CARD_V1.md`, row comparator appendices |
| `v_model` / `V_model(r)` | QCT model speed | velocity | `v_model = sqrt(Upsilon) * v_bar * sqrt(1 + Delta)` in `NGC0247_MODEL_LOCK_CARD_V1.md` |
| `sqrt(1 + Delta)` | response lift factor | dimensionless | same forward-model rule |
| `Upsilon` | fitted nuisance scaling used in the rowwise forward model | dimensionless | `NGC0247_MODEL_LOCK_CARD_V1.md`, `CURRENT_QCT_ROW_COMPARATOR_APPENDIX__NGC0247__PHASE2_RECONSTRUCTED_V1.md` |
| `v_obs` | observed speed | velocity | row comparator tables |
| `sigma_v` | observational velocity uncertainty | velocity | row comparator tables |
| `resid_QCT_current` | model-data residual | velocity | current row comparator appendix |
| `chi2_QCT_*` | chi-square terms | dimensionless | current row comparator appendix |

## C. Current predictor-surface variables

| Symbol | Role | Dimension / unit | Public anchor |
| --- | --- | --- | --- |
| `delta_1d` | preserved predictor-side response quantity | dimensionless | `NGC0247_PHASE2_CASELOCK_AND_FORWARD_MODEL_NOTE_20260605.md` |
| `sigma_delta_1d` | uncertainty on `delta_1d` | dimensionless | same source |
| `delta_1d_current` | current visible predictor-side response quantity | dimensionless | `NGC0247_MODEL_LOCK_CARD_V1.md` |
| `sigma_delta_1d_current` | current visible predictor-side uncertainty | dimensionless and positive | `NGC0247_MODEL_LOCK_CARD_V1.md` |

## D. Bridge-stage coefficient-space variables

These objects are not presented as SI observables in the current paper.
They belong to the bounded common-basis bridge layer.

| Symbol | Role | Dimension / unit | Public anchor |
| --- | --- | --- | --- |
| `H_S` | finite-volume common-basis image | coefficient-space vector on the declared 5-anchor basis | `COMMON_BASIS_VECTOR_DERIVATION_NOTE.md` |
| `H_N` | cluster-local common-basis image | coefficient-space vector on the declared 5-anchor basis | `COMMON_BASIS_VECTOR_DERIVATION_NOTE.md` |
| `Xi_hat` | normalized bridge diagnostic | dimensionless | `COMMON_BASIS_VECTOR_DERIVATION_NOTE.md` |
| `Xi_hat_min` | robustness floor for the normalized bridge diagnostic | dimensionless | `COMMON_BASIS_VECTOR_DERIVATION_NOTE.md` |
| `Xi_raw` | raw bridge overlap scalar on the declared basis | basis-scalar published as a pure numeric quantity on the current normalized route | `COMMON_BASIS_VECTOR_DERIVATION_NOTE.md` |

## E. White-law carrier and lifted-source variables

| Symbol | Role | Dimension / unit | Public anchor |
| --- | --- | --- | --- |
| `S(R) = (I - Pi_r)[M](R)` | morphology-survival numerator | inherits the same carrier dimension as `N(R)` on the admitted white-law route | `DOWNSTREAM_ANALYTIC_GUARD_EXPANSION_NOTE_20260606.md` |
| `N(R) = N_r[M](R)` | positive local normalization for the white guard | same inherited carrier dimension as `S(R)` | `DOWNSTREAM_ANALYTIC_GUARD_EXPANSION_NOTE_20260606.md` |
| `u(R) = S(R)/N(R)` | internal white-law ratio | dimensionless | `DOWNSTREAM_ANALYTIC_GUARD_EXPANSION_NOTE_20260606.md` |
| `G_morph^(<r-fixed>)(R)` | bounded morphology-survival guard | dimensionless | `DOWNSTREAM_ANALYTIC_GUARD_EXPANSION_NOTE_20260606.md`, `FIXED_R_MORPHOLOGY_SURVIVAL_WHITE_LAW_FORMALIZATION_V1.md` |
| `gamma_*` / `gamma_0` | white-arm amplitude multiplying the bounded guard into a potential surface | gravitational-potential unit, `m^2 s^-2` | `THE_FIXED_R_MORPHOLOGY_SURVIVAL_WHITE_POTENTIAL.md`, `DOWNSTREAM_ANALYTIC_GUARD_EXPANSION_NOTE_20260606.md` |
| `Phi_white(R)` / `Phi_FMR(R)` | compact radial white potential | gravitational potential, `m^2 s^-2` | same white-law sources |
| `Xi(R,phi,z)` | lifted conservative completion factor with `Xi(R,phi,0)=1` on the public route | dimensionless | `THE_FIXED_R_MORPHOLOGY_SURVIVAL_WHITE_POTENTIAL.md`, `DOWNSTREAM_ANALYTIC_GUARD_EXPANSION_NOTE_20260606.md` |
| `rho_eff_white` / `rho_eff_FMR` | Einstein-side effective-source representation of the lifted white potential | `kg m^-3` | same white-law sources |
| `G_review` | review-stage gravitational constant used in the effective-source representation | `m^3 kg^-1 s^-2` | `THE_FIXED_R_MORPHOLOGY_SURVIVAL_WHITE_POTENTIAL.md`, `DOWNSTREAM_ANALYTIC_GUARD_EXPANSION_NOTE_20260606.md` |

## F. Source-operator normalization caveat

The current public bridge package intentionally compresses the longer canonical
source expression

- `O_phi = -(alpha_star/M_P) T_m^ren`

into the shorter public statement

- `O_phi = T_m^ren`

for the bridge-stage common-parent declaration.

At the current stage, this is an operator-level source declaration, not one
finished external normalization theorem for every later cosmology lane.

So the clean reading is:

- the operator relation is explicit,
- its role is physically meaningful already,
- but the final external normalization theorem remains later-stage work.

## What this closes

This register is enough to block the lighter deduction:

- "the packet only dimension-audits the headline PDE but leaves the working
  intermediate variables implicit."

The remaining fair deduction, if any, should now be:

- one later source-instantiated closure above the now-public downstream
  analytic guard expansion,

not:

- one blurry dimensional stack.
