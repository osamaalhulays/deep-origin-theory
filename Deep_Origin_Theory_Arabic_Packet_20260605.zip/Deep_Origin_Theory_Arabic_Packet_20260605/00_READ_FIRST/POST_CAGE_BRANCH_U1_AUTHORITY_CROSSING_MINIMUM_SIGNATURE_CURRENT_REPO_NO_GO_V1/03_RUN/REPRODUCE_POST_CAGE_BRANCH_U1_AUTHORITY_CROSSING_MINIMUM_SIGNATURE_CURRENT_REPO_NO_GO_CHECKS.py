#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"

SIGNATURE_REPORT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_MINIMUM_SIGNATURE_V1/04_OUTPUTS/AUTHORITY_CROSSING_MINIMUM_SIGNATURE_REPORT.md"
FORM_A_VERDICT = "artifacts/debt_board_20260530/L2_FORM_A_CURRENT_REPO_NO_GO_V1/04_OUTPUTS/verdict.json"
FORM_C_VERDICT = "artifacts/debt_board_20260530/L2_FORM_C_CURRENT_REPO_NO_GO_V1/04_OUTPUTS/verdict.json"
AUTHORITY_FAILURE_REPORT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_V1/04_OUTPUTS/PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_REPORT.md"
DISCRIMINATOR_REPORT = "artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_V1/04_OUTPUTS/AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_REPORT.md"

NOTE_CHECKS = [
    {
        "key": "signature_materialized",
        "path": SIGNATURE_REPORT,
        "fragments": [
            "Verdict: `POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_MINIMUM_SIGNATURE_MATERIALIZED`",
            "- the same carrier `Q` must own the jump to promotable authority,",
            "- and the event must remain same-route and non-`Form D` to count as authority crossing.",
        ],
        "meaning": "the minimum crossing signature is already frozen",
    },
    {
        "key": "form_a_no_direct_authority_pack",
        "path": FORM_A_VERDICT,
        "fragments": [
            "\"no populated direct Delta/Xi authority pack is currently visible\"",
        ],
        "meaning": "no populated direct authority pack is currently visible",
    },
    {
        "key": "form_c_no_callable_or_bundle",
        "path": FORM_C_VERDICT,
        "fragments": [
            "\"repo-wide code-bearing scan finds no callable Delta_QCT_L2/Xi_QCT_L2 evaluator surface\"",
            "\"no evaluator-grade bundle directory is presently visible\"",
        ],
        "meaning": "no callable evaluator family or evaluator-grade emitted bundle is currently visible",
    },
    {
        "key": "authority_surface_absent",
        "path": AUTHORITY_FAILURE_REPORT,
        "fragments": [
            "- but the same route still lacks one Q-owned promotable authority surface,",
            "- and no reviewer-visible form-d reopening is presently materialized,",
        ],
        "meaning": "no Q-owned promotable authority surface is currently visible on the route",
    },
    {
        "key": "crossing_must_remain_non_formd",
        "path": DISCRIMINATOR_REPORT,
        "fragments": [
            "- authority crossing is one landing-class same-route event,",
            "- `Form D` is one engine-grade supersession-class event from above,",
            "- do not treat `Form D` arrival as silent proof that the current route crossed its own authority tooth,",
        ],
        "meaning": "same-route crossing remains non-Form D by current route discipline",
    },
]


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
if WORKSPACE_ROOT is None:
    raise RuntimeError("could not locate workspace root from crossing-signature no-go runner")


def read_text(logical_relative_path: str) -> str:
    return (WORKSPACE_ROOT / logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": item["path"],
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def tf(value: bool) -> str:
    return str(value).lower()


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": (
            "POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_MINIMUM_SIGNATURE_CURRENT_REPO_NO_GO_MATERIALIZED"
            if all_note_checks_pass
            else "POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_MINIMUM_SIGNATURE_CURRENT_REPO_NO_GO_NOT_MATERIALIZED"
        ),
        "signature_materialized": note_check_map["signature_materialized"],
        "form_a_no_direct_authority_pack": note_check_map["form_a_no_direct_authority_pack"],
        "form_c_no_callable_or_bundle": note_check_map["form_c_no_callable_or_bundle"],
        "authority_surface_absent": note_check_map["authority_surface_absent"],
        "crossing_must_remain_non_formd": note_check_map["crossing_must_remain_non_formd"],
        "same_route_authority_crossing_landed": False,
        "all_note_checks_pass": all_note_checks_pass,
    }

    verdict = {
        "verdict": status_summary["verdict"],
        "scope": "current_repo_visible_frozen_route_only",
        "why": [
            "the minimum same-route crossing signature is already frozen",
            "no populated direct authority pack is currently visible",
            "no callable evaluator family or evaluator-grade emitted bundle is currently visible",
            "no Q-owned promotable authority surface is currently visible on the route",
            "same-route crossing must still remain non-Form D",
        ],
        "next_exact_move": "MATERIALIZE_ONE_REAL_SAME_ROUTE_CROSSING_GRADE_WITNESS_OR_ELSE_BE_SUPERSEDED_BY_FORMD_OR_FIRED_U2",
        "reopen_if": [
            "a Q-owned promotable evaluator/value authority surface becomes materially visible above the bounded probe on the same route",
            "a callable evaluator family plus one evaluator-owned emitted value/prediction surface becomes visible without hidden widening",
            "a new reviewer-visible same-route crossing-grade package directly satisfies the frozen minimum signature",
        ],
        "supersede_if": [
            "a real reviewer-visible Form D engine appears first",
            "a typed U2 trigger fires first",
        ],
        "ceiling": [
            "not a permanent impossibility theorem",
            "not a rejection of Form D in principle",
            "not an immediate U2-forcing verdict",
            "not a full-program failure verdict",
        ],
    }

    report_lines = [
        "# Authority Crossing Minimum Signature Current-Repo No-Go Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- minimum crossing signature already frozen: `{tf(status_summary['signature_materialized'])}`",
        f"- no direct authority pack currently visible: `{tf(status_summary['form_a_no_direct_authority_pack'])}`",
        f"- no callable evaluator family / emitted bundle currently visible: `{tf(status_summary['form_c_no_callable_or_bundle'])}`",
        f"- no `Q`-owned promotable authority surface currently visible: `{tf(status_summary['authority_surface_absent'])}`",
        f"- same-route crossing still remains non-`Form D`: `{tf(status_summary['crossing_must_remain_non_formd'])}`",
        f"- all note checks pass: `{tf(status_summary['all_note_checks_pass'])}`",
        "",
        "## Reading",
        "",
        "- the minimum crossing signature is now exact enough to be judged directly,",
        "- but the current repo-visible route still does not materialize a witness-grade surface satisfying it,",
        "- so hidden crossing-witness hunting on the current route is no longer the honest local move.",
        "",
        "## Ceiling",
        "",
        "- this report does not claim same-route crossing is impossible in principle,",
        "- it does not claim `Form D` is impossible in principle,",
        "- it does not claim `U2` is already forced.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    (OUTPUT_ROOT / "AUTHORITY_CROSSING_MINIMUM_SIGNATURE_CURRENT_REPO_NO_GO_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
