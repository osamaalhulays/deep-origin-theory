#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

CLEAN_ANCHOR_SPLIT_PATH = HERE / "CLEAN_ANCHOR_MINORITY_CROSS_LANE_DISPERSION_V1.json"
CROSS_COURT_PATH = HERE / "CLEAN_ANCHOR_MINORITY_VS_FULLY_CLOSED_HUBBLE_FLOW_SENSITIVE_BODY_CROSS_COURT_SYNTHESIS_V1.json"
HUBBLE_O7_CONVERGENCE_PATH = HERE / "HUBBLE_FLOW_SENSITIVE_BODY_LAYERED_O7_CONVERGENCE_V1.json"
HUBBLE_REMAINDER_PATH = HERE / "HUBBLE_FLOW_SENSITIVE_BODY_CURRENT_O7_REMAINDER_LOCALIZATION_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def close_enough(left, right, tolerance=1e-9):
    return abs(left - right) <= tolerance


def main():
    clean_anchor_split = load_json(CLEAN_ANCHOR_SPLIT_PATH)
    cross_court = load_json(CROSS_COURT_PATH)
    hubble_convergence = load_json(HUBBLE_O7_CONVERGENCE_PATH)
    hubble_remainder = load_json(HUBBLE_REMAINDER_PATH)

    clean_anchor_court = cross_court["clean_anchor_minority_court"]
    hubble_court = cross_court["fully_closed_hubble_flow_sensitive_body_court"]

    clean_anchor_singleton = clean_anchor_split["cross_program_repeated_toward_qct_subset"]
    clean_anchor_o7_triad = clean_anchor_split["o7_positive_spoiler_layer_subset"]
    hubble_o7_heptad = hubble_convergence["o7_positive_spoiler_intersection"]
    hubble_pocket = hubble_remainder["current_o7_nonintersecting_remainder"]

    full_head_case_count = clean_anchor_court["case_count"] + hubble_court["case_count"]
    full_head_public_delta_aic_total = (
        clean_anchor_court["delta_aic_sum"] + hubble_court["public_delta_aic_total_sum"]
    )

    o7_positive_full_head_cases = sorted(
        set(clean_anchor_o7_triad["cases"]) | set(hubble_o7_heptad["cases"])
    )
    non_o7_full_head_cases = sorted(
        set(clean_anchor_singleton["cases"]) | set(hubble_pocket["cases"])
    )

    o7_positive_full_head_case_to_layer = {
        **clean_anchor_o7_triad["case_to_layer"],
        **hubble_o7_heptad["case_to_o7_layer"],
    }

    consistency_checks = {
        "clean_anchor_split_exhausts_clean_anchor_court": (
            set(clean_anchor_singleton["cases"]) | set(clean_anchor_o7_triad["cases"])
        )
        == set(clean_anchor_court["cases"]),
        "clean_anchor_split_is_disjoint": set(clean_anchor_singleton["cases"]).isdisjoint(
            set(clean_anchor_o7_triad["cases"])
        ),
        "hubble_split_exhausts_hubble_court": (
            set(hubble_o7_heptad["cases"]) | set(hubble_pocket["cases"])
        )
        == set(hubble_convergence["full_hubble_flow_sensitive_body"]["cases"]),
        "hubble_split_is_disjoint": set(hubble_o7_heptad["cases"]).isdisjoint(
            set(hubble_pocket["cases"])
        ),
        "full_head_case_count_is_fourteen": full_head_case_count == 14,
        "four_lane_blocks_exhaust_the_full_head": (
            set(clean_anchor_singleton["cases"])
            | set(clean_anchor_o7_triad["cases"])
            | set(hubble_o7_heptad["cases"])
            | set(hubble_pocket["cases"])
        )
        == (set(clean_anchor_court["cases"]) | set(hubble_convergence["full_hubble_flow_sensitive_body"]["cases"])),
        "four_lane_blocks_are_pairwise_disjoint_by_construction": len(
            set(clean_anchor_singleton["cases"])
            | set(clean_anchor_o7_triad["cases"])
            | set(hubble_o7_heptad["cases"])
            | set(hubble_pocket["cases"])
        )
        == full_head_case_count,
        "court_public_totals_recombine_to_full_head_public_total": close_enough(
            clean_anchor_court["delta_aic_sum"] + hubble_court["public_delta_aic_total_sum"],
            full_head_public_delta_aic_total,
        ),
        "hubble_heptad_and_pocket_recombine_to_hubble_public_total": close_enough(
            hubble_o7_heptad["public_delta_aic_total"] + hubble_pocket["public_delta_aic_total"],
            hubble_court["public_delta_aic_total_sum"],
        ),
        "full_head_o7_positive_case_count_is_ten": len(o7_positive_full_head_cases) == 10,
        "full_head_non_o7_case_count_is_four": len(non_o7_full_head_cases) == 4,
        "full_head_o7_positive_and_non_o7_sets_are_disjoint": set(o7_positive_full_head_cases).isdisjoint(
            set(non_o7_full_head_cases)
        ),
        "full_head_o7_positive_and_non_o7_sets_exhaust_full_head": (
            set(o7_positive_full_head_cases) | set(non_o7_full_head_cases)
        )
        == (set(clean_anchor_court["cases"]) | set(hubble_convergence["full_hubble_flow_sensitive_body"]["cases"])),
        "full_head_o7_positive_layers_collapse_to_four_distinct_layers": len(
            set(o7_positive_full_head_case_to_layer.values())
        )
        == 4,
        "hubble_pocket_remains_all_quality1_exact_qumond_protected": (
            hubble_remainder["localization_structure"]["all_cases_are_quality1"]
            and hubble_remainder["localization_structure"]["all_cases_have_exact_qumond_protection"]
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "bounded_packet_facing_full_head_topology_synthesis",
        "surface": "current_full_head_asymmetric_two_court_two_lane_topology",
        "full_head": {
            "case_count": full_head_case_count,
            "public_delta_aic_total": full_head_public_delta_aic_total,
        },
        "court_a_protected_clean_anchor_minority": {
            "case_count": clean_anchor_court["case_count"],
            "cases": clean_anchor_court["cases"],
            "public_delta_aic_total": clean_anchor_court["delta_aic_sum"],
            "fraction_of_full_head_public_delta_aic_total": clean_anchor_court[
                "fraction_of_giant_spiral_head_burden"
            ],
            "internal_lane_split": {
                "repeated_toward_qct_singleton": {
                    **clean_anchor_singleton,
                    "fraction_of_full_head_case_count": clean_anchor_singleton["case_count"]
                    / full_head_case_count,
                },
                "o7_positive_spoiler_dispersion_triad": {
                    **clean_anchor_o7_triad,
                    "fraction_of_full_head_case_count": clean_anchor_o7_triad["case_count"]
                    / full_head_case_count,
                },
            },
        },
        "court_b_hubble_flow_sensitive_body": {
            "case_count": hubble_court["case_count"],
            "cases": hubble_convergence["full_hubble_flow_sensitive_body"]["cases"],
            "public_delta_aic_total": hubble_court["public_delta_aic_total_sum"],
            "fraction_of_full_head_public_delta_aic_total": hubble_court[
                "fraction_of_giant_spiral_head_burden"
            ],
            "internal_lane_split": {
                "o7_reinforced_heptad": {
                    **hubble_o7_heptad,
                    "fraction_of_full_head_case_count": hubble_o7_heptad["case_count"]
                    / full_head_case_count,
                    "fraction_of_full_head_public_delta_aic_total": hubble_o7_heptad[
                        "public_delta_aic_total"
                    ]
                    / full_head_public_delta_aic_total,
                },
                "current_nonoverlap_quality1_continuation_pocket": {
                    **hubble_pocket,
                    "fraction_of_full_head_case_count": hubble_pocket["case_count"]
                    / full_head_case_count,
                    "fraction_of_full_head_public_delta_aic_total": hubble_pocket[
                        "public_delta_aic_total"
                    ]
                    / full_head_public_delta_aic_total,
                    "all_cases_are_quality1": hubble_remainder["localization_structure"][
                        "all_cases_are_quality1"
                    ],
                    "all_cases_have_exact_qumond_protection": hubble_remainder[
                        "localization_structure"
                    ]["all_cases_have_exact_qumond_protection"],
                },
            },
        },
        "full_head_lane_union": {
            "o7_positive_materialized_union": {
                "case_count": len(o7_positive_full_head_cases),
                "cases": o7_positive_full_head_cases,
                "fraction_of_full_head_case_count": len(o7_positive_full_head_cases)
                / full_head_case_count,
                "distinct_o7_layer_count": len(set(o7_positive_full_head_case_to_layer.values())),
                "case_to_o7_layer": dict(sorted(o7_positive_full_head_case_to_layer.items())),
            },
            "non_o7_union": {
                "case_count": len(non_o7_full_head_cases),
                "cases": non_o7_full_head_cases,
                "fraction_of_full_head_case_count": len(non_o7_full_head_cases)
                / full_head_case_count,
                "internal_split": {
                    "repeated_toward_qct_singleton": clean_anchor_singleton["cases"],
                    "localized_quality1_continuation_pocket": hubble_pocket["cases"],
                },
            },
        },
        "structural_reading": {
            "the_current_full_head_is_not_only_bifurcated_by_court_but_asymmetric_by_lane_behavior": True,
            "the_clean_anchor_minority_survives_but_disperses_across_lanes": True,
            "the_hubble_flow_sensitive_majority_dominates_and_is_cross_lane_reinforced": True,
            "the_non_o7_remainder_is_not_a_second_large_rival_block_but_one_singleton_plus_one_narrow_three_witness_pocket": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the current full head already closes as one asymmetric two-court two-lane topology rather than one random pile",
            "ten of fourteen current full-head cases already materialize inside four distinct O7 positive-spoiler layers",
            "the non-O7 remainder is not one rival half but one repeated-toward-QCT singleton plus one narrow three-witness quality1 continuation pocket",
            "the majority-side pressure is both burden-dominant and cross-lane reinforced",
        ],
        "not_supported_now": [
            "the current full head is one symmetric two-side split",
            "the current full head is one uniform O7-positive wall",
            "the current full head is already globally terminally settled",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_frontier": [
            "test whether the narrow three-witness continuation pocket later joins the same O7 branch or remains structurally separate",
            "extend the cross-observable court without collapsing this asymmetric topology into one final theory verdict",
        ],
    }

    output["verdict"] = (
        "CURRENT_FULL_HEAD_ASYMMETRIC_TWO_COURT_TWO_LANE_TOPOLOGY_CLOSED__THE_HEAD_SPLITS_INTO_A_DISPERSED_PROTECTED_MINORITY_AND_A_BURDEN_DOMINANT_CROSS_LANE_REINFORCED_MAJORITY_WITH_ONLY_A_NARROW_NON_O7_REMAINDER"
        if all(consistency_checks.values())
        else "CURRENT_FULL_HEAD_ASYMMETRIC_TWO_COURT_TWO_LANE_TOPOLOGY_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
