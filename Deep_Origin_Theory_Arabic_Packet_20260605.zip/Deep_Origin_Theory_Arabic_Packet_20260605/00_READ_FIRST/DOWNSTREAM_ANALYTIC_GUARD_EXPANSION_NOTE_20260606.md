# Downstream Analytic Guard Expansion Note

Date: `2026-06-06`

Status: `bounded reviewer-facing analytic expansion`

Purpose:

This note closes one specific mathematics deduction:

- the white-law guard had already been formalized at operator level,
- but its downstream analytic structure had not yet been written out in one
  compact reviewer-facing form.

This note does **not** claim a full end-to-end derivation of the white arm from
`SPEC-201`.

It does something narrower and cleaner:

- it writes the already-admitted guard algebra explicitly,
- pushes it through the immediate derivative chain,
- and makes the radial and lifted carrier surfaces mathematically legible to a
  cold reader.

## 1. Scope boundary

What is already admitted upstream:

- one radius-only projector `Pi_r`,
- one morphology-survival operator `I - Pi_r`,
- one positive local normalization `N_r[M](R)`,
- one bounded monotone map `B(x) = x / sqrt(1+x^2)`,
- and one compact white potential surface
  `Phi_white(R) = gamma_* G_morph^(<r-fixed>)(R)`.

What this note adds:

- one explicit downstream expansion of that guard surface.

What this note still does **not** claim:

- one final source-instantiated closed family for every admissible
  `M / Pi_r / N_r`,
- one final rank verdict on `gamma_*`,
- or one finished root-truth theorem for the white arm.

## 2. Exact guard decomposition

Define the survival numerator

\[
S(R) := \bigl(I-\Pi_r\bigr)[\mathcal M](R),
\]

and the positive local normalization

\[
N(R) := \mathcal N_r[\mathcal M](R) > 0.
\]

Then define the dimensionless internal ratio

\[
u(R) := \frac{S(R)}{N(R)}.
\]

The bounded monotone map is

\[
\mathcal B(x) := \frac{x}{\sqrt{1+x^2}}.
\]

So the guarded morphology-survival surface becomes

\[
\boxed{
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R)
=
\mathcal B\!\bigl(u(R)\bigr)
=
\frac{u(R)}{\sqrt{1+u(R)^2}}
=
\frac{S(R)}{\sqrt{N(R)^2 + S(R)^2}}.
}
\]

That last form is the cleanest closed expression on the current public path.

It shows directly that:

- the guard is dimensionless,
- the nonlinear saturation sits entirely in the `sqrt(N^2 + S^2)` denominator,
- and the amplitude normalization of the white potential lives outside the
  guard in `gamma_*`.

## 3. Immediate consequences

### 3.1 Dimension

Because `u = S/N` is dimensionless, the guard is dimensionless:

\[
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R)\in\mathbb R,
\qquad
[\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}] = 1.
\]

### 3.2 Boundedness

\[
\left|
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R)
\right|
=
\frac{|u|}{\sqrt{1+u^2}}
\le 1.
\]

So runaway behavior is blocked analytically, not only verbally.

### 3.3 Vanishing when morphology-survival vanishes

If the survival numerator is zero, then

\[
S(R)=0 \Longrightarrow u(R)=0
\Longrightarrow
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R)=0.
\]

In particular, if the object lies entirely inside the radius-only explanatory
image,

\[
\mathcal M \in \mathrm{Im}(\Pi_r)
\Longrightarrow
\bigl(I-\Pi_r\bigr)[\mathcal M] \equiv 0
\Longrightarrow
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}\equiv 0.
\]

This is the analytic form of the “radius-only collapse prohibition.”

## 4. Exact derivative chain

The bounded map satisfies

\[
\mathcal B'(x) = (1+x^2)^{-3/2},
\qquad
\mathcal B''(x) = -3x(1+x^2)^{-5/2}.
\]

Since

\[
u(R)=\frac{S(R)}{N(R)},
\]

its first and second derivatives are

\[
u'(R)
=
\frac{S'(R)N(R)-S(R)N'(R)}{N(R)^2},
\]

\[
u''(R)
=
\frac{
S''N^2 - 2S'NN' - SNN'' + 2S(N')^2
}{N^3}.
\]

Therefore

\[
\boxed{
\frac{d}{dR}\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R)
=
\frac{u'(R)}{\bigl(1+u(R)^2\bigr)^{3/2}}
}
\]

and

\[
\boxed{
\frac{d^2}{dR^2}\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R)
=
\frac{
\bigl(1+u(R)^2\bigr)u''(R) - 3u(R)\bigl(u'(R)\bigr)^2
}{
\bigl(1+u(R)^2\bigr)^{5/2}
}.
}
\]

This is the first fully explicit downstream derivative expansion on the public
packet path.

## 5. Small-signal and saturation expansions

### 5.1 Small-signal regime

For `|u| << 1`,

\[
\frac{1}{\sqrt{1+u^2}}
=
1 - \frac{1}{2}u^2 + \frac{3}{8}u^4 + O(u^6),
\]

so

\[
\boxed{
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R)
=
u(R)
- \frac{1}{2}u(R)^3
+ \frac{3}{8}u(R)^5
+ O\!\bigl(u(R)^7\bigr).
}
\]

Thus the guard is linear to first order:

\[
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R)
=
u(R) + O(u^3).
\]

### 5.2 Large-signal regime

For `|u| >> 1`,

\[
\sqrt{1+u^2}
=
|u|\left(1+\frac{1}{2u^2}-\frac{1}{8u^4}+O(u^{-6})\right),
\]

so

\[
\boxed{
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R)
=
\operatorname{sgn}(u)
\left(
1
- \frac{1}{2u^2}
+ \frac{3}{8u^4}
+ O(u^{-6})
\right).
}
\]

This makes the anti-runaway saturation analytically explicit.

## 6. Radial carrier expansion

The compact radial white potential is

\[
\Phi_{\mathrm{white}}(R) = \gamma_\star\,\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R).
\]

So

\[
\Phi'_{\mathrm{white}}(R)
=
\gamma_\star
\frac{u'(R)}{\bigl(1+u(R)^2\bigr)^{3/2}},
\]

\[
\Phi''_{\mathrm{white}}(R)
=
\gamma_\star
\frac{
\bigl(1+u(R)^2\bigr)u''(R) - 3u(R)\bigl(u'(R)\bigr)^2
}{
\bigl(1+u(R)^2\bigr)^{5/2}
}.
\]

For the cylindrical radial operator,

\[
\mathcal L_R[\Phi_{\mathrm{white}}]
:=
\frac{1}{R}\frac{d}{dR}
\left(
R\frac{d\Phi_{\mathrm{white}}}{dR}
\right),
\]

we get

\[
\boxed{
\mathcal L_R[\Phi_{\mathrm{white}}]
=
\gamma_\star
\left[
\frac{u'(R)}{R\bigl(1+u(R)^2\bigr)^{3/2}}
+
\frac{
\bigl(1+u(R)^2\bigr)u''(R)-3u(R)\bigl(u'(R)\bigr)^2
}{
\bigl(1+u(R)^2\bigr)^{5/2}
}
\right].
}
\]

So the downstream carrier is no longer only a symbolic “guarded potential.”
Its radial operator is now explicitly visible.

## 7. Conservative lifted form

The already-admitted lifted surface is

\[
\Phi_{\mathrm{white}}^{\mathrm{complete}}(R,\varphi,z)
=
\gamma_\star\,
\Xi(R,\varphi,z)\,
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R),
\qquad
\Xi(R,\varphi,0)=1.
\]

Because the guard depends only on `R` on the present public route, the
Laplacian expands as

\[
\boxed{
\nabla^2 \Phi_{\mathrm{white}}^{\mathrm{complete}}
=
\gamma_\star
\left[
\mathcal G\,\nabla^2\Xi
+ 2\,\partial_R\Xi\,\mathcal G'
+ \Xi\,\frac{1}{R}\frac{d}{dR}\!\left(R\mathcal G'\right)
\right].
}
\]

Equivalently, the effective-source representation is

\[
\rho_{\mathrm{eff}}^{\mathrm{white}}
=
\frac{1}{4\pi G_{\mathrm{review}}}
\nabla^2 \Phi_{\mathrm{white}}^{\mathrm{complete}}.
\]

This is the clean downstream analytic bridge from:

- guarded morphology-survival signal

to:

- conservative scalar-potential carrier
- and effective-source representation.

## 8. Selected-line discipline

The packet also preserves one derived selected-line surface:

\[
\Phi_{\mathrm{CALFMB}}(R)
=
\gamma_0\,
\mathrm{core\_auto\_linear\_filtered\_morphology\_balance\_guard}(R),
\qquad
\lambda = 0.00625.
\]

The correct reading is:

- this is one frozen derived line under the canonical `FMR` root,
- not one promotion of the selected line into root identity,
- and not one proof that every selected-line implementation is already a final
  law-bearing root.

So the present note closes the downstream guard algebra

without committing root theft or false theorem inflation.

## 9. What is now closed, and what remains later

This note now closes the weaker deduction:

- "the packet has only a metaphorical white guard, not one explicit analytic
  downstream form."

What still remains later is narrower:

- one fully source-instantiated family for the admissible `M / Pi_r / N_r`
  objects,
- one final rank verdict on `gamma_*`,
- and one stronger necessity/truth theorem above the present bounded analytic
  carrier.

## Bottom line

The white-law guard is no longer only:

- one operator-level slogan.

It is now also:

- one explicit dimensionless bounded ratio,
- one explicit derivative chain,
- one explicit small-signal and saturation expansion,
- one explicit radial carrier operator,
- and one explicit conservative lifted source-facing surface.

That is not yet the last white theorem.

But it is already a real reviewer-facing analytic object.
