# Anti-`QCT` Case Investigation Protocol And First-Pass Topology Note

Date: `2026-06-08`

Status: `bounded packet-facing absorption`

Purpose:

This note exists to prevent two equally bad readings of anti-`QCT` cases:

- that they are being ignored or defended ad hoc,
- or that every hard case already yields one blunt public theory-loss verdict.

The stronger current packet-facing reading is narrower:

- anti-`QCT` cases are now investigated through one fixed lawful protocol,
- repeated role patterns are already visible,
- and the spoiler universe already has internal structure rather than one flat
  hostile pile.

## Short verdict

The packet may now say something stronger than:

- "there are a few spoiler galaxies,"

or:

- "one harsh object hurts us."

It may now say:

- one governed anti-`QCT` investigation protocol exists,
- one first-pass topology already separates structure-sensitive,
  parity-rematerialization, and representation-sensitive spoiler families,
- one repeated cross-program role map is already visible,
- one mild spoiler core exists for cheap lawful investigation,
- and the heavier spoiler side is no longer one anonymous later pile but a
  structured discordance map with internal texture.

That is a real strengthening of the comparator story.

It is **not**:

- one new official public benchmark count surface,
- whole-family matched-nuisance completion,
- whole-family `MOND/QUMOND` verdict closure,
- or one promise that anti-`QCT` cases disappear under the protocol.

## 1. What counts and what does not

This note distinguishes two layers.

Official count language should remain tied to admitted governed live-lane
matrices.

The wider rematerialized replay inventory may still be used,
but only as a technical investigation universe.

That distinction matters because this note is about:

- investigation discipline,
- role structure,
- and spoiler topology,

not one inflated replacement for the admitted count surfaces.

## 2. Governing investigation protocol

The current lawful anti-`QCT` protocol now asks six fixed questions.

### Role stability

Ask first whether a case is:

- toward `QCT` in more than one governed program,
- spoiler in more than one governed program,
- or only locally discordant.

Repeated role stability is stronger than one isolated replay.

### Public-gap dominance

If the public compressed reference gap is overwhelmingly `QCT`-side dominant,
the case is tagged first as:

- compression / artifact-sensitive

before one broad public physics verdict is allowed.

### Component-aware shift topology

Anti-`QCT` cases are then split into three governing families:

1. structure-sensitive prime:
   `QCT` worsens while `QUMOND` stays stable or improves
2. parity-rematerialization prime:
   both worsen, but `QCT` worsens more
3. representation-sensitive prime:
   both improve, but `QUMOND` improves more

This is stronger than treating every spoiler as one undifferentiated failure.

### Lawful parity escalation

Only lawful parity items are admitted at this stage:

- distance uncertainty,
- inclination uncertainty,
- quality-flag aware masking grammar,
- and component-aware baryonic rematerialization from raw source

The protocol does **not** allow:

- post-hoc row deletion,
- theory-specific rescue knobs,
- or hidden smoothing / beautification.

### Magnitude priority

The spoiler attack order is now explicit:

- mild first,
- then moderate,
- then large.

That matters because the current away-cases are not all giant monsters.

### Hard-spoiler admission

The protocol also allows one honest end state:

- some cases may remain stable hard spoilers after the same gates.

So the protocol is not one hidden guarantee that every pressure object gets
rescued.

## 3. First-pass topology now visible

### Official admitted trend is not one fixed `30%` myth

The admitted live-lane checkpoints do **not** support one stable fixed
approximately-`30%` toward-`QCT` ratio.

They support a narrower reading:

- `4` cases: `3 toward / 1 away`
- `11` cases: `3 toward / 8 away`
- `66` cases: `23 toward / 43 away`
- `145` cases: `30 toward / 115 away`

So the fair reading is:

- not fixed `30%`,
- but also not collapse to zero.

There is one persistent toward-`QCT` core plus one larger spoiler
superstructure.

### Stable repeated role map already exists

The strongest already repeated cross-program role map remains:

- `NGC0247` = toward `QCT` in both programs
- `NGC5055` = toward `QCT` in both programs
- `NGC6946` = toward `QCT` in both programs
- `UGC11914` = spoiler in both programs
- `NGC5585` = spoiler in both programs

So the live comparator lane is not one random cloud.

It already contains repeat case roles.

### Technical replay universe first pass

Across the currently available rematerialized replay inventory:

- total replay objects seen = `154`
- toward `QCT` = `51`
- away from `QCT` = `103`

Again, this wider inventory is used here as a technical investigation universe
only.

### Three spoiler families already separate cleanly

Inside the current `103` anti-`QCT` replay objects, the first-pass topology is:

- structure-sensitive prime = `44`
- parity-rematerialization prime = `51`
- representation-sensitive prime = `8`

That means the away-cases are already more structured than:

- "all these galaxies independently crush the model in the same way."

### Public-gap sensitivity is not optional texture

Among those `103` anti-`QCT` replay objects:

- `103/103` are overwhelmingly `QCT`-side dominant at the public-gap layer
- `32` already show high public-gap sensitivity (`>= 100`)
- `18` already show very high public-gap sensitivity (`>= 500`)

So the spoiler universe is visibly entangled with one strong `QCT`-side public
gap surface.

That does **not** erase the spoilers.
It does forbid one simplistic all-physics reading of the whole away-set.

### The queue map is now structured

The first execution core is no longer anonymous.

The mild first-wave investigation core already includes:

- `UGC11914`
- `NGC5005`
- `NGC4183`
- `F583-4`
- `NGC3972`
- `UGCA281`

Above that core, the heavier spoiler side is now better read as:

- one discordance / high-public-gap head,
- one formal outer discordance ring,
- and one softer but still discordant subfamily.

The formal outer discordance ring is already visible through:

- `DDO154`
- `NGC2403`
- `UGC00128`
- `NGC6674`
- `F571-8`
- `DDO161`

The softer but still discordant subfamily is already visible through:

- `UGC06973`
- `NGC4217`
- `UGC11455`

So the outer nonshared burden is no longer best read as one generic giant
queue.

## 4. Why this helps the packet

This note strengthens the packet in one important way:

- it proves that hostile cases are not being hidden,
- it proves that they are not being treated with one ad hoc defense per case,
- and it proves that the away-cases already have one lawful structural map.

That makes the empirical and comparator fronts more serious.

It also supports the narrower reading of `UGC11914`:

- not one random embarrassment,
- but one seed structure-sensitive witness inside a broader governed
  anti-`QCT` investigation grammar.

## 5. Claim ceiling

This note does **not** claim:

- that the wider replay inventory is one new official count surface,
- that anti-`QCT` cases mostly disappear,
- that the current family topology is final,
- that the heavier queues are exhausted,
- that matched-nuisance execution is complete,
- or that whole-family `MOND/QUMOND` verdict closure is already complete.

It only claims:

- one fixed anti-`QCT` investigation protocol now exists,
- one first-pass spoiler topology now exists,
- and one structured queue map already replaces the older anonymous spoiler
  swamp reading.

## Best outward-safe reading

The English packet may now say:

> The current comparator record no longer treats anti-`QCT` galaxies as one
> anonymous hostile pile. It now exposes one governed investigation protocol,
> one repeated cross-program role map, and one first-pass spoiler topology
> that separates structure-sensitive, parity-rematerialization, and
> representation-sensitive pressure families without claiming final whole-family
> closure.
