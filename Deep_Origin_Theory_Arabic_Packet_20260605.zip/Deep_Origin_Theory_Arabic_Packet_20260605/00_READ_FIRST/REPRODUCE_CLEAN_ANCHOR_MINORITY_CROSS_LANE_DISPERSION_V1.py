#!/usr/bin/env python3
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent

CLEAN_ANCHOR_SYNTHESIS_PATH = HERE / "CLEAN_ANCHOR_MINORITY_VS_FULLY_CLOSED_HUBBLE_FLOW_SENSITIVE_BODY_CROSS_COURT_SYNTHESIS_V1.json"
ANTI_QCT_NOTE_PATH = HERE / "ANTI_QCT_CASE_INVESTIGATION_PROTOCOL_AND_FIRST_PASS_TOPOLOGY_NOTE_20260608.md"
O7_TAIL_NOTE_PATH = HERE / "BEST_DRESSED_ADVERSARIAL_COMPARATOR_O7_TAIL_STATUS_NOTE_20260608.md"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_text(path: Path):
    return path.read_text(encoding="utf-8")


def extract_backticked_tokens(text: str):
    return re.findall(r"`([^`]+)`", text)


def extract_following_bullet_cases(text: str, heading: str):
    pattern = re.escape(heading) + r"\n\n((?:- `[^`\n]+`\n)+)"
    match = re.search(pattern, text)
    if not match:
        raise ValueError(f"Could not locate bullet block after heading: {heading}")
    return extract_backticked_tokens(match.group(1))


def extract_inline_layer_cases(text: str, label: str):
    pattern = r"- " + re.escape(label) + r":\n  (.+)"
    match = re.search(pattern, text)
    if not match:
        raise ValueError(f"Could not locate inline layer: {label}")
    return extract_backticked_tokens(match.group(1))


def close_enough(left, right, tolerance=1e-9):
    return abs(left - right) <= tolerance


def main():
    clean_anchor = load_json(CLEAN_ANCHOR_SYNTHESIS_PATH)
    anti_qct_note = load_text(ANTI_QCT_NOTE_PATH)
    o7_tail_note = load_text(O7_TAIL_NOTE_PATH)

    clean_anchor_court = clean_anchor["clean_anchor_minority_court"]
    clean_anchor_cases = clean_anchor_court["cases"]

    second_severe_triad = extract_following_bullet_cases(
        o7_tail_note,
        "It then materialized a second severe positive-spoiler-band triad:",
    )
    third_depth_triad = extract_following_bullet_cases(
        o7_tail_note,
        "Kreib then materialized a third depth triad:",
    )
    mixed_shift_persistence = extract_inline_layer_cases(
        o7_tail_note,
        "mixed-shift persistence",
    )

    repeated_toward_qct_case = "SPARC_NGC5055"
    repeated_toward_qct_phrase = "- `NGC5055` = toward `QCT` in both programs"
    repeated_toward_qct_cases = []
    if repeated_toward_qct_phrase in anti_qct_note:
        repeated_toward_qct_cases.append(repeated_toward_qct_case)

    o7_layer_map = {}
    layer_sources = {
        "second_severe_positive_spoiler_band_triad": second_severe_triad,
        "third_depth_triad": third_depth_triad,
        "mixed_shift_persistence_layer": mixed_shift_persistence,
    }
    for layer_name, cases in layer_sources.items():
        for case_id in cases:
            if case_id in clean_anchor_cases:
                o7_layer_map[case_id] = layer_name

    partitioned_cases = set(repeated_toward_qct_cases) | set(o7_layer_map)

    consistency_checks = {
        "clean_anchor_case_count_is_four": clean_anchor_court["case_count"] == 4,
        "clean_anchor_case_list_length_matches_case_count": len(clean_anchor_cases)
        == clean_anchor_court["case_count"],
        "clean_anchor_court_remains_all_quality1": clean_anchor_court["all_quality1"] is True,
        "clean_anchor_court_remains_non_hubble_flow_anchored": clean_anchor_court[
            "all_non_hubble_flow_anchored"
        ]
        is True,
        "ngc5055_repeated_toward_qct_role_is_explicitly_present": repeated_toward_qct_phrase
        in anti_qct_note,
        "clean_anchor_intersection_with_second_severe_triad_is_exactly_ngc3198": (
            set(clean_anchor_cases) & set(second_severe_triad)
        )
        == {"SPARC_NGC3198"},
        "clean_anchor_intersection_with_third_depth_triad_is_exactly_ngc2841": (
            set(clean_anchor_cases) & set(third_depth_triad)
        )
        == {"SPARC_NGC2841"},
        "clean_anchor_intersection_with_mixed_shift_persistence_is_exactly_ngc7331": (
            set(clean_anchor_cases) & set(mixed_shift_persistence)
        )
        == {"SPARC_NGC7331"},
        "repeated_toward_qct_subset_and_o7_positive_subset_are_disjoint": set(
            repeated_toward_qct_cases
        ).isdisjoint(set(o7_layer_map)),
        "cross_lane_partition_exhausts_the_clean_anchor_court": partitioned_cases
        == set(clean_anchor_cases),
        "o7_positive_subset_spans_three_distinct_layers": len(set(o7_layer_map.values())) == 3,
        "count_shares_sum_to_one": close_enough(
            len(repeated_toward_qct_cases) / clean_anchor_court["case_count"]
            + len(o7_layer_map) / clean_anchor_court["case_count"],
            1.0,
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "bounded_packet_facing_clean_anchor_cross_lane_dispersion",
        "surface": "clean_anchor_minority_cross_lane_dispersion",
        "clean_anchor_minority_court": {
            "case_count": clean_anchor_court["case_count"],
            "cases": clean_anchor_cases,
            "public_delta_aic_total": clean_anchor_court["delta_aic_sum"],
            "fraction_of_giant_spiral_head_burden": clean_anchor_court[
                "fraction_of_giant_spiral_head_burden"
            ],
            "all_quality1": clean_anchor_court["all_quality1"],
            "all_non_hubble_flow_anchored": clean_anchor_court["all_non_hubble_flow_anchored"],
            "all_visible_multiseed_stable": clean_anchor_court["all_visible_multiseed_stable"],
        },
        "cross_program_repeated_toward_qct_subset": {
            "case_count": len(repeated_toward_qct_cases),
            "cases": repeated_toward_qct_cases,
            "fraction_of_clean_anchor_case_count": len(repeated_toward_qct_cases)
            / clean_anchor_court["case_count"],
            "source_note": ANTI_QCT_NOTE_PATH.name,
            "source_phrase": "NGC5055 = toward QCT in both programs",
        },
        "o7_positive_spoiler_layer_subset": {
            "case_count": len(o7_layer_map),
            "cases": sorted(o7_layer_map),
            "fraction_of_clean_anchor_case_count": len(o7_layer_map)
            / clean_anchor_court["case_count"],
            "case_to_layer": dict(sorted(o7_layer_map.items())),
            "distinct_layer_count": len(set(o7_layer_map.values())),
            "layer_memberships_touched_inside_clean_anchor_court": [
                {
                    "layer": "second_severe_positive_spoiler_band_triad",
                    "clean_anchor_cases": sorted(set(clean_anchor_cases) & set(second_severe_triad)),
                },
                {
                    "layer": "third_depth_triad",
                    "clean_anchor_cases": sorted(set(clean_anchor_cases) & set(third_depth_triad)),
                },
                {
                    "layer": "mixed_shift_persistence_layer",
                    "clean_anchor_cases": sorted(
                        set(clean_anchor_cases) & set(mixed_shift_persistence)
                    ),
                },
            ],
            "source_note": O7_TAIL_NOTE_PATH.name,
        },
        "structural_reading": {
            "clean_anchor_minority_does_not_collapse_to_one_uniform_cross_program_role": True,
            "o6_clean_anchor_membership_does_not_predict_one_uniform_o7_role": True,
            "lane_identity_still_matters_inside_the_clean_anchor_minority": True,
            "the_three_o7_positive_clean_anchor_cases_already_span_three_distinct_internal_o7_layers": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "protected_clean_anchor_minority_does_not_collapse_to_one_uniform_cross_program_role",
            "NGC5055 remains repeated toward QCT across both currently cited programs",
            "NGC3198 NGC2841 and NGC7331 are already materialized across three distinct O7 positive-spoiler layers",
            "lane identity still matters even inside the protected clean-anchor minority",
        ],
        "not_supported_now": [
            "The protected clean-anchor minority is one uniform pro-QCT block across all lanes",
            "O6 clean-anchor court membership alone predicts one uniform O7 role",
            "O7 positive-spoiler layer membership erases the protected clean-anchor minority court",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_frontier": [
            "test whether later quality1 survivor pockets show the same O6 O7 cross-lane dispersion",
            "extend the cross-observable court without collapsing court membership and lane identity into one label",
        ],
    }

    output["verdict"] = (
        "CLEAN_ANCHOR_MINORITY_CROSS_LANE_DISPERSION_CLOSED__NGC5055_REMAINS_REPEATED_TOWARD_QCT_WHILE_NGC3198_NGC2841_AND_NGC7331_ALREADY_SPAN_THREE_DISTINCT_O7_POSITIVE_SPOILER_LAYERS"
        if all(consistency_checks.values())
        else "CLEAN_ANCHOR_MINORITY_CROSS_LANE_DISPERSION_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
