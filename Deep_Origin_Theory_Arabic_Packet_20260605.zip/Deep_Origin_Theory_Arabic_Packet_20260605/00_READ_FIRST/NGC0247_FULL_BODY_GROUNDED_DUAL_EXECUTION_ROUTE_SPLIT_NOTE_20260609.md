# `NGC0247` Full-Body-Grounded Dual-Execution Route-Split Note

Date: `2026-06-09`

Status: `bounded packet-facing dual-execution absorption`

Purpose:

After the no-makeup cross-observable court is selected and frozen,
this note absorbs the first actual dual execution return on the shared bridge
witness `NGC0247`:

- the `O6` matched-nuisance execution return
- the `O7` best-dressed hardening execution return

It should be read after:

- `NGC0247_FIRST_FULL_BODY_GROUNDED_NO_MAKEUP_COURT_DOUBLE_LAUNCH_NOTE_20260609.md`

Machine-readable companion:

- `NGC0247_FULL_BODY_GROUNDED_DUAL_EXECUTION_ROUTE_SPLIT_V1.json`

Direct continuation now already visible at the two-spear level in:

- `SHARED_SPEAR_DOUBLE_WITNESS_ROUTE_SPLIT_AND_SAME_SIGN_SOFTENING_NOTE_20260609.md`

## Short verdict

The first shared no-makeup spear no longer sits only at launch stage.

It now has a bounded full-body-grounded dual execution return:

- release-side best-dressed hardening remains anchor-stable and anti-`QCT`
- fixed public live and matched-nuisance live routes remain pro-`QCT`

So `NGC0247` remains one full-body-grounded release-vs-live route-split
witness.

## 1. `O6` matched-nuisance execution return

The first full-body-grounded matched-nuisance return on `SPARC_NGC0247` now
exists with:

- public fixed-`QUMOND` `Delta AIC_total = -13.914066963632308`
- faithful matched-nuisance `Delta AIC_total = -15.398764714420167`
- component-aware matched-nuisance `Delta AIC_total = -39.63154845025974`
- component-aware hardening shift = `-24.232783735839575`
- faithful/public `QUMOND` absolute gap = `2.338197191420477e-08`

So the same witness remains pro-`QCT` on public, faithful, and
component-aware live surfaces.

## 2. `O7` best-dressed hardening execution return

The first full-body-grounded best-dressed hardening return on
`SPARC_NGC0247` now exists with:

- `option2_minimal Delta AIC_total = +330.508310757082`
- `option1_robust Delta AIC_total = +330.508310757082`
- anchor spread absolute gap = `0.0`
- release minus public-live gap = `344.4223777207143`
- release minus `O6` faithful gap = `345.90707547150214`
- release minus `O6` component-aware gap = `370.1398592073417`

So the release-side hardening remains anchor-stable and anti-`QCT`.

## 3. What the dual execution means

The route split now survives explicit full-body grounding on both sides.

The court is already grounded by:

- clean-anchor fraction = `0.3445341820567513`
- fully closed Hubble-flow-sensitive body fraction = `0.6554658179432487`

Yet the same witness still remains:

- anti-`QCT` on both release-side hardening anchors
- pro-`QCT` on the fixed public live lane
- further pro-`QCT` under component-aware matched nuisance

So the disagreement is route-level, not anchor-level.

## 4. What this does not authorize

This note does **not** authorize the claims that:

- `NGC0247` alone kills `QCT`
- `NGC0247` alone kills `MOND/QUMOND`
- one route may replace the other by convenience
- one witness already settles the whole court

## 5. Next honest escalation

The next honest escalation is not overclaim.

It is:

- carrying the second shared spear `NGC6946` beside this first route-split
  spear
- then preserving the bounded multi-morphology court without collapsing it
  into one story

## Best outward-safe reading

One mature outward-safe sentence is:

> `NGC0247` now has a bounded full-body-grounded dual execution return:
> the release-side best-dressed hardening stays anchor-stable and anti-`QCT`,
> while the fixed public live lane and matched-nuisance live returns stay
> pro-`QCT`, so the first shared spear remains an explicit route-split
> witness rather than a one-sided verdict.
