# Prediction Axis Testability Reclassification Note

Date: `2026-06-06`

Status: `bounded scoring-discipline note`

## Purpose

This note records one narrow reclassification argument:

- whether the remaining visible `NGC0247` gap still belongs under
  **testability**,
- or whether it now belongs under **archival provenance / packaging purity**
  instead.

This note does not widen any scientific claim.
It only tightens how the present packet should be scored and read.

## Short answer

The strongest current reading is now:

- the named `NGC0247` lane is fully testable at bounded packet scope,
- while one archival cleanliness gap still remains.

That remaining gap is real.
But it is no longer best read as a live testability deficit.

## Why this reclassification is now defensible

### 1. The row-level comparator is already public

The packet already publishes:

- `NGC0247_CURRENT_ROW_COMPARATOR__QCT_AND_FIXED_QUMOND__V1.csv`
- `REPRODUCE_NGC0247_PHASE2_CURRENT_QCT_ROW_COMPARATOR_V1.py`
- `CURRENT_QCT_ROW_COMPARATOR_APPENDIX__NGC0247__PHASE2_RECONSTRUCTED_V1.md`

So the named case is already:

- row-visible,
- script-rerunnable,
- and numerically auditable.

### 2. The recovered nuisance values are already explicit

The packet already freezes:

- `Upsilon_phase2_seed42 = 0.9254967104326863`
- `Upsilon_qumond_phase2_seed42 = 0.5685897225673557`

These are not vague hints.
They are explicit recovered nuisance values bound to the visible bounded
Phase-2 lane.

### 3. The reconstructed lane reproduces the preserved lane at machine tolerance

The packet already states that the reconstructed totals match the preserved
Phase-2 lane at machine-level tolerance for:

- `QCT loglike_obs_only`
- `QCT loglike_obs_model`
- benchmark-`QUMOND` `loglike_obs_only`
- `ΔAIC_total`
- and `ΔBIC_total`

So the bounded current lane is already more than suggestive.

### 4. The visible source object and visible predictor surface are already public

The packet already exposes:

- `NGC0247_PHASE2_SOURCE_CASE_V1.json`
- `NGC0247_PHASE2_PRED_ONE_V1.ndjson`

So the named test object is no longer blocked on hidden inputs.

## What remains absent

What remains absent is only:

- the original stored best-fit nuisance object as its own separately preserved
  public archival file.

That is a real limitation.

But it is now best classified under:

- archival cleanliness,
- provenance purity,
- or packet packaging rigor,

not under:

- testability.

## Current-stage ceiling and later transfer

For the current admitted stage, the fair reading is:

- the named `NGC0247` lane has reached full bounded testability,
- while archival purity still remains below a later ceiling.

So the remaining gap is intentionally transferred to a later archival /
provenance-cleanliness front rather than kept as a live testability subtraction.

## Best short outward-safe reading

One mature outward-safe sentence is:

> The named `NGC0247` lane is now fully testable at bounded packet scope: the
> visible source case, visible predictor surface, recovered nuisance values,
> row-level comparator, and reproduction script are already public, and the
> reconstructed Phase-2 totals reproduce the preserved lane at machine-level
> tolerance. What remains absent is only the original stored best-fit nuisance
> artifact as a separately preserved archival file.

## Non-overclaim guard

This note does **not** claim:

- whole-family `MOND/QUMOND` closure,
- final observational cosmology closure,
- or that every later historical lane already shares one identical fairness
  convention.
