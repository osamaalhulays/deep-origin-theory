from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[4]
OBJECT_ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = OBJECT_ROOT / "04_OUTPUTS"
OUTPUTS.mkdir(parents=True, exist_ok=True)

ARTIFACTS = ROOT / "artifacts/debt_board_20260530"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


minimum_signature_report = ARTIFACTS / "POST_CAGE_BRANCH_U1_FORMD_MINIMUM_ENGINE_SIGNATURE_V1/04_OUTPUTS/status_summary.json"
ownership_report = ARTIFACTS / "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_V1/04_OUTPUTS/PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_REPORT.md"
visible_paths_json = ARTIFACTS / "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_V1/04_OUTPUTS/form_d_visible_paths.json"

minimum_signature_status = json.loads(read(minimum_signature_report))
ownership_text = read(ownership_report)
visible_paths = json.loads(read(visible_paths_json))

excluded_dir_names = {
    "POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_V1",
    "POST_CAGE_BRANCH_U1_FORMD_MINIMUM_ENGINE_SIGNATURE_V1",
    "POST_CAGE_BRANCH_U1_FORMD_MINIMUM_ENGINE_SIGNATURE_CURRENT_REPO_NO_GO_V1",
    "POST_CAGE_BRANCH_U1_FORMD_GRADE_ENGINE_DECISION_GATE_V1",
}

formd_named_dirs = []
for path in ARTIFACTS.rglob("*"):
    if not path.is_dir():
        continue
    if not re.search(r"FORMD|FORM_D|form_d", path.name):
        continue
    if any(part in excluded_dir_names for part in path.parts):
        continue
    formd_named_dirs.append(str(path.relative_to(ROOT)))

callable_candidate_files = []
for path in ARTIFACTS.rglob("*"):
    if not path.is_file():
        continue
    lower = path.name.lower()
    if not lower.endswith((".py", ".ts", ".js", ".sh")):
        continue
    if any(part in excluded_dir_names for part in path.parts):
        continue
    if "formd" in lower or "form_d" in lower:
        callable_candidate_files.append(str(path.relative_to(ROOT)))

checks = [
    {
        "name": "minimum_signature_materialized",
        "passed": minimum_signature_status["verdict"]
        == "POST_CAGE_BRANCH_U1_FORMD_MINIMUM_ENGINE_SIGNATURE_MATERIALIZED",
    },
    {
        "name": "ownership_report_still_zero",
        "passed": "reviewer-visible form-d object count: `0`" in ownership_text,
    },
    {
        "name": "stored_visible_paths_empty",
        "passed": visible_paths == [],
    },
    {
        "name": "no_extra_formd_named_dirs",
        "passed": len(formd_named_dirs) == 0,
    },
    {
        "name": "no_callable_formd_candidate_files",
        "passed": len(callable_candidate_files) == 0,
    },
]

materialized = all(item["passed"] for item in checks)
generated_at = datetime.now(timezone.utc).isoformat()

verdict = {
    "object": "POST_CAGE_BRANCH_U1_FORMD_MINIMUM_ENGINE_SIGNATURE_CURRENT_REPO_NO_GO_V1",
    "generated_at": generated_at,
    "materialized": materialized,
    "reviewer_visible_formd_engine_count": 0 if materialized else None,
    "extra_formd_named_dirs": formd_named_dirs,
    "callable_formd_candidate_files": callable_candidate_files,
}

status_summary = {
    "verdict": (
        "POST_CAGE_BRANCH_U1_FORMD_MINIMUM_ENGINE_SIGNATURE_CURRENT_REPO_NO_GO_MATERIALIZED"
        if materialized
        else "POST_CAGE_BRANCH_U1_FORMD_MINIMUM_ENGINE_SIGNATURE_CURRENT_REPO_NO_GO_NOT_MATERIALIZED"
    ),
    "minimum_signature_input_confirmed": checks[0]["passed"],
    "ownership_report_zero_confirmed": checks[1]["passed"],
    "stored_visible_paths_empty": checks[2]["passed"],
    "extra_formd_named_dir_count": len(formd_named_dirs),
    "callable_formd_candidate_count": len(callable_candidate_files),
}

report_lines = [
    "# Post-Cage Branch U1 Form D Minimum Engine Signature Current-Repo No-Go Report",
    "",
    f"Generated at: `{generated_at}`",
    "",
    f"Verdict: `{status_summary['verdict']}`",
    "",
    "## Summary",
    "",
    f"- minimum signature input confirmed: `{checks[0]['passed']}`",
    f"- ownership report still zero: `{checks[1]['passed']}`",
    f"- stored visible-path list empty: `{checks[2]['passed']}`",
    f"- extra Form D named dir count: `{len(formd_named_dirs)}`",
    f"- callable Form D candidate count: `{len(callable_candidate_files)}`",
    "",
    "## Extra Form D named dirs",
    "",
]
report_lines.extend([f"- `{item}`" for item in formd_named_dirs] or ["- none"])
report_lines.extend(
    [
        "",
        "## Callable Form D candidate files",
        "",
    ]
)
report_lines.extend([f"- `{item}`" for item in callable_candidate_files] or ["- none"])
report_lines.extend(
    [
        "",
        "## Reading",
        "",
        "- current repo-visible Form D remains class language and routing language only,",
        "- no standalone reviewer-visible Form D engine object is presently visible,",
        "- and hidden Form D hunting on the current frozen route is therefore below the line.",
        "",
        "## Bottom line",
        "",
        "- future Form D progress must come from fresh engine materialization, not hidden current-repo discovery.",
    ]
)

(OUTPUTS / "checks.json").write_text(json.dumps(checks, indent=2), encoding="utf-8")
(OUTPUTS / "verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")
(OUTPUTS / "status_summary.json").write_text(json.dumps(status_summary, indent=2), encoding="utf-8")
(OUTPUTS / "FORMD_MINIMUM_ENGINE_SIGNATURE_CURRENT_REPO_NO_GO_REPORT.md").write_text(
    "\n".join(report_lines) + "\n",
    encoding="utf-8",
)
