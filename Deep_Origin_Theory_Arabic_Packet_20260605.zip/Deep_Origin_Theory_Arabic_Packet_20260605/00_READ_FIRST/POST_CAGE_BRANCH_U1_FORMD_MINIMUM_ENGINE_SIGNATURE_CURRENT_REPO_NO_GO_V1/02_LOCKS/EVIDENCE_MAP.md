# Evidence Map

1. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_FORMD_MINIMUM_ENGINE_SIGNATURE_V1/04_OUTPUTS/FORMD_MINIMUM_ENGINE_SIGNATURE_REPORT.md`
   - freezes the minimum `Form D` signature
2. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_V1/04_OUTPUTS/PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_REPORT.md`
   - already reports reviewer-visible `Form D` object count = `0`
3. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_V1/04_OUTPUTS/form_d_visible_paths.json`
   - currently stores zero visible `Form D` paths
4. `artifacts/debt_board_20260530/POST_CAGE_BRANCH_U1_AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_V1/04_OUTPUTS/AUTHORITY_CROSSING_VERSUS_FORMD_SUPERSESSION_DISCRIMINATOR_REPORT.md`
   - proves that current `Form D` visibility so far is grammar / routing class
     language, not same-route crossing
