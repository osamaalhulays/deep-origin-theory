# Post-Cage Branch U1 I_amp Source-Purity Gate Localizes To Metric/Matter-Only Amplitude Shell Note

Date: `2026-06-08`

Status: `parallel shell-tightening after J_lin register freeze`

## Purpose

The live `U1` route already carries one exact linear-head freeze:

`J_lin = I_amp`

at source-binding grade.

So the next exact question becomes:

- if this freeze is to remain honest,
  what is the first positive admissible class that `I_amp` should belong to

## Candidate readings

The positive side of the gate could in principle have been:

1. one vague source-amplitude knob later stabilized by empirical rescue
2. one metric/matter-only source-amplitude shell
3. one disguised second-carrier or preinflated screening lane

## Short verdict

The current record best supports the second reading.

The first positive admissible class for the current `I_amp` gate is:

`I_amp^(0) = metric/matter-only source-amplitude shell`

meaning:

- `I_amp` must first be admissible as one source-strength register built only
  from the already-owned metric/matter route

before it is asked to carry any stronger shared interaction-law burden.

This is stronger than saying only:

- `J_lin` is owned by `I_amp`

because it supplies the positive mirror:

- yes, the owner may first live as one `g,ψ`-side amplitude shell at
  register-definition grade.

That is a real gain.

## 1. Why the freeze now needs a positive shell, not only ownership language

The current `J_lin` freeze already carries strong negative guardrails:

1. no observational borrowing
2. no halo fit
3. no baryonic tuning
4. no hidden second carrier
5. no reopening of `RR1`
6. no reopening of `T_S`

Those are necessary,
but they still leave one possible fog:

- "`I_amp` owns the head somehow"

The current record is already sharp enough to do better.

It can name the first clean shell class for that owner itself.

## 2. Why metric/matter-only is already repo-native

Three current lines align directly.

### A. The `IR1` scaffold already types `I_amp[g,ψ]`

The shared-source scaffold writes:

- `I_src^(IR1)[g,ψ] = (I_amp[g,ψ], I_mix[g,ψ], I_geo[g,ψ])`

It does not write:

- `I_amp[g,ψ,Q]`

So the register-definition layer already places `I_amp` on the
metric/matter side first.

### B. The `J_lin` freeze already treats `I_amp` as one source-binding owner,
not one rescued parameter

The freeze note explicitly says:

- `J_lin` is frozen at shared-source register-binding grade
- stronger theorem-grade descent is still later

and it rejects:

- empirical rescue
- hidden second-carrier borrowing
- public inflation

That already points toward one clean first shell,
not one late-fit amplitude control.

### C. The typed worksheet already makes the linear slot
`J_lin[g,ψ] Q` explicit

The current `QF1/IF1` worksheet does not hide the linear source head.

It writes:

- `J_lin[g,ψ] Q`

as the explicit admitted linear source slot.

That already matches one natural first shell for its owner:

- a source-amplitude functional on the `g,ψ` side.

## 3. Exact meaning of the metric/matter-only amplitude shell

The fair current positive class is:

`I_amp^(0)[g,ψ]`

with the following first-grade contract:

1. it is a functional of `g,ψ` only
2. it carries the first source-strength content feeding `J_lin`
3. it does **not** depend directly on `Q` at register-definition grade
4. it does **not** borrow from observational fit, halo rescue, or baryonic
   tuning
5. it does **not** smuggle in one hidden second carrier
6. it does **not** preinflate the separate `W_src` screening problem into
   solved identity by naming alone

This does **not** yet declare one final formula.

It declares the first lawful shell class.

## 4. Why direct `Q`-fed or screening-preinflated `I_amp` is too early

If `I_amp` already needed direct `Q` dependence at register-definition grade,
then the distinction between:

- source-binding owner now

and:

- stronger theorem-grade descent later

would collapse too early.

If `I_amp` already had to absorb the separate `W_src` screening burden at the
same first shell grade,
then the current asymmetry between the cleaner linear lane and the harder
screening lane would be lost.

So the first honest shell cannot be:

- `I_amp[g,ψ,Q]`

and cannot be:

- one silent `I_amp = I_screen` inflation.

If such coupling becomes unavoidable later,
that is a later flip condition,
not the first admissible shell.

## 5. Why this is a real gain

This note upgrades the linear-head freeze from:

- one lawful owner name

to:

- one lawful owner name plus one positive admissible shell class

So the live line now knows more exactly what the owner of `J_lin` is allowed
to be before stronger interaction-law promotion is attempted.

That removes one more layer of vagueness.

## 6. What this does not say

This note does **not** claim:

1. that the final functional form of `I_amp^(0)` is already known
2. that `W_src` is solved
3. that the screening-coefficient theorem is already promoted
4. that `J_lin` has already reached full theorem-grade descent
5. that interaction closure is complete

It claims something narrower and useful:

- the first positive admissible shell for `I_amp` is now named.

## 7. Exact flip conditions

This shell reading should be revoked immediately if later lawful work shows:

1. `I_amp` cannot be typed meaningfully on the `g,ψ` side alone
2. direct `Q` dependence is required already at register-definition grade
3. one hidden second carrier is required to keep `J_lin` source-bound
4. the linear lane survives only by empirical or fitted rescue
5. the real first shell lies elsewhere than the metric/matter route

If any of those appears,
this shell reading fails.

## Bottom line

The current live `U1` route now supports one sharper linear-owner reading
again:

1. `J_lin` is already frozen by `I_amp`
2. that freeze is no longer only ownership language
3. its first positive admissible class is
   `I_amp^(0)[g,ψ]`
   as one metric/matter-only source-amplitude shell
4. only after that shell survives cleanly may stronger interaction-law
   promotion be attempted without inflation

That is the cleanest current positive formulation of the live `I_amp` gate.
