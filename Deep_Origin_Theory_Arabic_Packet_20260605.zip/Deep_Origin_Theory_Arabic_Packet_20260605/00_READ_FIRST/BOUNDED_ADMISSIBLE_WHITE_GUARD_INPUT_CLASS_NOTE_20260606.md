# Bounded Admissible White-Guard Input Class Note

Date: `2026-06-06`

Status: `reviewer-facing bounded admissible-class clarification`

Purpose:

After the downstream analytic guard expansion was made explicit, one narrower
mathematical question remained:

- does the public white guard still float over an unconstrained symbolic
  `M / Pi_r / N_r` trio,
- or is there already a bounded admissible class on which the current public
  guard is meant to live?

This note answers that narrower question.

It does **not** claim a final upstream derivation of every admissible white
input from the full parent law.

It does something cleaner:

- it states the bounded admissible class already visible on the public route,
- and it spells out the mathematical consequences of restricting the guard to
  that class.

## 1. Public route: not arbitrary, not widened

The current white-law route is not a free symbolic playground.

The preserved admissibility surfaces already say:

- one governed current family is explicitly bound,
- alternative families remain only placeholder or later classes,
- comparative widening is explicitly blocked,
- and the white-law dictionary is narrowed before any function-class widening.

The strongest packet-facing anchors are:

- `FAMILY_ADMISSIBILITY_AND_NO_WIDENING_NOTE.md`
- `family_admissibility_set_layer_status.md`
- `white_law_closure_first_status.md`
- `fixed_r_morphology_survival_white_law_formalization_v1_status.md`

The fair current reading is therefore:

- the public white guard lives on one bounded admitted route,
- not on an unrestricted space of speculative family substitutions.

## 2. Bounded admissible class

Let `I` be one admitted radial interval on the current review path.

Define the bounded public white-guard input class `W_adm(I)` by the following
conditions.

### W1. Governed family binding

`\mathcal M` belongs to the currently bound white-route carrier family on the
public path.

This does **not** mean every plausible morphology family is presently active.
It means the current public path is already restricted to one governed carrier
class and no comparative widening is yet admitted.

### W2. Projector-defined survival

There exists a declared radius-only projector `Pi_r` on the admitted route,
and the survival numerator

\[
S(R) := (I-\Pi_r)[\mathcal M](R)
\]

is well-defined on `I`.

### W3. Positive normalization

There exists one positive local normalization

\[
N(R) := \mathcal N_r[\mathcal M](R) > 0
\]

on `I`, with `S` and `N` carrying the same underlying carrier dimension, so
that

\[
u(R) := \frac{S(R)}{N(R)}
\]

is dimensionless.

### W4. Minimal regularity

On the current public analytic route, the guard-facing functions are assumed
to satisfy the minimal regularity needed by the explicit derivative chain:

\[
S, N \in C^2(I),
\qquad
N(R) > 0 \ \text{for all } R \in I.
\]

For the lifted conservative surface, the completion factor is assumed to obey

\[
\Xi \in C^2(\Omega),
\qquad
\Xi(R,\varphi,0)=1
\]

on the admitted local domain `\Omega`.

### W5. Potential-scale amplitude

The white amplitude `gamma_*` (or `gamma_0` on the selected derived line) is
treated on the present route as a finite potential-scale coefficient:

\[
[\gamma_*] = [\gamma_0] = \mathrm{m^2\,s^{-2}}.
\]

This is enough for the compact white potential

\[
\Phi_{\mathrm{white}}(R) = \gamma_\star\,
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R)
\]

to carry the correct gravitational-potential unit.

## 3. Immediate consequences on `W_adm(I)`

Once `W1`-`W5` hold, the public white guard is no longer only formally named.
It is mathematically well-posed on its admitted class.

### C1. Dimensionless and bounded guard

Because `u = S/N` is dimensionless, the bounded map

\[
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R)
=
\frac{u(R)}{\sqrt{1+u(R)^2}}
\]

is dimensionless and satisfies

\[
\left|
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R)
\right| \le 1.
\]

### C2. `C^2` regularity of the guard

Since `S,N \in C^2(I)` and `N>0`, the quotient `u=S/N` lies in `C^2(I)`.
Because

\[
\mathcal B(x)=\frac{x}{\sqrt{1+x^2}}
\]

is smooth on all of `\mathbb R`, the composed guard

\[
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}
=
\mathcal B\circ u
\]

also lies in `C^2(I)`.

So the derivative formulas written in
`DOWNSTREAM_ANALYTIC_GUARD_EXPANSION_NOTE_20260606.md`
are not free symbolic gestures.
They are lawful on the admitted class.

### C3. Vanishing on radius-only collapse

If the candidate lies entirely in the radius-only image,

\[
\mathcal M \in \mathrm{Im}(\Pi_r),
\]

then

\[
S(R)\equiv 0
\Longrightarrow
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R)\equiv 0.
\]

So the radius-only collapse prohibition is not merely verbal.
It holds analytically on the admitted class.

### C4. Well-posed radial carrier

Because `gamma_*` has potential units and the guard is dimensionless,

\[
\Phi_{\mathrm{white}} \in C^2(I)
\]

with the correct gravitational-potential unit.

Therefore the radial operator

\[
\mathcal L_R[\Phi_{\mathrm{white}}]
=
\frac{1}{R}\frac{d}{dR}
\left(
R\frac{d\Phi_{\mathrm{white}}}{dR}
\right)
\]

is mathematically meaningful wherever the admitted interval excludes the usual
cylindrical singular point or carries the declared regularity rule there.

### C5. Well-posed lifted conservative surface

If `\Xi \in C^2(\Omega)` with `\Xi(R,\varphi,0)=1`, then

\[
\Phi_{\mathrm{white}}^{\mathrm{complete}}(R,\varphi,z)
=
\gamma_\star\,
\Xi(R,\varphi,z)\,
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R)
\]

is a well-defined `C^2` lifted carrier on the admitted local domain.

Hence

\[
\rho_{\mathrm{eff}}^{\mathrm{white}}
=
\frac{1}{4\pi G_{\mathrm{review}}}
\nabla^2 \Phi_{\mathrm{white}}^{\mathrm{complete}}
\]

exists as a classical effective-source surface on that same admitted domain.

## 4. What this closes

This note closes a narrower but real deduction route:

- "the packet wrote one explicit guard expansion, but the guard still seems to
  float over an unconstrained symbolic input class."

That reading is no longer fair.

The present public route already exposes:

- one bounded governed carrier family,
- one no-widening rule,
- one positive normalization requirement,
- one minimal regularity class,
- and one lawful radial-plus-lifted carrier consequence.

## 5. What still remains later

This note does **not** yet claim:

- one final upstream proof that the full parent-law source stack uniquely
  materializes the whole admissible class,
- one final comparative-family theorem above the no-widening boundary,
- one final rank verdict for `gamma_*`,
- or one all-regime / strong-field closure.

Those remain later work.

But the remaining fair deduction is now narrower:

- not "the current white guard lacks an admitted mathematical habitat,"

but:

- "the current white guard has a bounded admitted habitat, while stronger
  upstream or all-regime theorems remain later."

## Bottom line

The white guard is no longer only:

- one explicit formula.

It is now also:

- one explicit formula living on a bounded admitted class,
- with positive normalization,
- regularity conditions,
- no-widening discipline,
- and lawful radial / lifted carrier consequences.

That is not final white sovereignty.

But it is a rarer and stronger mathematical posture than a loose review-only
equation surface.
