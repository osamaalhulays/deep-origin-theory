# Residual Reopening Branch Full Closure Note

Date: `2026-06-09`

Status: `bounded packet-facing cross-archive closure`

Purpose:

This note absorbs the full residual reopening branch after explicit
compression of:

- the active residual quality-`1` reopening triad
- the residual quality-`1` reserve triplet
- the bounded quality-`2` sidecar

It should be read after:

- `RESIDUAL_QUALITY1_REOPENING_TRIAD_CLOSURE_NOTE_20260609.md`
- `UGC05253_BOUNDED_QUALITY2_SIDECAR_ENTRY_NOTE_20260609.md`

Machine-readable companion:

- `RESIDUAL_REOPENING_BRANCH_FULL_CLOSURE_V1.json`

## Short verdict

The residual reopening branch is no longer a loose tail.

It now closes as an explicit seven-witness governed block:

- `UGC06786`
- `NGC2903`
- `NGC6674`
- `NGC5033`
- `UGC02487`
- `UGC03205`
- `UGC05253`

All seven remain anti-`QCT` under the named matched-nuisance surfaces.

## 1. Full branch closure summary

The full residual reopening branch now carries combined burden:

- combined public `Delta AIC_total = +51062.13353371295`
- combined faithful `Delta AIC_total = +41425.17318172108`
- combined component-aware `Delta AIC_total = +45175.52967601052`
- combined component-aware shift = `+3750.3564942894284`
- full Hubble-flow-sensitive body share = `40.86638502776014%`
- giant-spiral head share = `26.78651848860453%`

## 2. Meaning

This does **not** settle the whole empirical court.

But it does remove the remaining ambiguity inside the residual branch and
turn it into one explicit governed matched-nuisance body rather than one
loose residual tail.

## 3. What this does not authorize

This note does **not** authorize the claims that:

- the whole empirical court is already settled
- this seven-witness closure alone ends the wider body-level question
- whole-family `MOND/QUMOND` closure is already complete

## 4. Next honest escalation

The next honest escalation is:

- whole-body closure of the Hubble-flow-sensitive body

## Best outward-safe reading

One mature outward-safe sentence is:

> The residual reopening branch now closes as an explicit seven-witness
> governed matched-nuisance block,
> with all seven witnesses remaining anti-`QCT` under the named surfaces,
> and the next honest step therefore moving to whole-body closure rather than
> more hidden branch work.
