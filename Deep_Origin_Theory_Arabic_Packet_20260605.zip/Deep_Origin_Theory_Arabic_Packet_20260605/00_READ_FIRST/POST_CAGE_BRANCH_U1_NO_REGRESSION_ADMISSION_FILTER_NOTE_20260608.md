# Post-Cage Branch U1 No-Regression Admission Filter Note

Date: `2026-06-08`

Purpose:

This note states one exact rule for the post-cage `U1` line:

- no new `U1` candidate counts as progress unless it preserves the gains
  already secured.

## Short verdict

A later `U1` candidate is not admitted just because it looks elegant or more
ambitious.

It must first pass one no-regression filter.

That means it must preserve:

1. the current packet stop line
2. the weak-field spine already earned
3. the rule/operator/probe/authority distinction
4. the single-carrier ownership discipline
5. the `U1 -> U2` pivot discipline

## 1. What it may not damage

No later `U1` candidate may silently damage any of the following:

- the current `O1/O2/O3` public closure reading
- the explicit routing of `O4/O5` above the packet
- the current weak-field continuity gains
- the distinction between bounded no-claim probe and promotable authority
- the honesty of the south side below full physical promotion

## 2. What it may not hide

No later `U1` candidate may survive by hiding:

- one second transport-bearing field
- one separate south field
- one external response-authority patch
- or one bridge carrier not truly owned by `Q`

If that happens, the route has already drifted out of clean `U1`.

## 3. What it may not borrow

No later `U1` candidate may close the authority gap by borrowing from:

- empirical fit
- observed-output calibration
- baryonic tuning
- halo fit
- or non-variational patchwork

That would be apparent progress but real regression.

## Bottom line

The next `U1` move should now be judged by two tests together:

- the minimum worksheet test
- the no-regression admission filter

Only if it passes both does it count as a true advance.
