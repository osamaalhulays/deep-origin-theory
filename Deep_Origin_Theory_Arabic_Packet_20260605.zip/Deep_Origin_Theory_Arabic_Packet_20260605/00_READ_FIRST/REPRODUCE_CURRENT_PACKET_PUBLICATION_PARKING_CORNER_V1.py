#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

REVIEW_FACE_PATH = HERE / "CURRENT_REVIEWER_FACING_REVIEW_LAUNCH_PACKET_FACE_V1.json"
FRONT_TO_EVIDENCE_SPINE_PATH = HERE / "CURRENT_REVIEWER_FACING_FRONT_TO_EVIDENCE_SPINE_V1.json"
COURT_STATE_ASCENT_PATH = HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_STATE_AND_ASCENT_SYNTHESIS_V1.json"
EMPIRICAL_TENSION_PATH = HERE / "CURRENT_REVIEWER_FACING_ROUTE_SPLIT_AND_FULL_BODY_EMPIRICAL_TENSION_V1.json"
POCKET_BOUNDARY_PATH = HERE / "CURRENT_REVIEWER_FACING_NARROW_QUALITY1_CONTINUATION_POCKET_BOUNDARY_V1.json"
LATE_KREIB_REAFFIRMATION_PATH = (
    HERE / "LATE_KREIB_JUNE9_STATUS_SURFACES_REAFFIRM_PACKET_COVERAGE_AND_POST_RESIDUAL_BRANCH_CARRY_FORWARD_V1.json"
)


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    review_face = load_json(REVIEW_FACE_PATH)
    front_to_evidence_spine = load_json(FRONT_TO_EVIDENCE_SPINE_PATH)
    court_state_ascent = load_json(COURT_STATE_ASCENT_PATH)
    empirical_tension = load_json(EMPIRICAL_TENSION_PATH)
    pocket_boundary = load_json(POCKET_BOUNDARY_PATH)
    late_kreib_reaffirmation = load_json(LATE_KREIB_REAFFIRMATION_PATH)

    consistency_checks = {
        "review_face_is_already_packet_contained_and_bounded": review_face["structural_reading"][
            "the_packet_now_has_one_first_page_review_face_before_the_reader_enters_the_evidence_spine"
        ],
        "front_to_evidence_route_is_already_short_and_explicit": front_to_evidence_spine[
            "structural_reading"
        ]["the_packet_now_has_one_short_front_to_evidence_descent_route"],
        "selected_court_is_already_one_readable_state_plus_ascent_object": court_state_ascent[
            "structural_reading"
        ]["the_selected_court_can_now_be_read_as_one_present_state_plus_one_governed_ascent_object"],
        "latest_rotation_tension_is_already_absorbed_packet_side": empirical_tension[
            "structural_reading"
        ][
            "the_packet_now_carries_one_compressed_surface_linking_the_local_ngc0247_route_split_to_the_much_larger_ten_witness_same_sign_body"
        ],
        "latest_three_case_pocket_boundary_is_already_absorbed_packet_side": pocket_boundary[
            "boundary_reading"
        ][
            "the_packet_does_not_yet_authorize_renaming_this_pocket_as_one_fresh_exact_three_witness_o7_block"
        ],
        "latest_kreib_refresh_still_reports_no_rescue_level_omission": (
            not late_kreib_reaffirmation["current_reading"]["new_rescue_level_packet_omission_found"]
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "publication_facing_reading_state_established",
        "surface": "current_packet_publication_reading_state",
        "publication_reading_state": {
            "selected_state_name": "review_object_route_and_latest_digests_are_packet_contained",
            "why_this_state_is_now_readable": [
                "the packet now has one explicit first-page review face for one bounded selected court",
                "the packet now has one short front-to-evidence descent route instead of one loose archive walk",
                "the selected court now reads as one present-state plus governed-ascent object rather than one scope destination only",
                "the latest Kreib sharpenings are no longer merely external remarks because both the route-split versus full-body tension and the three-case pocket boundary are now packet-contained",
                "the latest Kreib late-status sweep still reports no new rescue-level packet omission",
            ],
            "contained_surface_bundle": [
                "CURRENT_REVIEWER_FACING_REVIEW_LAUNCH_PACKET_FACE_V1.json",
                "CURRENT_REVIEWER_FACING_FRONT_TO_EVIDENCE_SPINE_V1.json",
                "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_STATE_AND_ASCENT_SYNTHESIS_V1.json",
                "CURRENT_REVIEWER_FACING_ROUTE_SPLIT_AND_FULL_BODY_EMPIRICAL_TENSION_V1.json",
                "CURRENT_REVIEWER_FACING_NARROW_QUALITY1_CONTINUATION_POCKET_BOUNDARY_V1.json",
                "LATE_KREIB_JUNE9_STATUS_SURFACES_REAFFIRM_PACKET_COVERAGE_AND_POST_RESIDUAL_BRANCH_CARRY_FORWARD_V1.json",
            ],
        },
        "what_follows_from_this_state": {
            "maintenance_priorities": [
                "wording polish without claim widening",
                "cross-link audit and duplicate suppression",
                "front-door ordering cleanup",
                "cold reviewer readability passes",
                "build audit zip regeneration and packaging verification",
            ],
            "future_revision_criteria": [
                "one genuinely new authoritative packet object",
                "one hard contradiction discovered inside the current packet",
                "one later materialized evidence bridge that changes the current reading rather than merely renaming it",
            ],
        },
        "what_this_state_is_not": [
            "whole-theory completion",
            "whole-family MOND_QUMOND closure",
            "full cosmology completion",
            "final north authority closure",
            "formal external acceptance",
        ],
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the packet now has one readable publication-facing state where publication cleanup can proceed without leaving a half-built reviewer route",
            "the latest Kreib gains are now metabolized inside the packet rather than hanging outside as unstated dependencies",
            "the packet now has one cleaner operational split between scientific widening and publication cleanup",
            "the reading state remains bounded below whole-family closure and other forbidden inflation lines",
        ],
        "not_supported_now": [
            "this reading state means scientific finality",
            "this reading state means whole-family MOND_QUMOND closure",
            "this reading state means peer-review acceptance is already earned",
            "future revision should be driven by phrasing appetite alone rather than by new evidence",
        ],
        "next_honest_continuation": [
            "treat this as the default publication-facing reading state for maintenance and release preparation until new evidence justifies revision",
            "from this point prefer cleaning wording ordering duplication and reviewer readability over adding fresh packet science by inertia",
        ],
    }

    output["verdict"] = (
        "CURRENT_PACKET_PUBLICATION_READING_STATE_CLOSED__THE_PACKET_NOW_HAS_ONE_READABLE_PUBLICATION_FACING_STATE_FROM_WHICH_MAINTENANCE_AND_RELEASE_PREPARATION_CAN_PROCEED_WITHOUT_LEAVING_THE_REVIEW_OBJECT_ROUTE_OR_LATE_KREIB_DIGESTS_UNSETTLED"
        if all(consistency_checks.values())
        else "CURRENT_PACKET_PUBLICATION_PARKING_CORNER_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
