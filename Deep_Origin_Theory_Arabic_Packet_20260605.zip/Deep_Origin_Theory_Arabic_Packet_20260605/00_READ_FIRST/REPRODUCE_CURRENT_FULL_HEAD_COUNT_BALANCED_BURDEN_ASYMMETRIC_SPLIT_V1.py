#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

FULL_HEAD_TOPOLOGY_PATH = HERE / "CURRENT_FULL_HEAD_ASYMMETRIC_TWO_COURT_TWO_LANE_TOPOLOGY_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def close_enough(left, right, tolerance=1e-9):
    return abs(left - right) <= tolerance


def main():
    topology = load_json(FULL_HEAD_TOPOLOGY_PATH)

    full_head = topology["full_head"]
    clean_anchor_court = topology["court_a_protected_clean_anchor_minority"]
    hubble_court = topology["court_b_hubble_flow_sensitive_body"]

    heptad = hubble_court["internal_lane_split"]["o7_reinforced_heptad"]
    pocket = hubble_court["internal_lane_split"]["current_nonoverlap_quality1_continuation_pocket"]
    repeated_singleton = clean_anchor_court["internal_lane_split"]["repeated_toward_qct_singleton"]
    clean_anchor_o7_triad = clean_anchor_court["internal_lane_split"]["o7_positive_spoiler_dispersion_triad"]

    complement_cases = sorted(
        set(clean_anchor_court["cases"]) | set(pocket["cases"])
    )
    complement_public_delta_aic_total = (
        clean_anchor_court["public_delta_aic_total"] + pocket["public_delta_aic_total"]
    )

    consistency_checks = {
        "full_head_case_count_is_fourteen": full_head["case_count"] == 14,
        "heptad_case_count_is_seven": heptad["case_count"] == 7,
        "complement_case_count_is_seven": len(complement_cases) == 7,
        "heptad_and_complement_split_the_head_evenly_by_count": heptad["case_count"]
        == len(complement_cases),
        "heptad_and_complement_are_disjoint": set(heptad["cases"]).isdisjoint(set(complement_cases)),
        "heptad_and_complement_exhaust_full_head": (
            set(heptad["cases"]) | set(complement_cases)
        ) == (
            set(clean_anchor_court["cases"]) | set(hubble_court["cases"])
        ),
        "complement_recombines_from_clean_anchor_quartet_and_pocket_triad": set(complement_cases)
        == (set(clean_anchor_court["cases"]) | set(pocket["cases"])),
        "complement_public_total_recombines_exactly": close_enough(
            complement_public_delta_aic_total,
            full_head["public_delta_aic_total"] - heptad["public_delta_aic_total"],
        ),
        "heptad_and_complement_public_totals_recombine_to_full_head": close_enough(
            heptad["public_delta_aic_total"] + complement_public_delta_aic_total,
            full_head["public_delta_aic_total"],
        ),
        "heptad_public_burden_is_strictly_larger_than_complement": (
            heptad["public_delta_aic_total"] > complement_public_delta_aic_total
        ),
        "heptad_public_burden_is_strictly_larger_than_whole_clean_anchor_court": (
            heptad["public_delta_aic_total"] > clean_anchor_court["public_delta_aic_total"]
        ),
        "heptad_public_burden_is_strictly_larger_than_pocket": (
            heptad["public_delta_aic_total"] > pocket["public_delta_aic_total"]
        ),
        "heptad_still_spans_four_o7_layers": heptad["distinct_o7_layer_count"] == 4,
        "pocket_remains_all_quality1_exact_qumond_protected": (
            pocket["all_cases_are_quality1"] and pocket["all_cases_have_exact_qumond_protection"]
        ),
        "clean_anchor_quartet_internal_count_is_four": clean_anchor_court["case_count"] == 4,
        "pocket_internal_count_is_three": pocket["case_count"] == 3,
    }

    output = {
        "date": "2026-06-09",
        "status": "bounded_packet_facing_count_balanced_burden_asymmetric_split",
        "surface": "current_full_head_count_balanced_burden_asymmetric_split",
        "full_head": full_head,
        "dominant_o7_reinforced_heptad": {
            **heptad,
            "fraction_of_full_head_case_count": heptad["case_count"] / full_head["case_count"],
            "fraction_of_full_head_public_delta_aic_total": heptad["public_delta_aic_total"]
            / full_head["public_delta_aic_total"],
        },
        "seven_case_complement": {
            "case_count": len(complement_cases),
            "cases": complement_cases,
            "public_delta_aic_total": complement_public_delta_aic_total,
            "fraction_of_full_head_case_count": len(complement_cases) / full_head["case_count"],
            "fraction_of_full_head_public_delta_aic_total": complement_public_delta_aic_total
            / full_head["public_delta_aic_total"],
            "internal_split": {
                "protected_clean_anchor_quartet": {
                    "case_count": clean_anchor_court["case_count"],
                    "cases": clean_anchor_court["cases"],
                    "public_delta_aic_total": clean_anchor_court["public_delta_aic_total"],
                    "fraction_of_full_head_public_delta_aic_total": clean_anchor_court[
                        "fraction_of_full_head_public_delta_aic_total"
                    ],
                    "internal_lane_split": {
                        "repeated_toward_qct_singleton": repeated_singleton["cases"],
                        "o7_positive_dispersion_triad": clean_anchor_o7_triad["cases"],
                    },
                },
                "localized_quality1_continuation_pocket": {
                    **pocket,
                    "fraction_of_full_head_public_delta_aic_total": pocket[
                        "fraction_of_full_head_public_delta_aic_total"
                    ],
                },
            },
        },
        "structural_reading": {
            "the_current_full_head_can_be_split_evenly_by_count_but_not_by_burden": True,
            "one_single_o7_reinforced_heptad_already_outweighs_the_other_seven_cases_combined": True,
            "the_other_seven_cases_do_not_form_one_rival_reinforced_block_but_a_quartet_plus_a_narrow_pocket": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the current full head is count-balanced at seven versus seven but burden-asymmetric",
            "one single O7-reinforced heptad already outweighs the other seven full-head cases combined",
            "the seven-case complement is not one rival coherent block but a protected quartet plus a narrow quality1 pocket",
            "the dominant heptad still spans four distinct O7 layers while the pocket remains exact-QUMOND-protected and localized",
        ],
        "not_supported_now": [
            "the two seven-case halves are symmetric in scientific weight",
            "the seven-case complement is one rival cross-lane reinforced block",
            "the current full head is already globally terminally settled",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_frontier": [
            "test whether the narrow three-witness pocket later joins the same O7 branch or remains permanently structurally separate",
            "extend the cross-observable court without collapsing this count-balanced burden-asymmetric split into one final theory verdict",
        ],
    }

    output["verdict"] = (
        "CURRENT_FULL_HEAD_COUNT_BALANCED_BURDEN_ASYMMETRIC_SPLIT_CLOSED__ONE_O7_REINFORCED_HEPTAD_EQUALS_HALF_THE_HEAD_BY_COUNT_BUT_OUTWEIGHS_THE_OTHER_SEVEN_CASES_COMBINED"
        if all(consistency_checks.values())
        else "CURRENT_FULL_HEAD_COUNT_BALANCED_BURDEN_ASYMMETRIC_SPLIT_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
