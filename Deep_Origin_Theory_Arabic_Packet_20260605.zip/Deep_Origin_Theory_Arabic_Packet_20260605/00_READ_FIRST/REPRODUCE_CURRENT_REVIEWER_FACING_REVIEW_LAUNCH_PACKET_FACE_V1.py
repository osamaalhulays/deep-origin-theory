#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

MASTER_FRONT_PATH = HERE / "CURRENT_REVIEWER_FACING_MASTER_FRONT_V1.json"
COURT_STATE_ASCENT_PATH = (
    HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_STATE_AND_ASCENT_SYNTHESIS_V1.json"
)
FRONT_TO_EVIDENCE_SPINE_PATH = HERE / "CURRENT_REVIEWER_FACING_FRONT_TO_EVIDENCE_SPINE_V1.json"
COURT_LAUNCH_FRONT_PATH = HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LAUNCH_FRONT_V1.json"
COURT_LANE_BOARD_PATH = (
    HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_STATUS_BOARD_V1.json"
)
COURT_LANE_LADDER_PATH = (
    HERE / "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_PROGRESSION_LADDER_V1.json"
)
PARITY_PROMOTION_PATH = HERE / "NGC0247_EXECUTED_PARITY_WITNESS_PROMOTION_BOUNDARY_V1.json"
HUBBLE_FLOW_CLOSURE_PATH = HERE / "HUBBLE_FLOW_SENSITIVE_BODY_FULL_CLOSURE_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    master_front = load_json(MASTER_FRONT_PATH)
    court_state_ascent = load_json(COURT_STATE_ASCENT_PATH)
    front_to_evidence = load_json(FRONT_TO_EVIDENCE_SPINE_PATH)
    court_launch_front = load_json(COURT_LAUNCH_FRONT_PATH)
    court_lane_board = load_json(COURT_LANE_BOARD_PATH)
    court_lane_ladder = load_json(COURT_LANE_LADDER_PATH)
    parity_promotion = load_json(PARITY_PROMOTION_PATH)
    hubble_flow_closure = load_json(HUBBLE_FLOW_CLOSURE_PATH)

    selected_scope = court_state_ascent["governing_court"]["selected_scope"]

    review_object = {
        "bounded_object_under_review": "selected_no_makeup_cross_observable_court_only",
        "selected_scope": selected_scope,
        "selected_scope_contains": court_state_ascent["governing_court"]["court_lanes"],
        "review_grade": "current_stage_bounded_public_review_only",
        "packet_face_claim": (
            "judge_whether_the_selected_court_is_honestly_presented_as_one_present_state_plus_"
            "governed_ascent_object_under_preserved_lane_distinctions"
        ),
    }

    reviewer_is_being_asked_to_judge = [
        "whether_the_packet_front_honestly_lands_on_one_selected_cross_observable_court",
        "whether_the_current_state_of_each_lane_inside_that_court_is_honestly_frozen",
        "whether_the_next_upgrade_rule_of_each_lane_inside_that_court_is_honestly_frozen",
        "whether_the_rotation_and_north_evidence_descents_support_that_court_without_claim_inflation",
    ]

    reviewer_is_not_being_asked_to_certify = [
        "whole_family_mond_qumond_closure",
        "full_cosmology_completion",
        "authority_closed_macs1206_north_ascent",
        "the_selected_court_as_already_fully_executed",
        "final_xi_continuity_across_all_shelves",
        "formal_external_acceptance",
    ]

    launch_route = {
        "entry_surface": "CURRENT_REVIEWER_FACING_MASTER_FRONT_V1.json",
        "descent_surface": "CURRENT_REVIEWER_FACING_FRONT_TO_EVIDENCE_SPINE_V1.json",
        "court_object_surface": (
            "CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_STATE_AND_ASCENT_SYNTHESIS_V1.json"
        ),
        "rotation_evidence_surfaces": front_to_evidence["reviewer_facing_front_to_evidence_spine"][
            "rotation_evidence_bundle"
        ]["subbundles"],
        "north_evidence_surfaces": front_to_evidence["reviewer_facing_front_to_evidence_spine"][
            "north_evidence_bundle"
        ]["primary_surfaces"],
    }

    review_burden_minimization = {
        "why_the_review_burden_is_bounded": [
            "the_review_object_is_one_selected_court_not_the_whole_packet",
            "the_court_is_already_compressed_to_one_launch_front_one_state_board_and_one_ascent_ladder",
            "the_reviewer_now_has_one_short_front_to_evidence_spine_instead_of_one_loose_deep_archive",
            "the_north_side_remains_openly_authority_gated_instead_of_being_smuggled_as_closed",
        ],
        "named_live_numeric_anchors": {
            "ngc0247_faithful_delta_aic_total": parity_promotion["live_matched_nuisance_witness"][
                "faithful_delta_aic_total"
            ],
            "ngc0247_component_aware_delta_aic_total": parity_promotion[
                "live_matched_nuisance_witness"
            ]["component_aware_delta_aic_total"],
            "rotation_fixed_public_qumond_crosscheck_count_with_zero_public_gap": (
                court_launch_front["rotation_side"][
                    "fixed_public_qumond_crosscheck_count_with_zero_public_gap"
                ]
            ),
            "ten_witness_faithful_delta_aic_total": hubble_flow_closure["combined_burden"][
                "faithful_delta_aic_total"
            ],
            "best_visible_member_pte": court_launch_front["north_rail"][
                "best_visible_member_pte"
            ],
        },
    }

    stopping_lines = {
        "selected_court_not_already_executed": (
            "the selected court is already fully executed"
        ),
        "north_not_already_closed": "the north rail is already authority-closed",
        "uniform_maturity_forbidden": "all four lanes are already mature in the same sense",
        "whole_family_closure_forbidden": "Whole-family MOND_QUMOND closure",
    }

    consistency_checks = {
        "master_front_and_review_face_share_the_same_selected_court": (
            master_front["selected_next_court"]["selected_scope"] == selected_scope
        ),
        "court_object_and_review_face_share_the_same_four_lanes": (
            court_state_ascent["governing_court"]["court_lanes"]
            == court_lane_board["board_sequence"]
            == court_lane_ladder["ladder_sequence"]
        ),
        "front_to_evidence_spine_still_descends_through_the_same_selected_court": (
            front_to_evidence["reviewer_facing_front_to_evidence_spine"]["court_object_entry"][
                "court_lanes"
            ]
            == court_state_ascent["governing_court"]["court_lanes"]
        ),
        "review_face_remains_bounded_below_whole_family_closure": (
            "Whole-family MOND_QUMOND closure" in master_front["not_supported_now"]
            and "Whole-family MOND_QUMOND closure" in court_state_ascent["not_supported_now"]
            and "Whole-family MOND_QUMOND closure" in front_to_evidence["not_supported_now"]
        ),
        "north_side_remains_same_kernel_and_authority_gated": (
            court_launch_front["north_rail"]["same_kernel_only"]
            and court_lane_board["lane_status_board"][
                "same_kernel_macs1206_secondary_deltasigma_rail"
            ]["lane_status"]
            == "same_kernel_locked_authority_gated_rail"
        ),
        "rotation_side_remains_split_between_matched_nuisance_and_best_dressed_evidence": (
            parity_promotion["witness"] == "SPARC_NGC0247"
            and hubble_flow_closure["uniform_direction"][
                "hubble_flow_sensitive_body_is_now_closed_as_a_governed_block"
            ]
        ),
        "latest_rotation_tension_and_pocket_boundary_digests_are_visible_on_the_review_route": (
            "CURRENT_REVIEWER_FACING_ROUTE_SPLIT_AND_FULL_BODY_EMPIRICAL_TENSION_V1.json"
            in launch_route["rotation_evidence_surfaces"]["matched_nuisance_parity_evidence"][
                "primary_surfaces"
            ]
            and "CURRENT_REVIEWER_FACING_NARROW_QUALITY1_CONTINUATION_POCKET_BOUNDARY_V1.json"
            in launch_route["rotation_evidence_surfaces"]["best_dressed_hardening_evidence"][
                "primary_surfaces"
            ]
        ),
        "review_burden_is_actually_shortened_by_the_spine": (
            front_to_evidence["structural_reading"][
                "the_packet_now_has_one_short_front_to_evidence_descent_route"
            ]
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "packet_contained_reviewer_facing_review_launch_packet_face",
        "surface": "current_reviewer_facing_review_launch_packet_face",
        "review_object": review_object,
        "reviewer_is_being_asked_to_judge": reviewer_is_being_asked_to_judge,
        "reviewer_is_not_being_asked_to_certify": reviewer_is_not_being_asked_to_certify,
        "launch_route": launch_route,
        "review_burden_minimization": review_burden_minimization,
        "stopping_lines": stopping_lines,
        "structural_reading": {
            "the_packet_now_has_one_first_page_review_face_before_the_reader_enters_the_evidence_spine": True,
            "the_review_face_binds_object_scope_route_scope_and_claim_scope_on_one_surface": True,
            "the_reviewer_can_now_see_in_one_place_what_is_being_tested_and_what_is_explicitly_out_of_scope": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the packet now has one reviewer-facing review-launch face rather than only a front and a later evidence spine",
            "the review object is now explicitly one selected court rather than one vague whole-packet challenge",
            "the review route is now explicitly bounded before deeper evidence descent begins",
            "the review route now visibly includes the packet-contained local-route-split-versus-full-body tension digest and the packet-contained narrow-pocket boundary digest",
            "the stopping lines are now visible on the same surface as the review invitation itself",
        ],
        "not_supported_now": [
            "the reviewer is being asked to certify the whole theory or the whole packet at once",
            "the selected court is already fully executed",
            "the north rail is already authority-closed",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_continuation": [
            "use_this_review_face_as_the_default_first_page_before_the_master_front_and_the_front_to_evidence_spine",
            "keep_the_review_object_bounded_to_the_selected_court_until_lane_specific_evidence_is_opened",
        ],
    }

    output["verdict"] = (
        "CURRENT_REVIEWER_FACING_REVIEW_LAUNCH_PACKET_FACE_CLOSED__THE_PACKET_NOW_HAS_ONE_FIRST_PAGE_REVIEW_FACE_THAT_BINDS_THE_BOUNDED_REVIEW_OBJECT_THE_DESCENT_ROUTE_AND_THE_STOPPING_LINES_BEFORE_DEEPER_EVIDENCE_OPENS"
        if all(consistency_checks.values())
        else "CURRENT_REVIEWER_FACING_REVIEW_LAUNCH_PACKET_FACE_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
