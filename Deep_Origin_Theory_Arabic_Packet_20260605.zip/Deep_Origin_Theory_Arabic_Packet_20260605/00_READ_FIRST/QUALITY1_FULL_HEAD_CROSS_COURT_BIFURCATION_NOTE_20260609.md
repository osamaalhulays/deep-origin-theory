# Quality-`1` Full-Head Cross-Court Bifurcation Note

Date: `2026-06-09`

Status: `packet-contained court-membership clarification`

Purpose:

After the packet had already shown that:

- the protected clean-anchor minority is all quality `1`,
- and the Hubble-flow-sensitive hardening body is not a `quality-2` artifact,

one sharper conclusion became available:

- quality `1` alone does not settle the current full-head reading either.

This note closes that point explicitly.

Machine-readable companion:

- `QUALITY1_FULL_HEAD_CROSS_COURT_BIFURCATION_V1.json`

Reproduction script:

- `REPRODUCE_QUALITY1_FULL_HEAD_CROSS_COURT_BIFURCATION_V1.py`

It should be read after:

- `CLEAN_ANCHOR_MINORITY_VS_FULLY_CLOSED_HUBBLE_FLOW_SENSITIVE_BODY_CROSS_COURT_SYNTHESIS_NOTE_20260609.md`
- `HUBBLE_FLOW_SENSITIVE_BODY_QUALITY_STRATIFIED_HARDENING_NOTE_20260609.md`

## Short verdict

Quality `1` alone does not settle the current full-head verdict.

Within the current quality-`1` slice of the giant-spiral head:

- one protected clean-anchor minority court still exists
- one larger Hubble-flow-sensitive quality-`1` subgroup also exists

The current quality-`1` full-head slice carries:

- `11` named witnesses
- total public burden `142010.45220036965`

That quality-`1` slice is already bifurcated into:

- clean-anchor quality-`1` court = `65677.25633547574`
- Hubble-flow-sensitive quality-`1` subgroup = `76333.1958648939`

So the current split inside quality `1` itself is:

- clean-anchor side = `46.24818477643351%`
- Hubble-flow-sensitive side = `53.75181522356649%`

## 1. The quality-`1` clean-anchor court

The quality-`1` clean-anchor court carries:

- `4` cases
- `NGC5055`
- `NGC3198`
- `NGC7331`
- `NGC2841`
- public burden `65677.25633547574`
- all non-Hubble-flow anchored
- all visibly multiseed stable

So one real quality-`1` protected minority survives on the clean-anchor side.

## 2. The quality-`1` Hubble-flow-sensitive subgroup

The quality-`1` members inside the Hubble-flow-sensitive body carry:

- `7` cases
- `UGC09133`
- `UGC06786`
- `NGC2903`
- `NGC6674`
- `NGC5033`
- `UGC02487`
- `UGC03205`
- public burden `76333.1958648939`
- component-aware burden `57972.45670655153`
- component-aware shift `+5002.012048760745`

All seven harden uniformly away from `QCT` under component-aware parity.

So a larger quality-`1` Hubble-flow-sensitive hardening subgroup also survives.

## 3. Meaning

This means the current full-head picture cannot be reduced to:

- "`quality-1` means clean-anchor survival,"

or to:

- "`quality-1` means hardening against `QCT`."

Both are already present.

The stronger present organizer is therefore not raw quality `1` status alone,
but court membership:

- clean-anchor minority membership
- versus Hubble-flow-sensitive body membership

## 4. Why this matters

This closes one natural reviewer escape hatch.

The packet already blocked:

- "`hardening` is just a `quality-2` tail effect."

This note blocks the nearby fallback:

- "fine, but `quality-1` alone still tells the story."

No.

The quality-`1` slice itself is already bifurcated.

## 5. What this does not authorize

This note does **not** authorize the claims that:

- whole-family `MOND/QUMOND` closure already exists
- every later quality-`1` case must follow one side
- Hubble-flow sensitivity is already a final theorem rather than the stronger
  current empirical organizer

## Best outward-safe reading

One mature outward-safe sentence is:

> The current giant-spiral head cannot be reduced to a raw quality-`1`
> explanation. The quality-`1` slice itself is already bifurcated between a
> protected clean-anchor minority and a larger Hubble-flow-sensitive subgroup
> that hardens uniformly away from `QCT`. So the stronger present organizer is
> court membership, not quality flag alone.
