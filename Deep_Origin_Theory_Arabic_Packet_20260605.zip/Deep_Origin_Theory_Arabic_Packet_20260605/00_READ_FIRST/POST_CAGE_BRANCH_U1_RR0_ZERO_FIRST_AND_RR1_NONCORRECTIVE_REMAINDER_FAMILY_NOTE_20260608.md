# Post-Cage Branch U1 RR0 Zero-First And RR1 Noncorrective Remainder Family Note

Date: `2026-06-08`

Purpose:

This note freezes the first exact narrowing order for the same-carrier
remainder `R_res[g,ψ,Q]`.

## Short verdict

The live line should now use the following exact order:

1. `RR0 = zero_remainder_first_test`
2. `RR1 = conditional_noncorrective_factorized_same_carrier_remainder`

with:

`R_res^(RR0)[g,ψ,Q] = 0`

as the first recommended test,

and only if that fails lawfully may the line reopen:

`R_res^(RR1)[g,ψ,Q] = Q U_res^perp[g,ψ,Q]`

This means:

- zero first
- factorized same-carrier remainder second
- hidden second-sector parking never

## Why `RR0` comes first

The absorbed evidence does not justify a generous remainder.

It instead shows:

1. explicit ledger heads already exist
2. Kreib keeps `no_residual_derived_correction`
3. Kreib still does not give clean authority to relabel unresolved
   metric/constraint leftovers as owned same-carrier remainder

So the first honest test is to set the remainder to zero and only reopen it
if that zero-first route fails lawfully.

## What `RR1` may be

If `RR0` fails,
the only admissible next class is:

`R_res^(RR1)[g,ψ,Q] = Q U_res^perp[g,ψ,Q]`

with strict guards:

- source-governed only
- same-carrier only
- no independent derivatives on `Q`
- no fitted residual correction
- no diagnostic-to-law inflation
- no metric/constraint laundering
- no independent south dynamics
- no independent south transport

## South and transport consequence

Under this order:

1. `BS1` should first be tested with zero residual face
2. transport should first be audited with no remainder sector at all
3. only a lawful forced failure may reopen `RR1`

This makes both the south face and the transport audit stricter and cleaner.

## What breaks it

Reject immediately if:

- `RR0` is skipped without lawful failure
- `RR1` is opened for convenience
- `U_res^perp` launders unresolved leftovers
- `U_res^perp` carries fitted residual corrections
- `RR1` reopens public gas authority
- or `RR1` hides future second-sector architecture

That would no longer be clean `U1`.

## Bottom line

The first exact remainder order is now frozen:

- `RR0` first
- `RR1` second only if forced

with one strict safety law:

- no residual-derived correction
- no unresolved-leftover laundering
- no gas-authority reopening
- no hidden second-sector parking
