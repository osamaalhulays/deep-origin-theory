#!/usr/bin/env python3
import csv
import json
import re
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PACKET_ROOT = HERE.parent
LEDGER_PATH = PACKET_ROOT / "SHA256SUMS.txt"
CURRENT_STACK_SCRIPT = HERE / "REPRODUCE_NGC0247_CURRENT_STACK_V1.py"
PHASE2_SCRIPT = HERE / "REPRODUCE_NGC0247_PHASE2_CURRENT_QCT_ROW_COMPARATOR_V1.py"
READINESS_GATE_PATH = HERE / "NGC0247_PARITY_READINESS_GATE_V1.json"
HISTORICAL_CONTROL_PATH = HERE / "NGC0247_HISTORICAL_PHASE2_SAME_CONVENTION_CONTROL_V1.json"
CURRENT_ROW_COMPARATOR_PATH = HERE / "NGC0247_CURRENT_ROW_COMPARATOR__QCT_AND_FIXED_QUMOND__V1.csv"
CASE_LEVEL_APPENDIX_PATH = HERE / "CASE_LEVEL_BENCHMARK_APPENDIX__NGC0247__ARTIFACT_EMULATOR_V1.md"

ESSENTIAL_OBJECTS = {
    "phase2_source_case": HERE / "NGC0247_PHASE2_SOURCE_CASE_V1.json",
    "phase2_prediction": HERE / "NGC0247_PHASE2_PRED_ONE_V1.ndjson",
    "current_replication_rows": HERE / "NGC0247_CURRENT_REPLICATION_ROWS_V1.csv",
    "current_row_comparator": CURRENT_ROW_COMPARATOR_PATH,
    "current_stack_script": CURRENT_STACK_SCRIPT,
    "phase2_row_script": PHASE2_SCRIPT,
    "parity_readiness_gate_json": READINESS_GATE_PATH,
    "historical_same_convention_control_json": HISTORICAL_CONTROL_PATH,
    "tri_comparator_note": HERE / "NGC0247_CANONICAL_TRI_COMPARATOR_AND_CLAIM_BOUNDARY_NOTE_20260606.md",
    "model_lock_card": HERE / "NGC0247_MODEL_LOCK_CARD_V1.md",
    "current_replication_capsule": HERE / "NGC0247_CURRENT_REPLICATION_CAPSULE_V1.md",
    "case_level_benchmark_appendix": CASE_LEVEL_APPENDIX_PATH,
}

CASE_LEVEL_KEY_MAP = {
    "Historical bounded ML lane": "historical_bounded_ml_lane",
    "Historical bounded `oracle10` ceiling lane": "historical_bounded_oracle10_ceiling_lane",
    "Preserved Phase-2 single-case case-lock lane": "preserved_phase2_single_case_caselock_lane",
}


def run_json_script(script_path: Path):
    output = subprocess.check_output(
        [sys.executable, str(script_path)],
        cwd=str(HERE),
        text=True,
    )
    return json.loads(output)


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_rows(csv_path: Path):
    with csv_path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def as_float(row, key):
    return float(row[key])


def count_signs(values):
    negative = sum(1 for value in values if value < 0.0)
    positive = sum(1 for value in values if value > 0.0)
    zero = len(values) - negative - positive
    return {
        "negative": negative,
        "positive": positive,
        "zero": zero,
        "label": f"{negative} negative / {positive} positive / {zero} zero",
    }


def summarize_lane(rows, residual_key, chi2_key):
    residuals = [as_float(row, residual_key) for row in rows]
    chi2_terms = [as_float(row, chi2_key) for row in rows]
    signs = count_signs(residuals)
    return {
        "row_count": len(rows),
        "residual_signs": signs,
        "mean_abs_residual_km_s": sum(abs(value) for value in residuals) / len(residuals),
        "max_abs_residual_km_s": max(abs(value) for value in residuals),
        "chi2_total": sum(chi2_terms),
    }


def load_ledger_hashes(ledger_path: Path):
    hashes = {
        "exact": {},
        "entries": [],
        "basename_counts": {},
    }
    for line in ledger_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        digest, path_text = stripped.split(None, 1)
        normalized_path = path_text.strip()
        basename = Path(normalized_path).name
        hashes["exact"][normalized_path] = digest
        hashes["entries"].append((normalized_path, digest))
        hashes["basename_counts"][basename] = hashes["basename_counts"].get(basename, 0) + 1
    return hashes


def lookup_ledger_digest(ledger_hashes, path: Path):
    relative = path.relative_to(PACKET_ROOT).as_posix()
    exact_candidates = (
        str(path.resolve()),
        f"./{relative}",
        relative,
    )

    for candidate in exact_candidates:
        digest = ledger_hashes["exact"].get(candidate)
        if digest is not None:
            return digest

    suffix_matches = {
        digest
        for entry_path, digest in ledger_hashes["entries"]
        if entry_path.endswith(relative) or entry_path.endswith(f"/{relative}")
    }
    if len(suffix_matches) == 1:
        return next(iter(suffix_matches))

    basename = path.name
    if ledger_hashes["basename_counts"].get(basename) == 1:
        basename_matches = {
            digest
            for entry_path, digest in ledger_hashes["entries"]
            if Path(entry_path).name == basename
        }
        if len(basename_matches) == 1:
            return next(iter(basename_matches))

    return None


def collect_integrity_objects(ledger_hashes):
    objects = {}
    all_present = True
    all_hash_anchored = True

    for key, path in ESSENTIAL_OBJECTS.items():
        exists = path.exists()
        sha256 = lookup_ledger_digest(ledger_hashes, path)
        all_present = all_present and exists
        all_hash_anchored = all_hash_anchored and (sha256 is not None)
        objects[key] = {
            "path": path.name,
            "exists": exists,
            "sha256": sha256,
        }

    return {
        "all_essential_objects_present": all_present,
        "all_essential_objects_hash_anchored": all_hash_anchored,
        "essential_object_count": len(objects),
        "objects": objects,
    }


def parse_case_level_bridge(markdown_path: Path):
    text = markdown_path.read_text(encoding="utf-8")
    multiseed_match = re.search(r"preserved multiseed set = `([^`]+)`", text)
    if not multiseed_match:
        raise SystemExit("could not locate multiseed set")

    multiseed_set = [int(part.strip()) for part in multiseed_match.group(1).split(",")]

    lanes = {}
    for line in text.splitlines():
        if not line.startswith("| "):
            continue
        cells = [cell.strip() for cell in line.split("|")[1:-1]]
        if len(cells) != 7 or cells[0] == "Lane":
            continue
        lane_label = cells[0]
        mapped_key = CASE_LEVEL_KEY_MAP.get(lane_label)
        if mapped_key is None:
            continue
        lanes[mapped_key] = {
            "lane_label": lane_label,
            "benchmark_object": cells[1].replace("`", ""),
            "qct_loglike_obs_only": float(cells[2].replace("`", "")),
            "qumond_loglike_obs_only": float(cells[3].replace("`", "")),
            "delta_aic_total": float(cells[4].replace("`", "")),
            "delta_bic_total": float(cells[5].replace("`", "")),
            "reading": cells[6],
        }

    if len(lanes) != 3:
        raise SystemExit("case-level bridge table parse incomplete")

    return {
        "preserved_multiseed_set": multiseed_set,
        "seed_count": len(multiseed_set),
        "five_seed_stability_visible": len(multiseed_set) == 5,
        "case_level_lanes": lanes,
    }


def main():
    rows = load_rows(CURRENT_ROW_COMPARATOR_PATH)
    current_stack = run_json_script(CURRENT_STACK_SCRIPT)
    phase2 = run_json_script(PHASE2_SCRIPT)
    readiness = load_json(READINESS_GATE_PATH)
    historical_control = load_json(HISTORICAL_CONTROL_PATH)
    ledger_hashes = load_ledger_hashes(LEDGER_PATH)
    integrity = collect_integrity_objects(ledger_hashes)
    case_level_bridge = parse_case_level_bridge(CASE_LEVEL_APPENDIX_PATH)

    fixed_qumond_lane = summarize_lane(
        rows,
        residual_key="resid_QUMOND_fixed_km_s",
        chi2_key="chi2_QUMOND_fixed_term",
    )
    current_qct_lane = summarize_lane(
        rows,
        residual_key="resid_QCT_current_km_s",
        chi2_key="chi2_QCT_obs_only_term",
    )
    current_qct_lane["chi2_obs_model_total"] = sum(
        as_float(row, "chi2_QCT_obs_model_term") for row in rows
    )
    benchmark_replay_lane = summarize_lane(
        rows,
        residual_key="resid_QUMOND_phase2_benchmark_km_s",
        chi2_key="chi2_QUMOND_phase2_benchmark_term",
    )

    output = {
        "surface": "ngc0247_parity_ready_pilot_object",
        "case_id": "NGC0247",
        "row_count": len(rows),
        "integrity": integrity,
        "numeric_readiness_gate_closed": readiness["numeric_readiness_gate_closed"],
        "rowwise_lanes": {
            "fixed_qumond_source_locked": fixed_qumond_lane,
            "current_reconstructed_qct": {
                **current_qct_lane,
                "upsilon_phase2_seed42": phase2["upsilon_phase2_seed42"],
                "ll_qct_obs_only": phase2["ll_qct_obs_only"],
                "ll_qct_obs_model": phase2["ll_qct_obs_model"],
            },
            "historical_phase2_benchmark_replay": {
                **benchmark_replay_lane,
                "upsilon_qumond_phase2_seed42": phase2["upsilon_qumond_phase2_seed42"],
                "ll_qumond_benchmark_obs_only": phase2["ll_qumond_benchmark_obs_only"],
            },
        },
        "case_level_bridge": case_level_bridge,
        "parity_readiness_gate": {
            "numeric_readiness_gate_closed": readiness["numeric_readiness_gate_closed"],
            "verification": readiness["verification"],
            "historical_lane_recovered_nuisances": readiness["historical_lane_recovered_nuisances"],
        },
        "historical_same_convention_control": {
            "friendliest_shell_minus_historical_mixed_delta_aic": historical_control[
                "friendliest_shell_minus_historical_mixed_delta_aic"
            ],
            "equal_free_obs_only_delta_aic": historical_control["same_convention_shells"][
                "equal_free_obs_only"
            ]["delta_aic"],
            "verdict": historical_control["verdict"],
        },
        "remaining_open_items": [
            "freeze distance replay policy",
            "freeze inclination replay policy",
            "freeze quality-flag aware masking rule",
            "execute the lawful matched-nuisance parity replay itself",
            "freeze one promotable same-convention scoring shell above the fenced historical control",
            "recover the clean original fitted-Y artifact or replace it with a stronger clean current-production closure",
        ],
        "claim_boundary": {
            "does_claim": [
                "NGC0247 is now materialized as one packet-contained parity-ready pilot object",
                "the first reviewer-facing parity precursor is now a named machine-checkable object rather than only prose",
                "the historical same-convention shell is fenced as a negative control instead of the first scored parity artifact",
            ],
            "does_not_claim": [
                "the matched-nuisance parity replay is already executed",
                "the promotable same-convention scoring shell is already frozen",
                "the original fitted-Y provenance gap is already closed",
                "whole-family MOND/QUMOND closure is finished",
            ],
        },
    }

    output["pilot_object_materialized"] = (
        integrity["all_essential_objects_present"]
        and integrity["all_essential_objects_hash_anchored"]
        and readiness["numeric_readiness_gate_closed"] is True
        and readiness["verification"]["current_stack_verified"] is True
        and readiness["verification"]["phase2_row_comparator_verified"] is True
        and case_level_bridge["five_seed_stability_visible"] is True
        and historical_control["verdict"]
        == "HISTORICAL_PHASE2_SAME_CONVENTION_CONTROL_IS_STRONGLY_ANTI_QCT__DO_NOT_PROMOTE_AS_REVIEWER_FACING_PARITY_ARTIFACT"
    )

    output["verdict"] = (
        "NGC0247_PARITY_READY_PILOT_OBJECT_MATERIALIZED__PROMOTE_THIS_OBJECT_NOT_THE_HISTORICAL_CONTROL_SHELL"
        if output["pilot_object_materialized"]
        else "NGC0247_PARITY_READY_PILOT_OBJECT_NOT_YET_MATERIALIZED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
