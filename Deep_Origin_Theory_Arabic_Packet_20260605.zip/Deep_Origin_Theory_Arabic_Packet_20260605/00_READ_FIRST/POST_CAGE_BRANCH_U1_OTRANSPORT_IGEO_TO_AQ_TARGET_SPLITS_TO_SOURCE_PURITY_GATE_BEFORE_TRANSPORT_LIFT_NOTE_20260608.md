# Post-Cage Branch U1 O_transport I_geo->A_Q Target Splits To Source-Purity Gate Before Transport Lift Note

Date: `2026-06-08`

Status: `bounded packet-facing absorption`

## Purpose

The live `U1` route now already carries:

1. `O_transport` as the local execution owner
2. its first local tooth as one `I_geo`-mediated carrier-law freeze
3. its next exact target as one source-governed
   `I_geo -> A_Q` carrier-law certification

So the next exact question becomes:

- inside that certification target itself,
  what comes first

## Candidate readings

The target could in principle open first through:

1. immediate transport-lift of `A_Q -> T_Q ownership`
2. prior source-purity certification of the `I_geo` lane
3. one symmetric joint certification of purity and transport-lift at once

## Short verdict

The current record best supports:

`first gate inside I_geo -> A_Q certification = I_geo source-purity gate`

This means the next exact gate is not yet:

- final transport-lift,
  and not yet
- one full joint certification of everything at once.

It is first:

- certify that `I_geo` is genuinely source-governed at register-definition
  grade

with the exact negative conditions already visible in the record:

1. no direct `Q` dependence at register-definition grade
2. no empirical calibration or baryonic tuning
3. no hidden second carrier
4. no non-variational patch

Only after that gate survives cleanly does the route lawfully advance to:

- `A_Q -> T_Q` transport-lift inside the same certified lane

That is a real gain because it turns the next attack from one broad ambition
into one exact gate.

## 1. Why transport-lift does not come first

The current route already knows what transport-lift wants to do:

- support `A_Q` as the first real `T_Q` ownership pivot

But the same route also already knows that this lift must remain:

- source-governed
- single-carrier honest
- no-fit
- no-patch

So transport-lift cannot honestly be the first gate.

It depends first on whether the lane carrying it is clean at definition grade.

That lane is:

- `I_geo`

## 2. Why source-purity is already the repo-native first gate

The `IR1` scaffold already fixed exact pass criteria for the shared register:

1. the slots `I_amp`, `I_mix`, and `I_geo` are all source-governed
2. no slot requires direct `Q` dependence at register-definition grade
3. no slot requires empirical calibration, halo fit, or baryonic tuning
4. the induced image does not hide one second carrier

Those are not generic preferences.

They are already the acceptance grammar for the register layer itself.

So the first honest gate inside the `I_geo -> A_Q` target is not invented
here.

It is already implied by the standing `IR1` contract.

## 3. Exact meaning of the `I_geo` source-purity gate

The gate asks one narrower question:

- can `I_geo[g,ψ]` stand as one genuinely source-governed geometry-response
  moderation register before any carrier-law lift is claimed from it

The gate fails immediately if `I_geo` needs:

1. direct feedback from `Q` at register-definition grade
2. empirical tuning or observed-output borrowing
3. one second independent carrier hidden inside the moderation lane
4. one non-variational exchange or helper patch

If any of those appears,
the lane is not clean enough to bear the first local transport certification.

## 4. Why joint certification is too early

The temptation would be to say:

- let us certify `I_geo` purity and `A_Q -> T_Q` lift together.

That is too early.

Why:

1. the route already preserves one order:
   register neck before stronger headwise freeze
2. the transport front already preserves one order:
   local tooth before full closure
3. the carrier side already preserves one order:
   `A_Q` first, `M_Q` later

So the clean next gate should preserve that same discipline.

That means:

- lane purity first,
- then transport-lift on top of that lane.

## 5. Why this gate still preserves `U1-first`

This gate is maximally conservative in the right way.

It still does **not** force:

1. one separate south tensor
2. one second transport-bearing carrier
3. one external exchange-current patch

So it remains an honest `U1-first` strike.

It asks whether the existing moderation lane is clean enough,
not whether a wider architecture is already necessary.

## 6. Exact next-gate wording

The fair exact next gate is:

- certify that `I_geo[g,ψ]` is pure enough at register-definition grade to
  count as one source-governed moderation lane for later `A_Q -> T_Q`
  transport-lift,
  with no direct `Q` dependence,
  no empirical borrowing,
  no hidden second carrier,
  and no non-variational patch

That is narrower than:

- carrier-law certification as a whole

but stronger than:

- generic source-governed hope.

## 7. What this does not say

This note does **not** claim:

- that `I_geo` already passes the gate
- that `A_Q` is already transport-certified
- that `M_Q` is solved
- or that exact total transport closure is near-finished

It claims something narrower and useful:

- the next gate inside the current exact target is now sharply identified.

## 8. Exact flip conditions

This gate ordering should be revoked immediately if later lawful work shows:

1. transport-lift can be certified without prior `I_geo` source-purity
2. `I_geo` source-purity is not actually separable from `A_Q` transport-lift
3. the real first gate lies on `M_Q` or elsewhere in the carrier lane
4. a `U2` trigger fires before this gate can even be posed honestly

If any of those appears,
this gate ordering fails.

## Bottom line

The current live `U1` route now supports one sharper reading again:

1. `O_transport` is the local execution owner
2. its first local tooth is the `I_geo`-mediated carrier-law freeze
3. its next exact target is `I_geo -> A_Q` carrier-law certification
4. the first gate inside that target is not transport-lift yet
5. it is `I_geo` source-purity certification at register-definition grade

That is the cleanest next gate inside the live transport attack.
