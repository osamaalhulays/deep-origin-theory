# Empirical Validation Closure Ledger

Date: `2026-06-05`

This ledger records the strongest already-materialized surfaces behind the
packet's empirical-validation axis.

Its purpose is to separate:

- real already-visible matching-to-data surfaces,
- real already-visible design and fairness controls,
- real already-visible out-of-sample discipline,
- and later-stage closures that are still honestly deferred.

## Short verdict

The repo sweep supports a stronger reading than the packet had been making
obvious:

- bounded data-match surfaces are already materially present,
- the experimental design is unusually locked against hidden rescue,
- reproducibility and audit posture are not merely promised but operationally
  specified,
- one historical blind same-source holdout pass is already preserved,
- one recovered six-case sentinel core plus wider seeded benchmark family are
  already visible,
- one recovered tail-driver localization plus one honest gas-fence closure are
  already visible,
- one recovered `k_star = 2` body snapshot plus one preserved later narrow
  negative-crossing branch are already visible,
- and out-of-sample discipline has already materialized in both sentinel and
  holdout form.

What remains open is narrower than "experimental validation still mostly
missing."

For the packet-wide stage-ceiling rule behind that reading, also see:

- `CURRENT_STAGE_CEILING_AND_LATER_STAGE_TRANSFER_RULE_NOTE_20260606.md`

For the strongest front-door articulation of the same axis, also read:

- `EMPIRICAL_VALIDATION_AXIS_FRONT_CARD_20260606.md`
- `DATA_FIT_10_OF_10_CANDIDATE_NOTE_20260606.md`
- `LARGE_SCALE_MULTISEED_EFFORT_FRONT_CARD_20260606.md`
- `RECOVERED_DATED_QUMOND_FAIRNESS_AND_SENTINEL_FAMILY_NOTE_20260606.md`
- `RECOVERED_DATED_TAIL_DRIVER_AND_GAS_FENCE_NOTE_20260606.md`
- `RECOVERED_DATED_KSTAR2_BODY_AND_NARROW_NEGATIVE_CROSSING_NOTE_20260606.md`
- `COMPARATOR_COMPLETENESS_CEILING_AND_LATER_FAIRNESS_TRANSFER_NOTE_20260606.md`
- `FITTED_UPSILON_ARTIFACT_GAP_RECLASSIFICATION_AND_CLAIM_SAFETY_NOTE_20260606.md`
- `AUTHORITY_GATED_FRONTS_NOTE__MACS1206_AND_L2_20260606.md`

## A. Data matching is already materially visible

### 1. One same-source benchmark pass is already explicit

The reestablished `Action-vs-EPIC` same-source validation surface already
states:

- `benchmark_state = materialized`
- `validation_state = pass__phi_and_delta_below_threshold`
- `phi_max_relative_error = 0.0`
- `delta_max_relative_error = 0.0`
- acceptance threshold = `< 1%`

This is not a future validation plan.
It is one bounded benchmark match already preserved on the lawful same-source
path.

### 2. `NGC0247` already gives row-level observational pressure, not only a slogan

The packet already preserves for the same named galaxy:

- a `26`-row visible table,
- a recomputable fixed-`QUMOND` comparator,
- row-wise residuals,
- row-wise `chi2` contributions,
- and one current replication script that reproduces the visible claims.

That is already a real data-facing validation surface.

### 3. `NGC6946` now gives a second row-readable fixed-comparator case

The packet now also preserves for a second named galaxy:

- a source-locked fixed-`QUMOND` row table across `58` rows,
- one-sided fixed-comparator residual pressure,
- and a sign-changing oracle profile split `29` negative / `29` positive.

This is not yet full parity with `NGC0247`.
But it is already enough to improve the fair reading from:

- one isolated case,

to:

- one primary spear plus one second row-readable holdout witness.

### 4. The case-level benchmark bridge is already numerically explicit

The same `NGC0247` witness also carries bounded case-level benchmark support:

- one preserved historical ML lane,
- one stronger preserved `oracle10` ceiling lane,
- and identical results across five preserved seeds.

This does not close the final current production lane.
But it does mean the witness is already stronger than "interesting rows."

### 5. North-side bounded witness maturity is already high

`MACS1206` is still blocked above final ascent.
But the `C` shelf is already explicit that the north object contains:

- a bounded reproducible response witness,
- a public witness ledger,
- and high internal witness maturity.

So even outside the galaxy spear, the packet is not validation-empty.

## B. Experimental design is stronger than the score suggests

### 6. The benchmark culture is reviewer-hard, not opponent-soft

The broader `QUMOND` benchmark line already froze:

- the baseline definition,
- identical data splits,
- identical nuisance-prior treatment,
- transparent parameter counting,
- and an obs-only model-selection comparator for both sides.

That is a genuine design strength.

It means the packet did not protect itself by changing the opponent or by
moving the scoring rule after opening the benchmark.

### 7. The program already enforced global-parameter discipline

The pre-Rank-9 galaxy line did not rely on per-galaxy theory rescue knobs.

The visible runner line already moved toward:

- shared global parameters,
- measured photometric inputs,
- nuisance marginalization instead of local hand-shaped rescue,
- and stronger cross-galaxy exposure.

That makes the data-match surfaces scientifically harder than a loose
galaxy-by-galaxy fit culture.

### 8. The phenomenological closure was kept under validation pressure

The galaxy PDE was not falsely sold as exact derivation everywhere.

Instead, the visible note preserves:

- phenomenological closure explicitly admitted,
- no extra closure-side free parameters,
- validation against the action-consistent spherical equation,
- and a target validation error below `1%`.

That is not weaker design.
It is better design hygiene.

### 9. Benchmark admissibility was repaired lawfully, not cosmetically

The earlier proxy benchmark stayed rejected.

What replaced it was:

- a reestablished same-source compare mode,
- locked source embedding,
- shared profile identity,
- support-radius identity,
- boundary / matching locks,
- extraction-rule locks,
- and a fixed validation window.

That is experimental design work of a high order, not mere repo bookkeeping.

## C. Reproducibility and data hygiene are operational, not rhetorical

### 10. The replication stack is already visible and rerunnable

For `NGC0247`, the packet already exposes:

- one row file,
- one lock card,
- one metric-bridge note,
- and one runnable reproduction script.

That is a direct reproducibility surface, not just a promise of later code
release.

### 11. Blind-protocol and audit-clean execution were already specified

The older Apex runbook and sign-off surfaces already preserve:

- strict environment pinning,
- a cryptographic manifest hash,
- unblind guards,
- tamper-evident results capsules,
- no raw observational data retention inside output capsules,
- and fail-loudly behavior for schema / domain / config violations.

This is a real validation strength.

It means the packet was already trying to make later empirical execution
auditable and bias-resistant.

### 12. Data quality requirements were not left vague

The LG-3 runbook does not say merely:

- "use good data."

It already gives visible quality constraints such as:

- outer-region emphasis,
- `sigma_gamma_t < 0.02`,
- `S/N > 5` in at least one outer bin,
- and recommended `N >= 20` high-quality stacks/galaxies.

That kind of quality rule should count on the empirical-validation axis.

## D. Out-of-sample discipline is already real

### 13. Sentinel discipline already materialized

The packet already preserves:

- a fixed manual six-case sentinel core,
- one broader named multiseed pressure panel around `NGC0247`, `NGC6946`, and
  `UGC11914`,
- a conservative `B1Y` sentinel surface,
- and an explicit refusal to promote partial-stage success by inference.

That is already more serious than ad hoc cherry-picking.

### 14. One historical blind holdout execution already passed

The packet also now makes more visible that one historical blind holdout gate
was not only designed but executed:

- candidate = `C1`
- result = `PASSED`
- regime = declared same-source window
- split = `predeclared_regime_holdout`
- no emulator rescue
- no post-hoc regime rewrite

The bounded claim remains narrow:

- branch-level non-emulator edge survived blind holdout.

That is still enough to count as real out-of-sample execution history rather
than mere holdout aspiration.

### 15. Holdout discipline became materially real in `C`

The later `L2` line is not just "we should do holdouts someday."

It already preserves:
- same-source unbinned failure anatomy,
- a selected independent binned holdout,
- a materialized `KIDS1000` central-relation holdout with `15` rows,
- a no-refit lock,
- uncertainty policy,
- comparison object,
- residual display object,
- and a cold `C0_NO_CLAIM_EXPORT` ceiling.

This is exactly what real out-of-sample discipline looks like before final
claim authorization.

### 16. The current non-`SPARC` holdout blocker is exact, not vague

The present out-of-sample bottleneck is already narrowed to:

- missing official source-side baryonic component rows for the non-`SPARC`
  holdout route.

That matters because it means the next missing piece is:

- not "experimental design unclear,"

but:

- one exact data-procurement blocker above an already materialized holdout
  grammar.

## E. Current-stage ceiling and later transfer

For the present packet, the empirical-validation line should now be read as
having reached the bounded ceiling it seeks at this stage:

- one same-source benchmark pass is visible,
- one primary row-auditable witness is visible,
- one second row-readable holdout witness is visible,
- one recovered broader sentinel-family stress layer is visible,
- one recovered tail-driver plus gas-fence discipline layer is visible,
- and real audit / sentinel / holdout discipline is visible.

The remainder is intentionally transferred to later empirical fronts:

- broader family verdicts,
- stronger north ascent / replication authority,
- and wider observational closure.

## F. What remains genuinely open

### 17. Directly preserved original current-production closure for `NGC0247` is still absent

The packet now does publish:

- one bounded reconstructed current Phase-2 `v_QCT_current` row comparator.

But it still does not publish:

- the original fitted-`Y` production closure object for that case,
- or a broader current-production widening beyond that reconstructed lane.

This is a fair remaining deduction.
It is not evidence that there is no serious data-match surface already.

### 18. The broad galaxy aggregate still remains harsher than the spear

The packet also keeps the painful broader `QUMOND` aggregate benchmark visible.

That honesty is a strength.
But it also means the packet cannot lawfully generalize the `NGC0247` spear
into a global victory claim yet.

### 19. Later observational openings remain bounded below fit/claim

`L0`, `L2`, and the north ascent gate still preserve exact blockers above the
already visible validation objects.

Those are real later steps.
But they sit above a stronger empirical-validation base than the current score
suggests.

## G. Fair scoring consequence

After this sweep, the empirical-validation axis should no longer be read as:

- "good reproducibility hygiene, but only modest real validation structure."

The fairer reading is:

- one bounded same-source benchmark pass already exists,
- one named row-auditable galaxy witness already exists,
- one second named row-readable holdout witness already exists,
- one preserved case-level benchmark bridge already exists,
- one reviewer-hard benchmark design already exists,
- one blind/audit-clean execution culture already exists,
- one historical blind same-source holdout pass already exists,
- and one material out-of-sample holdout discipline already exists.

The remaining deductions are real, but narrower:

- final current-production closure,
- broader aggregate external success,
- and later authority-bearing observational openings.

## Best short route

If empirical validation is the main concern, read:

1. `EMPIRICAL_VALIDATION_AND_OUT_OF_SAMPLE_NOTE_20260605.md`
2. `EMPIRICAL_VALIDATION_CLOSURE_LEDGER_20260605.md`
3. `DIFFERENTIAL_WITNESS_CAPSULE__NGC0247__V1.md`
4. `FIXED_QUMOND_COMPARATOR_APPENDIX__NGC0247__SOURCE_LOCKED_V1.md`
5. `NGC0247_CURRENT_REPLICATION_CAPSULE_V1.md`
6. `01_A_PreRank9/.../QUMOND_BENCHMARK_HONESTY_NOTE.md`
7. `01_A_PreRank9/.../GLOBAL_PARAMETER_DISCIPLINE_NOTE.md`
8. `01_A_PreRank9/.../FINAL_SIGNOFF.md`
9. `01_A_PreRank9/.../RUNBOOK_UNBLIND_LG3.md`
10. `02_B_Rank9/.../PUBLIC_EVIDENCE_APPENDIX.md`
11. `03_C_Cluster/.../L2_SECOND_GENERATION_HOLDOUT_STATUS_NOTE_20260604.md`
12. `03_C_Cluster/.../L2_EXTERNAL_BARYONIC_PROCUREMENT_BLOCKER_STATUS_NOTE_20260605.md`

## Bottom line

The packet's empirical-validation story is stronger than the current score
suggests.

Not because every later observational claim is already open,
but because the bounded matching, design, reproducibility, and out-of-sample
surfaces are already more mature and more explicit than the score gives them
credit for, including one second row-readable witness and one historical blind
same-source holdout pass.
