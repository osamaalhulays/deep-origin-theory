#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

O7_CONVERGENCE_PATH = HERE / "HUBBLE_FLOW_SENSITIVE_BODY_LAYERED_O7_CONVERGENCE_V1.json"
REOPENING_TRIAD_PATH = HERE / "RESIDUAL_QUALITY1_REOPENING_TRIAD_CLOSURE_V1.json"
RESERVE_TRIPLET_PATH = HERE / "RESIDUAL_QUALITY1_RESERVE_TRIPLET_CLOSURE_V1.json"
NGC5033_PATH = HERE / "NGC5033_FIRST_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def close_enough(left, right, tolerance=1e-9):
    return abs(left - right) <= tolerance


def main():
    convergence = load_json(O7_CONVERGENCE_PATH)
    reopening = load_json(REOPENING_TRIAD_PATH)
    reserve = load_json(RESERVE_TRIPLET_PATH)
    ngc5033 = load_json(NGC5033_PATH)

    full_body = convergence["full_hubble_flow_sensitive_body"]
    overlap = convergence["o7_positive_spoiler_intersection"]
    remainder = convergence["current_nonintersecting_remainder"]

    reopening_rows = {
        row["case_id"]: row for row in reopening["witnesses"] if row["case_id"] in remainder["cases"]
    }
    reserve_witness = ngc5033["witness"]

    remainder_case_catalog = {
        "SPARC_NGC2903": {
            **reopening_rows["SPARC_NGC2903"],
            "segment": "residual_quality1_reopening_triad",
            "quality_flag": 1,
        },
        "SPARC_NGC6674": {
            **reopening_rows["SPARC_NGC6674"],
            "segment": "residual_quality1_reopening_triad",
            "quality_flag": 1,
        },
        "SPARC_NGC5033": {
            **reserve_witness,
            "segment": "quality1_reserve_triplet",
        },
    }

    exact_qumond_protection_count = sum(
        1 for row in remainder_case_catalog.values() if row["faithful_public_qumond_gap_abs"] == 0.0
    )
    quality1_count = sum(1 for row in remainder_case_catalog.values() if row["quality_flag"] == 1)

    reopening_case_ids = sorted(
        case_id
        for case_id, row in remainder_case_catalog.items()
        if row["segment"] == "residual_quality1_reopening_triad"
    )
    reserve_case_ids = sorted(
        case_id
        for case_id, row in remainder_case_catalog.items()
        if row["segment"] == "quality1_reserve_triplet"
    )

    consistency_checks = {
        "remainder_case_count_is_three": remainder["case_count"] == 3,
        "remainder_case_ids_match_expected_triad": set(remainder["cases"])
        == {"SPARC_NGC2903", "SPARC_NGC6674", "SPARC_NGC5033"},
        "remainder_is_disjoint_from_current_o7_overlap": set(remainder["cases"]).isdisjoint(
            set(overlap["cases"])
        ),
        "remainder_reopening_intersection_is_ngc2903_and_ngc6674": reopening_case_ids
        == ["SPARC_NGC2903", "SPARC_NGC6674"],
        "remainder_reserve_intersection_is_ngc5033": reserve_case_ids == ["SPARC_NGC5033"],
        "remainder_has_no_primary_core_member": not any(
            row["segment"] == "primary_parity_core" for row in remainder_case_catalog.values()
        ),
        "remainder_has_no_quality2_member": quality1_count == remainder["case_count"],
        "all_remainder_cases_have_exact_qumond_protection": exact_qumond_protection_count
        == remainder["case_count"],
        "remainder_public_total_matches_catalog_sum": close_enough(
            sum(row["public_delta_aic_total"] for row in remainder_case_catalog.values()),
            remainder["public_delta_aic_total"],
        ),
        "remainder_component_total_matches_catalog_sum": close_enough(
            sum(row["component_aware_delta_aic_total"] for row in remainder_case_catalog.values()),
            remainder["component_aware_delta_aic_total"],
        ),
        "remainder_shift_total_matches_catalog_sum": close_enough(
            sum(row["component_aware_shift"] for row in remainder_case_catalog.values()),
            remainder["component_aware_shift"],
        ),
        "remainder_and_overlap_recombine_to_full_body_public_total": close_enough(
            remainder["public_delta_aic_total"] + overlap["public_delta_aic_total"],
            full_body["public_delta_aic_total"],
        ),
        "remainder_and_overlap_recombine_to_full_body_component_total": close_enough(
            remainder["component_aware_delta_aic_total"] + overlap["component_aware_delta_aic_total"],
            full_body["component_aware_delta_aic_total"],
        ),
        "remainder_and_overlap_recombine_to_full_body_shift_total": close_enough(
            remainder["component_aware_shift"] + overlap["component_aware_shift"],
            full_body["component_aware_shift"],
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "bounded_packet_facing_remainder_localization",
        "surface": "hubble_flow_sensitive_body_current_o7_remainder_localization",
        "current_o7_nonintersecting_remainder": {
            "case_count": remainder["case_count"],
            "cases": remainder["cases"],
            "public_delta_aic_total": remainder["public_delta_aic_total"],
            "faithful_delta_aic_total": remainder["faithful_delta_aic_total"],
            "component_aware_delta_aic_total": remainder["component_aware_delta_aic_total"],
            "component_aware_shift": remainder["component_aware_shift"],
            "fraction_of_body_case_count": remainder["fraction_of_body_case_count"],
            "fraction_of_body_public_delta_aic_total": remainder["fraction_of_body_public_delta_aic_total"],
            "fraction_of_body_component_aware_delta_aic_total": remainder[
                "fraction_of_body_component_aware_delta_aic_total"
            ],
            "segment_breakdown": remainder["segment_breakdown"],
        },
        "localization_structure": {
            "all_cases_are_quality1": True,
            "all_cases_have_exact_qumond_protection": True,
            "reopening_triad_cases": reopening_case_ids,
            "reserve_triplet_cases": reserve_case_ids,
            "primary_core_cases": [],
            "bounded_quality2_sidecar_cases": [],
        },
        "remainder_case_catalog": remainder_case_catalog,
        "structural_reading": {
            "the_current_o7_nonoverlap_is_a_narrow_quality1_continuation_pocket_not_a_bodywide_counterpattern": True,
            "the_current_nonoverlap_lives_entirely_below_the_primary_core_and_below_quality2": True,
            "the_current_nonoverlap_is_split_only_between_reopening_and_reserve_quality1_segments": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the current three-witness nonoverlap is narrowly localized rather than spread across the whole body",
            "all three current nonoverlap witnesses are quality1 and exact-QUMOND-protected on the faithful-public gap surface",
            "the current nonoverlap contains no primary-core and no quality2 witness",
            "the current nonoverlap is confined to the quality1 reopening-reserve continuation pocket",
        ],
        "not_supported_now": [
            "the current three-witness nonoverlap is a bodywide counterpattern",
            "the current nonoverlap already overturns the seven-witness layered O7 convergence",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_frontier": [
            "test whether this narrow quality1 continuation pocket later materializes inside O7 or remains a structurally separate pocket",
            "extend the cross-observable court without collapsing current nonoverlap into a final theory verdict",
        ],
    }

    output["verdict"] = (
        "HUBBLE_FLOW_SENSITIVE_BODY_CURRENT_O7_REMAINDER_LOCALIZED__THE_THREE_WITNESS_NONOVERLAP_IS_A_NARROW_ALL_QUALITY1_EXACT_QUMOND_PROTECTED_CONTINUATION_POCKET"
        if all(consistency_checks.values())
        else "HUBBLE_FLOW_SENSITIVE_BODY_CURRENT_O7_REMAINDER_NOT_YET_LOCALIZED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
