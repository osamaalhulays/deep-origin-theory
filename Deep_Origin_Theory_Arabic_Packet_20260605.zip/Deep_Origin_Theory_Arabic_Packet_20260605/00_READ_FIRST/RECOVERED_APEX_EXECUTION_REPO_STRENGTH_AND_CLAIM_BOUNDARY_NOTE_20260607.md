# Recovered Apex Execution Repo Strength And Claim-Boundary Note

Date: `2026-06-07`

Status: `reviewer-facing repo-harvest note`

Purpose:

This note absorbs what the historical `QCT_Apex_Repo_Run` legitimately adds
to the packet, without letting the packet overclaim what that repository does
not actually prove.

That repo is worth using.

But it must be used for the right reasons.

## 1. What that repo genuinely gives us

### 1. One serious governed execution stack

The repo materially preserves:

- strict manifest anchoring,
- blind / unblind enforcement,
- fail-loud execution discipline,
- and audit-facing production packaging.

This is not paper language only.
It is implemented in code and tests.

### 2. One real benchmark-and-adjudication culture

The repo also preserves:

- multi-seed benchmark execution,
- same-nuisance comparator pressure,
- worst-case extraction,
- stage-gated batch execution,
- and post-run interpretive / adjudicative tooling.

This gives the packet one real historical execution culture,
not only one later narrative about fairness.

### 3. One real historical release line

The repo preserves a genuine release branch with:

- production summaries,
- bounded negative-crossing variants,
- patched-case accounting,
- and hygiene / packaging decisions.

That is real historical operational weight.

### 4. One materially present Solar-System limit-recovery layer

The repo also contains a real `TG-4` engineering-and-test lane:

- one solver,
- one benchmark recipe,
- one benchmark-corrected note,
- and one dedicated test layer.

So the packet may safely treat this repo as a real execution witness for
limit-recovery seriousness.

## 2. What that repo does **not** give us

It does **not** close the higher upstream derivation debts.

In particular, it does not provide:

- one final necessity theorem for the common parent-source law,
- one exact action-derived public closure for `SPEC-205`,
- or one final public `A -> B` transport theorem in the stronger older sense.

Those belong to other layers of the larger archive history.

So this repo should not be used as if it were the final home of those claims.

## 3. Two boundaries that matter

### 1. One live identity drift remains inside the lensing branch

The repo preserves strong lensing execution machinery,
but it also preserves nontrivial identity drift across `LG1 / LG2 / LG3`.

In plain terms:

- some files promote a hybrid mainline,
- while others still speak in a baryon-only baseline voice for the key
  falsification surface.

So the repo is valuable,
but it should not be sold as if its lensing identity layer were already
perfectly single-voiced.

### 2. One live fairness inconsistency remains in the benchmark layer

The repo's fairness prose and test expectation say that model selection should
use the same `obs-only` likelihood basis for both sides.

But the current implementation still computes the `QCT` `AIC/BIC` line from
`obs+model` rather than `obs-only`.

That means the packet may safely use this repo as evidence of:

- governed execution seriousness,
- real historical benchmark effort,
- and release-line weight,

but should **not** use it as if it were the final spotless authority for the
comparator-fairness verdict.

## 4. What the fair packet use is

The fair packet use is now clear.

Use this repo to support:

- reviewability,
- execution seriousness,
- blind-governance rigor,
- multiseed / gatepipe / compass weight,
- historical release evidence,
- and bounded Solar-System execution substance.

Do **not** use it to pretend we already possess there:

- the final upstream derivation closure,
- the final parent-law necessity proof,
- or one perfectly closed comparator-fairness endpoint.

## Bottom line

The historical Apex execution repo strengthens the packet in exactly the right
bounded way:

- it proves that serious governed execution already exists,
- it preserves real release and adjudication weight,
- and it hardens the packet against the weak reading that everything was still
  only aspirational.

But it should be cited as:

- one strong historical execution-and-release witness,

not as:

- the final upstream derivation archive.
