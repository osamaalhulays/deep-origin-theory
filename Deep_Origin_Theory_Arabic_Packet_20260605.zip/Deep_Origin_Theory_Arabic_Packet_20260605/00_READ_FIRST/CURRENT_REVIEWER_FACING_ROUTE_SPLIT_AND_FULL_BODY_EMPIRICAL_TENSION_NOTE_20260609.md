# Current Reviewer-Facing Route-Split And Full-Body Empirical Tension Note

Date: `2026-06-09`

Status: `packet-contained reviewer-facing empirical tension compression`

Purpose:

The packet already had:

- one exact `NGC0247` route-split witness
- and one exact ten-witness Hubble-flow-sensitive hardening body

But a cold reviewer could still ask one fair question:

- how should these two truths be held together on one honest empirical
  surface?

This note answers that question.

Machine-readable companion:

- `CURRENT_REVIEWER_FACING_ROUTE_SPLIT_AND_FULL_BODY_EMPIRICAL_TENSION_V1.json`

Reproduction script:

- `REPRODUCE_CURRENT_REVIEWER_FACING_ROUTE_SPLIT_AND_FULL_BODY_EMPIRICAL_TENSION_V1.py`

It should be read together with:

- `NGC0247_FULL_BODY_GROUNDED_DUAL_EXECUTION_ROUTE_SPLIT_NOTE_20260609.md`
- `HUBBLE_FLOW_SENSITIVE_BODY_FULL_CLOSURE_NOTE_20260609.md`
- `CURRENT_FULL_HEAD_CONCENTRATED_BUT_NONTERMINAL_BOUNDARY_NOTE_20260609.md`
- `CURRENT_REVIEWER_FACING_CROSS_OBSERVABLE_COURT_LANE_STATUS_BOARD_NOTE_20260609.md`

## Short verdict

The current packet now carries one honest compressed rotation-side sentence:

- `NGC0247` is still a real local route-split witness
- the ten-witness Hubble-flow-sensitive body is still the much larger
  anti-`QCT` burden
- and no honest reader sentence may erase either side

So the present empirical state is not:

- one pro-`QCT` slogan

and not:

- one anti-`QCT` slogan

It is:

- one local route split beside one much larger same-sign hardening body

## 1. The local route split is real

`NGC0247` still carries both sides at once:

- release-side best-dressed hardening
  `Delta AIC_total = +330.508310757082`
- fixed-public live lane
  `Delta AIC_total = -13.914066963632308`
- faithful matched-nuisance live lane
  `Delta AIC_total = -15.398764714420167`
- component-aware matched-nuisance live lane
  `Delta AIC_total = -39.63154845025974`

So the route split is not rhetorical.

It is executed and packet-contained.

## 2. The ten-witness body is also real

The Hubble-flow-sensitive body still carries:

- `10` witnesses
- public `Delta AIC_total = +124948.98557586371`
- faithful `Delta AIC_total = +86258.84036593112`
- component-aware `Delta AIC_total = +92780.09909850561`

So the wider hardening burden also remains real,
closed,
and much larger in visible scale than the single `NGC0247` route split.

## 3. Why this matters

Without this compression,
an external reader can cheat in either direction:

- mention only `NGC0247` and hide the larger body burden
- or mention only the larger body burden and hide the real route split

This note blocks both shortcuts.

It freezes the honest middle sentence:

- one named local route split still exists,
- but the larger ten-witness body still dominates the present anti-`QCT`
  burden geography.

## 4. What this does not authorize

This note does **not** authorize the claims that:

- `NGC0247` alone outweighs the wider body
- the wider body makes `NGC0247` disappear by convenience
- one single rotation slogan already settles the whole selected court
- whole-family `MOND/QUMOND` closure already exists

## Best outward-safe reading

One mature outward-safe sentence is:

> The packet now carries one honest compressed rotation-side empirical
> tension surface: `NGC0247` remains a real local release-vs-live route-split
> witness, while the ten-witness Hubble-flow-sensitive body remains the much
> larger anti-`QCT` burden. The current state therefore cannot be described
> honestly by one single-sided rotation slogan.
