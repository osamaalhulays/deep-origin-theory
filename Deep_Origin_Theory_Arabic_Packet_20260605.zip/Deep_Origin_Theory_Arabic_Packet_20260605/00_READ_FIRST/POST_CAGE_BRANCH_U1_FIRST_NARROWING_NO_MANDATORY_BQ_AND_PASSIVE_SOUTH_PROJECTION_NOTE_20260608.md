# Post-Cage Branch U1 First Narrowing: No Mandatory B_Q And Passive South Projection

Date: `2026-06-08`

Purpose:

This note tightens the first typed `QF1 + IF1` worksheet one step further.

## Short verdict

The safest first narrowed live form is:

`S_U1^(1a) = S_EH[g] + S_m[g,ψ] + S_Q^(QF1a)[g,ψ,Q] + S_int^(IF1a)[g,ψ,Q]`

with:

`L_Q^(QF1a) = A_Q[g,ψ] g^{μν} ∇_μ Q ∇_ν Q + M_Q[g,ψ] Q^2`

`L_int^(IF1a) = J_lin[g,ψ] Q + W_src[g,ψ] Q^2 + R_res[g,ψ,Q]`

and with the first south projection taken only as:

`South[Q] = P_S^(0)[Q] = B_S[J_lin Q + W_src Q^2 + R_res]`

This means:

- no mandatory primitive `B_Q` in the first narrowed strike
- south enters first as one bounded readout from the same-carrier ledger
- not as one second dynamical carrier

## Why this narrowing is cleaner

The Kreib-side `Q`/`S2_Q` material gives real pressure for:

- exact final bulk carrier `Q`
- kinetic / gradient / masslike / identity slot pressure
- and one source-governed interaction-ledger grammar

But it does **not** yet give clean first-strike authority to freeze the cross
slot as mandatory primitive parent structure.

So `B_Q` may remain one later recovery class,
but it should not be treated as first-strike necessity.

## Exact reading

Under this narrowing:

1. the parent action is smaller and cleaner
2. any unresolved pressure stays in `R_res` rather than in one hidden second
   carrier
3. south becomes one bounded passive face of the same `Q` route
4. transport audit becomes cleaner because south no longer smuggles in its
   own transport-bearing role

## What breaks it

Reject the narrowed route immediately if it needs:

- mandatory `B_Q`
- one hidden sector inside `R_res`
- one independent south dynamics
- one independent south transport tensor
- or one diagnostic no-claim formula promoted into parent-law authority

That would no longer be clean `U1`.

## Bottom line

The live line is now tighter than the first worksheet:

- `S_EH + S_m + S_Q^(QF1a) + S_int^(IF1a)`

with:

- no mandatory primitive `B_Q`
- one explicit same-carrier remainder ledger
- one passive bounded south projection
- and one cleaner transport-facing audit surface
