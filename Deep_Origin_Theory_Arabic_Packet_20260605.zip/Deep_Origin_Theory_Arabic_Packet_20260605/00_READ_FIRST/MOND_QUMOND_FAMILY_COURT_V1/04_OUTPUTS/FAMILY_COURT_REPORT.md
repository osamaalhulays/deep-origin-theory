# MOND/QUMOND Family Court Report

Date: `2026-06-10`

Status: `materialized reviewer-facing family court`

## Short verdict

`MOND_QUMOND_FAMILY_COURT_V1` now exists as one reviewer-facing family-scale
comparator object.

It carries:

- `12` executed named matched-nuisance witnesses
- `2` protected family-pressure cases
- `4` live reinflation-frontier cases

## Method ceiling

- current differential reading = procedural preference under symmetric
  matched-nuisance `MLE` treatment
- Bayesian evidence claimed = `false`
- later stronger method front =
  `independent_upsilon_prior_full_marginalization_bayes_factor`

## Executed court morphology

- route split count = `1`
- same-sign softening count = `1`
- same-sign hardening count = `10`

## Protected family-pressure cases

- `SPARC_NGC5055` = repeated toward QCT across both currently cited programs
- `SPARC_UGC11914` = structure-sensitive stress object, not blunt stand-alone falsifier


## Live frontier

- `SPARC_UGC03546` = bridge case between near-neutral persistence and stronger reinflation
- `SPARC_UGC12732` = clean reinflation case where a tiny faithful positive result expands sharply after component-aware replay
- `SPARC_NGC2366` = next high-reinflation positive case after ugc12732
- `SPARC_UGC08286` = next reinflation case after the opening subband batch


## Boundary

- whole-family total closure claimed = `false`
- `D1` materialized = `true`
- `D2` materialized = `true`
