# Same-Convention Comparator Law

Date: `2026-06-10`

Status: `family-court protocol lock`

Purpose:

Freeze the comparator law for the reviewer-facing `MOND_QUMOND_FAMILY_COURT_V1`
object so the family verdict cannot be silently laundered through mixed shells.

## Governing rules

- preserved historical mixed shells remain auditable history only
- reviewer-facing final parity shells must use one same-convention comparator
  basis where that basis is packet-visible
- differential preference language requires the same nuisance-fitting
  procedure on both sides even when the fitted nuisance values differ
- `obs+model` versus `obs-only` mixed-shell history must never be relabeled as
  the final parity shell by naming alone
- route split, same-sign softening, and same-sign hardening must remain
  visibly distinct court morphologies
- fixed-public `QUMOND` remains one audit anchor rather than one hidden moving
  benchmark

## Current court reading

- `NGC0247` remains the explicit route-split witness
- `NGC6946` remains the explicit same-sign softening witness
- the ten-witness body remains the explicit same-sign hardening block
- the current lawful differential reading is procedural preference under
  symmetric matched-nuisance `MLE` treatment

## Claim ceiling

This protocol locks comparator honesty only.

It does **not** itself claim whole-family total closure,
Bayesian evidence,
or unconditional physical superiority.
