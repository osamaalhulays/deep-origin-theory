# Nuisance Parity Lock

Date: `2026-06-10`

Status: `family-court nuisance lock`

Purpose:

Keep nuisance handling explicit across the family-court surface.

## Governing rules

- faithful matched-nuisance replay is the primary executed live lane
- component-aware replay must remain visible beside the faithful lane rather
  than overwrite it
- nuisance parity means matched fitting procedure rather than forced equality
  of the fitted nuisance values
- if later independently measured nuisance quantities such as distance or
  inclination are opened on both sides, they should enter symmetrically
  rather than by one-sided handling
- fixed-public `QUMOND` remains a visible audit anchor
- protected pressure cases and live-frontier microfront cases must be labeled
  by status rather than smuggled into the executed comparator table
- cases that are not currently packet-visible as symmetric executed matched-
  nuisance rows must not be given invented parity numbers

## Current court reading

- the executed comparator family is `12` named witnesses
- the protected pressure family includes `SPARC_NGC5055` and
  `SPARC_UGC11914`
- the live reinflation-opening frontier is
  `SPARC_UGC03546 + SPARC_UGC12732 + SPARC_NGC2366`
  with reserve `SPARC_UGC08286`
- one later symmetric-prior route for independently measured nuisance
  quantities remains compatible with this lock
- the stronger Bayesian `Upsilon`-marginalized comparator remains one later
  method front rather than a present family-court claim
