#!/usr/bin/env python3
import csv
import json
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
COURT_ROOT = THIS_FILE.parents[1]


def find_packet_root():
    for parent in THIS_FILE.parents:
        if parent.name == "00_READ_FIRST" and (parent / "START_HERE_FIRST.md").exists():
            return parent

    for parent in THIS_FILE.parents:
        candidate = parent / "Deep_Origin_Theory_English_Packet_20260605" / "00_READ_FIRST"
        if candidate.exists() and (parent / "artifacts").exists():
            return candidate

    raise RuntimeError("could not locate packet root from family-court runner")


PACKET_ROOT = find_packet_root()
CASES_ROOT = COURT_ROOT / "01_CASES"
PROTOCOL_ROOT = COURT_ROOT / "02_PROTOCOL"
OUTPUT_ROOT = COURT_ROOT / "04_OUTPUTS"

SOURCE_FILES = {
    "morphology_partition": PACKET_ROOT / "NAMED_EXECUTED_MATCHED_NUISANCE_COURT_MORPHOLOGY_PARTITION_V1.json",
    "route_split_tension": PACKET_ROOT / "CURRENT_REVIEWER_FACING_ROUTE_SPLIT_AND_FULL_BODY_EMPIRICAL_TENSION_V1.json",
    "primary_core": PACKET_ROOT / "PRIMARY_PARITY_CORE_TRIAD_ORDER_AND_UNIFORM_COMPONENT_HARDENING_V1.json",
    "residual_reopening": PACKET_ROOT / "RESIDUAL_QUALITY1_REOPENING_TRIAD_CLOSURE_V1.json",
    "reserve_ngc5033": PACKET_ROOT / "NGC5033_FIRST_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json",
    "reserve_ugc02487": PACKET_ROOT / "UGC02487_SECOND_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json",
    "reserve_ugc03205": PACKET_ROOT / "UGC03205_THIRD_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json",
    "quality2_sidecar": PACKET_ROOT / "UGC05253_BOUNDED_QUALITY2_SIDECAR_ENTRY_V1.json",
    "clean_anchor_dispersion": PACKET_ROOT / "CLEAN_ANCHOR_MINORITY_CROSS_LANE_DISPERSION_V1.json",
    "reinflation_microfront": PACKET_ROOT / "O7_REINFLATION_MICROFRONT_AFTER_NEAR_NEUTRAL_PERSISTENCE_V1.json",
}

CASE_ORDER = [
    "SPARC_NGC0247",
    "SPARC_NGC6946",
    "SPARC_UGC09133",
    "SPARC_UGC02953",
    "SPARC_UGC06787",
    "SPARC_UGC06786",
    "SPARC_NGC2903",
    "SPARC_NGC6674",
    "SPARC_NGC5033",
    "SPARC_UGC02487",
    "SPARC_UGC03205",
    "SPARC_UGC05253",
    "SPARC_NGC5055",
    "SPARC_UGC11914",
    "SPARC_UGC03546",
    "SPARC_UGC12732",
    "SPARC_NGC2366",
    "SPARC_UGC08286",
]

CASE_PROTOCOL_TEXT = """# Same-Convention Comparator Law

Date: `2026-06-10`

Status: `family-court protocol lock`

Purpose:

Freeze the comparator law for the reviewer-facing `MOND_QUMOND_FAMILY_COURT_V1`
object so the family verdict cannot be silently laundered through mixed shells.

## Governing rules

- preserved historical mixed shells remain auditable history only
- reviewer-facing final parity shells must use one same-convention comparator
  basis where that basis is packet-visible
- differential preference language requires the same nuisance-fitting
  procedure on both sides even when the fitted nuisance values differ
- `obs+model` versus `obs-only` mixed-shell history must never be relabeled as
  the final parity shell by naming alone
- route split, same-sign softening, and same-sign hardening must remain
  visibly distinct court morphologies
- fixed-public `QUMOND` remains one audit anchor rather than one hidden moving
  benchmark

## Current court reading

- `NGC0247` remains the explicit route-split witness
- `NGC6946` remains the explicit same-sign softening witness
- the ten-witness body remains the explicit same-sign hardening block
- the current lawful differential reading is procedural preference under
  symmetric matched-nuisance `MLE` treatment

## Claim ceiling

This protocol locks comparator honesty only.

It does **not** itself claim whole-family total closure,
Bayesian evidence,
or unconditional physical superiority.
"""

NUISANCE_PROTOCOL_TEXT = """# Nuisance Parity Lock

Date: `2026-06-10`

Status: `family-court nuisance lock`

Purpose:

Keep nuisance handling explicit across the family-court surface.

## Governing rules

- faithful matched-nuisance replay is the primary executed live lane
- component-aware replay must remain visible beside the faithful lane rather
  than overwrite it
- nuisance parity means matched fitting procedure rather than forced equality
  of the fitted nuisance values
- fixed-public `QUMOND` remains a visible audit anchor
- protected pressure cases and live-frontier microfront cases must be labeled
  by status rather than smuggled into the executed comparator table
- cases that are not currently packet-visible as symmetric executed matched-
  nuisance rows must not be given invented parity numbers

## Current court reading

- the executed comparator family is `12` named witnesses
- the protected pressure family includes `SPARC_NGC5055` and
  `SPARC_UGC11914`
- the live reinflation-opening frontier is
  `SPARC_UGC03546 + SPARC_UGC12732 + SPARC_NGC2366`
  with reserve `SPARC_UGC08286`
- the stronger Bayesian `Upsilon`-marginalized comparator remains one later
  method front rather than a present family-court claim
"""

VERDICT_BOUNDARY_TEXT = """# Family Verdict Boundary

Date: `2026-06-10`

Status: `bounded family-verdict grammar`

Purpose:

State what the new family-court object does and does not settle.

## Supported by this object

- one reviewer-facing family court now exists
- the named executed matched-nuisance court is family-scale and reproducible
- the current `NGC0247` differential shell supports one procedural
  preference reading under symmetric matched-nuisance `MLE` treatment
- `D1` is visible as one exact reinflation-opening microfront
- `D2` is visible as one bounded family verdict rather than one prose promise

## Not supported by this object

- whole-family `MOND/QUMOND` total defeat
- Bayesian evidence language for the present family court
- unconditional physical-superiority language from the current differential
  shell alone
- erasure of the `NGC0247` route split
- erasure of the `NGC6946` softening exception
- blunt single-galaxy falsifier promotion from `UGC11914`
- execution of the `D72` reinflation batch itself
- cosmology completion
"""


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def ensure_dirs():
    for path in (CASES_ROOT, PROTOCOL_ROOT, OUTPUT_ROOT):
        path.mkdir(parents=True, exist_ok=True)


def optional_float(value):
    if value is None:
        return None
    return float(value)


def csv_cell(value):
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:.15g}"
    return str(value)


def write_text(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content.rstrip() + "\n", encoding="utf-8")


def write_json(path: Path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")


def build_case_entry(
    case_id,
    case_class,
    morphology,
    status,
    reviewer_reading,
    source_surfaces,
    public_delta_aic_total=None,
    faithful_delta_aic_total=None,
    component_aware_delta_aic_total=None,
    component_aware_shift=None,
    quality_flag=None,
    release_side_delta_aic_total=None,
):
    return {
        "case_id": case_id,
        "case_class": case_class,
        "morphology": morphology,
        "status": status,
        "quality_flag": quality_flag,
        "public_delta_aic_total": optional_float(public_delta_aic_total),
        "faithful_delta_aic_total": optional_float(faithful_delta_aic_total),
        "component_aware_delta_aic_total": optional_float(component_aware_delta_aic_total),
        "component_aware_shift": optional_float(component_aware_shift),
        "release_side_delta_aic_total": optional_float(release_side_delta_aic_total),
        "source_surfaces": source_surfaces,
        "reviewer_reading": reviewer_reading,
        "order": CASE_ORDER.index(case_id) + 1,
    }


def build_case_entries():
    morphology_partition = load_json(SOURCE_FILES["morphology_partition"])
    route_split_tension = load_json(SOURCE_FILES["route_split_tension"])
    primary_core = load_json(SOURCE_FILES["primary_core"])
    residual_reopening = load_json(SOURCE_FILES["residual_reopening"])
    reserve_ngc5033 = load_json(SOURCE_FILES["reserve_ngc5033"])
    reserve_ugc02487 = load_json(SOURCE_FILES["reserve_ugc02487"])
    reserve_ugc03205 = load_json(SOURCE_FILES["reserve_ugc03205"])
    quality2_sidecar = load_json(SOURCE_FILES["quality2_sidecar"])
    reinflation_microfront = load_json(SOURCE_FILES["reinflation_microfront"])

    cases = []

    ngc0247_live = route_split_tension["local_route_split_witness"]["live_matched_nuisance_return"]
    ngc0247_release = route_split_tension["local_route_split_witness"]["release_side_best_dressed_return"]
    cases.append(
        build_case_entry(
            case_id="SPARC_NGC0247",
            case_class="executed_named_witness",
            morphology="route_split",
            status="executed_matched_nuisance_witness",
            reviewer_reading="only named executed pro-QCT route-split witness",
            source_surfaces=[
                SOURCE_FILES["route_split_tension"].name,
                SOURCE_FILES["morphology_partition"].name,
            ],
            public_delta_aic_total=ngc0247_live["public_delta_aic_total"],
            faithful_delta_aic_total=ngc0247_live["faithful_delta_aic_total"],
            component_aware_delta_aic_total=ngc0247_live["component_aware_delta_aic_total"],
            component_aware_shift=ngc0247_live["component_aware_delta_aic_total_shift"],
            release_side_delta_aic_total=ngc0247_release["option1_robust_delta_aic_total"],
        )
    )

    ngc6946 = morphology_partition["partitions"]["same_sign_softening"]["witness"]
    cases.append(
        build_case_entry(
            case_id="SPARC_NGC6946",
            case_class="executed_named_witness",
            morphology="same_sign_softening",
            status="executed_matched_nuisance_witness",
            reviewer_reading="only named executed same-sign softening witness",
            source_surfaces=[SOURCE_FILES["morphology_partition"].name],
            public_delta_aic_total=ngc6946["public_delta_aic_total"],
            faithful_delta_aic_total=ngc6946["faithful_delta_aic_total"],
            component_aware_delta_aic_total=ngc6946["component_aware_delta_aic_total"],
            component_aware_shift=ngc6946["component_aware_shift"],
            release_side_delta_aic_total=ngc6946["release_option1_robust_delta_aic_total"],
        )
    )

    for witness in primary_core["ordered_core"]:
        cases.append(
            build_case_entry(
                case_id=witness["case_id"],
                case_class="executed_named_witness",
                morphology="same_sign_hardening",
                status="executed_matched_nuisance_witness",
                reviewer_reading="primary parity core witness inside the same-sign hardening body",
                source_surfaces=[SOURCE_FILES["primary_core"].name],
                public_delta_aic_total=witness["public_delta_aic_total"],
                faithful_delta_aic_total=witness["faithful_delta_aic_total"],
                component_aware_delta_aic_total=witness["component_aware_delta_aic_total"],
                component_aware_shift=witness["component_aware_shift"],
                quality_flag=witness["quality_flag"],
            )
        )

    for witness in residual_reopening["witnesses"]:
        cases.append(
            build_case_entry(
                case_id=witness["case_id"],
                case_class="executed_named_witness",
                morphology="same_sign_hardening",
                status="executed_matched_nuisance_witness",
                reviewer_reading="residual reopening witness inside the same-sign hardening body",
                source_surfaces=[SOURCE_FILES["residual_reopening"].name],
                public_delta_aic_total=witness["public_delta_aic_total"],
                faithful_delta_aic_total=witness["faithful_delta_aic_total"],
                component_aware_delta_aic_total=witness["component_aware_delta_aic_total"],
                component_aware_shift=witness["component_aware_shift"],
                quality_flag=1,
            )
        )

    reserve_witness = reserve_ngc5033["witness"]
    cases.append(
        build_case_entry(
            case_id=reserve_witness["case_id"],
            case_class="executed_named_witness",
            morphology="same_sign_hardening",
            status="executed_matched_nuisance_witness",
            reviewer_reading="first quality-1 reserve witness inside the same-sign hardening body",
            source_surfaces=[SOURCE_FILES["reserve_ngc5033"].name],
            public_delta_aic_total=reserve_witness["public_delta_aic_total"],
            faithful_delta_aic_total=reserve_witness["faithful_delta_aic_total"],
            component_aware_delta_aic_total=reserve_witness["component_aware_delta_aic_total"],
            component_aware_shift=reserve_witness["component_aware_shift"],
            quality_flag=reserve_witness["quality_flag"],
        )
    )

    reserve_witness = reserve_ugc02487["witness"]
    cases.append(
        build_case_entry(
            case_id=reserve_witness["case_id"],
            case_class="executed_named_witness",
            morphology="same_sign_hardening",
            status="executed_matched_nuisance_witness",
            reviewer_reading="second quality-1 reserve witness inside the same-sign hardening body",
            source_surfaces=[SOURCE_FILES["reserve_ugc02487"].name],
            public_delta_aic_total=reserve_witness["public_delta_aic_total"],
            faithful_delta_aic_total=reserve_witness["faithful_delta_aic_total"],
            component_aware_delta_aic_total=reserve_witness["component_aware_delta_aic_total"],
            component_aware_shift=reserve_witness["component_aware_shift"],
            quality_flag=reserve_witness["quality_flag"],
        )
    )

    reserve_witness = reserve_ugc03205["witness"]
    cases.append(
        build_case_entry(
            case_id=reserve_witness["case_id"],
            case_class="executed_named_witness",
            morphology="same_sign_hardening",
            status="executed_matched_nuisance_witness",
            reviewer_reading="third quality-1 reserve witness inside the same-sign hardening body",
            source_surfaces=[SOURCE_FILES["reserve_ugc03205"].name],
            public_delta_aic_total=reserve_witness["public_delta_aic_total"],
            faithful_delta_aic_total=reserve_witness["faithful_delta_aic_total"],
            component_aware_delta_aic_total=reserve_witness["component_aware_delta_aic_total"],
            component_aware_shift=reserve_witness["component_aware_shift"],
            quality_flag=reserve_witness["quality_flag"],
        )
    )

    quality2_witness = quality2_sidecar["witness"]
    cases.append(
        build_case_entry(
            case_id=quality2_witness["case_id"],
            case_class="executed_named_witness",
            morphology="same_sign_hardening",
            status="executed_matched_nuisance_witness",
            reviewer_reading="only bounded quality-2 continuation inside the same-sign hardening body",
            source_surfaces=[SOURCE_FILES["quality2_sidecar"].name],
            public_delta_aic_total=quality2_witness["public_delta_aic_total"],
            faithful_delta_aic_total=quality2_witness["faithful_delta_aic_total"],
            component_aware_delta_aic_total=quality2_witness["component_aware_delta_aic_total"],
            component_aware_shift=quality2_witness["component_aware_shift"],
            quality_flag=quality2_witness["quality_flag"],
        )
    )

    cases.append(
        build_case_entry(
            case_id="SPARC_NGC5055",
            case_class="protected_family_pressure_case",
            morphology="repeated_toward_qct_cross_lane_singleton",
            status="packet_visible_role_only",
            reviewer_reading="repeated toward QCT across both currently cited programs",
            source_surfaces=[
                SOURCE_FILES["clean_anchor_dispersion"].name,
                "CURRENT_FULL_HEAD_THREE_BLOCK_BURDEN_HIERARCHY_V1.json",
            ],
        )
    )

    cases.append(
        build_case_entry(
            case_id="SPARC_UGC11914",
            case_class="protected_family_pressure_case",
            morphology="structure_sensitive_protected_adverse_case",
            status="packet_visible_adjudicated_pressure_case",
            reviewer_reading="structure-sensitive stress object, not blunt stand-alone falsifier",
            source_surfaces=[
                "UGC11914_STRUCTURE_SENSITIVE_WITNESS_AND_NON_BLUNT_FALSIFIER_NOTE_20260608.md",
                "O7_D33B_UGC11914_RELEASE_ARTIFACT_SPLIT_ADJUDICATION_20260608.md",
            ],
            public_delta_aic_total=654.4865504512914,
            faithful_delta_aic_total=527.6553640570605,
            component_aware_delta_aic_total=533.0880840993498,
            component_aware_shift=5.432720042289247,
            release_side_delta_aic_total=-418.95087549513755,
        )
    )

    for frontier in reinflation_microfront["reinflation_microfront"]["selected_next_batch"]:
        cases.append(
            build_case_entry(
                case_id=frontier["case_id"],
                case_class="live_frontier_microfront",
                morphology="reinflation_opening_selected_batch",
                status="selected_live_frontier_case",
                reviewer_reading=frontier["reason"],
                source_surfaces=[SOURCE_FILES["reinflation_microfront"].name],
            )
        )

    for frontier in reinflation_microfront["reinflation_microfront"]["reserve_cases"]:
        cases.append(
            build_case_entry(
                case_id=frontier["case_id"],
                case_class="live_frontier_microfront",
                morphology="reinflation_opening_reserve",
                status="reserve_live_frontier_case",
                reviewer_reading=frontier["reason"],
                source_surfaces=[SOURCE_FILES["reinflation_microfront"].name],
            )
        )

    return sorted(cases, key=lambda item: item["order"])


def write_case_surfaces(cases):
    for case in cases:
        case_root = CASES_ROOT / case["case_id"]
        summary = dict(case)
        write_json(case_root / "summary.json", summary)

        numeric_lines = []
        for key in (
            "public_delta_aic_total",
            "faithful_delta_aic_total",
            "component_aware_delta_aic_total",
            "component_aware_shift",
            "release_side_delta_aic_total",
        ):
            value = case.get(key)
            if value is not None:
                numeric_lines.append(f"- `{key} = {value}`")

        if not numeric_lines:
            numeric_lines.append("- no symmetric packet-visible numeric comparator row is frozen here yet")

        source_lines = [f"- `{item}`" for item in case["source_surfaces"]]
        note = f"""# {case["case_id"]} Family Court Case Note

Date: `2026-06-10`

Status: `{case["status"]}`

Case class:

- `{case["case_class"]}`

Morphology:

- `{case["morphology"]}`

Reviewer-facing reading:

- {case["reviewer_reading"]}

Visible numeric surface:

{chr(10).join(numeric_lines)}

Source surfaces:

{chr(10).join(source_lines)}
"""
        write_text(case_root / "CASE_NOTE.md", note)


def write_protocol_surfaces():
    write_text(PROTOCOL_ROOT / "SAME_CONVENTION_COMPARATOR_LAW.md", CASE_PROTOCOL_TEXT)
    write_text(PROTOCOL_ROOT / "NUISANCE_PARITY_LOCK.md", NUISANCE_PROTOCOL_TEXT)
    write_text(PROTOCOL_ROOT / "FAMILY_VERDICT_BOUNDARY.md", VERDICT_BOUNDARY_TEXT)


def write_case_table(cases):
    path = OUTPUT_ROOT / "family_case_table.csv"
    fieldnames = [
        "case_id",
        "case_class",
        "morphology",
        "status",
        "quality_flag",
        "public_delta_aic_total",
        "faithful_delta_aic_total",
        "component_aware_delta_aic_total",
        "component_aware_shift",
        "release_side_delta_aic_total",
        "source_surface",
        "reviewer_reading",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for case in cases:
            writer.writerow(
                {
                    "case_id": case["case_id"],
                    "case_class": case["case_class"],
                    "morphology": case["morphology"],
                    "status": case["status"],
                    "quality_flag": csv_cell(case["quality_flag"]),
                    "public_delta_aic_total": csv_cell(case["public_delta_aic_total"]),
                    "faithful_delta_aic_total": csv_cell(case["faithful_delta_aic_total"]),
                    "component_aware_delta_aic_total": csv_cell(case["component_aware_delta_aic_total"]),
                    "component_aware_shift": csv_cell(case["component_aware_shift"]),
                    "release_side_delta_aic_total": csv_cell(case["release_side_delta_aic_total"]),
                    "source_surface": " | ".join(case["source_surfaces"]),
                    "reviewer_reading": case["reviewer_reading"],
                }
            )


def write_delta_table(cases):
    path = OUTPUT_ROOT / "family_delta_aic_bic.csv"
    fieldnames = [
        "case_id",
        "morphology",
        "public_delta_aic_total",
        "faithful_delta_aic_total",
        "component_aware_delta_aic_total",
        "component_aware_shift",
        "public_delta_bic_total",
        "faithful_delta_bic_total",
        "component_aware_delta_bic_total",
        "bic_visibility_status",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for case in cases:
            if case["case_class"] != "executed_named_witness":
                continue
            writer.writerow(
                {
                    "case_id": case["case_id"],
                    "morphology": case["morphology"],
                    "public_delta_aic_total": csv_cell(case["public_delta_aic_total"]),
                    "faithful_delta_aic_total": csv_cell(case["faithful_delta_aic_total"]),
                    "component_aware_delta_aic_total": csv_cell(case["component_aware_delta_aic_total"]),
                    "component_aware_shift": csv_cell(case["component_aware_shift"]),
                    "public_delta_bic_total": "",
                    "faithful_delta_bic_total": "",
                    "component_aware_delta_bic_total": "",
                    "bic_visibility_status": "current_family_scale_packet_surface_is_aic_centered_beyond_case_local_shells",
                }
            )


def write_morphology_table():
    morphology_partition = load_json(SOURCE_FILES["morphology_partition"])
    partitions = morphology_partition["partitions"]
    rows = [
        {
            "morphology": "route_split",
            "member_count": partitions["route_split"]["summary"]["witness_count"],
            "members": "|".join(partitions["route_split"]["members"]),
            "public_delta_aic_total": partitions["route_split"]["summary"]["public_delta_aic_total"],
            "faithful_delta_aic_total": partitions["route_split"]["summary"]["faithful_delta_aic_total"],
            "component_aware_delta_aic_total": partitions["route_split"]["summary"]["component_aware_delta_aic_total"],
            "component_aware_shift": partitions["route_split"]["summary"]["component_aware_shift"],
        },
        {
            "morphology": "same_sign_softening",
            "member_count": partitions["same_sign_softening"]["summary"]["witness_count"],
            "members": "|".join(partitions["same_sign_softening"]["members"]),
            "public_delta_aic_total": partitions["same_sign_softening"]["summary"]["public_delta_aic_total"],
            "faithful_delta_aic_total": partitions["same_sign_softening"]["summary"]["faithful_delta_aic_total"],
            "component_aware_delta_aic_total": partitions["same_sign_softening"]["summary"]["component_aware_delta_aic_total"],
            "component_aware_shift": partitions["same_sign_softening"]["summary"]["component_aware_shift"],
        },
        {
            "morphology": "same_sign_hardening",
            "member_count": partitions["same_sign_hardening_hubble_flow_sensitive_body"]["summary"]["witness_count"],
            "members": "|".join(partitions["same_sign_hardening_hubble_flow_sensitive_body"]["members"]),
            "public_delta_aic_total": partitions["same_sign_hardening_hubble_flow_sensitive_body"]["summary"]["public_delta_aic_total"],
            "faithful_delta_aic_total": partitions["same_sign_hardening_hubble_flow_sensitive_body"]["summary"]["faithful_delta_aic_total"],
            "component_aware_delta_aic_total": partitions["same_sign_hardening_hubble_flow_sensitive_body"]["summary"]["component_aware_delta_aic_total"],
            "component_aware_shift": partitions["same_sign_hardening_hubble_flow_sensitive_body"]["summary"]["component_aware_shift"],
        },
    ]

    path = OUTPUT_ROOT / "route_split_morphology_table.csv"
    fieldnames = [
        "morphology",
        "member_count",
        "members",
        "public_delta_aic_total",
        "faithful_delta_aic_total",
        "component_aware_delta_aic_total",
        "component_aware_shift",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: csv_cell(value) for key, value in row.items()})


def build_verdict(cases):
    morphology_partition = load_json(SOURCE_FILES["morphology_partition"])
    route_split_tension = load_json(SOURCE_FILES["route_split_tension"])
    clean_anchor_dispersion = load_json(SOURCE_FILES["clean_anchor_dispersion"])
    reinflation_microfront = load_json(SOURCE_FILES["reinflation_microfront"])

    executed_cases = [case for case in cases if case["case_class"] == "executed_named_witness"]
    protected_cases = [case["case_id"] for case in cases if case["case_class"] == "protected_family_pressure_case"]
    frontier_cases = [case["case_id"] for case in cases if case["case_class"] == "live_frontier_microfront"]

    verdict = {
        "date": "2026-06-10",
        "status": "materialized_reviewer_facing_family_court",
        "surface": "mond_qumond_family_court_v1",
        "g3_family_court_materialized": True,
        "d1_reinflation_microfront_materialized": True,
        "d2_family_verdict_materialized": True,
        "whole_family_total_closure_claimed": False,
        "differential_claim_standard": "same_procedure_matched_nuisance_on_both_sides",
        "current_ngc0247_allowed_reading": (
            "under symmetric matched-nuisance MLE treatment, QCT is procedurally preferred "
            "to QUMOND at NGC0247"
        ),
        "bayesian_evidence_claimed": False,
        "later_stronger_method_front": "independent_upsilon_prior_full_marginalization_bayes_factor",
        "executed_named_witness_count": len(executed_cases),
        "executed_named_morphology_counts": {
            "route_split": 1,
            "same_sign_softening": 1,
            "same_sign_hardening": 10,
        },
        "executed_named_totals": morphology_partition["named_executed_absolute_burden_totals"],
        "protected_family_pressure_cases": protected_cases,
        "live_frontier_cases": frontier_cases,
        "live_frontier_selected_batch": [
            item["case_id"] for item in reinflation_microfront["reinflation_microfront"]["selected_next_batch"]
        ],
        "live_frontier_reserve": [
            item["case_id"] for item in reinflation_microfront["reinflation_microfront"]["reserve_cases"]
        ],
        "current_family_scale_verdict": [
            "the named executed matched-nuisance court is already family-scale and reproducible",
            "all named nonhardening behavior at executed matched-nuisance scale is exhausted by NGC0247 and NGC6946",
            "the ten-witness executed body remains uniformly same-sign hardening",
            "NGC5055 remains one protected repeated-toward-QCT cross-lane singleton",
            "UGC11914 remains one protected structure-sensitive adverse case rather than one blunt falsifier",
            "the next best-dressed live frontier remains the exact D72 reinflation-opening microfront"
        ],
        "not_supported_now": [
            "Whole-family MOND_QUMOND total defeat",
            "Erasure of the NGC0247 route split",
            "Erasure of the NGC6946 softening exception",
            "D72 reinflation batch already executed",
            "UGC11914 already physically explained",
        ],
        "key_numeric_anchors": {
            "ngc0247_faithful_delta_aic_total": route_split_tension["local_route_split_witness"]["live_matched_nuisance_return"]["faithful_delta_aic_total"],
            "ngc6946_component_aware_delta_aic_total": morphology_partition["partitions"]["same_sign_softening"]["witness"]["component_aware_delta_aic_total"],
            "ten_witness_public_delta_aic_total": route_split_tension["ten_witness_hardening_body"]["combined_burden"]["public_delta_aic_total"],
            "clean_anchor_minority_case_count": clean_anchor_dispersion["clean_anchor_minority_court"]["case_count"],
            "clean_anchor_minority_public_delta_aic_total": clean_anchor_dispersion["clean_anchor_minority_court"]["public_delta_aic_total"],
        },
        "verdict": "G3_FAMILY_COURT_MATERIALIZED__THE_REVIEWER_FACING_FAMILY_COMPARATOR_OBJECT_NOW_EXISTS_WITH_12_EXECUTED_WITNESSES_TWO_PROTECTED_PRESSURE_TYPES_AND_ONE_EXACT_LIVE_REINFLATION_MICROFRONT_WITHOUT_CLAIMING_WHOLE_FAMILY_TOTAL_CLOSURE",
    }
    return verdict


def write_verdict(verdict):
    write_json(OUTPUT_ROOT / "verdict.json", verdict)


def write_report(cases, verdict):
    executed_cases = [case for case in cases if case["case_class"] == "executed_named_witness"]
    protected_cases = [case for case in cases if case["case_class"] == "protected_family_pressure_case"]
    frontier_cases = [case for case in cases if case["case_class"] == "live_frontier_microfront"]
    report = f"""# MOND/QUMOND Family Court Report

Date: `2026-06-10`

Status: `materialized reviewer-facing family court`

## Short verdict

`MOND_QUMOND_FAMILY_COURT_V1` now exists as one reviewer-facing family-scale
comparator object.

It carries:

- `{len(executed_cases)}` executed named matched-nuisance witnesses
- `{len(protected_cases)}` protected family-pressure cases
- `{len(frontier_cases)}` live reinflation-frontier cases

## Method ceiling

- current differential reading = procedural preference under symmetric
  matched-nuisance `MLE` treatment
- Bayesian evidence claimed = `{str(verdict["bayesian_evidence_claimed"]).lower()}`
- later stronger method front =
  `{verdict["later_stronger_method_front"]}`

## Executed court morphology

- route split count = `1`
- same-sign softening count = `1`
- same-sign hardening count = `10`

## Protected family-pressure cases

{"".join(f"- `{case['case_id']}` = {case['reviewer_reading']}\n" for case in protected_cases)}

## Live frontier

{"".join(f"- `{case['case_id']}` = {case['reviewer_reading']}\n" for case in frontier_cases)}

## Boundary

- whole-family total closure claimed = `{str(verdict["whole_family_total_closure_claimed"]).lower()}`
- `D1` materialized = `{str(verdict["d1_reinflation_microfront_materialized"]).lower()}`
- `D2` materialized = `{str(verdict["d2_family_verdict_materialized"]).lower()}`
"""
    write_text(OUTPUT_ROOT / "FAMILY_COURT_REPORT.md", report)


def main():
    ensure_dirs()
    for path in SOURCE_FILES.values():
        if not path.exists():
            raise FileNotFoundError(f"missing required source surface: {path}")

    cases = build_case_entries()
    write_case_surfaces(cases)
    write_protocol_surfaces()
    write_case_table(cases)
    write_delta_table(cases)
    write_morphology_table()
    verdict = build_verdict(cases)
    write_verdict(verdict)
    write_report(cases, verdict)
    print(json.dumps({"status": "ok", "generated_case_count": len(cases), "verdict_path": str(OUTPUT_ROOT / "verdict.json")}))


if __name__ == "__main__":
    main()
