# SPARC_UGC02953 Family Court Case Note

Date: `2026-06-10`

Status: `executed_matched_nuisance_witness`

Case class:

- `executed_named_witness`

Morphology:

- `same_sign_hardening`

Reviewer-facing reading:

- primary parity core witness inside the same-sign hardening body

Visible numeric surface:

- `public_delta_aic_total = 23006.79616540764`
- `faithful_delta_aic_total = 13674.629519818027`
- `component_aware_delta_aic_total = 14050.678497308445`
- `component_aware_shift = 376.0489774904181`

Source surfaces:

- `PRIMARY_PARITY_CORE_TRIAD_ORDER_AND_UNIFORM_COMPONENT_HARDENING_V1.json`
