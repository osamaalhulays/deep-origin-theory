# SPARC_UGC05253 Family Court Case Note

Date: `2026-06-10`

Status: `executed_matched_nuisance_witness`

Case class:

- `executed_named_witness`

Morphology:

- `same_sign_hardening`

Reviewer-facing reading:

- only bounded quality-2 continuation inside the same-sign hardening body

Visible numeric surface:

- `public_delta_aic_total = 7163.349725740571`
- `faithful_delta_aic_total = 5773.385358167621`
- `component_aware_delta_aic_total = 5890.42421601313`
- `component_aware_shift = 117.03885784550857`

Source surfaces:

- `UGC05253_BOUNDED_QUALITY2_SIDECAR_ENTRY_V1.json`
