# SPARC_NGC6946 Family Court Case Note

Date: `2026-06-10`

Status: `executed_matched_nuisance_witness`

Case class:

- `executed_named_witness`

Morphology:

- `same_sign_softening`

Reviewer-facing reading:

- only named executed same-sign softening witness

Visible numeric surface:

- `public_delta_aic_total = 1166.5509651336554`
- `faithful_delta_aic_total = 1033.7327930524393`
- `component_aware_delta_aic_total = 944.931988370284`
- `component_aware_shift = -88.80080468215533`
- `release_side_delta_aic_total = 76.37985194114344`

Source surfaces:

- `NAMED_EXECUTED_MATCHED_NUISANCE_COURT_MORPHOLOGY_PARTITION_V1.json`
