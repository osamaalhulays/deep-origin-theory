# SPARC_UGC02487 Family Court Case Note

Date: `2026-06-10`

Status: `executed_matched_nuisance_witness`

Case class:

- `executed_named_witness`

Morphology:

- `same_sign_hardening`

Reviewer-facing reading:

- second quality-1 reserve witness inside the same-sign hardening body

Visible numeric surface:

- `public_delta_aic_total = 5395.448939562626`
- `faithful_delta_aic_total = 4194.204085355166`
- `component_aware_delta_aic_total = 4616.2697654791955`
- `component_aware_shift = 422.0656801240293`

Source surfaces:

- `UGC02487_SECOND_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json`
