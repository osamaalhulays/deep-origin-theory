# SPARC_UGC06786 Family Court Case Note

Date: `2026-06-10`

Status: `executed_matched_nuisance_witness`

Case class:

- `executed_named_witness`

Morphology:

- `same_sign_hardening`

Reviewer-facing reading:

- residual reopening witness inside the same-sign hardening body

Visible numeric surface:

- `public_delta_aic_total = 11014.272641235095`
- `faithful_delta_aic_total = 8211.136581522982`
- `component_aware_delta_aic_total = 8968.011104353986`
- `component_aware_shift = 756.8745228310036`

Source surfaces:

- `RESIDUAL_QUALITY1_REOPENING_TRIAD_CLOSURE_V1.json`
