# SPARC_UGC09133 Family Court Case Note

Date: `2026-06-10`

Status: `executed_matched_nuisance_witness`

Case class:

- `executed_named_witness`

Morphology:

- `same_sign_hardening`

Reviewer-facing reading:

- primary parity core witness inside the same-sign hardening body

Visible numeric surface:

- `public_delta_aic_total = 32434.41205692153`
- `faithful_delta_aic_total = 17318.65683423732`
- `component_aware_delta_aic_total = 18687.351246554146`
- `component_aware_shift = 1368.694412316825`

Source surfaces:

- `PRIMARY_PARITY_CORE_TRIAD_ORDER_AND_UNIFORM_COMPONENT_HARDENING_V1.json`
