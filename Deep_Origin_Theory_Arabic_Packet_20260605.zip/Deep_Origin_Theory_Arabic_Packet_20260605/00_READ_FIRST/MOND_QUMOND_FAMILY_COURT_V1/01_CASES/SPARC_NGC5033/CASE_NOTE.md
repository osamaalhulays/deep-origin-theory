# SPARC_NGC5033 Family Court Case Note

Date: `2026-06-10`

Status: `executed_matched_nuisance_witness`

Case class:

- `executed_named_witness`

Morphology:

- `same_sign_hardening`

Reviewer-facing reading:

- first quality-1 reserve witness inside the same-sign hardening body

Visible numeric surface:

- `public_delta_aic_total = 5570.267649338578`
- `faithful_delta_aic_total = 4985.679012905682`
- `component_aware_delta_aic_total = 5652.826397413262`
- `component_aware_shift = 667.1473845075807`

Source surfaces:

- `NGC5033_FIRST_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json`
