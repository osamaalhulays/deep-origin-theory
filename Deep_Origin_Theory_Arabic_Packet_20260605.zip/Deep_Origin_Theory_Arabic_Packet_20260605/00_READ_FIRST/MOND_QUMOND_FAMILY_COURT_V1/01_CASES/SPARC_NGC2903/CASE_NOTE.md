# SPARC_NGC2903 Family Court Case Note

Date: `2026-06-10`

Status: `executed_matched_nuisance_witness`

Case class:

- `executed_named_witness`

Morphology:

- `same_sign_hardening`

Reviewer-facing reading:

- residual reopening witness inside the same-sign hardening body

Visible numeric surface:

- `public_delta_aic_total = 9732.29415949837`
- `faithful_delta_aic_total = 8055.354864442071`
- `component_aware_delta_aic_total = 8118.33166010191`
- `component_aware_shift = 62.9767956598389`

Source surfaces:

- `RESIDUAL_QUALITY1_REOPENING_TRIAD_CLOSURE_V1.json`
