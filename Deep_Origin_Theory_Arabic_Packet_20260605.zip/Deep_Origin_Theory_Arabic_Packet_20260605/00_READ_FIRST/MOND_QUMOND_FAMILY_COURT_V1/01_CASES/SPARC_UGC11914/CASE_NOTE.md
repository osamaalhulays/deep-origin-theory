# SPARC_UGC11914 Family Court Case Note

Date: `2026-06-10`

Status: `packet_visible_adjudicated_pressure_case`

Case class:

- `protected_family_pressure_case`

Morphology:

- `structure_sensitive_protected_adverse_case`

Reviewer-facing reading:

- structure-sensitive stress object, not blunt stand-alone falsifier

Visible numeric surface:

- `public_delta_aic_total = 654.4865504512914`
- `faithful_delta_aic_total = 527.6553640570605`
- `component_aware_delta_aic_total = 533.0880840993498`
- `component_aware_shift = 5.432720042289247`
- `release_side_delta_aic_total = -418.95087549513755`

Source surfaces:

- `UGC11914_STRUCTURE_SENSITIVE_WITNESS_AND_NON_BLUNT_FALSIFIER_NOTE_20260608.md`
- `O7_D33B_UGC11914_RELEASE_ARTIFACT_SPLIT_ADJUDICATION_20260608.md`
