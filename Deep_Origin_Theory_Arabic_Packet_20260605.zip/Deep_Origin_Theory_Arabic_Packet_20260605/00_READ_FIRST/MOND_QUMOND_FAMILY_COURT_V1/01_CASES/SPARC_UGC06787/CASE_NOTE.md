# SPARC_UGC06787 Family Court Case Note

Date: `2026-06-10`

Status: `executed_matched_nuisance_witness`

Case class:

- `executed_named_witness`

Morphology:

- `same_sign_hardening`

Reviewer-facing reading:

- primary parity core witness inside the same-sign hardening body

Visible numeric surface:

- `public_delta_aic_total = 18445.643819821606`
- `faithful_delta_aic_total = 13840.38083015469`
- `component_aware_delta_aic_total = 14866.53967863251`
- `component_aware_shift = 1026.1588484778185`

Source surfaces:

- `PRIMARY_PARITY_CORE_TRIAD_ORDER_AND_UNIFORM_COMPONENT_HARDENING_V1.json`
