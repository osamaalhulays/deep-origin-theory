# SPARC_NGC0247 Family Court Case Note

Date: `2026-06-10`

Status: `executed_matched_nuisance_witness`

Case class:

- `executed_named_witness`

Morphology:

- `route_split`

Reviewer-facing reading:

- only named executed pro-QCT route-split witness

Visible numeric surface:

- `public_delta_aic_total = -13.914066963632308`
- `faithful_delta_aic_total = -15.398764714420167`
- `component_aware_delta_aic_total = -39.63154845025974`
- `component_aware_shift = -24.232783735839575`
- `release_side_delta_aic_total = 330.508310757082`

Source surfaces:

- `CURRENT_REVIEWER_FACING_ROUTE_SPLIT_AND_FULL_BODY_EMPIRICAL_TENSION_V1.json`
- `NAMED_EXECUTED_MATCHED_NUISANCE_COURT_MORPHOLOGY_PARTITION_V1.json`
