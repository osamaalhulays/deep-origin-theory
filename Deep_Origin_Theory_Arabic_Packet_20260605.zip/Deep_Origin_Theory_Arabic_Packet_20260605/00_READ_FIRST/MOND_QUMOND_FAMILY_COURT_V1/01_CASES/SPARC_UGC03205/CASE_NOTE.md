# SPARC_UGC03205 Family Court Case Note

Date: `2026-06-10`

Status: `executed_matched_nuisance_witness`

Case class:

- `executed_named_witness`

Morphology:

- `same_sign_hardening`

Reviewer-facing reading:

- third quality-1 reserve witness inside the same-sign hardening body

Visible numeric surface:

- `public_delta_aic_total = 4924.190931628839`
- `faithful_delta_aic_total = 4326.343492450953`
- `component_aware_delta_aic_total = 4965.0202347622035`
- `component_aware_shift = 638.6767423112506`

Source surfaces:

- `UGC03205_THIRD_QUALITY1_RESERVE_BRANCH_ENTRY_V1.json`
