# SPARC_NGC6674 Family Court Case Note

Date: `2026-06-10`

Status: `executed_matched_nuisance_witness`

Case class:

- `executed_named_witness`

Morphology:

- `same_sign_hardening`

Reviewer-facing reading:

- residual reopening witness inside the same-sign hardening body

Visible numeric surface:

- `public_delta_aic_total = 7262.309486708873`
- `faithful_delta_aic_total = 5879.069786876613`
- `component_aware_delta_aic_total = 6964.646297886829`
- `component_aware_shift = 1085.5765110102166`

Source surfaces:

- `RESIDUAL_QUALITY1_REOPENING_TRIAD_CLOSURE_V1.json`
