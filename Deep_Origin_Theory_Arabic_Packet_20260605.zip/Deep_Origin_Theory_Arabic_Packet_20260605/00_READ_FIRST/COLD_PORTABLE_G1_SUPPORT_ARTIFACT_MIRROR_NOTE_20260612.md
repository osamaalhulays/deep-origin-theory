# Cold-Portable `G1` Support-Artifact Mirror Note

Date: `2026-06-12`

The current upper `G1` packet line now contains many reviewer-facing bounded
objects whose reproduction runners still lawfully reference:

- `artifacts/debt_board_20260530/...`

That is acceptable inside the author workspace, but it was not yet sufficient
for one cold reviewer who unpacks only the latest public ZIP and tries to run
those `POST_CAGE_BRANCH_U1` reproduction scripts directly.

The bounded fix is now:

- the latest cold ZIP intentionally carries one sibling mirror of the exact
  `artifacts/debt_board_20260530` subset required by the current
  `POST_CAGE_BRANCH_U1` reproduction runners
- the fileset is declared in
  `artifacts/debt_board_20260530/G1_COLD_PORTABLE_SUPPORT_ARTIFACT_MIRROR_FILESET_20260612.json`
- the mirror is support-only for cold audit portability
- it is **not** one new science claim, one new theorem witness, or one hidden
  widening of the packet's public scope

So the intended cold-review reading is now:

- packet-local `G1` reviewer objects remain the visible science layer
- the sibling mirror is only the exact support floor that lets the visible
  reproduction runners execute from the cold ZIP without requiring the author
  workspace

This is a packaging fix, not a truth promotion.
