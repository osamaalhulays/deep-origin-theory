# `NGC0247` Phase-2 Matched-Nuisance Window Replay And No-Rescue Note

Date: `2026-06-09`

Status: `packet-contained replay closure`

Purpose:

This note closes the next exact tooth above the already-frozen
`NGC0247` parity-ready pilot object and the already-frozen
matched-nuisance source-policy lock.

The open question used to be:

- can the lawful `distance / inclination` replay actually be executed,
- or does the packet still stop at policy naming only?

That question is now closed.

## Short verdict

The lawful `±1 sigma` `distance / inclination` matched-nuisance window replay
for the preserved `NGC0247` Phase-2 lane is now executable from packet
objects, and it does **not** rescue `QCT`.

Across the full visible source window:

- the historical mixed shell stays anti-`QCT`
- the reoptimized same-convention `obs-only` shell stays anti-`QCT`
- the one-extra-`QCT`-penalty `obs-only` shell stays anti-`QCT`

The window moves the `Delta AIC` only slightly.

It does not flip the sign.

## What is rebuilt now

The replay is rebuilt from packet-contained objects:

1. `NGC0247_PHASE2_SOURCE_CASE_V1.json`
2. `NGC0247_PHASE2_PRED_ONE_V1.ndjson`
3. `NGC0247_MATCHED_NUISANCE_SOURCE_SUPPORT_V1.json`
4. `REPRODUCE_NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_V1.py`
5. `NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_V1.json`

The source-side replay laws are frozen explicitly as:

- `R' = R * (D' / D)`
- `v_bar' = v_bar * sqrt(D' / D)`
- `v_obs' = v_obs * sin(i) / sin(i')`
- `sigma_v' = sigma_v * sin(i) / sin(i')`

So this is no longer one remembered nuisance policy.

It is one replayed bounded object.

For cold review discipline, this replay is packet-sufficient even without any
optional external archive.

The packet-visible replay path remains:

- `historical_delta_surface_replay_mode = packet_visible_delta_1d_replay_only`

unless one author-side opt-in explicitly enables archival inspection.

## What the preserved historical archive adds

When one author-side opt-in archival inspection is enabled and the
historically matching single-case archive is present, the replay now also
confirms one deeper structural fact:

- the preserved `external_model_v2.npz` member set for this exact lane has
  `delta_1d.npy` and `sigma_delta_1d.npy`
- it does **not** have `features_hashes.npy`

So even though the sibling metadata file still carries `v2_schema = true`,
the actual preserved member layout puts this exact lane on one effective
`V1_fixed_delta_surface` replay path rather than one feature-hash-indexed
surface.

That matters because it removes one false blocker:

- this replay is not waiting for one hidden visible `features_hash` lookup to
  perturb the preserved `Delta` rows.

## Main numeric result

At the adopted central source point:

- historical mixed shell:
  `Delta AIC = +159.88921767501586`
- reoptimized equal-free `obs-only` shell:
  `Delta AIC = +293.31161341697657`
- reoptimized extra-penalty `obs-only` shell:
  `Delta AIC = +295.31161341697657`

Across the full lawful `±1 sigma` window:

- best point for `QCT` sits at
  `D = 3.89 Mpc`, `i = 77.0 deg`
- worst point for `QCT` sits at
  `D = 3.51 Mpc`, `i = 71.0 deg`

Window spans:

- historical mixed shell:
  `Delta AIC` span = `0.9961164074815088`
- reoptimized equal-free `obs-only` shell:
  `Delta AIC` span = `0.9961164074816224`
- reoptimized extra-penalty `obs-only` shell:
  `Delta AIC` span = `0.9961164074816224`

So the whole lawful source window moves the score by **less than one AIC
point** in every shell reported here.

## Why this is stronger than the earlier negative control

The earlier bounded same-convention control note fenced the preserved
historical shell as anti-`QCT`.

This new replay does something stronger:

- it actually perturbs the source geometry inside the lawful visible window
- and it reoptimizes the fitted nuisance values on the replayed shell

So this note is not just saying:

- the old control remained negative

It is saying:

- even a friendlier lawful nuisance replay inside the visible `distance /
  inclination` box does not rescue the preserved `NGC0247` Phase-2 lane.

## Historical consequence at issuance, and current live consequence after `O8` retirement

### `O6` closes one more exact tooth here

`O6` no longer stops at:

- parity-readiness gate,
- pilot-object materialization,
- or source-policy naming.

It now also carries:

- one executed bounded lawful `distance / inclination` window replay with a
  no-rescue verdict on the named spear.

### The historical `O8` side above this replay was

What still stayed above this replay at issuance was narrower:

- the clean promotable scoring rule to emphasize outwardly
- the cleaner provenance object behind the fitted current lane
- and any broader sample-level fairness promotion beyond this one named
  replayed witness

Current live reading is now narrower again:

- the raw Phase-2 replacement branch is closed
- the old live `O8` replacement pressure is retired
- the first executed witness and its outward shell are packet-contained
- and the surviving live burden is broader executed-court extension under the
  preserved bifurcated boundary

## Claim ceiling

This note does **not** claim:

- whole-family `MOND/QUMOND` closure
- that every future nuisance family will behave the same way
- that the fitted-`Y` provenance gap is fully solved
- or that broader representative matched-nuisance execution is finished

It only claims:

- the lawful visible `distance / inclination` replay now exists as one
  packet-contained bounded object
- and that replay does not rescue the preserved `NGC0247` Phase-2 lane

## Best outward-safe reading

The packet may now say:

> The named `NGC0247` spear no longer stops at parity-readiness, source-policy
> naming, or historical-control fencing. Its lawful visible `distance /
> inclination` matched-nuisance window is now replayable from packet objects,
> and that replay does not rescue the preserved Phase-2 `QCT` lane. The next
> remaining work is therefore no longer basic replay admissibility, but wider
> sample-level execution and the cleaner provenance shell above this bounded
> witness.
