# Comparator Symmetry Front Card

Date: `2026-06-06`

This front card exists to make one point explicit:

the question "Deep Origin Theory vs `MOND/QUMOND`" is not only a matter of who
wins one frozen strict benchmark.

It is also a matter of how fair the comparator lane is.

## Short reading

The packet already preserves one important strict lane:

- source-locked,
- fixed-comparator,
- low-cosmetic,
- reviewer-auditable,
- and intentionally hostile to silent rescue.

That lane is scientifically valuable.
But it is not the only fair lane that a serious reader may want.

The older record is also stronger than a cold current reading may infer.
Deep recovery now shows that a reviewer-hard fairness doctrine and a broader
sentinel pressure family already existed historically rather than appearing
only as a late wish.

The fairest public next step is to state a three-lane comparator program
explicitly:

1. `strict-austere lane`
2. `matched-nuisance parity lane`
3. `best-dressed adversarial lane`

## Why this matters

If one side is evaluated under near-zero cosmetic freedom while the other side
is usually discussed together with wider nuisance handling, published
preprocessing, and geometry allowances, then a reasonable fairness question
exists:

- are we seeing theory strength only,
- or theory strength plus protocol asymmetry?

The right answer is not complaint.
It is comparator symmetry.

For the recovered older fairness doctrine and broader sentinel-family memory
behind this front, also read:

- `RECOVERED_DATED_QUMOND_FAIRNESS_AND_SENTINEL_FAMILY_NOTE_20260606.md`

## What this section does not claim

This section does **not** claim:

- that the current packet already closes the whole-family `MOND/QUMOND`
  question,
- that every comparator lane has already been executed,
- or that nuisance parity automatically favors the present theory.

Its claim is narrower and stronger:

- comparator fairness itself should be presented as a governed empirical
  object,
- not as a hidden background assumption.

## Best short outward-safe reading

The right public posture is:

- the current strict lane remains valid and important,
- the older record had already materialized a harder fairness doctrine plus a
  wider sentinel-family stress memory,
- but the fairest completed comparison program should distinguish raw
  low-cosmetic stress, matched-nuisance parity, and best-dressed adversarial
  comparison rather than collapsing all comparator culture into one lane.
