# Prediction Axis Full-Score Candidate Note

Date: `2026-06-06`

Status: `candidate scoring note`

## Purpose

This note records the strongest score-maximization reading that can now be
argued **without** adding new science.

It does not force that reading on every reviewer.
It exists so the packet can distinguish between:

- one still-defensible conservative public read,
- and one stronger full-score candidate read.

## Conservative read still available

One conservative packet read remains:

- `testable = 11/12`
- `falsifiability = 9/10`
- `differential = 8/8`
- `precision = 6/6`

This remains defensible for readers who still choose to count:

- the absent original stored best-fit nuisance file
  as a live testability subtraction,
- and the previously distributed falsifier culture
  as still slightly under-fronted.

## Stronger candidate read now available

A stronger packet-wide candidate read is now materially present:

- `testable = 12/12` candidate
- `falsifiability = 10/10` candidate
- `differential = 8/8`
- `precision = 6/6`

That yields:

- `36/36` as a candidate reading of the prediction / testability /
  falsifiability axis.

## Why the full-score candidate is now materially present

### Candidate lift for testability

The packet now already exposes:

- the named source case object,
- the named current predictor surface,
- recovered fitted nuisance values,
- a row-level current comparator,
- a reproduction script,
- and machine-tolerance reproduction of the preserved Phase-2 totals.

That is why the remaining `NGC0247` gap can now be read as archival rather
than testability-only.

See:

- `PREDICTION_AXIS_TESTABILITY_RECLASSIFICATION_NOTE_20260606.md`

### Candidate lift for falsifiability

The packet now already exposes:

- one unified falsifier and kill-front map,
- explicit `F1-F6`,
- explicit later kill-fronts,
- and explicit carry-forward discipline that prevents partial success from
  silently retiring later falsifiers.

That is why the remaining falsifiability weakness is no longer best read as
absence of failure culture.

See:

- `UNIFIED_KILL_FRONT_AND_FALSIFIER_MAP_20260606.md`

## What this candidate note does **not** do

This note does **not** turn the axis candidate into:

- whole-family `MOND/QUMOND` closure,
- final observational victory,
- or a widened program claim.

It is only a score candidate built from already visible bounded packet
surfaces.

## Best mature reading

The most mature packet reading is therefore:

- conservative score still defensible,
- stronger full-score candidate now materially arguable,
- and neither reading widens the scientific claim boundary.

## Best short outward-safe wording

One outward-safe sentence is:

> The prediction axis now supports a stronger full-score candidate reading
> without widening any scientific claim: the named primary witness is fully
> testable at bounded packet scope, and the packet's falsifier culture is now
> front-facing rather than merely distributed. A stricter reviewer may still
> keep the conservative read, but the stronger candidate is now materially
> available inside the packet.
