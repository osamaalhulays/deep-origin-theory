# Parent-Source Normalization Class Note

Date: `2026-06-06`

Status: `reviewer-facing normalization-class clarification`

Purpose:

One mathematical reading can still subtract too cheaply from the current
parent-law layer:

- the public bridge uses the compact declaration `O_phi = T_m^ren`,
- while the upstream canonical language also shows
  `O_phi = -(alpha_star/M_P) T_m^ren`,
- so has the packet left a hidden law-switch or normalization ambiguity in the
  middle of the bridge?

This note closes that narrower deduction.

It does **not** claim a final external cosmological normalization theorem.

It does something smaller and cleaner:

- it identifies the present public declaration as one bounded
  parent-source normalization class on the current bridge route,
- and it separates that class clearly from the stronger theorem that remains
  later.

## 1. The two visible forms

The public `Keystone I` route uses the compact statement

\[
O_\phi = T_m^{\mathrm{ren}}.
\]

The upstream canonicalized source-coupling language also preserves the longer
form

\[
O_\phi = -\frac{\alpha_\star}{M_P}\,T_m^{\mathrm{ren}}.
\]

The current packet already states that the shorter form is a deliberate
compression of the longer normalization layer, not a declaration of a second
law.

## 2. Current bounded normalization class

For the present bridge route, define the bounded parent-source normalization
class

\[
[T_m^{\mathrm{ren}}]_{\mathrm{bridge}}
\]

to mean:

- the renormalized matter-side source trace is the declared parent-source
  object,
- the scalar-mediated coupling route is fixed by one frozen convention factor
  on the current route,
- and the packet is allowed to use either the explicit representative
  \[
  O_\phi = c_\star\,T_m^{\mathrm{ren}}
  \]
  with
  \[
  c_\star := -\alpha_\star/M_P,
  \]
  or the compact representative
  \[
  O_\phi = T_m^{\mathrm{ren}},
  \]
  provided the claim being made is only the present bounded one:

- one common-parent bridge discipline,
- not one finished observable normalization theorem for every later lane.

So the honest reading is:

- the packet is not switching parent laws,
- it is compressing one frozen normalization layer into the shorter
  representative appropriate to the current claim boundary.

## 3. What the current bridge actually needs

The current bridge does not yet claim:

- one final luminosity-distance normalization,
- one final `H(z)` normalization,
- one final cosmological transport theorem,
- or one final measured value of every upstream coupling factor.

What it does need is narrower:

- one declared common parent-source frame,
- one governed common-response setting,
- and one prohibition against treating the two published response contrasts as
  unrelated arrays post-processed into similarity.

At the current stage, the common-parent declaration does that work already.

## 4. Why the compact form is not a hidden law switch

The present public bridge is built on:

- two independently prepared traceless response contrasts,
- one declared common-parent manifest,
- one authorized common basis,
- and published `Xi_*` diagnostics on that authorized basis.

Within that bounded route, the role of the compact declaration

\[
O_\phi = T_m^{\mathrm{ren}}
\]

is to preserve the identity of the parent-source class, not to settle every
later normalization question.

So the fair mathematical reading is:

- the compact form and the longer canonical form belong to the same bounded
  parent-source normalization class on the current bridge route,
- while the stronger theorem that would fix the whole external observable
  normalization stack remains later.

## 5. What this closes

This note closes the weaker deduction:

- "the packet appears to switch silently between two different parent laws in
  the middle of its bridge construction."

That reading is no longer fair.

The current packet already shows:

- one declared parent-source object,
- one preserved longer canonical representative,
- one deliberate compression into the shorter public representative,
- and one bounded claim boundary explaining why the compression is lawful now.

## 6. What still remains later

This note does **not** yet establish:

- one final derivation of `c_star = -alpha_star/M_P` from a fully closed
  external theory,
- one final observable normalization theorem for every later cosmology lane,
- or one completed transport theorem binding the same normalization all the
  way into later distance / likelihood surfaces.

Those remain later theorem work.

So the remaining fair deduction is now narrower:

- not "the present bridge hides a parent-law switch,"

but:

- "the present bridge uses one bounded normalization class, while the final
  external normalization theorem remains later."

## Bottom line

At the current admitted scope, the parent-source layer is no longer best read
as:

- one compact line with unresolved internal identity.

It is better read as:

- one bounded declared parent-source normalization class,
- one longer canonical representative,
- one shorter public representative,
- and one still-open higher theorem above both.
