#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"
PACKET_PREFIX = "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"
ARTIFACT_PREFIX = "artifacts/debt_board_20260530/"

ATTEMPT_STATUS_PATH = (
    "artifacts/debt_board_20260530/"
    "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT_V1/"
    "04_OUTPUTS/status_summary.json"
)
ATTEMPT_VERDICT_PATH = (
    "artifacts/debt_board_20260530/"
    "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT_V1/"
    "04_OUTPUTS/verdict.json"
)
AUTHORITY_FAILURE_STATUS_PATH = (
    "artifacts/debt_board_20260530/"
    "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_V1/"
    "04_OUTPUTS/status_summary.json"
)
AUTHORITY_FAILURE_VERDICT_PATH = (
    "artifacts/debt_board_20260530/"
    "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_V1/"
    "04_OUTPUTS/verdict.json"
)
TYPED_U2_STATUS_PATH = (
    "artifacts/debt_board_20260530/"
    "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_V1/"
    "04_OUTPUTS/status_summary.json"
)
TYPED_U2_VERDICT_PATH = (
    "artifacts/debt_board_20260530/"
    "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_V1/"
    "04_OUTPUTS/verdict.json"
)
TYPED_U2_TRIGGER_MATRIX_PATH = (
    "artifacts/debt_board_20260530/"
    "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_V1/"
    "04_OUTPUTS/trigger_matrix.json"
)

NOTE_CHECKS = [
    {
        "key": "attempt_scope_boundary",
        "path": (
            "artifacts/debt_board_20260530/"
            "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT_V1/"
            "02_LOCKS/ATTEMPT_SCOPE_AND_BOUNDARY.md"
        ),
        "fragments": [
            "the next honest act is now one exact-attempt shell,",
            "widening stays downstream and trigger-bound.",
        ],
        "meaning": "the attempt shell is explicitly bounded below present widening",
    },
    {
        "key": "attempt_test_matrix",
        "path": (
            "artifacts/debt_board_20260530/"
            "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT_V1/"
            "02_LOCKS/ATTEMPT_TEST_MATRIX.md"
        ),
        "fragments": [
            "one hidden second transport-bearing companion,",
            "one widening verdict before the exact-attempt shell can even be posed,",
            "The allowed current positive outcome is only:",
        ],
        "meaning": "the attempt matrix already distinguishes not-yet-landed state from widening failure",
    },
    {
        "key": "authority_failure_scope",
        "path": (
            "artifacts/debt_board_20260530/"
            "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_V1/"
            "02_LOCKS/FAILURE_SCOPE_AND_BOUNDARY.md"
        ),
        "fragments": [
            "the missing lawful `Q`-owned jump from bounded probe",
            "the current same-route `U1` ledger is still alive below the authority step,",
        ],
        "meaning": "the current surviving wound is fixed as the missing Q-owned authority jump",
    },
    {
        "key": "u1_vs_u2_boundary",
        "path": (
            "artifacts/debt_board_20260530/"
            "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_V1/"
            "02_LOCKS/U1_VS_U2_BOUNDARY.md"
        ),
        "fragments": [
            "one stronger current-route failure verdict inside `U1`",
            "promotable response-authority ownership",
            "one already-forced `U2` split.",
        ],
        "meaning": "the current route failure remains inside U1 and is not yet a forced U2 pivot",
    },
]


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


def find_packet_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if parent.name == "00_READ_FIRST" and (parent / "START_HERE_FIRST.md").exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
SCRIPT_PACKET_ROOT = find_packet_root()
if SCRIPT_PACKET_ROOT is not None:
    PACKET_ROOT = SCRIPT_PACKET_ROOT
    RUNNING_FROM_PACKET = True
elif WORKSPACE_ROOT is not None:
    PACKET_ROOT = WORKSPACE_ROOT / "Deep_Origin_Theory_English_Packet_20260605" / "00_READ_FIRST"
    RUNNING_FROM_PACKET = False
else:
    raise RuntimeError("could not locate workspace or packet root from landing-test runner")


def candidate_paths(logical_relative_path: str) -> list[Path]:
    candidates: list[Path] = []

    def add(path: Path) -> None:
        if path not in candidates:
            candidates.append(path)

    if RUNNING_FROM_PACKET:
        if logical_relative_path.startswith(PACKET_PREFIX):
            add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])
        elif logical_relative_path.startswith(ARTIFACT_PREFIX):
            add(PACKET_ROOT / logical_relative_path[len(ARTIFACT_PREFIX) :])
        else:
            add(PACKET_ROOT / logical_relative_path)

    if WORKSPACE_ROOT is not None:
        add(WORKSPACE_ROOT / logical_relative_path)
        if logical_relative_path.startswith(PACKET_PREFIX):
            add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])
        elif logical_relative_path.startswith(ARTIFACT_PREFIX):
            add(PACKET_ROOT / logical_relative_path[len(ARTIFACT_PREFIX) :])

    return candidates


def resolve_existing_path(logical_relative_path: str) -> Path:
    for candidate in candidate_paths(logical_relative_path):
        if candidate.exists():
            return candidate
    searched = "\n".join(str(path) for path in candidate_paths(logical_relative_path))
    raise FileNotFoundError(
        f"could not resolve landing-test surface: {logical_relative_path}\n{searched}"
    )


def read_text(logical_relative_path: str) -> str:
    return resolve_existing_path(logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def read_json(logical_relative_path: str) -> dict:
    return json.loads(read_text(logical_relative_path))


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": item["path"],
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def load_attempt_input() -> dict:
    status = read_json(ATTEMPT_STATUS_PATH)
    verdict = read_json(ATTEMPT_VERDICT_PATH)
    passed = (
        status["verdict"]
        == "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT_MATERIALIZED"
        and status["typed_u2_input_confirmed"] is True
        and status["same_carrier_ledger_admission_visible"] is True
        and status["coefficient_law_gate_visible"] is True
        and status["shell_typed_ir1_image_gate_visible"] is True
        and status["ownership_preserving_attempt_now_ordered"] is True
        and status["exact_vanishing_already_achieved"] is False
        and status["all_note_checks_pass"] is True
    )
    return {
        "status_path": ATTEMPT_STATUS_PATH,
        "verdict_path": ATTEMPT_VERDICT_PATH,
        "status": status,
        "verdict": verdict,
        "passed": passed,
    }


def load_authority_failure_input() -> dict:
    status = read_json(AUTHORITY_FAILURE_STATUS_PATH)
    verdict = read_json(AUTHORITY_FAILURE_VERDICT_PATH)
    passed = (
        status["verdict"]
        == "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_PROMOTABLE_RESPONSE_OWNERSHIP_FAILURE_MATERIALIZED"
        and status["form_c_no_go_confirmed"] is True
        and status["reviewer_visible_form_d_object_count"] == 0
        and status["u2_already_forced"] is False
        and status["all_note_checks_pass"] is True
    )
    return {
        "status_path": AUTHORITY_FAILURE_STATUS_PATH,
        "verdict_path": AUTHORITY_FAILURE_VERDICT_PATH,
        "status": status,
        "verdict": verdict,
        "passed": passed,
    }


def load_typed_u2_input() -> dict:
    status = read_json(TYPED_U2_STATUS_PATH)
    verdict = read_json(TYPED_U2_VERDICT_PATH)
    trigger_matrix = read_json(TYPED_U2_TRIGGER_MATRIX_PATH)
    passed = (
        status["verdict"]
        == "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_TYPED_U2_TRIGGER_ADJUDICATION_MATERIALIZED"
        and status["u2_currently_forced"] is False
        and status["all_note_checks_pass"] is True
        and trigger_matrix["global_reading"]["current_trigger_state"] == "not_yet_fired"
        and trigger_matrix["global_reading"]["next_honest_move"]
        == "OWNERSHIP_PRESERVING_EXACT_VANISHING_ATTEMPT"
    )
    return {
        "status_path": TYPED_U2_STATUS_PATH,
        "verdict_path": TYPED_U2_VERDICT_PATH,
        "trigger_matrix_path": TYPED_U2_TRIGGER_MATRIX_PATH,
        "status": status,
        "verdict": verdict,
        "trigger_matrix": trigger_matrix,
        "passed": passed,
    }


def build_report(status: dict, note_checks: list[dict]) -> str:
    lines = [
        "# Post-Cage Branch U1 Current-Route Exact-Vanishing Landing Test Report",
        "",
        f"Generated at: `{status['generated_at_utc']}`",
        "",
        f"Verdict: `{status['verdict']}`",
        "",
        "## Summary",
        "",
        f"- exact-attempt stack confirmed: `{str(status['exact_attempt_stack_confirmed']).lower()}`",
        f"- authority failure confirmed: `{str(status['authority_failure_confirmed']).lower()}`",
        f"- typed U2 not-yet-fired state confirmed: `{str(status['typed_u2_not_yet_fired_confirmed']).lower()}`",
        f"- promotable response-authority tooth crossed: `{str(status['promotable_response_authority_tooth_crossed']).lower()}`",
        f"- reviewer-visible Form D engine present: `{str(status['reviewer_visible_form_d_engine_present']).lower()}`",
        f"- hidden widening presently forced: `{str(status['hidden_widening_presently_forced']).lower()}`",
        f"- exact vanishing landed on current route: `{str(status['exact_vanishing_landed_on_current_route']).lower()}`",
        "",
        "## Note checks",
        "",
    ]
    for check in note_checks:
        lines.append(f"- `{check['path']}` -> `{str(check['passed']).lower()}`")
    lines.extend(
        [
            "",
            "## Reading",
            "",
            "- the route already deserves one ownership-preserving exact-attempt shell,",
            "- the current route still fails at the promotable response-authority tooth,",
            "- typed widening remains visible but not yet forced,",
            "- so present same-route exact landing is not yet earned,",
            "- and the present failure is pre-widening authority non-crossing, not hidden widening.",
            "",
            "## Supersession rule",
            "",
            "- if one real reviewer-visible Form D engine appears first, this landing test is superseded,",
            "- if one lawful Q-owned authority crossing appears first, the landing state must be recomputed,",
            "- if one typed U2 trigger fires first, widening becomes the honest verdict instead.",
            "",
            "## Ceiling",
            "",
            "- this report does not prove exact vanishing impossible in principle,",
            "- it does not force U2 on the present snapshot,",
            "- it does not claim true L0 observed-row crossing.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    attempt_input = load_attempt_input()
    authority_failure_input = load_authority_failure_input()
    typed_u2_input = load_typed_u2_input()

    reviewer_visible_form_d_engine_present = (
        authority_failure_input["status"]["reviewer_visible_form_d_object_count"] > 0
    )

    status = {
        "object_kind": "post_cage_branch_u1_current_route_exact_vanishing_landing_test_status",
        "generated_at_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "scope": "current_repo_visible_frozen_u1_route_only",
        "exact_attempt_stack_confirmed": attempt_input["passed"],
        "authority_failure_confirmed": authority_failure_input["passed"],
        "typed_u2_not_yet_fired_confirmed": typed_u2_input["passed"],
        "promotable_response_authority_tooth_crossed": False,
        "reviewer_visible_form_d_engine_present": reviewer_visible_form_d_engine_present,
        "hidden_widening_presently_forced": False,
        "exact_vanishing_landed_on_current_route": False,
        "current_blocker": "PROMOTABLE_RESPONSE_AUTHORITY_TOOTH_NOT_CROSSED",
        "current_classification": "EXACT_LANDING_NOT_YET_EARNED__PRE_WIDENING_AUTHORITY_FAILURE",
        "route_superseded_by_form_d": reviewer_visible_form_d_engine_present,
        "all_note_checks_pass": all(check["passed"] for check in note_checks),
        "verdict": "POST_CAGE_BRANCH_U1_CURRENT_ROUTE_EXACT_VANISHING_LANDING_TEST_MATERIALIZED",
    }

    landing_matrix = {
        "exact_attempt_shell": {
            "passed": status["exact_attempt_stack_confirmed"],
            "reading": "one ownership-preserving exact-attempt shell is already materialized on the current route",
        },
        "typed_u2_trigger_state": {
            "passed": status["typed_u2_not_yet_fired_confirmed"],
            "reading": "typed U2 trigger classes remain not_yet_fired",
        },
        "promotable_response_authority_tooth": {
            "passed": status["promotable_response_authority_tooth_crossed"],
            "reading": "one lawful Q-owned promotable response-authority crossing is not presently visible on the current route",
        },
        "hidden_widening_absence": {
            "passed": not status["hidden_widening_presently_forced"],
            "reading": "present failure is not yet one forced hidden-widening verdict",
        },
        "form_d_supersession": {
            "passed": not status["route_superseded_by_form_d"],
            "reading": "no reviewer-visible Form D engine presently supersedes the route",
        },
        "current_outcome": {
            "exact_vanishing_landed_on_current_route": False,
            "hidden_widening_presently_forced": False,
            "blocker": status["current_blocker"],
            "classification": status["current_classification"],
        },
    }

    verdict = {
        "verdict": status["verdict"],
        "scope": status["scope"],
        "current_state": {
            "exact_vanishing_landed_on_current_route": False,
            "hidden_widening_presently_forced": False,
            "blocker": status["current_blocker"],
            "classification": status["current_classification"],
        },
        "why": [
            "the current route already carries one reviewer-visible ownership-preserving exact-attempt shell",
            "the same route already carries one stronger promotable response-authority ownership failure verdict",
            "typed U2 trigger classes are already materialized but still not yet fired",
            "no reviewer-visible Form D engine presently reorders the route",
            "so the present snapshot blocks exact landing at the authority tooth before hidden widening is honestly earned",
        ],
        "supersession_rule": [
            "supersede this object if a real reviewer-visible Form D engine appears first",
            "recompute this object if a lawful Q-owned authority crossing appears first",
            "replace this object with widening verdict logic if a typed U2 trigger fires first",
        ],
        "ceiling": [
            "not a proof that exact vanishing is impossible in principle",
            "not a present U2-forcing verdict",
            "not a true L0 observed-row crossing",
        ],
    }

    report = build_report(status, note_checks)

    (OUTPUT_ROOT / "note_checks.json").write_text(
        json.dumps(note_checks, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUT_ROOT / "attempt_inputs.json").write_text(
        json.dumps(attempt_input, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUT_ROOT / "authority_failure_inputs.json").write_text(
        json.dumps(authority_failure_input, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUT_ROOT / "typed_u2_inputs.json").write_text(
        json.dumps(typed_u2_input, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUT_ROOT / "landing_matrix.json").write_text(
        json.dumps(landing_matrix, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUT_ROOT / "status_summary.json").write_text(
        json.dumps(status, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUT_ROOT / "verdict.json").write_text(
        json.dumps(verdict, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (OUTPUT_ROOT / "EXACT_VANISHING_LANDING_TEST_REPORT.md").write_text(
        report,
        encoding="utf-8",
    )

    if not attempt_input["passed"]:
        raise SystemExit("attempt input is not in the expected landed-test state")
    if not authority_failure_input["passed"]:
        raise SystemExit("authority failure input is not in the expected landed-test state")
    if not typed_u2_input["passed"]:
        raise SystemExit("typed U2 input is not in the expected landed-test state")
    if reviewer_visible_form_d_engine_present:
        raise SystemExit("a reviewer-visible Form D engine is now present; landing test is superseded")
    if not all(check["passed"] for check in note_checks):
        raise SystemExit("required landing-test note evidence check failed")


if __name__ == "__main__":
    main()
