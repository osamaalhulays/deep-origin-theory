# Landing Criteria And Failure Signatures

Date: `2026-06-10`

Status: `criteria lock`

## Exact landing criteria

The current route counts as landed exact vanishing only if **all** of the
following hold together:

1. typed `U2` triggers remain `not_yet_fired`,
2. `T_Q^(0)` remains one same-carrier variational ledger admission,
3. `C_closure^(0)` remains one same-carrier coefficient-law sufficiency
   gate under the ownership map,
4. that same gate remains localized to shell-typed `IR1` image sufficiency,
5. one lawful `Q`-owned promotable response-authority surface is materially
   visible on the same route,
6. the claim survives without one hidden second transport-bearing companion,
   one independent south carrier, one external exchange-current patch, or
   one non-`Q` authority import,
7. and no real `Form D` engine has already superseded the route before the
   landing claim is made.

## Failure family A: not-yet-landed authority failure

The route is **not yet landed** if:

1. the lower exact-attempt stack remains intact,
2. typed `U2` triggers remain not yet fired,
3. but the promotable response-authority tooth is still not crossed.

This is still a same-route verdict.

It is not yet widening.

## Failure family B: hidden widening

The route has crossed into hidden widening if:

1. one typed `U2` trigger class fires,
2. or the supposed exact landing survives only by importing one hidden
   second transport-bearing companion,
3. one independent south carrier,
4. one external exchange-current patch,
5. or one effectively second architecture disguised as same-carrier closure.

At that point the fair verdict is no longer:

- current-route exact landing pending.

It becomes:

- widening honestly earned.

## Failure family C: superseded route

The route is superseded rather than judged landed or widened if:

1. one real reviewer-visible `Form D` engine appears first and lawfully
   changes the route order.

That is not present landing.

It is one later route replacement.

## Current reading

The present snapshot fits failure family A:

- lower exact-attempt stack: present
- typed `U2` triggers: not yet fired
- promotable response-authority tooth: not crossed
- hidden widening: not yet forced
- route supersession by `Form D`: not present

So the fair present state is:

- exact landing not yet earned,
- hidden widening not yet earned.
