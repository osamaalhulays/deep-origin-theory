# Metric Bridge Note — NGC0247

Date: `2026-06-05`

Status: `bounded explanatory note`

## The reviewer-facing question

Why does the source-locked fixed-`QUMOND` row table expose:

- `chi^2_total ≈ 1160.321`

while the preserved historical case-level benchmark lane exposes:

- `QUMOND loglike_obs_only = -268.4815452508469`

instead of the naive `-0.5 * chi^2` identity?

## Short answer

Because these are two different preserved surfaces.

They are linked to the same named case and the same broad benchmark family,
but they are **not** the same published numeric object.

## Surface A — source-locked public row comparator

The fixed-`QUMOND` appendix is a bounded public source-locked table built from:

- `R`
- `v_obs`
- `sigma_v`
- `v_bar`
- the frozen simple-`QUMOND` rule

Its purpose is visibility:

- make the one-sided fixed-`QUMOND` residual explicit row by row
- keep the witness auditable without pretending that the full production
  benchmark object has already been opened

## Surface B — historical artifact-emulator benchmark lane

The historical case-level bridge comes from the preserved evidence mini
bundles.

That lane carries its own audited benchmark wrapper:

- `delta_source = artifact_emulator`
- case-level `loglike_obs_only`
- case-level `AIC/BIC`
- seed-stable preserved outputs

Its purpose is different:

- record that the same named case already showed bounded case-level advantage
  over fixed `QUMOND`

## What is safe to conclude

It is safe to conclude all of the following:

- the source-locked fixed-`QUMOND` row comparator is reproducible
- the row residuals are one-sided and negative across all `26` rows
- the oracle morphology is sign-changing across radius
- the historical benchmark lane is internally consistent in its own
  `loglike/AIC/BIC` arithmetic

## What is not safe to conclude

It is **not** safe to force numerical identity between:

- the public source-locked `chi^2_total`
- and the historical benchmark `loglike_obs_only`

because the packet does not publish enough current production internals to
equate those two surfaces row by row.

So the correct use rule is:

- audit each preserved surface on its own terms,
- do not force them into one metric without a published bridge object,
- and do not overclaim current final fitted-`Υ` closure from this packet alone.
