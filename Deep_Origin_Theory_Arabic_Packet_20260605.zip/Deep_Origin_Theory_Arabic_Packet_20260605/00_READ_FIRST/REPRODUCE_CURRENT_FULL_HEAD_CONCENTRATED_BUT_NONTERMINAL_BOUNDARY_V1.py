#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

STRUCTURED_GEOGRAPHY_PATH = HERE / "CURRENT_FULL_HEAD_STRUCTURED_BURDEN_GEOGRAPHY_V1.json"
GLOBAL_BOUNDARY_PATH = HERE / "GLOBAL_CROSS_COURT_ADMISSIBLE_VERDICT_BOUNDARY_AFTER_FULL_BODY_CLEAN_ANCHOR_SYNTHESIS_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    geography = load_json(STRUCTURED_GEOGRAPHY_PATH)
    boundary = load_json(GLOBAL_BOUNDARY_PATH)

    structured_pair = geography["structured_pair"]
    pocket = geography["residual_narrow_pocket"]
    full_head = geography["full_head"]

    admissible_now = set(boundary["admissible_now"])
    not_admissible_now = set(boundary["not_admissible_now"])

    consistency_checks = {
        "full_head_case_count_is_fourteen": full_head["case_count"] == 14,
        "structured_pair_public_burden_exceeds_eighty_eight_percent": (
            structured_pair["fraction_of_full_head_public_delta_aic_total"] > 0.88
        ),
        "pocket_public_burden_stays_below_twelve_percent": (
            pocket["fraction_of_full_head_public_delta_aic_total"] < 0.12
        ),
        "global_boundary_is_explicitly_bifurcated": (
            boundary["boundary_class"] == "bifurcated_cross_court_reading_only"
        ),
        "protected_clean_anchor_minority_is_admissible_now": (
            "protected_four_case_clean_anchor_minority_court_exists" in admissible_now
        ),
        "fully_closed_hubble_body_is_admissible_now": (
            "fully_closed_ten_case_hubble_flow_sensitive_body_exists" in admissible_now
        ),
        "terminal_qct_win_is_not_admissible_now": (
            "qct_wins_the_full_giant_spiral_head_on_the_fairest_reading" in not_admissible_now
        ),
        "terminal_qct_defeat_is_not_admissible_now": (
            "fully_closed_hubble_flow_sensitive_body_alone_globally_erases_the_clean_anchor_survival_body"
            in not_admissible_now
        ),
        "terminal_full_head_closure_is_not_admissible_now": (
            "the_entire_giant_spiral_head_is_already_terminally_closed" in not_admissible_now
        ),
        "pocket_remains_exact_qumond_protected": pocket["all_cases_have_exact_qumond_protection"],
    }

    output = {
        "date": "2026-06-09",
        "status": "bounded_packet_facing_concentrated_but_nonterminal_boundary",
        "surface": "current_full_head_concentrated_but_nonterminal_boundary",
        "full_head": full_head,
        "concentration_surface": {
            "structured_pair_case_count": structured_pair["case_count"],
            "structured_pair_fraction_of_full_head_case_count": structured_pair[
                "fraction_of_full_head_case_count"
            ],
            "structured_pair_fraction_of_full_head_public_delta_aic_total": structured_pair[
                "fraction_of_full_head_public_delta_aic_total"
            ],
            "pocket_case_count": pocket["case_count"],
            "pocket_fraction_of_full_head_case_count": pocket["fraction_of_full_head_case_count"],
            "pocket_fraction_of_full_head_public_delta_aic_total": pocket[
                "fraction_of_full_head_public_delta_aic_total"
            ],
        },
        "boundary_surface": {
            "boundary_class": boundary["boundary_class"],
            "admissible_now": boundary["admissible_now"],
            "not_admissible_now": boundary["not_admissible_now"],
        },
        "structural_reading": {
            "the_present_full_head_is_already_strongly_concentrated": True,
            "that_concentration_is_real_but_not_yet_terminal": True,
            "the_packet_can_now_forbid_both_diffuse_failure_reading_and_terminal_victory_reading_at_once": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the current full head is already strongly concentrated in present burden geography",
            "that concentration still coexists with one protected clean-anchor minority and one narrow exact-QUMOND-protected pocket",
            "the present state therefore supports a concentrated-but-nonterminal reading",
            "the packet may now block both a diffuse anti-QCT reading and a premature terminal-closure reading",
        ],
        "not_supported_now": [
            "the current full head is only a broad scattered anti-QCT field",
            "the present concentration already authorizes final whole-head terminal closure language",
            "the surviving minority and narrow pocket can be silently dropped from outward wording",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_frontier": [
            "the explicit no-makeup MOND_QUMOND cross-observable court scope choice",
            "later cross-observable escalation without inflating present full-head concentration into terminal closure",
        ],
    }

    output["verdict"] = (
        "CURRENT_FULL_HEAD_CONCENTRATED_BUT_NONTERMINAL_BOUNDARY_CLOSED__THE_HEAD_IS_ALREADY_STRONGLY_CONCENTRATED_BUT_NO_HONEST_SENTENCE_MAY_UPGRADE_THAT_PRESENT_STATE_INTO_TERMINAL_CLOSURE"
        if all(consistency_checks.values())
        else "CURRENT_FULL_HEAD_CONCENTRATED_BUT_NONTERMINAL_BOUNDARY_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
