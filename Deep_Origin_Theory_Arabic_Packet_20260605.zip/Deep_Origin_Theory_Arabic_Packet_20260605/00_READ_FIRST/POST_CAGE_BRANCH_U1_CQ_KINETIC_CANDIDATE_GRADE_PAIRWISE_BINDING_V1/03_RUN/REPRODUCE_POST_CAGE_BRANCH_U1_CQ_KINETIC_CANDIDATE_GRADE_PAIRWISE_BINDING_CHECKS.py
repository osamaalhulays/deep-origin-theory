#!/usr/bin/env python3

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"
PACKET_PREFIX = "Deep_Origin_Theory_English_Packet_20260605/00_READ_FIRST/"

PAIR_ORDER_VERDICT_PATH = (
    "artifacts/debt_board_20260530/"
    + "POST_CAGE_BRANCH_U1_IAMP0_IGEO0_PAIR_ORDER_BEARING_CARRIER_CONTRACT_V1/04_OUTPUTS/verdict.json"
)
CANDIDATE_SELECTOR_VERDICT_PATH = (
    "artifacts/debt_board_20260530/"
    + "POST_CAGE_BRANCH_U1_PAIRWISE_COEFFICIENT_CANDIDATE_OCCUPANT_SELECTOR_V1/04_OUTPUTS/verdict.json"
)
CANDIDATE_CURRENT_PATH = (
    PACKET_PREFIX
    + "CURRENT_G1_CANDIDATE_PAIRWISE_COEFFICIENT_LAW_OCCUPANT_SELECTION_LANDS_ON_CQ_KINETIC_WITH_CQ_GRADIENT_SHADOW_ONLY_NOTE_20260612.md"
)
PROVENANCE_PATH = (
    PACKET_PREFIX
    + "CURRENT_G1_REMAINING_BURDEN_IS_Q_OWNED_COEFFICIENT_LAW_PROVENANCE_FOR_BQ_FREE_AQ0_SHELL_NOTE_20260612.md"
)
WORKSHEET_PATH = (
    "artifacts/debt_board_20260530/"
    + "POST_CAGE_BRANCH_U1_QF1_IF1_FIRST_TYPED_WORKSHEET_NOTE_20260608.md"
)
KINETIC_FREEZE_PATH = (
    PACKET_PREFIX
    + "CURRENT_G1_REMAINING_BURDEN_SHARPENS_TO_Q_OWNED_REDUCED_ACTION_KINETIC_COEFFICIENT_FREEZE_NOTE_20260612.md"
)
PREFILL_PATH = (
    PACKET_PREFIX
    + "POST_CAGE_KREIB_Q_PREFILL_AND_U1_SEED_CLASS_NOTE_20260608.md"
)

NOTE_CHECKS = [
    {
        "key": "pair_order_contract_materialized",
        "path": PAIR_ORDER_VERDICT_PATH,
        "fragments": [
            "POST_CAGE_BRANCH_U1_IAMP0_IGEO0_PAIR_ORDER_BEARING_CARRIER_CONTRACT_MATERIALIZED",
            "\"frozen_internal_order\": \"I_geo^(0) > I_amp^(0)\"",
        ],
        "meaning": "the lower pair-order carrier contract is already materialized",
    },
    {
        "key": "candidate_selector_materialized",
        "path": CANDIDATE_SELECTOR_VERDICT_PATH,
        "fragments": [
            "POST_CAGE_BRANCH_U1_PAIRWISE_COEFFICIENT_CANDIDATE_OCCUPANT_SELECTOR_MATERIALIZED",
            "\"selected_candidate_occupant\": \"C_Q_kinetic\"",
        ],
        "meaning": "the selected first lawful candidate occupant is already fixed as C_Q_kinetic",
    },
    {
        "key": "candidate_old_tooth_is_generic_binding_absence",
        "path": CANDIDATE_CURRENT_PATH,
        "fragments": [
            "one lawful pairwise coefficient freeze / binding for the selected",
            "`C_Q_kinetic` candidate under the already materialized pair-order contract",
        ],
        "meaning": "before this object, the next tooth above the selected candidate was still generic binding absence",
    },
    {
        "key": "bq_free_corridor_fixed",
        "path": PROVENANCE_PATH,
        "fragments": [
            "fixed `B_Q`-free `A_Q^(0)[I_geo^(0)]` first-shell corridor",
            "one lawful `Q`-owned coefficient-law provenance / freeze",
        ],
        "meaning": "the coefficient corridor below the selected candidate is already fixed",
    },
    {
        "key": "kinetic_slot_and_shadow_family_visible",
        "path": WORKSHEET_PATH,
        "fragments": [
            "`A_Q[g,ψ] g^{μν} ∇_μ Q ∇_ν Q`",
            "`C_Q_kinetic`",
            "shadow compatible with the Kreib-side `S2_Q` prefill:",
        ],
        "meaning": "the same-carrier kinetic slot and the C_Q_kinetic shadow family are already visible together",
    },
    {
        "key": "gradient_shadow_only",
        "path": KINETIC_FREEZE_PATH,
        "fragments": [
            "single-`Q` kinetic coefficient carried by the already fixed",
            "`C_Q_gradient` preserved as shadow pressure only rather than one",
        ],
        "meaning": "kinetic-first ownership survives and C_Q_gradient remains shadow-only",
    },
    {
        "key": "prefill_below_full_ownership",
        "path": PREFILL_PATH,
        "fragments": [
            "one real `S2_Q` coefficient-host prefill with final bulk carrier exactly",
            "That is seed material,",
            "not final closure.",
        ],
        "meaning": "host prefill remains bounded below full action ownership",
    },
]


def find_workspace_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if (parent / "Deep_Origin_Theory_English_Packet_20260605").exists() and (
            parent / "artifacts"
        ).exists():
            return parent
    return None


def find_packet_root() -> Path | None:
    for parent in THIS_FILE.parents:
        if parent.name == "00_READ_FIRST" and (parent / "START_HERE_FIRST.md").exists():
            return parent
    return None


WORKSPACE_ROOT = find_workspace_root()
SCRIPT_PACKET_ROOT = find_packet_root()
if SCRIPT_PACKET_ROOT is not None:
    PACKET_ROOT = SCRIPT_PACKET_ROOT
    RUNNING_FROM_PACKET = True
elif WORKSPACE_ROOT is not None:
    PACKET_ROOT = WORKSPACE_ROOT / "Deep_Origin_Theory_English_Packet_20260605" / "00_READ_FIRST"
    RUNNING_FROM_PACKET = False
else:
    raise RuntimeError("could not locate workspace or packet root from cq-kinetic pairwise binding runner")


def candidate_paths(logical_relative_path: str) -> list[Path]:
    candidates: list[Path] = []

    def add(path: Path) -> None:
        if path not in candidates:
            candidates.append(path)

    if RUNNING_FROM_PACKET and logical_relative_path.startswith(PACKET_PREFIX):
        add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    if WORKSPACE_ROOT is not None:
        add(WORKSPACE_ROOT / logical_relative_path)
        if logical_relative_path.startswith(PACKET_PREFIX):
            add(PACKET_ROOT / logical_relative_path[len(PACKET_PREFIX) :])

    return candidates


def resolve_existing_path(logical_relative_path: str) -> Path:
    for candidate in candidate_paths(logical_relative_path):
        if candidate.exists():
            return candidate
    searched = "\n".join(str(path) for path in candidate_paths(logical_relative_path))
    raise FileNotFoundError(
        f"could not resolve cq-kinetic pairwise binding surface: {logical_relative_path}\n{searched}"
    )


def read_text(logical_relative_path: str) -> str:
    return resolve_existing_path(logical_relative_path).read_text(
        encoding="utf-8", errors="ignore"
    )


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": item["path"],
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())

    verdict_name = (
        "POST_CAGE_BRANCH_U1_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_MATERIALIZED"
        if all_note_checks_pass
        else "POST_CAGE_BRANCH_U1_CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_NOT_MATERIALIZED"
    )

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": verdict_name,
        "pair_order_contract_materialized": note_check_map["pair_order_contract_materialized"],
        "candidate_selector_materialized": note_check_map["candidate_selector_materialized"],
        "candidate_old_tooth_is_generic_binding_absence": note_check_map[
            "candidate_old_tooth_is_generic_binding_absence"
        ],
        "bq_free_corridor_fixed": note_check_map["bq_free_corridor_fixed"],
        "kinetic_slot_and_shadow_family_visible": note_check_map[
            "kinetic_slot_and_shadow_family_visible"
        ],
        "gradient_shadow_only": note_check_map["gradient_shadow_only"],
        "prefill_below_full_ownership": note_check_map["prefill_below_full_ownership"],
        "all_note_checks_pass": all_note_checks_pass,
        "bound_candidate_occupant": "C_Q_kinetic" if all_note_checks_pass else None,
        "candidate_grade_binding_materialized": all_note_checks_pass,
        "final_pairwise_law_already_claimed": False,
    }

    verdict = {
        "verdict": verdict_name,
        "bound_candidate_occupant": "C_Q_kinetic",
        "supporting_pair_contract": "(I_amp^(0), I_geo^(0)) with I_geo^(0) > I_amp^(0)",
        "bound_corridor": "B_Q-free A_Q^(0)[I_geo^(0)]",
        "bound_slot": "single-Q reduced-action kinetic coefficient",
        "grade": "candidate_grade_pairwise_binding",
        "next_exact_tooth": "authority_grade_pairwise_coefficient_freeze_for_bound_C_Q_kinetic",
    }

    if all_note_checks_pass:
        reading_lines = [
            "- one selected first lawful candidate occupant is now also pairwise-bound at candidate grade,",
            "- that bound candidate occupant is `C_Q_kinetic`,",
            "- the binding is carried through the ordered shell-typed pair `(I_amp^(0), I_geo^(0))` and the already fixed `B_Q`-free `A_Q^(0)[I_geo^(0)]` corridor,",
            "- and `C_Q_gradient` remains shadow pressure only rather than one coequal first owner.",
        ]
    else:
        reading_lines = [
            "- the supporting route surfaces are present but do not yet pass the current candidate-grade binding check,",
            "- so the selected candidate cannot yet be treated as lawfully pairwise-bound at candidate grade,",
            "- and the route stays below materialized binding until the missing check surfaces are repaired or strengthened.",
        ]

    report_lines = [
        "# Post-Cage Branch U1 `C_Q_kinetic` Candidate-Grade Pairwise Binding Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- pair-order contract materialized: `{status_summary['pair_order_contract_materialized']}`",
        f"- candidate selector materialized: `{status_summary['candidate_selector_materialized']}`",
        f"- old next tooth was generic binding absence: `{status_summary['candidate_old_tooth_is_generic_binding_absence']}`",
        f"- `B_Q`-free corridor fixed: `{status_summary['bq_free_corridor_fixed']}`",
        f"- kinetic slot plus `C_Q_kinetic` shadow family visible: `{status_summary['kinetic_slot_and_shadow_family_visible']}`",
        f"- gradient remains shadow-only: `{status_summary['gradient_shadow_only']}`",
        f"- host prefill remains below full ownership: `{status_summary['prefill_below_full_ownership']}`",
        f"- all note checks pass: `{status_summary['all_note_checks_pass']}`",
        "",
        "## Reading",
        "",
        *reading_lines,
        "",
        "## Ceiling",
        "",
        "- this report does not claim final pairwise coefficient law,",
        "- it does not claim final public pairwise coefficient formula,",
        "- it does not claim full `S_Q` action ownership,",
        "- it does not claim `T_Q^(0)` closure or exact transport closure,",
        "- and it does not claim full `G1/G2` completion.",
        "",
    ]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    write_json(
        OUTPUT_ROOT / "source_inputs.json",
        {
            "pair_order_verdict_path": PAIR_ORDER_VERDICT_PATH,
            "candidate_selector_verdict_path": CANDIDATE_SELECTOR_VERDICT_PATH,
            "candidate_current_path": CANDIDATE_CURRENT_PATH,
            "provenance_path": PROVENANCE_PATH,
            "worksheet_path": WORKSHEET_PATH,
            "kinetic_freeze_path": KINETIC_FREEZE_PATH,
            "prefill_path": PREFILL_PATH,
        },
    )
    (OUTPUT_ROOT / "CQ_KINETIC_CANDIDATE_GRADE_PAIRWISE_BINDING_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
