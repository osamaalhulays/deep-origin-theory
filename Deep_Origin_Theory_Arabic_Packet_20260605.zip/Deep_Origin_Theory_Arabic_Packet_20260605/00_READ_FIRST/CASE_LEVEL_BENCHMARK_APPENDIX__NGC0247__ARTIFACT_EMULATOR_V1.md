# Case-Level Benchmark Appendix — NGC0247 (Historical Artifact-Emulator Lanes)

Date: `2026-06-05`

Status: `bounded public appendix`

## Purpose

The earlier `NGC0247` witness stack already made three things externally
inspectable:

- the named galaxy,
- the row-wise fixed-`QUMOND` comparator,
- and the sign-changing `delta_true` radial structure.

This appendix closes one narrower gap beyond that stack:

- do we also have any preserved **case-level benchmark result** for the same
  named witness, rather than only a row table and a morphology statement?

Short answer:

- `yes, in bounded historical artifact-emulator form`

## Scope rule

This appendix **does** publish:

- one preserved case-level benchmark read for `NGC0247` from a historical
  external-prediction / artifact-emulator lane,
- one stronger preserved ceiling read from the later `oracle10` variant of the
  same lane,
- one preserved Phase-2 single-case case-lock lane in which the benchmark path
  itself visibly wires the artifact-emulator surface into the QCT forward
  model,
- one companion bounded reconstructed Phase-2 row-level `QCT` comparator for
  that same preserved lane,
- and the fact that both reads are numerically stable across the preserved
  five-seed multiseed run.

This appendix does **not** claim:

- that the exact current public fitted-`Υ` production table has now been fully
  published row by row,
- that the original best-fit nuisance object is itself preserved here as a
  separate public artifact,
- or that full `MOND/QUMOND` non-reducibility has now been closed.

## Provenance

The preserved case-level numbers below are taken from two preserved local
evidence bundles:

- `QCT_GEMINI_EVIDENCE_MINI.zip`
- `QCT_GEMINI_EVIDENCE_MINI_oracle10.zip`

Inside each outer evidence bundle, the relevant objects are:

- `production_capsule.zip`
- `production_capsule.zip / multiseed_results.ndjson`
- `production_capsule.zip / production_summary.csv`

The preserved records also keep visible:

- the same manifest hash anchor,
- the same `NGC0247.json` source-file hash,
- and explicit audit fields such as `delta_source = artifact_emulator` and
  `upsilon_sigma_dex_used = 0.1`.

## Interpretation rule

These are **historical bounded benchmark lanes**.

They matter because they show that the `NGC0247` witness is not only:

- a row-readable fixed-`QUMOND` pressure pattern,
- and not only a sign-changing oracle morphology surface,

but also a preserved case-level benchmark object in which QCT can be compared
to fixed `QUMOND` numerically under the audited benchmark pipeline.

They do **not** erase the distinction between:

- a bounded historical external-prediction lane,
- and a final current-production public closure object.

## Preserved seed stability

For both preserved lanes below:

- `n_datapoints = 26`
- preserved multiseed set = `42, 101, 2022, 5555, 9999`
- the `NGC0247` case-level benchmark numbers are identical across all five
  preserved seeds

So the case-level result shown here is not a one-seed accident.

## Case-level benchmark table

| Lane | Benchmark object | `QCT loglike_obs_only` | `QUMOND loglike_obs_only` | `ΔAIC_total` | `ΔBIC_total` | Reading |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| Historical bounded ML lane | `artifact_emulator` from `QCT_GEMINI_EVIDENCE_MINI.zip` | `-260.99900774336845` | `-268.4815452508469` | `-12.965075014956938` | `-11.706978476935546` | already favors QCT over fixed `QUMOND` at case level |
| Historical bounded `oracle10` ceiling lane | `artifact_emulator` from `QCT_GEMINI_EVIDENCE_MINI_oracle10.zip` | `-237.48017228995866` | `-268.4815452508469` | `-60.00274592177652` | `-58.744649383755075` | stronger ceiling variant of the same named witness |
| Preserved Phase-2 single-case case-lock lane | `src/NGC0247.json` + `pred_one.ndjson` + `external_model_v2` + `multiseed_results.ndjson` | `-416.9274550145858` | `-268.4815452508469` | `159.85953681251374` | `161.11763335053513` | same-case benchmark object with visible forward-model wiring and a now-available bounded reconstructed row comparator companion |

## What the Phase-2 lane adds

This third row matters for a different reason than the two older historical
lanes above.

It is not just:

- an older bounded benchmark result,

but a preserved single-case case-run bundle in which we can still see:

- the exact `26` source rows,
- the exact `delta_1d` / `sigma_delta_1d` predictor surface,
- the exact artifact and manifest audit hashes,
- and the benchmark code path that builds the QCT velocity model from those
  ingredients.

So this row does **not** merely say:

- "a historical score once existed."

It says:

- "the named case still has a preserved case-lock benchmark lane whose
  source/artifact/metric chain is readable."

## Why this appendix alone did not finish the row table

This appendix by itself still stopped at the case-level benchmark read.

The same preserved Phase-2 lane made the final step possible because the
benchmark path uses a best-fit nuisance value `Upsilon` to form the QCT
velocity model, but the public benchmark output exposed only the case-level
metrics rather than a separately stored row-level best-fit parameter file.

That is why this appendix originally supported:

- preserved case-level QCT closure for `NGC0247`

and why the packet now adds the companion file:

- `CURRENT_QCT_ROW_COMPARATOR_APPENDIX__NGC0247__PHASE2_RECONSTRUCTED_V1.md`

That companion closes the bounded reconstructed row table:

- `v_QCT_current`
- `resid_QCT_current`
- `chi2_QCT_obs_only_term`
- `chi2_QCT_obs_model_term`

What still remains absent is narrower:

- the original best-fit nuisance object as its own preserved public artifact
- and any broader current-production widening beyond that reconstructed
  Phase-2 lane

## What this adds to the witness

This appendix upgrades the `NGC0247` stack in one specific way.

Before this note, the public witness could already say:

- fixed `QUMOND` misses one-sidedly row by row,
- while the paired radial correction target changes sign across radius.

After this note, the same named witness can also say:

- one preserved historical bounded benchmark lane already produces a
  **case-level AIC/BIC advantage** for `NGC0247`,
- one preserved Phase-2 case-lock lane already produces an explicit same-case
  QCT/QUMOND benchmark object with visible forward-model wiring,
- one bounded reconstructed Phase-2 row table now exposes
  `v_QCT_current / resid_QCT_current / chi2_QCT` terms for that same lane,
- and that advantage remains identical across five preserved seeds.

So the remaining gap is no longer:

- “is there any case-level benchmark support at all?”

It is now narrower:

- whether the reader also requires the original best-fit fitted-`Υ` object as
  its own preserved artifact,
- whether the reader also requires a broader current-production closure than
  the bounded reconstructed Phase-2 lane,
- and whether the bounded `NGC0247` witness should be generalized from fixed
  simple-`QUMOND` to the wider `MOND/QUMOND` family.

## Honest boundary

The safer and more accurate reading is:

- `NGC0247` is now backed by:
  - a named differential capsule,
  - a row-wise `delta_true` table,
  - a row-wise fixed-`QUMOND` comparator,
  - a preserved bounded historical case-level benchmark advantage,
  - and a bounded reconstructed Phase-2 current row-level `QCT` comparator.

That is stronger than a loose “interesting case” and stronger than a mere
aggregate tail name.

But it is still not the same as saying:

- the current final public fitted-`Υ` benchmark object is fully published,
- or the whole `MOND/QUMOND` question is finished.

## Use rule

Use this appendix to support the narrower statement:

> `NGC0247` is no longer only a named morphological stress witness; it also has
> preserved bounded case-level benchmark support against fixed `QUMOND` in a
> historical artifact-emulator lane, with identical results across five seeds.

Do **not** use it to claim:

- that the final current public QCT comparator is fully closed here,
- that the original best-fit nuisance artifact is itself openly preserved here,
- that the historical `oracle10` ceiling lane is the canonical present claim,
- or that the whole anti-`MOND/QUMOND` program is complete.
