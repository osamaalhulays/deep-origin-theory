# Compatibility Gate Spec

## Purpose

Freeze the exact remaining numeric question after the fresh `O2-T3` route is
materialized.

The gate is intentionally narrow.
It does not reopen:

- fit quality,
- claim inflation,
- QCT versus competitor verdicts,
- or cosmology.

It asks only whether the shipped `SPEC-205` implementation is numerically
bound to the fresh `Omega_m` route.

## Definitions to test

```text
Omega_m(r) = 1 + kappa * rho_b(r) / m^2

m_eff,U2^2(r) = m^2 * Omega_m(r)^gamma
f_U2(r)       = Omega_m(r)^(-gamma)
```

against the actual shipped implementation quantities

```text
m_eff_script^2(r)
f_script(r)
```

## Required frozen inputs

- frozen `m`
- frozen `gamma`
- frozen `kappa`
- rowwise `rho_b(r)`
- frozen script-side rows or one lawful equivalent emitted ledger

## Rowwise error definitions

For each frozen row `i`, define

```text
rel_delta_m_eff_sq_i
= abs(m_eff_script_sq_i - m_eff_U2_sq_i)
 / max(abs(m_eff_script_sq_i), abs(m_eff_U2_sq_i), 1e-300)

rel_delta_f_i
= abs(f_script_i - f_U2_i)
 / max(abs(f_script_i), abs(f_U2_i), 1e-300)
```

and

```text
max_rel_delta
= max over all rows of rel_delta_m_eff_sq_i and rel_delta_f_i
```

## Required outputs

1. compatibility audit status
2. row count
3. max absolute delta on `m_eff^2`
4. max relative delta on `m_eff^2`
5. max absolute delta on `f`
6. max relative delta on `f`
7. max relative delta overall
8. exact compatibility class
9. exchange current ledger status
10. `Qhat_nu` formula status
11. `Q_nu` formula status
12. Bianchi split status
13. exact blocker if the class is not full pass

## Compatibility classes

```text
COMPAT0_EXACT_MATCH
iff max_rel_delta < 1e-6

COMPAT1_DECLARED_APPROXIMATION_MATCH
iff 1e-6 <= max_rel_delta < 5e-3

COMPAT2_MISMATCH_BLOCKER
iff max_rel_delta >= 5e-3
```

## Allowed final gate verdicts

If `COMPAT0`:

```text
U2_CLOSED_FULL__NUMERICALLY_CONSISTENT_WITH_SPEC205_CALIBRATION__EXCHANGE_CURRENT_MATERIALIZED
```

If `COMPAT1`:

```text
U2_CLOSED_CONDITIONAL__SPEC205_APPROXIMATION_BOUND_REQUIRED__EXCHANGE_CURRENT_MATERIALIZED
```

If `COMPAT2`:

```text
U2_FORMAL_CLOSED_BUT_SPEC205_NUMERIC_BINDING_BLOCKED__EXCHANGE_CURRENT_MATERIALIZED
```

If rowwise `rho_b` is missing:

```text
G1_U2_COMPATIBILITY_AUDIT_HOLD__missing_rowwise_rho_b_for_U2_compatibility_audit
```

If frozen script-side values are missing:

```text
G1_U2_COMPATIBILITY_AUDIT_HOLD__missing_frozen_SPEC205_m_eff_or_f_script_values
```

## Exchange-current ledger requirement

The audit packet is now also required to carry

```text
Qhat_nu
= [
     (1/2) * Q^2 * gamma * kappa * Omega_m^(gamma-1)
     - Q * kappa * Omega_m^(-gamma)
         * (1 - gamma * kappa * Theta_m / (m^2 * Omega_m))
   ] * partial_nu Theta_m

Q_nu = C_Q * Qhat_nu
C_Q = m^2 / gamma^2
```

with the explicit Bianchi convention

```text
nabla^mu T^m_(mu nu) = +Q_nu
nabla^mu T^Q_(mu nu) = -Q_nu
nabla^mu (T^m_(mu nu) + T^Q_(mu nu)) = 0
```

## Packet-local pre-scan rule

One packet-local pre-scan is allowed to narrow the live gate without claiming
full closure.

It may say, for example:

- mass term already exactly matches at `gamma = 1`,
- source factor still remains unbound in the shipped evaluator,
- therefore full thresholded rowwise gate remains pending.

But the pre-scan may not silently rename itself as the full audit.
