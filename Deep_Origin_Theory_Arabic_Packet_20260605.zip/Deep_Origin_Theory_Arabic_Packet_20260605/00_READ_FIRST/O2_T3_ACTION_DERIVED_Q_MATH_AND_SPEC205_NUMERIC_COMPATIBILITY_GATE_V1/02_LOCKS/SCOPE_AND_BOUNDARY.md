# Scope And Boundary

## What this object is allowed to claim

- one fresh `O2-T3` action-derived rescue route above the old `O2-T2`
  offender proof,
- one explicit `S_Q^free + S_int^(U2)` split,
- one explicit formal operator/source route for `Q`,
- one formal weak-field map to the `SPEC-205` operator shape,
- one closed `C_Q = m^2 / gamma^2` kinetic coefficient,
- one explicit `I_geo^(0)` / `I_amp^(0)` split,
- one explicit same-carrier `T_Q` ledger,
- one explicit exchange-current Bianchi closure,
- and one bounded numeric compatibility gate against the shipped evaluator.

## What this object is forbidden to claim

- not backdated into the `2026-06-07` packet claim,
- no statement that the older public packet had already contained this route,
- no full numeric closure without the rowwise compatibility audit,
- no full cosmology completion,
- no silent new free parameter family,
- no hidden second transport-bearing companion,
- no forced independent south carrier,
- no forced external exchange-current patch,
- no silent `U1 -> U2` architectural trigger firing,
- no silent replacement of the current phenomenological packet history.

## Domain restriction

This object is admitted only on the bounded branch:

- baryonic nonrelativistic / weak-cosmological branch,
- `Theta_m -> rho_b >= 0`,
- `Omega_m > 0`.

It is not one universal strong-field all-equation-of-state closure object.

## Transport restriction

WKB is auxiliary, not closure-bearing.

So:

- WKB may be used only where `|grad M_Q| / M_Q^2 << 1`,
- sharp-gradient regions must fall back to the exact Green-operator statement
  or one controlled Born branch,
- and no WKB sentence may be promoted into a fake full transport proof.

## Numeric gate restriction

Even after the formal route is written, full numeric closure remains forbidden
before:

- frozen `m`
- frozen `gamma`
- frozen `kappa`
- rowwise `rho_b(r)`
- and the actual shipped `m_eff_script^2(r)` / `f_script(r)`

are compared under one explicit gate.
