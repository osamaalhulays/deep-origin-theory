#!/usr/bin/env python3

from __future__ import annotations

import csv
import json
import math
from datetime import datetime, timezone
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
OBJECT_ROOT = THIS_FILE.parents[1]
OUTPUT_ROOT = OBJECT_ROOT / "04_OUTPUTS"
PACKET_ROOT_NAME = "Deep_Origin_Theory_English_Packet_20260605"


def find_workspace_root() -> Path:
    for parent in THIS_FILE.parents:
        if (parent / PACKET_ROOT_NAME).exists() and (parent / "artifacts").exists():
            return parent
    raise RuntimeError("could not locate workspace root from O2-T3 runner")


WORKSPACE_ROOT = find_workspace_root()

MANUSCRIPT_PATH = OBJECT_ROOT / "01_BACKBONE" / "MANUSCRIPT.md"
SCOPE_PATH = OBJECT_ROOT / "02_LOCKS" / "SCOPE_AND_BOUNDARY.md"
GATE_PATH = OBJECT_ROOT / "02_LOCKS" / "COMPATIBILITY_GATE_SPEC.md"
EVIDENCE_MAP_PATH = OBJECT_ROOT / "02_LOCKS" / "EVIDENCE_MAP.md"
FORMC_EVALUATOR_PATH = (
    WORKSPACE_ROOT
    / PACKET_ROOT_NAME
    / "00_READ_FIRST"
    / "G4_FORM_C_SOURCE_GOVERNED_L2_EVALUATOR_V1"
    / "03_RUN"
    / "qct_l2_form_c_evaluator.py"
)
OLD_OFFENDER_PATH = (
    WORKSPACE_ROOT
    / "artifacts"
    / "debt_board_20260530"
    / "O2_T2_SCREENING_SHIFT_DESCENT_OR_OFFENDER_PROOF_20260607.md"
)
NGC4214_LOCK_ROOT = (
    WORKSPACE_ROOT
    / PACKET_ROOT_NAME
    / "00_READ_FIRST"
    / "G4_NGC4214_FIRST_NONTOY_FORMD_RUN_V1"
    / "02_LOCKS"
)
NGC4214_SOURCE_PROFILE_PATH = NGC4214_LOCK_ROOT / "SOURCE_PROFILE_AUTHOR_FROZEN.csv"
NGC4214_M_INV_LOCK_PATH = NGC4214_LOCK_ROOT / "M_INV_LOCK_AUTHOR_FROZEN.json"

G_SI = 6.67430e-11
C_SI = 299792458.0
KAPPA_SI = 8.0 * math.pi * G_SI / (C_SI ** 2)
COMPAT0_THRESHOLD = 1e-6
COMPAT1_THRESHOLD = 5e-3


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


NOTE_CHECKS = [
    {
        "key": "action_split_materialized",
        "path": MANUSCRIPT_PATH,
        "fragments": [
            "`S_Q^free`",
            "`S_int^(U2)`",
            "`C_Q = m^2 / gamma^2`",
        ],
        "meaning": "the fresh route keeps an explicit free/action interaction split",
    },
    {
        "key": "euler_lagrange_materialized",
        "path": MANUSCRIPT_PATH,
        "fragments": [
            "(-Box_g + m^2 * Omega_m^gamma) Q",
            "= kappa * Theta_m * Omega_m^(-gamma)",
            "P_Q Q = J_Q",
        ],
        "meaning": "the Euler-Lagrange route is explicit",
    },
    {
        "key": "weak_field_spec205_map_materialized",
        "path": MANUSCRIPT_PATH,
        "fragments": [
            "m_eff,U2^2(r)",
            "m^2 * (1 + kappa * rho_b(r) / m^2)^gamma",
            "f_U2(r)",
            "(1 + kappa * rho_b(r) / m^2)^(-gamma)",
        ],
        "meaning": "the weak-field map to the SPEC-205 operator shape is explicit",
    },
    {
        "key": "igeo_iamp_split_materialized",
        "path": MANUSCRIPT_PATH,
        "fragments": [
            "I_geo^(0) := iota = ln(Omega_m)",
            "I_amp^(0) := C_Q * J_Q",
            "`I_geo^(0)` = transport-leading screening face",
            "`I_amp^(0)` = support-side source-amplitude face",
        ],
        "meaning": "the noncoequal I_geo/I_amp split is explicit",
    },
    {
        "key": "tq_and_bianchi_materialized",
        "path": MANUSCRIPT_PATH,
        "fragments": [
            "T^Q_(mu nu)",
            "nabla^mu (T^m_(mu nu) + T^Q_(mu nu)) = 0",
            "Qhat_nu := (1/2) * Q^2 * partial_nu M_Q^2 - Q * partial_nu J_Q",
            "Q_nu = C_Q * Qhat_nu",
            "exchange-current Bianchi closure",
        ],
        "meaning": "the same-carrier stress-tensor and Bianchi route are explicit",
    },
    {
        "key": "scope_lock_materialized",
        "path": SCOPE_PATH,
        "fragments": [
            "not backdated into the `2026-06-07` packet claim",
            "full numeric closure remains forbidden",
            "no hidden second transport-bearing companion",
            "WKB is auxiliary, not closure-bearing",
        ],
        "meaning": "scope lock prevents backdating and claim inflation",
    },
    {
        "key": "compatibility_gate_classes_materialized",
        "path": GATE_PATH,
        "fragments": [
            "COMPAT0_EXACT_MATCH",
            "COMPAT1_DECLARED_APPROXIMATION_MATCH",
            "COMPAT2_MISMATCH_BLOCKER",
            "iff max_rel_delta < 1e-6",
            "iff 1e-6 <= max_rel_delta < 5e-3",
            "iff max_rel_delta >= 5e-3",
            "packet-local pre-scan is allowed to narrow the live gate",
        ],
        "meaning": "the numeric gate is frozen explicitly rather than left atmospheric",
    },
    {
        "key": "old_offender_history_preserved",
        "path": EVIDENCE_MAP_PATH,
        "fragments": [
            "O2_T2_SCREENING_SHIFT_DESCENT_OR_OFFENDER_PROOF_20260607.md",
            "qct_l2_form_c_evaluator.py",
        ],
        "meaning": "the new route is linked both to the old offender proof and the current shipped evaluator",
    },
]


def collect_note_checks() -> list[dict]:
    results = []
    for item in NOTE_CHECKS:
        text = read_text(item["path"])
        fragments = {fragment: (fragment in text) for fragment in item["fragments"]}
        results.append(
            {
                "key": item["key"],
                "path": str(item["path"]),
                "meaning": item["meaning"],
                "fragments": fragments,
                "passed": all(fragments.values()),
            }
        )
    return results


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def tf(value: bool) -> str:
    return str(value).lower()


def rel_delta(lhs: float, rhs: float) -> float:
    return abs(lhs - rhs) / max(abs(lhs), abs(rhs), 1e-300)


def density_ceiling_for_relative_threshold(threshold: float, *, m_sq: float, kappa: float) -> float:
    alpha_threshold = threshold / (1.0 - threshold)
    return alpha_threshold * m_sq / kappa


def classify_compatibility(max_rel_delta: float) -> str:
    if max_rel_delta < COMPAT0_THRESHOLD:
        return "COMPAT0_EXACT_MATCH"
    if max_rel_delta < COMPAT1_THRESHOLD:
        return "COMPAT1_DECLARED_APPROXIMATION_MATCH"
    return "COMPAT2_MISMATCH_BLOCKER"


def load_ngc4214_numeric_audit() -> dict:
    if not NGC4214_SOURCE_PROFILE_PATH.exists():
        return {
            "status": "missing_source_profile",
            "blocker": "G1_U2_COMPATIBILITY_AUDIT_HOLD__missing_rowwise_rho_b_for_U2_compatibility_audit",
        }
    if not NGC4214_M_INV_LOCK_PATH.exists():
        return {
            "status": "missing_m_inv_lock",
            "blocker": "G1_U2_COMPATIBILITY_AUDIT_HOLD__missing_frozen_SPEC205_m_eff_or_f_script_values",
        }

    with NGC4214_M_INV_LOCK_PATH.open(encoding="utf-8") as handle:
        m_lock = json.load(handle)
    m_inv = float(m_lock["m_inv_m1"])
    m_sq = m_inv ** 2

    with NGC4214_SOURCE_PROFILE_PATH.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))

    audit_rows = []
    max_abs_delta_m_eff_sq = 0.0
    max_rel_delta_m_eff_sq = 0.0
    max_abs_delta_f = 0.0
    max_rel_delta_f = 0.0
    max_rho = 0.0

    for row in rows:
        rho = float(row["rho_b_kg_m3"])
        max_rho = max(max_rho, rho)
        omega = 1.0 + (KAPPA_SI * rho / m_sq)
        m_eff_u2_sq = m_sq * omega
        f_u2 = omega ** (-1.0)
        m_eff_script_sq = m_sq + KAPPA_SI * rho
        f_script = 1.0
        abs_delta_m = abs(m_eff_script_sq - m_eff_u2_sq)
        rel_delta_m = rel_delta(m_eff_script_sq, m_eff_u2_sq)
        abs_delta_f = abs(f_script - f_u2)
        rel_delta_f = rel_delta(f_script, f_u2)

        max_abs_delta_m_eff_sq = max(max_abs_delta_m_eff_sq, abs_delta_m)
        max_rel_delta_m_eff_sq = max(max_rel_delta_m_eff_sq, rel_delta_m)
        max_abs_delta_f = max(max_abs_delta_f, abs_delta_f)
        max_rel_delta_f = max(max_rel_delta_f, rel_delta_f)

        audit_rows.append(
            {
                "row_id": row["row_id"],
                "r_m": row["r_m"],
                "rho_b_kg_m3": row["rho_b_kg_m3"],
                "omega_m": f"{omega:.17e}",
                "m_eff_u2_sq_m2": f"{m_eff_u2_sq:.17e}",
                "m_eff_script_sq_m2": f"{m_eff_script_sq:.17e}",
                "abs_delta_m_eff_sq": f"{abs_delta_m:.17e}",
                "rel_delta_m_eff_sq": f"{rel_delta_m:.17e}",
                "f_u2": f"{f_u2:.17e}",
                "f_script": f"{f_script:.17e}",
                "abs_delta_f": f"{abs_delta_f:.17e}",
                "rel_delta_f": f"{rel_delta_f:.17e}",
            }
        )

    max_rel_delta = max(max_rel_delta_m_eff_sq, max_rel_delta_f)
    compat_class = classify_compatibility(max_rel_delta)
    compat0_rho_ceiling = density_ceiling_for_relative_threshold(
        COMPAT0_THRESHOLD,
        m_sq=m_sq,
        kappa=KAPPA_SI,
    )
    compat1_rho_ceiling = density_ceiling_for_relative_threshold(
        COMPAT1_THRESHOLD,
        m_sq=m_sq,
        kappa=KAPPA_SI,
    )

    gate_verdict_map = {
        "COMPAT0_EXACT_MATCH": "U2_CLOSED_FULL__NUMERICALLY_CONSISTENT_WITH_SPEC205_CALIBRATION__EXCHANGE_CURRENT_MATERIALIZED",
        "COMPAT1_DECLARED_APPROXIMATION_MATCH": "U2_CLOSED_CONDITIONAL__SPEC205_APPROXIMATION_BOUND_REQUIRED__EXCHANGE_CURRENT_MATERIALIZED",
        "COMPAT2_MISMATCH_BLOCKER": "U2_FORMAL_CLOSED_BUT_SPEC205_NUMERIC_BINDING_BLOCKED__EXCHANGE_CURRENT_MATERIALIZED",
    }

    return {
        "status": "packet_local_rowwise_audit_materialized",
        "audit_case": "NGC4214",
        "closure_domain": "first_author_frozen_non_toy_ngc4214_rowset_only",
        "row_count": len(audit_rows),
        "gamma": 1.0,
        "kappa_si": KAPPA_SI,
        "m_inv_m1": m_inv,
        "m_sq_m2": m_sq,
        "max_rho_b_kg_m3": max_rho,
        "compat0_rho_ceiling_kg_m3": compat0_rho_ceiling,
        "compat1_rho_ceiling_kg_m3": compat1_rho_ceiling,
        "compat0_margin_factor": compat0_rho_ceiling / max_rho if max_rho > 0 else None,
        "max_abs_delta_m_eff_sq": max_abs_delta_m_eff_sq,
        "max_rel_delta_m_eff_sq": max_rel_delta_m_eff_sq,
        "max_abs_delta_f": max_abs_delta_f,
        "max_rel_delta_f": max_rel_delta_f,
        "max_rel_delta": max_rel_delta,
        "compatibility_class": compat_class,
        "gate_verdict": gate_verdict_map[compat_class],
        "script_side_reading": {
            "m_eff_script_sq_rule": "m_inv^2 + kappa * rho_b",
            "f_script_rule": "1.0",
        },
        "u2_exact_reading": {
            "m_eff_u2_sq_rule": "m^2 * (1 + kappa * rho_b / m^2)^gamma with gamma=1",
            "f_u2_rule": "(1 + kappa * rho_b / m^2)^(-gamma) with gamma=1",
        },
        "rows": audit_rows,
    }


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    note_checks = collect_note_checks()
    note_check_map = {item["key"]: item["passed"] for item in note_checks}
    all_note_checks_pass = all(note_check_map.values())
    numeric_audit = load_ngc4214_numeric_audit()

    evaluator_text = read_text(FORMC_EVALUATOR_PATH)
    mass_term_fragment = "m_eff2 = config.m_inv_m1 ** 2 + config.beta_alpha * config.kappa * rho"
    source_term_fragment = "b[i] = config.beta * config.kappa * rho[i]"
    omega_factor_fragment = "Omega_m"

    packet_local_scan = {
        "evaluator_path": str(FORMC_EVALUATOR_PATH),
        "mass_term_fragment_present": mass_term_fragment in evaluator_text,
        "source_term_fragment_present": source_term_fragment in evaluator_text,
        "explicit_omega_factor_present": omega_factor_fragment in evaluator_text,
        "mass_term_gamma1_exact_reading": mass_term_fragment in evaluator_text,
        "source_factor_exact_reading": omega_factor_fragment in evaluator_text,
        "preliminary_local_reading": (
            "mass_term_exact_at_gamma1__source_factor_not_yet_explicit"
            if (mass_term_fragment in evaluator_text and source_term_fragment in evaluator_text and omega_factor_fragment not in evaluator_text)
            else "local_formc_scan_not_narrow_enough"
        ),
    }

    status_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "verdict": (
            (
                "O2_T3_ACTION_DERIVED_SCREENING_RESCUE_ROUTE_MATERIALIZED__FIRST_PACKET_LOCAL_NUMERIC_COMPATIBILITY_AUDIT_LANDED"
                if (
                    all_note_checks_pass
                    and numeric_audit.get("status") == "packet_local_rowwise_audit_materialized"
                )
                else "O2_T3_ACTION_DERIVED_SCREENING_RESCUE_ROUTE_MATERIALIZED__FORMAL_U2_CLOSED_NUMERIC_SPEC205_THRESHOLD_GATE_PENDING"
            )
            if all_note_checks_pass
            else "O2_T3_ACTION_DERIVED_SCREENING_RESCUE_ROUTE_NOT_YET_MATERIALIZED"
        ),
        "formal_u2_math_materialized": all_note_checks_pass,
        "old_offender_note_still_present": OLD_OFFENDER_PATH.exists(),
        "packet_local_formc_scan_visible": (
            packet_local_scan["mass_term_fragment_present"]
            and packet_local_scan["source_term_fragment_present"]
        ),
        "packet_local_mass_term_gamma1_exact": packet_local_scan["mass_term_gamma1_exact_reading"],
        "packet_local_source_factor_explicit": packet_local_scan["source_factor_exact_reading"],
        "packet_local_rowwise_audit_materialized": (
            numeric_audit.get("status") == "packet_local_rowwise_audit_materialized"
        ),
        "packet_local_audit_case": numeric_audit.get("audit_case"),
        "packet_local_compatibility_class": numeric_audit.get("compatibility_class"),
        "packet_local_gate_verdict": numeric_audit.get("gate_verdict"),
        "full_numeric_spec205_closure_closed": (
            numeric_audit.get("status") == "packet_local_rowwise_audit_materialized"
            and numeric_audit.get("compatibility_class") == "COMPAT0_EXACT_MATCH"
        ),
        "remaining_exact_gate": (
            "none_inside_first_author_frozen_non_toy_ngc4214_rowset"
            if numeric_audit.get("status") == "packet_local_rowwise_audit_materialized"
            else "rowwise_source_factor_and_frozen_input_threshold_audit"
        ),
        "all_note_checks_pass": all_note_checks_pass,
    }

    verdict = {
        "verdict": status_summary["verdict"],
        "historical_preservation": [
            "the older O2-T2 offender proof remains true on the pre-fresh record",
            "the new object is a fresh route above that record, not a backdated edit of it",
        ],
        "formal_closures_gained": [
            "explicit S_Q^free + S_int^(U2) split",
            "explicit Euler-Lagrange route for Q",
            "formal weak-field SPEC-205 operator-shape match",
            "closed C_Q = m^2 / gamma^2 kinetic coefficient",
            "explicit I_geo^(0) and I_amp^(0) noncoequal split",
            "explicit T_Q ledger",
            "explicit Qhat_nu and physical Q_nu",
            "explicit exchange-current Bianchi closure",
        ],
        "packet_local_preliminary_scan": {
            "mass_term": (
                "exact gamma=1 local match against the shipped Form C evaluator"
                if packet_local_scan["mass_term_gamma1_exact_reading"]
                else "not resolved locally"
            ),
            "source_factor": (
                "Omega^(-gamma) not yet explicit in the shipped Form C evaluator"
                if not packet_local_scan["source_factor_exact_reading"]
                else "explicitly visible"
            ),
        },
        "packet_local_full_numeric_audit": numeric_audit,
        "remaining_exact_gate": (
            [
                "broader all-rowset promotion is not claimed here",
                "this landed object is bounded to the first author-frozen non-toy NGC4214 rowset",
            ]
            if numeric_audit.get("status") == "packet_local_rowwise_audit_materialized"
            else [
                "rowwise rho_b(r)",
                "frozen m",
                "frozen gamma",
                "frozen kappa",
                "actual script-side m_eff^2(r) and f(r)",
                "threshold class on max_rel_delta",
            ]
        ),
        "compatibility_classes": [
            "COMPAT0_EXACT_MATCH if max_rel_delta < 1e-6",
            "COMPAT1_DECLARED_APPROXIMATION_MATCH if 1e-6 <= max_rel_delta < 5e-3",
            "COMPAT2_MISMATCH_BLOCKER if max_rel_delta >= 5e-3",
        ],
        "ceiling": [
            "not backdated into the 2026-06-07 packet claim",
            "not a full numeric SPEC-205 closure verdict",
            "not cosmology completion",
            "not a hidden second-carrier architecture",
        ],
    }

    report_lines = [
        "# Action-Derived Q Math And SPEC205 Compatibility Gate Report",
        "",
        f"Generated at: `{status_summary['generated_at']}`",
        "",
        f"Verdict: `{status_summary['verdict']}`",
        "",
        "## Summary",
        "",
        f"- formal U2 math materialized: `{tf(status_summary['formal_u2_math_materialized'])}`",
        f"- old offender history preserved: `{tf(status_summary['old_offender_note_still_present'])}`",
        f"- packet-local Form C scan visible: `{tf(status_summary['packet_local_formc_scan_visible'])}`",
        f"- packet-local gamma=1 mass-term exact match: `{tf(status_summary['packet_local_mass_term_gamma1_exact'])}`",
        f"- packet-local Omega source factor explicit: `{tf(status_summary['packet_local_source_factor_explicit'])}`",
        f"- packet-local full rowwise audit materialized: `{tf(status_summary['packet_local_rowwise_audit_materialized'])}`",
        f"- packet-local audit case: `{status_summary['packet_local_audit_case']}`",
        f"- packet-local compatibility class: `{status_summary['packet_local_compatibility_class']}`",
        f"- full numeric SPEC205 closure closed: `{tf(status_summary['full_numeric_spec205_closure_closed'])}`",
        f"- all note checks pass: `{tf(status_summary['all_note_checks_pass'])}`",
        "",
        "## Reading",
        "",
        "- the old O2-T2 offender proof remains historically correct on the pre-fresh record,",
        "- the fresh O2-T3 route now closes the formal action-derived math at its declared level,",
        "- the shipped evaluator already shows one exact gamma=1 mass-term alignment,",
        "- the exchange current is now explicit at the reviewer-facing level,",
        (
            f"- the first packet-local full rowwise audit lands on `{status_summary['packet_local_audit_case']}` as `{status_summary['packet_local_compatibility_class']}`."
            if status_summary["packet_local_rowwise_audit_materialized"]
            else "- the remaining exact gate is now only the source-factor / rowwise frozen-input threshold audit."
        ),
        (
            f"- the frozen rowset maximum source density is `{numeric_audit['max_rho_b_kg_m3']:.6e}` kg m^-3 against a COMPAT0 ceiling `{numeric_audit['compat0_rho_ceiling_kg_m3']:.6e}` kg m^-3."
            if status_summary["packet_local_rowwise_audit_materialized"]
            else ""
        ),
        "",
        "## Ceiling",
        "",
        "- this report does not claim the old packet had already contained the fresh route,",
        (
            "- it claims one bounded rowset closure only; it does not promote that bounded result into a universal all-rowset theorem."
            if status_summary["packet_local_rowwise_audit_materialized"]
            else "- it does not claim full numeric compatibility is already closed,"
        ),
        "- it does not claim cosmology completion.",
        "",
    ]
    report_lines = [line for line in report_lines if line != "" or (report_lines and report_lines[-1] != "")]

    write_json(OUTPUT_ROOT / "note_checks.json", note_checks)
    write_json(OUTPUT_ROOT / "preliminary_packet_local_scan.json", packet_local_scan)
    write_json(OUTPUT_ROOT / "numeric_compatibility_audit.json", numeric_audit)
    if numeric_audit.get("status") == "packet_local_rowwise_audit_materialized":
        row_keys = [
            "row_id",
            "r_m",
            "rho_b_kg_m3",
            "omega_m",
            "m_eff_u2_sq_m2",
            "m_eff_script_sq_m2",
            "abs_delta_m_eff_sq",
            "rel_delta_m_eff_sq",
            "f_u2",
            "f_script",
            "abs_delta_f",
            "rel_delta_f",
        ]
        with (OUTPUT_ROOT / "rowwise_compatibility_audit.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=row_keys)
            writer.writeheader()
            writer.writerows(numeric_audit["rows"])
    write_json(OUTPUT_ROOT / "status_summary.json", status_summary)
    write_json(OUTPUT_ROOT / "verdict.json", verdict)
    (OUTPUT_ROOT / "ACTION_DERIVED_Q_MATH_AND_SPEC205_COMPATIBILITY_GATE_REPORT.md").write_text(
        "\n".join(report_lines),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
