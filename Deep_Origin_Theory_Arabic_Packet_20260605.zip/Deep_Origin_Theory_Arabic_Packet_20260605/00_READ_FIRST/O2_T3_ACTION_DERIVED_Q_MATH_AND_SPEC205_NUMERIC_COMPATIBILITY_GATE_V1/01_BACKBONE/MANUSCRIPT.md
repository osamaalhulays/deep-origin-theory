# O2-T3 Action-Derived `Q` Math And `SPEC-205` Numeric Compatibility Gate

Date: `2026-06-12`

Status: `reviewer-facing constructive rescue object`

## Purpose

This object is the exact next move named by the earlier `O2-T2` offender
proof.

It does **not** claim:

- that the older public packet had already contained this derivation,
- that full numeric `SPEC-205` binding is already closed,
- that cosmology is complete,
- that one second transport-bearing companion is introduced,
- or that any current public ceiling was silently widened retroactively.

It claims something narrower and stronger:

1. the old screening offender can now be met by one fresh action-derived
   rescue route,
2. that route closes the formal `Q`-sector math at its declared level,
3. and the only remaining exact gate is no longer "missing `I_geo` / missing
   `T_Q` / missing transport closure", but one bounded numeric compatibility
   question against the current shipped `SPEC-205` implementation.

## Short verdict

The old `O2-T2` verdict remains historically true on the pre-fresh record:

- the screening term was underived on the then-visible record.

But the current repo can now carry one stronger later truth above that record:

- one fresh action-derived route is materially written,
- one explicit interaction split is kept,
- one Euler-Lagrange route is written cleanly,
- one weak-field map to the `SPEC-205` operator shape is explicit,
- one closed `C_Q = m^2 / gamma^2` kinetic coefficient is fixed from canonical
  normalization,
- one explicit `(I_amp^(0), I_geo^(0))` split is written with noncoequal roles,
- one explicit `T_Q` ledger is written,
- one explicit exchange current is written,
- and one exchange-current Bianchi closure is written.

The formal route therefore closes as:

`U2_CLOSED_MATH__EXPLICIT_I_GEO_FACE__EXPLICIT_I_AMP_FACE__VARIABLE_MASS_TRANSPORT__EXPLICIT_EXCHANGE_CURRENT`

while the exact remaining gate narrows to:

`SPEC205_NUMERIC_COMPATIBILITY_THRESHOLD_AUDIT`

## 1. Fresh action split

The fresh route is written with an explicit split between:

- `S_Q^free`
- and `S_int^(U2)`

using the covariant density

```text
L_(Q+int)^(U2)
= -(C_Q/2) (nabla Q)^2
  -(C_Q/2) m^2 Omega_m^gamma Q^2
  + C_Q kappa Theta_m Omega_m^(-gamma) Q
```

with

```text
C_Q = m^2 / gamma^2
Theta_m[g,psi] = - g_(mu nu) T_m^(ren,mu nu)
Omega_m[g,psi] = 1 + kappa * Theta_m[g,psi] / m^2
iota[g,psi] = ln(Omega_m[g,psi])
M_Q^2[g,psi] = m^2 * Omega_m^gamma
f[g,psi] = Omega_m^(-gamma)
```

and the explicit split

```text
L_Q^free
= -(C_Q/2) (nabla Q)^2
  -(C_Q/2) m^2 Q^2

L_int^(U2)
= -(C_Q/2) m^2 (Omega_m^gamma - 1) Q^2
  + C_Q kappa Theta_m Omega_m^(-gamma) Q
```

So `S_int` is not deleted.
It is written explicitly as the source-screen plus mass-screen face.

## 2. Euler-Lagrange route

Holding `(g,psi)` fixed and varying with respect to `Q` only yields

```text
(-Box_g + m^2 * Omega_m^gamma) Q
= kappa * Theta_m * Omega_m^(-gamma)
```

That is the clean action-derived operator/source split:

```text
P_Q Q = J_Q

P_Q := -Box_g + m^2 * Omega_m^gamma
J_Q := kappa * Theta_m * Omega_m^(-gamma)
```

## 3. Weak-field map to `SPEC-205`

On the baryonic nonrelativistic branch:

```text
Theta_m -> rho_b >= 0
-Box_g -> nabla_SPEC^2
nabla_SPEC^2 := -Delta_(R^3)
```

so the fresh route gives

```text
nabla_SPEC^2 Q + m_eff,U2^2(r) Q
= kappa * rho_b(r) * f_U2(r)
```

with

```text
m_eff,U2^2(r)
= m^2 * (1 + kappa * rho_b(r) / m^2)^gamma

f_U2(r)
= (1 + kappa * rho_b(r) / m^2)^(-gamma)
```

This closes the **formal** `SPEC-205` shape match.

It does **not** yet silently claim the current shipped evaluator already uses
those exact rowwise functions.

## 4. Closed formal gains

### A. Closed kinetic coefficient

Defining the canonically normalized scalar

```text
varphi_Q := (m / gamma) * Q
```

gives immediately

```text
C_Q^(kinetic) = m^2 / gamma^2
```

This is no longer one atmospheric coefficient wish.
It is one closed reduced-action coefficient.

### B. Explicit `(I_amp^(0), I_geo^(0))` split

The fresh route now writes:

```text
I_geo^(0) := iota = ln(Omega_m)
I_amp^(0) := C_Q * J_Q
          = (m^2 / gamma^2) * kappa * Theta_m * Omega_m^(-gamma)
```

with the noncoequal role split:

- `I_geo^(0)` = transport-leading screening face
- `I_amp^(0)` = support-side source-amplitude face

This matters because the old live burden no longer needs to pretend these
faces are still unnamed.

### C. Explicit `T_Q` ledger, explicit exchange current, and Bianchi closure

The fresh route writes one explicit same-carrier stress tensor:

```text
T^Q_(mu nu)
= C_Q nabla_mu Q nabla_nu Q
 - (C_Q/2) g_(mu nu) (nabla Q)^2
 - (C_Q/2) g_(mu nu) M_Q^2 Q^2
 + C_Q g_(mu nu) J_Q Q
 + C_Q Q^2 * d(M_Q^2)/d g^(mu nu)
 - 2 C_Q Q * d(J_Q)/d g^(mu nu)
```

and keeps the total transport statement honest as

```text
nabla^mu (T^m_(mu nu) + T^Q_(mu nu)) = 0
```

The exchange current is not left implicit.
Define

```text
M_Q^2 = m^2 * Omega_m^gamma
J_Q   = kappa * Theta_m * Omega_m^(-gamma)
Omega_m = 1 + kappa * Theta_m / m^2
```

Then

```text
partial_nu M_Q^2
= gamma * kappa * Omega_m^(gamma-1) * partial_nu Theta_m
```

and

```text
partial_nu J_Q
= kappa * Omega_m^(-gamma)
   * (1 - gamma * kappa * Theta_m / (m^2 * Omega_m))
   * partial_nu Theta_m
```

Define the normalized exchange one-form

```text
Qhat_nu := (1/2) * Q^2 * partial_nu M_Q^2 - Q * partial_nu J_Q
```

so explicitly

```text
Qhat_nu
= [
     (1/2) * Q^2 * gamma * kappa * Omega_m^(gamma-1)
     - Q * kappa * Omega_m^(-gamma)
         * (1 - gamma * kappa * Theta_m / (m^2 * Omega_m))
   ] * partial_nu Theta_m
```

The physical exchange current is then

```text
Q_nu = C_Q * Qhat_nu
```

with the sign convention

```text
nabla^mu T^m_(mu nu) =  Q_nu
nabla^mu T^Q_(mu nu) = -Q_nu
```

on shell.

So the route now owns:

- one explicit `Qhat_nu`,
- one explicit physical `Q_nu`,
- and one explicit Bianchi-grade closure statement

rather than one handwave.

### D. Exact transport statement

The propagator-side route is also explicit:

```text
(-Box_(g,x) + m^2 * Omega_m(x)^gamma) G_Q(x,y)
= delta^(4)(x-y) / sqrt(-g(y))
```

and therefore

```text
Q(x)
= Q_hom(x)
 + integral d^4y sqrt(-g(y)) G_Q(x,y) kappa Theta_m(y) Omega_m(y)^(-gamma)
```

So the formal transport chain is now explicit:

```text
T_m^(ren) -> Theta_m -> Omega_m -> J_Q -> G_Q -> Q
```

## 5. Scope constraints

### A. Positivity domain

The fresh route is only admitted where

```text
Omega_m = 1 + kappa * Theta_m / m^2 > 0
```

On the baryonic nonrelativistic branch `Theta_m -> rho_b >= 0`, so
`Omega_m >= 1`.

### B. WKB is auxiliary, not closure-bearing

For variable-mass transport:

```text
M_Q = m * Omega_m^(gamma/2)
```

WKB is admissible only where

```text
|grad M_Q| / M_Q^2 << 1
```

equivalently on the baryonic branch

```text
(gamma / 2) * kappa * |grad rho_b|
/ (m^3 * Omega_m^(1 + gamma/2))
<< 1
```

In sharp-gradient regions:

- WKB is not promoted as a closure witness,
- exact Green-operator definition or a controlled Born branch must carry the
  route instead.

## 6. Preliminary packet-local compatibility scan

The fresh route is intentionally stricter than a broad philosophical claim:
it checks the current shipped packet-local `Form C` evaluator directly.

The present shipped evaluator still contains:

```text
m_eff_script^2 = m_inv^2 + kappa * rho_b
rhs_script      = kappa * rho_b
```

That gives one immediate gain:

### A. Mass-term exact local match at `gamma = 1`

If `gamma = 1`, then

```text
m_eff,U2^2
= m^2 * (1 + kappa * rho_b / m^2)
= m^2 + kappa * rho_b
```

So the mass term already has one exact local packet-side identity with the
shipped evaluator at `gamma = 1`.

### B. Source-factor gate remains real

But the fresh route also requires

```text
f_U2(r) = Omega_m(r)^(-gamma)
```

while the present packet-local evaluator still shows the bare right-hand side

```text
rhs_script = kappa * rho_b
```

with no explicit `Omega_m^(-gamma)` factor.

So the surviving exact gate is no longer the whole mathematical route.
It is narrower:

- one rowwise / frozen-input audit of whether the shipped implementation is
  already an exact match,
- one declared approximation match,
- or one true mismatch blocker on the source factor.

## 7. Thresholded numeric compatibility gate

The live gate is now:

```text
SPEC205_NUMERIC_COMPATIBILITY_THRESHOLD_AUDIT
```

For each frozen row `i`, define

```text
m_U2_sq_i
= m^2 * (1 + kappa * rho_b_i / m^2)^gamma

f_U2_i
= (1 + kappa * rho_b_i / m^2)^(-gamma)
```

against the shipped implementation values

```text
m_script_sq_i
f_script_i
```

and the relative errors

```text
delta_m_i
= abs(m_script_sq_i - m_U2_sq_i)
 / max(abs(m_script_sq_i), abs(m_U2_sq_i), 1e-300)

delta_f_i
= abs(f_script_i - f_U2_i)
 / max(abs(f_script_i), abs(f_U2_i), 1e-300)
```

Then define

```text
Delta_max
= max over all rows of delta_m_i and delta_f_i
```

with the exact classes

```text
COMPAT0_EXACT_MATCH
iff Delta_max < 1e-6

COMPAT1_DECLARED_APPROXIMATION_MATCH
iff 1e-6 <= Delta_max < 5e-3

COMPAT2_MISMATCH_BLOCKER
iff Delta_max >= 5e-3
```

The fresh route already settles the formal side.
What remains for full numeric closure is only the frozen threshold audit:

- frozen `m`
- frozen `gamma`
- frozen `kappa`
- rowwise `rho_b(r)`
- and the actual shipped script-side `m_eff_script^2(r)` and `f_script(r)`

Exact blockers remain:

```text
missing_rowwise_rho_b_for_U2_compatibility_audit
missing_frozen_SPEC205_m_eff_or_f_script_values
SPEC205_screen_function_not_equal_to_U2_Omega_route
```

## 8. Updated C6 reading

The Bianchi row is now stronger than before:

```text
C6. Bianchi conservation = double-checked
```

because the route now carries:

- variational `T_Q`,
- explicit normalized `Qhat_nu`,
- explicit physical `Q_nu = C_Q * Qhat_nu`,
- and the explicit split
  `nabla^mu T^m_(mu nu) = +Q_nu`,
  `nabla^mu T^Q_(mu nu) = -Q_nu`.

## Bottom line

The old offender proof is no longer the end of the story.

It now has one named constructive successor:

`O2-T3`

and that successor materially lands as:

- explicit action split,
- explicit Euler-Lagrange route,
- explicit weak-field `SPEC-205` map,
- closed `C_Q` kinetic coefficient,
- explicit `I_geo^(0)` / `I_amp^(0)` role split,
- explicit `T_Q` ledger,
- explicit exchange current,
- explicit variable-mass transport statement,
- and explicit exchange-current Bianchi closure.

So the fair current truth is no longer:

- "the screening side is still just underived."

It is:

- one fresh action-derived rescue route is materially present,
- one exact packet-local mass-term match is already visible at `gamma = 1`,
- and the only exact remaining gate is the thresholded numeric source-factor
  binding to the shipped `SPEC-205` route.
