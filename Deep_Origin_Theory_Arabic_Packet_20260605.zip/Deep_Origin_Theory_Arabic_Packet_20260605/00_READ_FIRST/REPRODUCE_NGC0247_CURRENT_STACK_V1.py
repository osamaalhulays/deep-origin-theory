#!/usr/bin/env python3
import csv
import json
import math
from pathlib import Path

A0 = 1.2e-10

HISTORICAL_LANES = {
    "ml": {
        "qct_loglike_obs_only": -260.99900774336845,
        "qumond_loglike_obs_only": -268.4815452508469,
        "delta_aic_total": -12.965075014956938,
        "delta_bic_total": -11.706978476935546,
        "delta_aic_free": -14.965075014956938,
        "delta_bic_free": -14.965075014956938,
        "n": 26,
    },
    "oracle10": {
        "qct_loglike_obs_only": -237.48017228995866,
        "qumond_loglike_obs_only": -268.4815452508469,
        "delta_aic_total": -60.00274592177652,
        "delta_bic_total": -58.744649383755075,
        "delta_aic_free": -62.00274592177652,
        "delta_bic_free": -62.00274592177652,
        "n": 26,
    },
}


def load_rows(csv_path: Path):
    with csv_path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def as_float(row, key):
    return float(row[key])


def verify_row_surface(rows):
    max_vq_err_kms = 0.0
    max_resid_err_kms = 0.0
    max_chi2_err = 0.0
    resid_sign_ok = True
    neg_delta = 0
    pos_delta = 0
    delta_current_vals = []
    sigma_current_vals = []
    chi2_total = 0.0

    for row in rows:
        R_m = as_float(row, "R_m")
        v_bar_ms = as_float(row, "v_bar_ms")
        v_obs_ms = as_float(row, "v_obs_ms")
        sigma_v_ms = as_float(row, "sigma_v_ms")
        vq_ms_ref = as_float(row, "v_QUMOND_fixed_ms")
        resid_ms_ref = as_float(row, "resid_QUMOND_ms")
        chi2_ref = as_float(row, "chi2_QUMOND")
        delta_true = as_float(row, "delta_true")
        delta_cur = as_float(row, "delta_1d_current")
        sigma_cur = as_float(row, "sigma_delta_1d_current")

        y = (v_bar_ms ** 2 / R_m) / A0
        nu = 0.5 + math.sqrt(0.25 + 1.0 / y)
        vq_ms = v_bar_ms * math.sqrt(nu)
        resid_ms = v_obs_ms - vq_ms
        chi2 = (resid_ms / sigma_v_ms) ** 2

        max_vq_err_kms = max(max_vq_err_kms, abs(vq_ms - vq_ms_ref) / 1000.0)
        max_resid_err_kms = max(max_resid_err_kms, abs(resid_ms - resid_ms_ref) / 1000.0)
        max_chi2_err = max(max_chi2_err, abs(chi2 - chi2_ref))
        chi2_total += chi2

        resid_sign_ok = resid_sign_ok and (resid_ms_ref < 0.0)

        if delta_true < 0:
            neg_delta += 1
        elif delta_true > 0:
            pos_delta += 1

        delta_current_vals.append(delta_cur)
        sigma_current_vals.append(sigma_cur)

    return {
        "row_count": len(rows),
        "max_vq_err_kms": max_vq_err_kms,
        "max_resid_err_kms": max_resid_err_kms,
        "max_chi2_err": max_chi2_err,
        "chi2_total": chi2_total,
        "all_qumond_residuals_negative": resid_sign_ok,
        "delta_true_negative_rows": neg_delta,
        "delta_true_positive_rows": pos_delta,
        "delta_1d_current_min": min(delta_current_vals),
        "delta_1d_current_max": max(delta_current_vals),
        "sigma_delta_current_min": min(sigma_current_vals),
        "sigma_delta_current_max": max(sigma_current_vals),
        "all_sigma_current_positive": all(x > 0 for x in sigma_current_vals),
    }


def verify_case_level_lane(name, lane):
    qct = lane["qct_loglike_obs_only"]
    qum = lane["qumond_loglike_obs_only"]
    n = lane["n"]
    delta_ll_term = -2.0 * (qct - qum)
    predicted_delta_aic_free = delta_ll_term
    predicted_delta_bic_free = delta_ll_term
    predicted_delta_aic_total = delta_ll_term + 2.0
    predicted_delta_bic_total = delta_ll_term + math.log(n)
    return {
        "lane": name,
        "delta_aic_free_err": abs(predicted_delta_aic_free - lane["delta_aic_free"]),
        "delta_bic_free_err": abs(predicted_delta_bic_free - lane["delta_bic_free"]),
        "delta_aic_total_err": abs(predicted_delta_aic_total - lane["delta_aic_total"]),
        "delta_bic_total_err": abs(predicted_delta_bic_total - lane["delta_bic_total"]),
    }


def main():
    here = Path(__file__).resolve().parent
    csv_path = here / "NGC0247_CURRENT_REPLICATION_ROWS_V1.csv"
    rows = load_rows(csv_path)
    row_summary = verify_row_surface(rows)

    output = {
        "surface": "ngc0247_current_stack",
        "row_count": row_summary["row_count"],
        "max_v_QUMOND_recompute_error_km_s": round(row_summary["max_vq_err_kms"], 12),
        "max_residual_recompute_error_km_s": round(row_summary["max_resid_err_kms"], 12),
        "max_chi2_recompute_error": round(row_summary["max_chi2_err"], 12),
        "chi2_total_QUMOND_source_locked": round(row_summary["chi2_total"], 12),
        "all_QUMOND_residuals_negative": row_summary["all_qumond_residuals_negative"],
        "delta_true_negative_rows": row_summary["delta_true_negative_rows"],
        "delta_true_positive_rows": row_summary["delta_true_positive_rows"],
        "delta_true_sign_split_label": (
            f"{row_summary['delta_true_negative_rows']} negative / "
            f"{row_summary['delta_true_positive_rows']} positive"
        ),
        "delta_1d_current_range": {
            "min": row_summary["delta_1d_current_min"],
            "max": row_summary["delta_1d_current_max"],
        },
        "sigma_delta_1d_current_range": {
            "min": row_summary["sigma_delta_current_min"],
            "max": row_summary["sigma_delta_current_max"],
        },
        "all_sigma_delta_1d_current_positive": row_summary["all_sigma_current_positive"],
        "historical_lane_errors": {},
        "notes": [
            "This script checks the current visible delta_1d_current / sigma_delta_1d_current surface.",
            "For the bounded reconstructed Phase-2 current row-level comparator, run REPRODUCE_NGC0247_PHASE2_CURRENT_QCT_ROW_COMPARATOR_V1.py.",
        ],
    }

    for name, lane in HISTORICAL_LANES.items():
        summary = verify_case_level_lane(name, lane)
        output["historical_lane_errors"][name] = {
            "delta_aic_free_err": summary["delta_aic_free_err"],
            "delta_bic_free_err": summary["delta_bic_free_err"],
            "delta_aic_total_err": summary["delta_aic_total_err"],
            "delta_bic_total_err": summary["delta_bic_total_err"],
        }

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
