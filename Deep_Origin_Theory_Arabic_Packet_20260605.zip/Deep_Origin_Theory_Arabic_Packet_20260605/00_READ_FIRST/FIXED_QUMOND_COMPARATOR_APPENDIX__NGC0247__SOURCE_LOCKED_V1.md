# Fixed-QUMOND Comparator Appendix — NGC0247 (Source-Locked Read)

Date: `2026-06-04`

Status: `bounded public appendix`

## Purpose

This appendix answers one reviewer request more directly than the earlier
oracle-only table:

- can the named `NGC0247` witness also be viewed against an explicit
  row-by-row fixed-`QUMOND` comparator rather than only through bounded
  wording plus `delta_true`?

## Scope rule

This appendix **does** publish:

- one source-locked fixed-`QUMOND` row comparator for `NGC0247`,
- the per-row `v_obs ± sigma`,
- the preserved `v_bar`,
- the derived fixed-`QUMOND` velocity under the locked simple-`nu(y)` rule,
- the per-row fixed-`QUMOND` residual,
- the per-row obs-only `chi^2` contribution for that fixed comparator,
- and the paired oracle `delta_true` sign pattern.

This appendix does **not** claim:

- that the exact production benchmark table with fitted `Υ` has now been
  published,
- that case-level `ΔAIC/ΔBIC` versus the final QCT comparator is now closed,
- or that full `MOND/QUMOND` non-reducibility has been finished.

## Provenance

This table is assembled from three preserved local sources:

- the preserved `NGC0247` joined SPARC source-side radial case for
  `R`, `v_obs`, `sigma_v`, and `v_bar`,
- `QUMOND_COMPARISON_PLAN.md` for the locked benchmark definition,
- and `epic30_oracle_points.ndjson` for the row-wise oracle `delta_true`.

## Fixed-comparator rule used here

The fixed source-locked comparator shown here uses the same public benchmark
definition already frozen in the packet:

- `a0 = 1.2 × 10^-10 m/s^2`
- simple `nu(y) = 0.5 + sqrt(0.25 + 1/y)`

with:

- `g_bar = v_bar^2 / R`
- `y = g_bar / a0`
- `v_QUMOND = v_bar * sqrt(nu(y))`

This makes the comparator explicit and inspectable without pretending that the
full fitted-`Υ` production benchmark table is already public.

## Frozen summary

- row count = `26`
- all fixed-`QUMOND` row residuals are negative in this source-locked read
- source-locked fixed-`QUMOND` obs-only `chi^2_total = 1160.321`
- mean absolute fixed-`QUMOND` residual = `16.883 km/s`
- max absolute fixed-`QUMOND` residual = `22.100 km/s`

The main bounded comparison point is therefore easy to inspect:

- the oracle witness changes sign across radius,
- while the explicit fixed-`QUMOND` residual remains one-sided and negative
  across all `26` preserved rows in this source-locked read.

That does **not** yet finish the whole anti-`MOND/QUMOND` question, but it
does make the named witness materially easier to audit.

## Row-by-row fixed comparator table

| Row | r/r_max | R (kpc) | v_obs ± σ (km/s) | v_bar (km/s) | v_QUMOND (km/s) | residual_QUMOND (km/s) | χ² contrib. | delta_true | sign |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--: |
| 1 | 0.0743 | 1.08 | 34.6 ± 0.9 | 22.4 | 41.1 | -6.5 | 51.603 | -0.009425 | - |
| 2 | 0.1107 | 1.61 | 47.0 ± 0.8 | 29.9 | 52.9 | -5.9 | 54.969 | 0.020660 | + |
| 3 | 0.1479 | 2.15 | 59.1 ± 3.1 | 35.0 | 61.6 | -2.5 | 0.641 | 0.181430 | + |
| 4 | 0.1857 | 2.70 | 64.4 ± 1.4 | 38.8 | 68.6 | -4.2 | 9.003 | 0.139595 | + |
| 5 | 0.2215 | 3.22 | 67.4 ± 2.3 | 42.4 | 74.9 | -7.5 | 10.732 | 0.045794 | + |
| 6 | 0.2593 | 3.77 | 69.8 ± 0.7 | 45.6 | 80.8 | -11.0 | 247.004 | -0.030800 | - |
| 7 | 0.2964 | 4.31 | 71.3 ± 1.1 | 48.4 | 86.0 | -14.7 | 178.514 | -0.101562 | - |
| 8 | 0.3336 | 4.85 | 73.2 ± 1.7 | 50.7 | 90.5 | -17.3 | 104.050 | -0.136843 | - |
| 9 | 0.3700 | 5.38 | 75.1 ± 3.0 | 52.3 | 94.2 | -19.1 | 40.734 | -0.147828 | - |
| 10 | 0.4072 | 5.92 | 78.5 ± 3.8 | 53.9 | 97.8 | -19.3 | 25.830 | -0.122653 | - |
| 11 | 0.4443 | 6.46 | 81.4 ± 5.0 | 55.4 | 101.2 | -19.8 | 15.707 | -0.107306 | - |
| 12 | 0.4807 | 6.99 | 83.5 ± 7.0 | 56.9 | 104.5 | -21.0 | 8.983 | -0.108887 | - |
| 13 | 0.5179 | 7.53 | 87.1 ± 7.2 | 58.5 | 107.9 | -20.8 | 8.315 | -0.083322 | - |
| 14 | 0.5550 | 8.07 | 90.7 ± 4.8 | 59.9 | 110.9 | -20.2 | 17.656 | -0.049651 | - |
| 15 | 0.5928 | 8.62 | 93.1 ± 1.4 | 61.2 | 113.9 | -20.8 | 220.169 | -0.042396 | - |
| 16 | 0.6286 | 9.14 | 95.9 ± 2.1 | 62.6 | 116.8 | -20.9 | 98.785 | -0.028019 | - |
| 17 | 0.6664 | 9.69 | 98.4 ± 5.2 | 63.8 | 119.5 | -21.1 | 16.500 | -0.014918 | - |
| 18 | 0.7036 | 10.23 | 101.0 ± 8.2 | 64.7 | 121.9 | -20.9 | 6.474 | 0.009425 | + |
| 19 | 0.7400 | 10.76 | 103.0 ± 9.4 | 65.3 | 123.8 | -20.8 | 4.907 | 0.030601 | + |
| 20 | 0.7772 | 11.30 | 104.0 ± 9.4 | 65.5 | 125.4 | -21.4 | 5.171 | 0.042817 | + |
| 21 | 0.8143 | 11.84 | 105.0 ± 8.9 | 65.3 | 126.4 | -21.4 | 5.777 | 0.069532 | + |
| 22 | 0.8514 | 12.38 | 105.0 ± 8.4 | 64.8 | 127.0 | -22.0 | 6.871 | 0.086428 | + |
| 23 | 0.8879 | 12.91 | 105.0 ± 9.0 | 63.9 | 127.1 | -22.1 | 6.030 | 0.118289 | + |
| 24 | 0.9271 | 13.48 | 106.0 ± 8.4 | 62.6 | 126.8 | -20.8 | 6.137 | 0.186825 | + |
| 25 | 0.9635 | 14.01 | 108.0 ± 7.7 | 61.2 | 126.3 | -18.3 | 5.633 | 0.250000 | + |
| 26 | 1.0000 | 14.54 | 107.0 ± 9.2 | 59.9 | 125.7 | -18.7 | 4.127 | 0.250000 | + |

## Use rule

Use this appendix to answer the narrower reviewer question:

- is the fixed-`QUMOND` pressure now visible row by row for the named
  `NGC0247` witness itself?

Do **not** use it to claim:

- that the exact fitted-`Υ` production benchmark table is already public,
- that `ΔAIC/ΔBIC` versus the final QCT comparator is already closed here,
- or that the whole anti-`MOND/QUMOND` program question is finished.
