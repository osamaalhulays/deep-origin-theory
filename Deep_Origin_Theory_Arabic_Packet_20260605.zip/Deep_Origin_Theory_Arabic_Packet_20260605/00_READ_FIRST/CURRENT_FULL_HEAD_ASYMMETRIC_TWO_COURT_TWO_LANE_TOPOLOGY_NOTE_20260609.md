# Current Full-Head Asymmetric Two-Court Two-Lane Topology Note

Date: `2026-06-09`

Status: `packet-contained full-head topology synthesis`

Purpose:

The packet had already separately shown that:

- one protected clean-anchor minority survives,
- one burden-dominant Hubble-flow-sensitive body is fully closed,
- the clean-anchor minority is internally lane-dispersed,
- the Hubble-flow-sensitive body is strongly reinforced across layered `O7`,
- and the current nonoverlap inside that body is only one narrow localized
  pocket.

This note turns those separate gains into one single full-head topology.

Machine-readable companion:

- `CURRENT_FULL_HEAD_ASYMMETRIC_TWO_COURT_TWO_LANE_TOPOLOGY_V1.json`

Reproduction script:

- `REPRODUCE_CURRENT_FULL_HEAD_ASYMMETRIC_TWO_COURT_TWO_LANE_TOPOLOGY_V1.py`

It should be read after:

- `CLEAN_ANCHOR_MINORITY_CROSS_LANE_DISPERSION_NOTE_20260609.md`
- `HUBBLE_FLOW_SENSITIVE_BODY_LAYERED_O7_CONVERGENCE_NOTE_20260609.md`
- `HUBBLE_FLOW_SENSITIVE_BODY_CURRENT_O7_REMAINDER_LOCALIZATION_NOTE_20260609.md`

## Short verdict

The current full head is no longer best read only as one bifurcated
two-court structure.

It is now better read as one asymmetric two-court two-lane topology.

The current head contains:

- `14` named cases total
- one protected clean-anchor minority court = `4` cases
- one Hubble-flow-sensitive majority court = `10` cases

But those two courts do not behave symmetrically across lanes.

## 1. Court A: protected minority, but lane-dispersed

The protected clean-anchor minority still carries:

- `4` cases
- `34.45341820567513%` of full-head public burden

Its internal lane split is:

- one repeated toward-`QCT` singleton:
  `NGC5055`
- one `O7`-positive dispersed triad:
  `NGC3198`, `NGC2841`, `NGC7331`

So Court A survives, but it does not collapse to one uniform later-lane role.

## 2. Court B: burden-dominant majority, and lane-reinforced

The Hubble-flow-sensitive court carries:

- `10` cases
- `65.54658179432487%` of full-head public burden

Its internal lane split is:

- one `O7`-reinforced heptad:
  `UGC09133`, `UGC02953`, `UGC06787`, `UGC06786`, `UGC02487`,
  `UGC03205`, `UGC05253`
- one narrow current nonoverlap pocket:
  `NGC2903`, `NGC6674`, `NGC5033`

The seven-case reinforced heptad alone carries:

- `50%` of full-head case count
- `53.70934938115022%` of full-head public burden

So Court B is not only larger. Its larger side is already cross-lane
reinforced.

## 3. The whole head already has one strong `O7`-materialized union

Across both courts together:

- `10/14` current full-head cases already materialize inside `O7`
  positive-spoiler layers
- those `10` cases span `4` distinct internal `O7` layers

The non-`O7` remainder is not another giant rival half.

It is only:

- one repeated toward-`QCT` singleton:
  `NGC5055`
- plus one narrow three-witness quality-`1` continuation pocket:
  `NGC2903`, `NGC6674`, `NGC5033`

## 4. Meaning

This is a better current full-head sentence than either of the following:

- "the head is just split in two"
- "the head is one flat spoiler wall"

No.

The current topology is asymmetric:

- the minority court survives but disperses across lanes
- the majority court dominates and is reinforced across lanes
- the non-`O7` remainder is not one second rival court of comparable size

## 5. What this does not authorize

This note does **not** authorize the claims that:

- the current full head is already globally terminally settled
- every remaining case must join the same later lane
- whole-family `MOND/QUMOND` closure already exists

## Best outward-safe reading

One mature outward-safe sentence is:

> The current full head is best read as one asymmetric two-court two-lane
> topology. A protected four-case minority survives but is internally
> dispersed across lanes, while a burden-dominant ten-case majority is
> strongly reinforced across layered `O7` space, leaving only a narrow
> non-`O7` remainder rather than a second rival half.
