# `NGC0247` Matched-Nuisance Final Comparator Parity Note

Date: `2026-06-10`

Status: `reviewer-facing comparator clarification`

Purpose:

Answer one narrow reviewer-grade question left by the outside reproducibility
pass:

- does the final same-convention matched-nuisance comparison use
  `obs-only` for both sides equally,
  or does the packet silently reuse the historical mixed shell?

## Short verdict

Yes.

The final same-convention replay shell uses:

- `QCT = ll_qct_obs_only`
- `QUMOND = ll_qumond_obs_only`
- one fitted nuisance count on each side

The preserved `ll_qct_obs_model` value remains visible only so that the
historical mixed shell can stay auditable as a separate historical object.

But no.

This same-convention replay shell is **not** itself the present pro-`QCT`
support shell.

In this replay file the sign convention is:

- `Delta AIC = AIC_QCT - AIC_QUMOND`

So positive values favor `QUMOND`,
and negative values favor `QCT`.

## Exact code split

Inside
`REPRODUCE_NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_V1.py`
the replay computes three likelihood objects:

- `ll_qct_obs_only`
- `ll_qct_obs_model`
- `ll_qumond_obs_only`

It then builds three distinct shells:

- `historical_mixed`
  uses `ll_qct_obs_model` versus `ll_qumond_obs_only`
- `equal_free_obs_only`
  uses `ll_qct_obs_only` versus `ll_qumond_obs_only`
- `qct_extra_penalty_obs_only`
  uses `ll_qct_obs_only` versus `ll_qumond_obs_only`
  with one extra `QCT`-side penalty term

So the packet does not silently blur the conventions.

It preserves both shells explicitly and separately.

## Why both `QCT` likelihoods stay visible

Both `QCT` likelihoods remain in the replay for one reason of bookkeeping
honesty:

- the historical mixed shell is part of the preserved Phase-2 history
- the reviewer-facing same-convention shell must remain separately visible
- and the packet should not hide the distinction by naming alone

This is why the replay keeps both objects instead of overwriting one with the
other.

## Final same-convention control shell

The final same-convention shell is the explicit
`equal_free_obs_only` shell.

At the adopted central point in
`NGC0247_PHASE2_MATCHED_NUISANCE_WINDOW_REPLAY_V1.json`
it yields:

- `Delta AIC = +293.31161341697657`
- `Delta BIC = +293.31161341697657`

Across the full lawful `±1 sigma` `distance / inclination` replay window:

- least unfavorable point for `QCT`:
  `Delta AIC = +292.85095231422747`
- most unfavorable point for `QCT`:
  `Delta AIC = +293.8470687217091`
- `rescue_seen_within_1sigma_box = false`

So the same-convention shell is not only explicit.

It is also executed and stable across the lawful visible replay box.

## What this shell authorizes as a claim

The final same-convention shell authorizes one parity sentence only:

> the packet does not silently mix comparator conventions:
> the explicit same-convention `obs-only` replay shell is visible,
> separate from the historical mixed shell,
> and it remains a negative/control lane against `QCT`.

That reading is lawful because:

- the comparator basis is `obs-only` on both sides
- one nuisance count is fitted on the `QCT` side
- one nuisance count is fitted on the `QUMOND` side
- and the fitted nuisance values remain separately visible rather than forced
  to coincide by naming alone

At the central adopted point those fitted values are preserved explicitly as:

- `upsilon_qct_obs_only`
- `upsilon_qumond_obs_only`

The present pro-`QCT` procedural support lives elsewhere:

- in the separately audited executed parity witness scoring shell
- with fixed-public `Delta AIC = -13.914066963632308`
- faithful matched-nuisance `Delta AIC = -15.398764714420167`
- and component-aware matched-nuisance `Delta AIC = -39.63154845025974`

So the packet must not relabel the positive `equal_free_obs_only` replay as
the support-bearing shell by naming alone.

## Claim ceiling

This note closes one comparator-parity wording question only.

It does **not** claim:

- family-scale `MOND/QUMOND` closure
- Bayesian evidence
- unconditional physical superiority of `QCT`
- that every future nuisance family will behave the same way
- or that the historical mixed shell should become the outward comparator

## Bottom line

The packet now states the exact intended reading plainly:

> the preserved historical mixed shell remains one separate historical
> object,
> the explicit same-convention `obs-only` replay shell remains one negative
> control lane against `QCT`,
> and the present pro-`QCT` procedural support belongs instead to the
> separately audited executed parity witness scoring shell.
