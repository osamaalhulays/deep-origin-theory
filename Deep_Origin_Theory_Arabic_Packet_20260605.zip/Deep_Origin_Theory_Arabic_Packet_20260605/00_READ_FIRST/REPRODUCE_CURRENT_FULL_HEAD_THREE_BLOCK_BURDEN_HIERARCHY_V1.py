#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

COUNT_BALANCED_PATH = HERE / "CURRENT_FULL_HEAD_COUNT_BALANCED_BURDEN_ASYMMETRIC_SPLIT_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def close_enough(left, right, tolerance=1e-9):
    return abs(left - right) <= tolerance


def per_case_public_burden(block):
    return block["public_delta_aic_total"] / block["case_count"]


def main():
    count_balanced = load_json(COUNT_BALANCED_PATH)

    full_head = count_balanced["full_head"]
    heptad = count_balanced["dominant_o7_reinforced_heptad"]
    complement = count_balanced["seven_case_complement"]
    quartet = complement["internal_split"]["protected_clean_anchor_quartet"]
    pocket = complement["internal_split"]["localized_quality1_continuation_pocket"]

    heptad_per_case = per_case_public_burden(heptad)
    quartet_per_case = per_case_public_burden(quartet)
    pocket_per_case = per_case_public_burden(pocket)

    consistency_checks = {
        "full_head_case_count_is_fourteen": full_head["case_count"] == 14,
        "three_blocks_recombine_to_full_head_case_count": (
            heptad["case_count"] + quartet["case_count"] + pocket["case_count"]
            == full_head["case_count"]
        ),
        "three_blocks_recombine_to_full_head_public_total": close_enough(
            heptad["public_delta_aic_total"]
            + quartet["public_delta_aic_total"]
            + pocket["public_delta_aic_total"],
            full_head["public_delta_aic_total"],
        ),
        "three_blocks_order_strictly_by_public_burden": (
            heptad["public_delta_aic_total"]
            > quartet["public_delta_aic_total"]
            > pocket["public_delta_aic_total"]
        ),
        "three_blocks_order_strictly_by_case_count": (
            heptad["case_count"] > quartet["case_count"] > pocket["case_count"]
        ),
        "heptad_spans_four_o7_layers": heptad["distinct_o7_layer_count"] == 4,
        "quartet_preserves_one_singleton_plus_one_dispersion_triad": (
            quartet["internal_lane_split"]["repeated_toward_qct_singleton"]
            == ["SPARC_NGC5055"]
            and quartet["internal_lane_split"]["o7_positive_dispersion_triad"]
            == ["SPARC_NGC2841", "SPARC_NGC3198", "SPARC_NGC7331"]
        ),
        "pocket_remains_all_quality1_and_exact_qumond_protected": (
            pocket["all_cases_are_quality1"] and pocket["all_cases_have_exact_qumond_protection"]
        ),
        "quartet_is_burden_dominant_inside_the_seven_case_complement": (
            quartet["public_delta_aic_total"] > pocket["public_delta_aic_total"]
        ),
        "quartet_per_case_density_exceeds_heptad_per_case_density": quartet_per_case > heptad_per_case,
        "quartet_per_case_density_exceeds_pocket_per_case_density": quartet_per_case > pocket_per_case,
        "fractional_public_burdens_sum_to_one": close_enough(
            heptad["fraction_of_full_head_public_delta_aic_total"]
            + quartet["fraction_of_full_head_public_delta_aic_total"]
            + pocket["fraction_of_full_head_public_delta_aic_total"],
            1.0,
        ),
    }

    output = {
        "date": "2026-06-09",
        "status": "bounded_packet_facing_three_block_burden_hierarchy",
        "surface": "current_full_head_three_block_burden_hierarchy",
        "full_head": full_head,
        "three_block_ordering": {
            "dominant_o7_reinforced_heptad": {
                **heptad,
                "average_public_delta_aic_total_per_case": heptad_per_case,
            },
            "protected_clean_anchor_quartet": {
                **quartet,
                "average_public_delta_aic_total_per_case": quartet_per_case,
                "fraction_of_seven_case_complement_public_delta_aic_total": quartet[
                    "public_delta_aic_total"
                ]
                / complement["public_delta_aic_total"],
            },
            "localized_quality1_continuation_pocket": {
                **pocket,
                "average_public_delta_aic_total_per_case": pocket_per_case,
                "fraction_of_seven_case_complement_public_delta_aic_total": pocket[
                    "public_delta_aic_total"
                ]
                / complement["public_delta_aic_total"],
            },
        },
        "derived_ratios": {
            "heptad_to_quartet_public_burden_ratio": heptad["public_delta_aic_total"]
            / quartet["public_delta_aic_total"],
            "heptad_to_pocket_public_burden_ratio": heptad["public_delta_aic_total"]
            / pocket["public_delta_aic_total"],
            "quartet_to_pocket_public_burden_ratio": quartet["public_delta_aic_total"]
            / pocket["public_delta_aic_total"],
            "quartet_to_heptad_per_case_density_ratio": quartet_per_case / heptad_per_case,
            "quartet_to_pocket_per_case_density_ratio": quartet_per_case / pocket_per_case,
        },
        "structural_reading": {
            "the_current_full_head_orders_into_three_public_burden_blocks": True,
            "the_middle_block_is_the_protected_clean_anchor_quartet_not_the_exact_qumond_pocket": True,
            "the_smallest_block_is_the_three_witness_exact_qumond_protected_quality1_pocket": True,
            "the_clean_anchor_quartet_is_denser_per_case_than_the_heptad_but_still_smaller_in_total_public_burden": True,
        },
        "consistency_checks": consistency_checks,
        "supported_now": [
            "the current full head now admits one explicit three-block public-burden ordering: heptad, quartet, then pocket",
            "the protected clean-anchor quartet carries nearly three quarters of the seven-case complement burden",
            "the exact-QUMOND-protected pocket is real but narrow in total burden",
            "the clean-anchor quartet is denser per case than the heptad even though the heptad remains the total-burden leader",
        ],
        "not_supported_now": [
            "the full head is only one flat seven-versus-seven split with no stronger internal ordering",
            "the exact-QUMOND-protected pocket rivals the clean-anchor quartet in current total burden",
            "per-case burden density alone settles the global scientific verdict",
            "Whole-family MOND_QUMOND closure",
        ],
        "next_honest_frontier": [
            "test whether later expansion pushes the narrow pocket into the same reinforced lane or leaves the three-block ordering intact",
            "extend the cross-observable court without promoting this present hierarchy into whole-family final closure",
        ],
    }

    output["verdict"] = (
        "CURRENT_FULL_HEAD_THREE_BLOCK_BURDEN_HIERARCHY_CLOSED__THE_HEAD_ORDERS_INTO_A_DOMINANT_O7_HEPTAD_A_DENSE_PROTECTED_QUARTET_AND_A_NARROW_EXACT_QUMOND_POCKET"
        if all(consistency_checks.values())
        else "CURRENT_FULL_HEAD_THREE_BLOCK_BURDEN_HIERARCHY_NOT_YET_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
