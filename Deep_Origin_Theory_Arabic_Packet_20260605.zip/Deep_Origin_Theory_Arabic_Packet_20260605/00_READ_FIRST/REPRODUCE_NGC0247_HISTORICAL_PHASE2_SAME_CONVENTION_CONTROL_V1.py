#!/usr/bin/env python3
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PHASE2_SCRIPT = HERE / "REPRODUCE_NGC0247_PHASE2_CURRENT_QCT_ROW_COMPARATOR_V1.py"


def run_json_script(script_path: Path):
    output = subprocess.check_output(
        [sys.executable, str(script_path)],
        cwd=str(HERE),
        text=True,
    )
    return json.loads(output)


def score_shell(ll_qct, ll_qumond, k_qct, k_qumond):
    delta_aic = (2.0 * k_qct - 2.0 * ll_qct) - (2.0 * k_qumond - 2.0 * ll_qumond)
    return delta_aic


def main():
    phase2 = run_json_script(PHASE2_SCRIPT)
    ll_qct_obs_only = phase2["ll_qct_obs_only"]
    ll_qumond_obs_only = phase2["ll_qumond_benchmark_obs_only"]
    historical_mixed_delta_aic = phase2["delta_aic_total_historic"]

    equal_free_obs_only = score_shell(ll_qct_obs_only, ll_qumond_obs_only, 1, 1)
    qct_extra_penalty_obs_only = score_shell(ll_qct_obs_only, ll_qumond_obs_only, 2, 1)

    output = {
        "surface": "ngc0247_historical_phase2_same_convention_control",
        "historical_mixed_shell": {
            "delta_aic_total": historical_mixed_delta_aic,
            "scoring_rule": "historical_mixed_qct_obs_model_vs_qumond_obs_only",
        },
        "same_convention_shells": {
            "equal_free_obs_only": {
                "delta_aic": equal_free_obs_only,
                "delta_bic": equal_free_obs_only,
                "k_qct": 1,
                "k_qumond": 1,
                "rule": "obs_only_for_both_models_with_one_fitted_nuisance_each",
            },
            "qct_extra_penalty_obs_only": {
                "delta_aic": qct_extra_penalty_obs_only,
                "k_qct": 2,
                "k_qumond": 1,
                "rule": "obs_only_for_both_models_with_one_extra_qct_side_penalty",
            },
        },
        "friendliest_shell_minus_historical_mixed_delta_aic": (
            equal_free_obs_only - historical_mixed_delta_aic
        ),
        "verdict": (
            "HISTORICAL_PHASE2_SAME_CONVENTION_CONTROL_IS_STRONGLY_ANTI_QCT__DO_NOT_PROMOTE_AS_REVIEWER_FACING_PARITY_ARTIFACT"
        ),
    }

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
