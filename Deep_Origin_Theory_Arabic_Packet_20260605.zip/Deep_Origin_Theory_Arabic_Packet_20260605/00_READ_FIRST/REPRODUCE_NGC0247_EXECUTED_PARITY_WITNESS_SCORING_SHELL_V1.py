#!/usr/bin/env python3
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SUPPORT_PATH = HERE / "NGC0247_EXECUTED_PARITY_WITNESS_SCORING_SUPPORT_V1.json"
SCORING_SHELL_PATH = HERE / "NGC0247_EXECUTED_PARITY_WITNESS_OUTWARD_SCORING_SHELL_V1.json"
PROMOTION_BOUNDARY_PATH = HERE / "NGC0247_EXECUTED_PARITY_WITNESS_PROMOTION_BOUNDARY_V1.json"
ROUTE_SPLIT_PATH = HERE / "NGC0247_FULL_BODY_GROUNDED_DUAL_EXECUTION_ROUTE_SPLIT_V1.json"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def close_enough(left, right, tolerance=1e-12):
    return abs(left - right) <= tolerance


def main():
    support = load_json(SUPPORT_PATH)
    shell = load_json(SCORING_SHELL_PATH)
    promotion = load_json(PROMOTION_BOUNDARY_PATH)
    route_split = load_json(ROUTE_SPLIT_PATH)

    faithful_delta = support["live_lane_replay_receipt"]["faithful_branch"]["delta_aic_total"]
    component_aware_delta = support["live_lane_replay_receipt"]["component_aware_branch"]["delta_aic_total"]
    public_delta = support["public_live_anchor_receipt"]["delta_aic_total"]
    component_shift = component_aware_delta - faithful_delta

    shell_headline = shell["headline_live_parity_score"]["delta_aic_total"]
    shell_component = shell["hardening_companion"]["delta_aic_total"]
    shell_component_shift = shell["hardening_companion"]["delta_aic_total_shift_vs_faithful"]
    shell_public = shell["audit_anchor"]["delta_aic_total"]

    promotion_live = promotion["live_matched_nuisance_witness"]
    route_live = route_split["o6_matched_nuisance_execution_return"]

    consistency_checks = {
        "shell_headline_matches_support": close_enough(shell_headline, faithful_delta),
        "shell_component_aware_matches_support": close_enough(shell_component, component_aware_delta),
        "shell_public_anchor_matches_support": close_enough(shell_public, public_delta),
        "shell_component_shift_matches_support": close_enough(shell_component_shift, component_shift),
        "promotion_boundary_matches_support": (
            close_enough(promotion_live["public_delta_aic_total"], public_delta)
            and close_enough(promotion_live["faithful_delta_aic_total"], faithful_delta)
            and close_enough(promotion_live["component_aware_delta_aic_total"], component_aware_delta)
            and close_enough(promotion_live["component_aware_shift_delta_aic_total"], component_shift)
        ),
        "route_split_matches_support": (
            close_enough(route_live["public_delta_aic_total"], public_delta)
            and close_enough(route_live["faithful_delta_aic_total"], faithful_delta)
            and close_enough(route_live["component_aware_delta_aic_total"], component_aware_delta)
            and close_enough(route_live["component_aware_delta_aic_total_shift"], component_shift)
        ),
        "public_anchor_gap_matches_shell": close_enough(
            abs(public_delta - faithful_delta),
            abs(shell_public - shell_headline),
        ),
    }

    output = {
        "surface": "ngc0247_executed_parity_witness_scoring_shell_replay",
        "case_id": support["witness"],
        "source_class": "packet_contained_cross_anchor_replay_with_imported_support_receipts",
        "faithful_delta_aic_total": faithful_delta,
        "component_aware_delta_aic_total": component_aware_delta,
        "fixed_public_delta_aic_total": public_delta,
        "component_aware_shift_delta_aic_total": component_shift,
        "public_vs_faithful_delta_aic_gap_abs": abs(public_delta - faithful_delta),
        "consistency_checks": consistency_checks,
    }

    output["scoring_shell_replay_closed"] = all(consistency_checks.values())
    output["verdict"] = (
        "NGC0247_EXECUTED_PARITY_WITNESS_SCORING_SHELL_REPLAY_CLOSED__SUPPORT_RECEIPTS_AND_PACKET_SHELLS_ARE_NUMERICALLY_CONCORDANT"
        if output["scoring_shell_replay_closed"]
        else "NGC0247_EXECUTED_PARITY_WITNESS_SCORING_SHELL_REPLAY_NOT_CLOSED"
    )

    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
