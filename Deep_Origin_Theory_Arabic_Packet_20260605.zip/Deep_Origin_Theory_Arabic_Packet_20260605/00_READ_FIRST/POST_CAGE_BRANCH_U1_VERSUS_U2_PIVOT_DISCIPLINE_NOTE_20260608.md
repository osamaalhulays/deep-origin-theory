# Post-Cage Branch U1 Versus U2 Pivot Discipline Note

Date: `2026-06-08`

Purpose:

This note states one exact later refinement inside the post-cage `O4/O5`
program:

- why `U1` still deserves the next clean attempt,
- and when the line should widen honestly into `U2`.

## Short verdict

Current fair reading:

1. `U1` remains alive
2. `U2` is not yet forced
3. but `U2` is no longer one vague fallback
4. its trigger classes are already typed

So the present discipline is:

- `U1-first`
- `U2-ready`
- pivot on architecture, not on frustration

## 1. Why `U1` still goes first

Nothing in the current record yet proves that:

- one single physical carrier cannot own the response route,
- the south side cannot be recovered as one bounded regime of that carrier,
- or promotable source-governed content is impossible inside that cleaner
  route.

The later `L2` witness even preserves genuine constructive prefill:

- one source-to-total rule,
- one nontrivial operator grammar,
- and one bounded nontrivial geometric probe at `C0_NO_CLAIM_EXPORT`.

So the line has progressed beyond pure route absence.

## 2. When `U2` becomes the honest split

The line should widen to `U2` if the record shows that `U1` cannot survive
without hidden extra carrierhood.

The exact trigger classes are now:

1. strong-field closure needs one genuinely new transport-bearing companion
2. the south generator/basis freeze needs one genuinely independent south
   carrier
3. the coefficient time law cannot be written from single-carrier-owned data
4. the supposed `U1` route survives only by smuggling a second field or one
   external transport patch in disguise

At that point the issue is no longer mere difficulty.

It is architecture-class mismatch.

## 3. Why this matters

This prevents two bad moves:

- widening too early just because the endgame is hard
- or keeping the single-carrier route alive after it has already become a
  disguised two-carrier construction

So the line is now disciplined at a finer level than:

- `Branch U yes/no`

It is disciplined at the exact split:

- `U1` if one carrier can still own the needed physics honestly
- `U2` once that honesty breaks

## Bottom line

The post-cage route is now clearer than before:

- `U1` remains the preferred next strike
- `U2` remains the ready escalation lane
- and the widening trigger is now exact rather than emotional
