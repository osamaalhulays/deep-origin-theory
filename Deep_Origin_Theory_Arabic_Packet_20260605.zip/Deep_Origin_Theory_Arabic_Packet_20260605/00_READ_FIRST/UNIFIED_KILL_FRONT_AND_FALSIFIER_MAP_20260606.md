# Unified Kill-Front And Falsifier Map

Date: `2026-06-06`

This surface exists to make one point explicit:

the packet does not only preserve support surfaces.
It also preserves governed failure surfaces.

The framework is meant to be killable if its central bounded claims are wrong.

## Core falsifier family

### `F1` smoothing-authority falsifier

If a visible bridge or witness survives only because smoothing is silently
treated as authority, the bounded claim fails.

Present packet binding:

- `NGC0247_PHASE2_CASELOCK_AND_FORWARD_MODEL_NOTE_20260605.md`
- `CASE_LEVEL_BENCHMARK_APPENDIX__NGC0247__ARTIFACT_EMULATOR_V1.md`
- `CURRENT_QCT_ROW_COMPARATOR_APPENDIX__NGC0247__PHASE2_RECONSTRUCTED_V1.md`

### `F2` hidden-parameter falsifier

If one hidden sector-specific width, coupling, amplitude, normalization, or
late repair parameter must be introduced after harmonization, the bounded
common-parent claim fails.

Present packet binding:

- `NGC0247_MODEL_LOCK_CARD_V1.md`
- `NGC0247_CURRENT_REPLICATION_CAPSULE_V1.md`
- `01_A_PreRank9/.../GLOBAL_PARAMETER_DISCIPLINE_NOTE.md`

### `F3` traceless / common-basis falsifier

If tracelessness or the declared common test basis is not preserved, the
same-parent bridge object fails.

Present packet binding:

- `CURRENT_SCOPE_SYMMETRY_AND_LIMIT_VALIDATION_TABLE_20260605.md`
- `02_B_Rank9/.../Keystone_I_The_First_Bearing_20260429/COMMON_BASIS_VECTOR_DERIVATION_NOTE.md`
- `02_B_Rank9/.../Keystone_I_The_First_Bearing_20260429/PARENT_OPERATOR_MEANING_NOTE.md`

### `F4` contact / subtraction falsifier

If contact or subtraction terms create the overlap signal or hide the true
mismatch, the bridge claim fails.

Present packet binding:

- `02_B_Rank9/.../Keystone_I_The_First_Bearing_20260429/COMMON_BASIS_VECTOR_DERIVATION_NOTE.md`
- `01_A_PreRank9/.../QCT_LINEAGE_AND_APEX_20260218_20260228/LENSING_DISCIPLINATOR_AND_BRANCH_DISCIPLINE_NOTE.md`

### `F5` decisive-support-loss falsifier

If accepted overlap survives only by discarding decisive nonmatching support,
the bounded bridge result fails.

Present packet binding:

- `HISTORICAL_SAME_SOURCE_BLIND_HOLDOUT_NOTE_20260605.md`
- `MULTI_GALAXY_DIFFERENTIAL_PANEL_NOTE_20260605.md`
- `DEFERRED_SCOPE_AND_ACTIVE_DEBTS.md`

### `F6` future-cosmology residual-fit falsifier

If the later cosmology program requires residual fitting of external nuisance
parameters or initial scalar data in order to generate the first lawful
background model vector, then the present framework may remain a bounded
bridge result while the complete cosmology program fails.

Present packet binding:

- `PREDICTION_AND_TESTABILITY_CLOSURE_LEDGER_20260605.md`
- `02_B_Rank9/.../CURRENT_STAGE_AND_PREDICTION_STATUS.md`
- `03_C_Cluster/.../L0_CROSSING_TRUTH_AUDIT_20260604.md`

## Differential kill-fronts already visible now

### `NGC0247`

Current visible failure modes include:

- row-level failure against the fixed comparator,
- morphology failure in the radial correction structure,
- replication failure on the bounded current stack,
- and failure of the bounded benchmark bridge if the preserved comparison lane
  does not hold under rerun.

### `NGC6946`

Current visible failure modes include:

- failure of the one-sided fixed-comparator pressure pattern,
- failure of the sign-changing oracle morphology,
- or failure of the preserved second-witness reading under exact row
  inspection.

This second witness is narrower than `NGC0247`,
but it still materially strengthens the visible kill-front map.

## Later kill-fronts

### Lensing / cluster kill-switch

The packet does not treat lensing or cluster-side opening as a decorative
future bonus.

They remain governed later kill-fronts.

Present packet binding:

- `03_C_Cluster/.../MACS1206_INTERNAL_ASCENT_GATE_PACKET_20260604.md`
- `03_C_Cluster/.../MACS1206_HIGHEST_PRESENT_CEILING_AND_TERMINAL_GAP_NOTE_20260606.md`
- `03_C_Cluster/.../MACS1206_TERMINAL_AUTHORITY_CAPTURE_PLAN_AND_TRAP_NOTE_20260606.md`

### `L2` public-hunt ceiling

The later non-`SPARC` baryonic lane has already been pushed to its lawful
public ceiling.

Its present live state is:

- public-hunt closure reached,
- reopen only on explicit machine-readable component-curve release or direct
  author payload.

Present packet binding:

- `03_C_Cluster/.../L2_PUBLIC_MP21A_3DBAROLO_BREAKTHROUGH_NOTE_20260606.md`
- `03_C_Cluster/.../L2_PUBLIC_HUNT_COSMIC_CLOSURE_AND_DIRECT_AUTHOR_ADMISSION_GATE_NOTE_20260606.md`
- `03_C_Cluster/.../C_LIVE_PHASE_KEYS_20260605.md`

## Carry-forward rule

No partial-stage success is allowed to retire later falsifiers prematurely.

That means:

- a bounded witness does not erase later holdout duties,
- a bridge result does not erase later cosmology duties,
- and a public-hunt breakthrough does not erase the exact missing-layer gate
  that still blocks claim-capable reopening.

See:

- `CURRENT_STAGE_CEILING_AND_LATER_STAGE_TRANSFER_RULE_NOTE_20260606.md`

## Current-stage ceiling and later transfer

For the current stage, the packet already preserves:

- explicit falsifiers,
- explicit bounded witnesses,
- explicit rerunnable tests,
- explicit later kill-fronts,
- and explicit carry-forward discipline.

What remains intentionally later is not "failure logic in general."
It is only the later closure of the fronts that are already named.

## Best short outward-safe reading

The packet should now be read as preserving:

- explicit falsifiers,
- explicit bounded witnesses,
- explicit rerunnable tests,
- explicit later kill-fronts,
- and explicit carry-forward discipline.

So the framework is not asking to be protected from failure.

It is asking to be judged under declared failure routes.
