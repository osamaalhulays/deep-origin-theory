# Bounded Source-To-White-Guard Instantiation Chain Note

Date: `2026-06-06`

Status: `reviewer-facing bounded instantiation-chain clarification`

Purpose:

The remaining `T1` debt after the recent mathematics closures is no longer:

- "where is the white guard?"

It is narrower:

- "where is the source-instantiation route from the parent-law root to the
  admitted white-guard class?"

This note does **not** claim a final uniqueness theorem for that full route.

It does something smaller and useful:

- it exposes the bounded instantiation chain that is already present on the
  public route,
- and it shows exactly where the chain is already materialized and where the
  stronger theorem still remains later.

## 1. The present bounded chain

At current scope, the public route already exposes the following chain:

\[
\mathcal A_{201}
\;\longrightarrow\;
\mathfrak W_{\mathrm{FMR}}
\;\longrightarrow\;
\mathfrak C_{\mathrm{adm}}
\;\longrightarrow\;
\mathcal S_{m|r}
\;\longrightarrow\;
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}
\;\longrightarrow\;
\Phi_{\mathrm{white}}
\;\longrightarrow\;
\Phi_{\mathrm{white}}^{\mathrm{complete}}
\;\longrightarrow\;
\rho_{\mathrm{eff}}^{\mathrm{white}}.
\]

Here:

- `\mathcal A_{201}` = the locked `SPEC-201` action root
- `\mathfrak W_FMR` = the canonical fixed-`r` morphology-survival white root
- `\mathfrak C_adm` = the bounded currently admitted carrier family on the
  public route
- `\mathcal S_{m|r} = I - \Pi_r` = the morphology-survival operator after
  fixing radius
- `\mathcal G_morph^{<r-fixed>}` = the bounded dimensionless white guard
- `\Phi_white` = the compact white potential
- `\Phi_white^{complete}` = the lifted conservative completion
- `\rho_eff_white` = the Einstein-side effective-source representation

The key point is not that the whole chain is already final.

The key point is that it is no longer absent.

## 2. Root level: action to white-root class

The white-law packet already states that the current white route:

- descends from the locked `SPEC-201` action,
- keeps `gamma` and `m` as the only global theory parameters on that root,
- and treats `FMR` as the canonical white potential descendant of that action
  root.

So the present route already has:

\[
\mathcal A_{201}
\longrightarrow
\mathfrak W_{\mathrm{FMR}}
\]

as a bounded declared root relation.

What is **not** yet claimed is:

- one full uniqueness theorem proving that every later admissible white object
  is generated from the action root in final external form.

## 3. White-root class to admitted carrier family

The current white-law admissibility surfaces already state that:

- one governed current carrier family is explicitly bound,
- the current admissible carrier id is
  `fixed_r_baryonic_contrast_candidate_family`,
- comparative widening remains blocked,
- and operator-dictionary closure narrows the lawful class before any wider
  function comparison is opened.

So the present route already has:

\[
\mathfrak W_{\mathrm{FMR}}
\longrightarrow
\mathfrak C_{\mathrm{adm}}
:
=
\mathfrak C_{\mathrm{fixed\text{-}r\ baryonic\ contrast}}
\]

as a bounded current-family instantiation step.

What is **not** yet claimed is:

- one theorem showing that no stronger later family could ever lawfully emerge,
- or one comparative-family closure theorem above the no-widening boundary.

## 4. Admitted carrier family to survival operator

Inside the present route, the admitted family is not left as a raw carrier
bucket.

It is acted on by the explicit radius-only projector `\Pi_r`, so that the
survival operator

\[
\mathcal S_{m|r} := I - \Pi_r
\]

extracts the non-radius surviving structure.

This already materializes the chain step

\[
\mathfrak C_{\mathrm{adm}}
\longrightarrow
\mathcal S_{m|r}.
\]

At current scope, the fair question is therefore no longer:

- "is there any operator at all between the family and the guard?"

It is:

- "what stronger theorem would later justify the full physical source meaning
  of this route beyond its current bounded formalization?"

## 5. Survival operator to bounded guard

Once the survival numerator

\[
S(R) := (I-\Pi_r)[\mathcal M](R)
\]

and the positive normalization

\[
N(R) := \mathcal N_r[\mathcal M](R) > 0
\]

are fixed on the admitted class, the guard is:

\[
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R)
=
\frac{S(R)}{\sqrt{N(R)^2 + S(R)^2}}.
\]

That step is now explicit both analytically and class-wise:

\[
\mathcal S_{m|r}
\longrightarrow
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}.
\]

The current debt is no longer at this step.

## 6. Guard to potential and lifted source

The admitted route already writes:

\[
\Phi_{\mathrm{white}}(R)
=
\gamma_\star\,
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R),
\]

and then

\[
\Phi_{\mathrm{white}}^{\mathrm{complete}}(R,\varphi,z)
=
\gamma_\star\,
\Xi(R,\varphi,z)\,
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}(R),
\]

followed by

\[
\rho_{\mathrm{eff}}^{\mathrm{white}}
=
\frac{1}{4\pi G_{\mathrm{review}}}
\nabla^2\Phi_{\mathrm{white}}^{\mathrm{complete}}.
\]

So the chain already continues as:

\[
\mathcal G_{\mathrm{morph}}^{\langle r\text{-fixed}\rangle}
\longrightarrow
\Phi_{\mathrm{white}}
\longrightarrow
\Phi_{\mathrm{white}}^{\mathrm{complete}}
\longrightarrow
\rho_{\mathrm{eff}}^{\mathrm{white}}.
\]

This is why the present public route is already more than:

- "one formula for a guard."

It is one bounded source-facing carrier chain.

## 7. Selected lines do not break the chain

One subtle but important point:

- the selected line `CALFMB` does not replace the chain above.

It sits *under* it as a derived operational line:

\[
\mathfrak W_{\mathrm{FMR}}
\longrightarrow
\text{selected line}
\]

with explicit root-mapping discipline and explicit refusal of root theft.

So the present route is not:

- one selected-line guess pretending to be the root.

It is:

- one bounded root-to-guard chain,
- with selected lines kept subordinate to that chain.

## 8. What this closes

This note closes the weaker deduction:

- "the packet has a white guard, but no visible source-to-guard route at all."

That reading is no longer fair.

The packet now visibly has:

- one action root,
- one canonical white-root class,
- one bounded admitted carrier family,
- one survival operator,
- one explicit bounded guard,
- one compact potential,
- one lifted conservative surface,
- and one effective-source representation.

## 9. What still remains later

This note does **not** yet prove:

- one final theorem of unique source-instantiation from the full parent-law
  stack,
- one theorem excluding every future lawful alternative family,
- or one final strong-form truth theorem for the whole chain.

Those remain the higher `T1` debt.

So the fair remaining deduction is now narrower:

- not "where is the source-to-guard route?"

but:

- "where is the final uniqueness/necessity theorem above the already-visible
  bounded instantiation chain?"

## Bottom line

The current white-law route is no longer best read as:

- one explicit guard with no visible source ancestry.

It is better read as:

- one bounded source-to-white-guard instantiation chain,
- already materialized enough to be reviewer-legible,
- while the final uniqueness theorem above that chain remains later.
