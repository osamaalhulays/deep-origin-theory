#!/usr/bin/env python3
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent
i0 = json.loads((ROOT/'I0_GLOBAL_BOUNDARY_POLICY.json').read_text())
receipt = json.loads((ROOT/'NO_RESULT_KNOWN_RECEIPT.json').read_text())
assert i0['I0_handling_mode'] == 'PREDECLARED_COSMOLOGY_ONLY_DOMAIN_WITH_ROBUST_ENVELOPE_ADJUDICATION'
assert i0['I0_is_rowwise'] is False
assert receipt['status'] == 'NO_GALAXY_RESULT_KNOWN'
print(json.dumps({'all_checks_pass': True, 'runtime_mode': 'standalone', 'I0_handling_mode': i0['I0_handling_mode']}, indent=2))
