# DO-K1 public preexecution lock runtime

Run `python3 verify_dok1_public_preexecution_lock_standalone.py`.
