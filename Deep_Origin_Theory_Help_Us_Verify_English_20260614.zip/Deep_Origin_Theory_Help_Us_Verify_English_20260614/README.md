# Help Us Verify This Work

This is a standalone companion package. It is intentionally separate from the
main packet so that outside readers can approach one bounded task directly.

This page is for independent checks, bounded technical readings, and
reproducibility reports.

We are not asking anyone to endorse the theory, agree with the conclusions,
or read the full archive. Each help track below has a narrow task and a clear
output.

## Quick Start

Choose one track:

| Track | Time | Who can do it? | Output |
|---|---:|---|---|
| H0. AI-assisted quick read | 2–5 min | Any non-technical volunteer with an AI model | screenshot + optional pasted reply |
| H1. Cold audit run | 10–20 min | Any careful user | terminal log + `all_checks_pass` value |
| H2. Technical replication | 30–90 min | Python/data/code user | reproduced outputs + hash/log report |
| H3. Bounded scientific read | 20–60 min | domain reader | `clear / partial / not clear` + 2 sentences |
| H4. Blind-holdout witness | 10 min now + 10 min later | independent timestamp witness | confirms locks existed before unblind |
| H5. arXiv category/endorsement advice | optional | qualified arXiv users only | private guidance, no pressure |
| H6. Error report | any | anyone | one issue with file, command, and observed problem |

## H0 — AI-Assisted Quick Read

If you are not technical and do not want to run code, use this path only:

1. Open `AI_USERS/START_HERE_AI_USERS.md`
2. Upload `AI_USERS/ATTACH_THIS_FILE_TO_YOUR_AI_MODEL__NO_EXTRA_COMMENT.txt`
3. Do not type any extra message to the model
4. Wait for the answer
5. Take one screenshot
6. Send the screenshot to the official project contact address

This path is useful as one quick outside read.

It is **not**:

- peer review,
- independent replication,
- or theory endorsement.

## H1 — Cold Audit Run

Goal: verify that the packet runs on an ordinary machine.

Run:

```bash
bash REVIEWER_AUDIT_BUNDLE_V1/RUN_AUDIT_ALL.sh
```

Please report:

```text
Packet filename:
Packet SHA256 if available:
OS:
Python version:
Command used:
Did it complete? yes/no
Final all_checks_pass value:
Attach terminal log or output folder:
```

This is a reproducibility/accessibility check, not a scientific endorsement.

## H2 — Technical Replication

Goal: independently verify that key outputs are regenerated, not merely
present.

Please check at least one of:

```text
NGC0247 current stack
NGC6946 fixed-QUMOND summary
NGC3992/LVHIS077/LVHIS072 triad court
G4 NGC4214 first non-toy run
Pavel PAYLOAD_B intake probe
Blind holdout protocol self-test
```

Return:

```text
clear / partially clear / not clear
which object you ran:
command:
output hash or JSON summary:
largest mismatch, if any:
```

## H3 — Bounded Scientific Read

Please choose only one question. We prefer a narrow answer over a broad
report.

Suggested questions:

1. Is the MOND/QUMOND comparison wording bounded and fair?
2. Is the same-nuisance rule clear enough before superiority language?
3. Is the clean-front triad claim reviewer-readable?
4. Is the G4 NGC4214 first non-toy crossing boundary honest?
5. Is the Pavel PAYLOAD_B intake separated from theory-side authoring?
6. Is the blind-holdout protocol a real pre-registration path?

Preferred answer:

```text
Question chosen:
Verdict: clear / partially clear / not clear
Strongest point:
Largest blocker:
One sentence I would change:
```

## H4 — Blind-Holdout Witness

Goal: confirm that targets, QCT predictions, and comparator protocol were
locked before unblinding.

You do not need to evaluate the theory. We may send you hashes or files such
as:

```text
TARGET_LOCK.json
PREDICTION_LOCK.json
COMPARATOR_PROTOCOL_LOCKED.json
```

Please keep or timestamp them, and later confirm that the unblinded result
used the same locked objects.

## H5 — arXiv Category / Endorsement Advice

This is not a public pressure request. If you are already qualified to advise
or endorse in the relevant arXiv category, and only if you independently feel
comfortable, we welcome private guidance on:

```text
best arXiv category
whether the submission is appropriate for that category
whether you would be comfortable endorsing through arXiv's own system
```

No one should endorse unless they are confident the work is suitable for arXiv
submission in the category. No quid pro quo, no public pressure, and no
endorsement is expected.

## H6 — Error Reports

Please report one concrete issue per issue/email:

```text
file:
command:
expected:
observed:
screenshot/log:
can you reproduce it? yes/no
```

## AI Use Disclosure

AI tools may help you summarize, inspect logs, or draft feedback. Please do
not use AI to invent run results.

If AI helped, please disclose:

```text
AI-assisted? yes/no
Used for: summary / log reading / code inspection / scientific reasoning / other
Human-checked? yes/no
```

AI-only endorsement is not useful. Logs, hashes, commands, and human judgment
are what count.
