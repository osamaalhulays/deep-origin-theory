## Help Us Verify This Packet

This text belongs to a standalone companion package, not to the main packet
body.

We welcome narrow independent checks. We are not asking for endorsement of the
theory.

**Easiest non-technical path:** open `AI_USERS/START_HERE_AI_USERS.md`, upload
`AI_USERS/ATTACH_THIS_FILE_TO_YOUR_AI_MODEL__NO_EXTRA_COMMENT.txt` to your AI
model with no extra comment, then send us one screenshot of the reply.

**Technical fast path:** run the reviewer audit and report whether it
completes:

```bash
bash REVIEWER_AUDIT_BUNDLE_V1/RUN_AUDIT_ALL.sh
```

Please include OS, Python version, terminal log, and the final
`all_checks_pass` value.

Other useful contributions:

1. **Cold audit replication** — run the packet on your machine.
2. **Technical replication** — reproduce one selected object such as NGC0247,
   the clean-front triad, G4 NGC4214, Pavel PAYLOAD_B, or the blind-holdout
   self-test.
3. **Bounded scientific read** — answer one specific question, e.g. whether
   the MOND/QUMOND claim is properly bounded under same-nuisance discipline.
4. **Blind-holdout witness** — receive target/prediction/protocol locks before
   unblinding and later confirm they were unchanged.
5. **arXiv category/endorsement advice** — private guidance only, no pressure,
   and only if you are independently comfortable under arXiv's own endorsement
   system.
6. **Error reports** — one concrete issue per report, with file, command,
   expected result, observed result, and log.

AI-assisted quick reads are welcome as one narrow outside-read lane.

AI-generated run results without logs/hashes are not useful.
