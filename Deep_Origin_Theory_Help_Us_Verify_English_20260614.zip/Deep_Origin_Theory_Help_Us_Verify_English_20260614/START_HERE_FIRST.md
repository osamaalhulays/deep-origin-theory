# Start Here First

This is a standalone companion package for narrow outside verification.

It is intentionally **not** embedded inside the main scientific packet.

Use this package if you want one of the following:

- one non-technical AI-assisted quick read,
- a cold audit run,
- a bounded technical rerun,
- a one-question scientific read,
- a blind-holdout witness role,
- arXiv advice,
- or one concrete error report.

## Fastest non-technical path

If you do **not** want to run code or read the archive, start here:

- `AI_USERS/START_HERE_AI_USERS.md`

## First step

Read:

- `README.md`

## Then choose one track

- `H0` AI-assisted quick read
- `H1` cold audit run
- `H2` technical replication
- `H3` bounded scientific read
- `H4` blind-holdout witness
- `H5` arXiv advice
- `H6` error report

## Important boundary

This package does **not** ask for endorsement of the theory.

It is a narrow verification companion only.
