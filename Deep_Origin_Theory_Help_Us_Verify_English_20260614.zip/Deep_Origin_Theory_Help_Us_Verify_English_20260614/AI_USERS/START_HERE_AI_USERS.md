# For AI Users

If you do not want to run code or read the archive, use this path only.

## What to do

1. Upload:
   `ATTACH_THIS_FILE_TO_YOUR_AI_MODEL__NO_EXTRA_COMMENT.txt`
2. Do **not** type any extra message.
3. Wait for the AI reply.
4. Take one screenshot of the reply.
5. Send the screenshot to:
   `Osamaalhulays@gmail.com`
6. Optional:
   paste the exact AI reply into the email body too.

If the placeholder above has not yet been replaced and you received this
package by email, replying to the same email thread is acceptable.

## What this is

This is one narrow AI-assisted outside read.

It is **not**:

- peer review,
- theory endorsement,
- or independent replication.

## Optional extra detail in the email

If easy, include:

- AI model used
- date
- whether the model could open the public links directly
