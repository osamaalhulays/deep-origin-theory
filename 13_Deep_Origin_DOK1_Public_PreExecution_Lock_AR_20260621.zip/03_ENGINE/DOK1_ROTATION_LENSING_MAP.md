# DO-K1 Rotation and Lensing Map

```text
V_c^2(R)=R partial_R psi(R,0)
Phi_lens=(psi+phi)/2=psi
```

Rotation and lensing are read from the same metric at the governing
local post-Newtonian order. No separate lensing rescue lane is admitted
in this lock.
