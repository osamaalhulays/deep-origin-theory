# DO-K1 AQUAL-Like Distinction

`DO-K1` is AQUAL-like because the local engine uses the locked
`mu_DO(x)`. It is not declared pure AQUAL-equivalent because the `K(Q)`
sector materializes a conditional Helmholtz/background coefficient
through `M_K^2(Qbar_0)`.
