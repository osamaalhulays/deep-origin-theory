# DO-K1 Exact Local PDE

Frozen local equation:

```text
div[mu_DO(|grad psi|/a_star) grad psi]
  + M_K^2(Qbar_0) psi
  = 4 pi G delta_rho_b + tidal_bg_below_governing_order
```

with:

```text
mu_DO(x)=x/(1+x^3)^(1/3)
M_K^2(Qbar_0)=a_star^2/[1-(Qbar_0-1)^2]^(3/2)
K_Q(Qbar_0)=I0/a_0^3
```
