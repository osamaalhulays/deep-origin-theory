# Comparator Protocol Prelock

Future lanes:

- DO-K1 frozen engine
- same-mu numerical AQUAL control
- fixed QUMOND
- strongest declared QUMOND/AQUAL EFE lanes

Symmetric nuisance treatment must be declared for distance,
inclination, stellar mass-to-light ratio, gas treatment, row roster,
and covariance policy before any comparison language.
