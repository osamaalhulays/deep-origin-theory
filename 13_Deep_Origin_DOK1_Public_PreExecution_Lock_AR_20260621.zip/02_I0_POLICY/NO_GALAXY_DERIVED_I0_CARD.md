# No Galaxy-Derived I0 Card

`I0` is global. It is not rowwise, not galaxy-specific, and not selected
from rotation-curve residuals, sign topology, SPARC rows, NGC0247 rows,
QUMOND residuals, or AQUAL residuals.

Post-unblind retuning of `I0` is forbidden. If a future result depends
on choosing `I0` after seeing galaxy data, the lawful verdict is protocol
failure / no verdict.
