#!/usr/bin/env python3
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT/'01_MANIFEST'/'DOK1_PUBLIC_PREEXECUTION_LOCK_MANIFEST.json').read_text())
i0 = json.loads((ROOT/'02_I0_POLICY'/'I0_GLOBAL_BOUNDARY_POLICY.json').read_text())
domain = json.loads((ROOT/'02_I0_POLICY'/'I0_VALUE_OR_DOMAIN_LOCK.json').read_text())
receipt = json.loads((ROOT/'05_NO_RESULT'/'NO_RESULT_KNOWN_RECEIPT.json').read_text())
assert manifest['primary_verdict'] == 'DOK1_PUBLIC_PREEXECUTION_LOCK_READY__I0_POLICY_FROZEN__NO_GALAXY_RESULT_KNOWN'
assert manifest['online_publication_status'] == 'PREPARED_FOR_MANUAL_PUBLICATION__NOT_PUBLISHED_BY_BUILDER'
assert i0['I0_is_global'] is True
assert i0['I0_is_rowwise'] is False
assert i0['I0_is_galaxy_specific'] is False
assert i0['galaxy_data_used_to_select_I0'] is False
assert i0['I0_handling_mode'] == 'PREDECLARED_COSMOLOGY_ONLY_DOMAIN_WITH_ROBUST_ENVELOPE_ADJUDICATION'
assert i0['I0_value_or_domain_frozen_before_execution'] is True
assert i0['post_unblind_I0_retuning_forbidden'] is True
assert domain['mode'] == 'PREDECLARED_COSMOLOGY_ONLY_DOMAIN_WITH_ROBUST_ENVELOPE_ADJUDICATION'
assert receipt['status'] == 'NO_GALAXY_RESULT_KNOWN'
assert receipt['NGC0247_executed'] is False
print(json.dumps({'all_checks_pass': True, 'primary_verdict': manifest['primary_verdict'], 'I0_handling_mode': i0['I0_handling_mode'], 'stop_line': 'READY_FOR_MANUAL_PUBLICATION_BEFORE_NGC0247_EXECUTION'}, indent=2))
