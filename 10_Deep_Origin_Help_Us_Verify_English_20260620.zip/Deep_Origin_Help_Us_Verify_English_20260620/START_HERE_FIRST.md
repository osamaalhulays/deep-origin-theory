# Start Here First

Date: `2026-06-20`

This is a standalone companion package for narrow outside verification of the
current public Deep Origin Theory release.

It is intentionally separate from:

- the main English scientific packet,
- the Arabic public-state access packet,
- the J2C pre-execution capsule,
- and the reviewer runtime package.

It exists so that a volunteer can choose one small task without entering the
full archive.

## Current Public Release

Zenodo record:

```text
https://zenodo.org/records/20776639
```

Specific DOI:

```text
10.5281/zenodo.20776639
```

Stable concept DOI:

```text
10.5281/zenodo.20542921
```

GitHub mirror:

```text
https://github.com/osamaalhulays/deep-origin-theory
```

## Fastest Non-Technical Path

If you do not want to run code or read the archive, start here:

- `AI_USERS/START_HERE_AI_USERS.md`

## First Step

Read:

- `README.md`

## Then Choose One Track

- `H0` AI-assisted quick read
- `H1` cold audit run
- `H2` technical replication
- `H3` bounded scientific read
- `H4` pre-execution lock witness
- `H5` arXiv/category advice
- `H6` error report

## Explicit Boundary

This package does **not** ask for endorsement of the theory.

It is a narrow verification companion only.
