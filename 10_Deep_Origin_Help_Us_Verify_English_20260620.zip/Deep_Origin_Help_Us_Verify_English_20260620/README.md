# Help Us Verify This Work

Date: `2026-06-20`

This is a standalone companion package for the current public release:

```text
Deep Origin Theory — Updated Scientific Snapshot and J2C Structural Action-Class Public Pre-Execution Lock
```

Current Zenodo record:

```text
https://zenodo.org/records/20776639
```

GitHub mirror:

```text
https://github.com/osamaalhulays/deep-origin-theory
```

This package is intentionally separate from the main scientific packets and
from the reproducibility runtime. The runtime package is for code execution.
This companion package is for outside help, quick checks, bounded reading, and
structured reports.

We are not asking anyone to endorse the theory, agree with the conclusions, or
read the full archive. Each help track below has a narrow task and a clear
output.

## Quick Start

Choose one track:

| Track | Time | Who can do it? | Output |
|---|---:|---|---|
| H0. AI-assisted quick read | 2-5 min | Any non-technical volunteer with an AI model | screenshot + optional pasted reply |
| H1. Cold audit run | 10-20 min | Any careful user | terminal log + `all_checks_pass` value |
| H2. Technical replication | 30-90 min | Python/data/code user | reproduced outputs + hash/log report |
| H3. Bounded scientific read | 20-60 min | domain reader | `clear / partial / not clear` + 2 sentences |
| H4. Pre-execution lock witness | 10 min now + 10 min later | independent timestamp witness | confirms locks existed before result |
| H5. arXiv/category advice | optional | qualified arXiv users only | private guidance, no pressure |
| H6. Error report | any | anyone | one issue with file, command, and observed problem |

## H0 — AI-Assisted Quick Read

If you are not technical and do not want to run code, use this path only:

1. Open `AI_USERS/START_HERE_AI_USERS.md`
2. Upload `AI_USERS/ATTACH_THIS_FILE_TO_YOUR_AI_MODEL__NO_EXTRA_COMMENT.txt`
3. Do not type any extra message to the model
4. Wait for the answer
5. Take one screenshot
6. Send the screenshot to the official project email:

```text
Osamaalhulays@gmail.com
```

This path is useful as one quick outside read. It is not peer review, theory
endorsement, or independent replication.

## H1 — Cold Audit Run

Use the sibling runtime package from the same public release:

```text
04_Deep_Origin_J2C_Reproducibility_Runtime_V1.zip
```

Then follow its `README.md`.

Expected bounded result: the runtime reports completed checks and exposes the
`all_checks_pass` value.

## H2 — Technical Replication

Use the English packet plus the runtime package. Send:

- exact command used
- operating system
- output directory name
- `all_checks_pass` value
- any mismatch or failure

## H3 — Bounded Scientific Read

Pick one narrow surface from the public release. A useful first target is the
J2C pre-execution capsule:

```text
03_Deep_Origin_J2C_Public_PreExecution_Capsule_V1.zip
```

Send:

```text
clear / partial / not clear
```

and two sentences explaining why.

## H4 — Pre-Execution Lock Witness

The J2C capsule is a public pre-execution lock. A witness can simply confirm:

- the lock exists at the Zenodo record above
- it says no J2C result is known
- it states the allowed verdicts before execution

No endorsement is requested.

## H5 — arXiv/category Advice

Only use this track if you are already familiar with arXiv category norms or
endorsement practice. Private guidance is enough.

## H6 — Error Report

Send one concrete issue:

- file name
- command or reading path
- what you expected
- what happened
- screenshot or log if available

## Contact

```text
Osamaalhulays@gmail.com
```
