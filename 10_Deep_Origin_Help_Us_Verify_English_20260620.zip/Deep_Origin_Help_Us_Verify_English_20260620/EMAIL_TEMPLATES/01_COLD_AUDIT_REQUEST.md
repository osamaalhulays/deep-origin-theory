Subject: 10-minute cold-run check request

Dear [Name],

I am not asking you to evaluate the theory.

I only need an independent cold-run check. If you are willing, please unzip
the packet and run:

```bash
bash REVIEWER_AUDIT_BUNDLE_V1/RUN_AUDIT_ALL.sh
```

Then send me:

- whether it completed,
- the final `all_checks_pass` value,
- your OS and Python version,
- the terminal log or output folder.

This is a reproducibility/accessibility check, not an endorsement.

Thank you,
Osama

