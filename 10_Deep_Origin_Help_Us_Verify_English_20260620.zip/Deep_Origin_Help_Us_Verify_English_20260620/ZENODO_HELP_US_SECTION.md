# Help Us Verify Companion

This companion package restores the public Help Us Verify lane as a sibling
file of the 2026-06-20 release.

It is separate from the reviewer runtime package. The runtime is for code and
audit execution. This package is for narrow outside help:

- AI-assisted quick read
- cold audit report
- technical replication note
- bounded scientific read
- pre-execution lock witness
- arXiv/category advice
- concrete error report

It does not request endorsement of the theory.

Current public release:

```text
https://zenodo.org/records/20776639
```
