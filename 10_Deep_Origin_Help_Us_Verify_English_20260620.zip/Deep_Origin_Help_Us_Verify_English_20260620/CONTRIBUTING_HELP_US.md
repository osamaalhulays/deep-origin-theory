# Contributing: Independent Checks Only

Please keep contributions narrow and auditable.

Good contributions:

- cold-run logs,
- output hashes,
- one-question bounded reviews,
- typo/bug reports,
- blind-holdout lock witnessing.

Not useful:

- broad claims of endorsement,
- AI-generated summaries without logs,
- untraceable statements like “looks good,”
- changing scientific wording without specifying the exact file and reason.

Use `README.md` to choose one track.
