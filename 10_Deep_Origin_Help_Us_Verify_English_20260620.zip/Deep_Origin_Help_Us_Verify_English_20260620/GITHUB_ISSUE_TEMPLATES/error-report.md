---
name: Error report
about: Report one concrete issue
labels: bug
---

## File / object

## Command used

```bash

```

## Expected

## Observed

## Log / screenshot

## Reproducible?

- [ ] yes
- [ ] no
- [ ] not sure

