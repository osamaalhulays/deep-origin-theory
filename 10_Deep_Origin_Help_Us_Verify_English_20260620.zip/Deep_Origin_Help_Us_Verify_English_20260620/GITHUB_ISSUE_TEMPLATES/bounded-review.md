---
name: Bounded scientific read
about: Answer one specific review question
labels: bounded-review
---

## Question chosen

<!-- Paste the exact question here. -->

## Verdict

- [ ] clear
- [ ] partially clear
- [ ] not clear

## Strongest point

## Largest blocker

## One sentence I would change

