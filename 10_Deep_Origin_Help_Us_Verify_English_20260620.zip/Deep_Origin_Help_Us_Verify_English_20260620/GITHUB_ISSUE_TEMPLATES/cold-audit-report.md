---
name: Cold audit report
about: Report a run of REVIEWER_AUDIT_BUNDLE_V1/RUN_AUDIT_ALL.sh
labels: cold-audit, reproducibility
---

## Packet

- Packet filename:
- Packet SHA256, if known:

## Environment

- OS:
- Python version:
- Shell:

## Command

```bash
bash REVIEWER_AUDIT_BUNDLE_V1/RUN_AUDIT_ALL.sh
```

## Result

- Completed? yes/no
- Final `all_checks_pass`:
- Runtime:

## Attachments

Please attach terminal log or output folder if possible.

