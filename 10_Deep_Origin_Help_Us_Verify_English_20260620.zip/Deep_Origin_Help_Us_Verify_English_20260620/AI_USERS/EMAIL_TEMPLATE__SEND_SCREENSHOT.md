# Email Template

To:

```text
Osamaalhulays@gmail.com
```

Subject:

```text
AI-assisted quick read screenshot for Deep Origin release 20776639
```

Body:

```text
Hello Osama,

I ran the AI-assisted quick-read prompt from the Help Us Verify package for:

https://zenodo.org/records/20776639

AI model used:
[model name]

Date:
[date]

I attached a screenshot of the model reply. I also pasted the text below if useful.

[paste reply here, optional]
```
