# For AI Users

Use this path if you do not want to run code or read the full archive.

## What To Do

1. Upload this file to your AI model:

```text
ATTACH_THIS_FILE_TO_YOUR_AI_MODEL__NO_EXTRA_COMMENT.txt
```

2. Do **not** type any extra message.
3. Wait for the AI reply.
4. Take one screenshot of the reply.
5. Send the screenshot to:

```text
Osamaalhulays@gmail.com
```

6. Optional: paste the exact AI reply into the email body too.

## What This Is

This is one narrow AI-assisted outside read of the current public release:

```text
https://zenodo.org/records/20776639
```

It is **not**:

- peer review,
- theory endorsement,
- or independent replication.

## Optional Email Details

If easy, include:

- AI model used
- date
- whether the model could open the public links directly
